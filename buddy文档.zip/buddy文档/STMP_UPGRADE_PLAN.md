# STMP 记忆检索升级计划

> 目标：修复 STMP 中文检索能力，接入 ByteEncoder 语义向量搜索，提升 LLM 记忆供给质量。

## 背景

STMP 是整个 Buddy 系统的记忆中枢（8 个子系统的共享基础设施）。当前检索依赖 FTS5，但 FTS5 使用默认 `unicode61` tokenizer，中文搜索基本无效。项目已有 ByteEncoder（字节级文本编码器，128 维向量，~145K 参数，CPU <3ms），但未接入 STMP。

## 三阶段计划

### Phase 1: ByteEncoder 接入 STMP（核心） 🔴 P0 ✅ 已完成

**目标**：STMP 写入时生成向量，查询时支持语义搜索。

#### 1.1 Schema 迁移 ✅
- `stmp_nodes` 表新增 `embedding BLOB` 列
- Migration: version 2

#### 1.2 STMPStore 改造 ✅
- 构造函数注入 ByteEncoder 实例（STMPStoreConfig）
- `insertNode()` 时调用 `byteEncoder.forward(content)` 存入 BLOB
- 新增 `vectorSearch(queryVec, limit)` 方法：全量余弦扫描
- 新增 `searchNodesHybrid(query, limit)` 方法：FTS5 + 向量合并重排
- `retrieve()` 改用 `searchNodesHybrid` 替代纯 FTS5

#### 1.3 检索合并策略 ✅
```
score = α * fts5_score + (1-α) * cosine_similarity
默认 α = 0.4（语义权重更高）
```

#### 1.4 测试 ✅
- 向量写入/读取测试
- 语义搜索 vs FTS5 对比测试
- 中文查询验证
- 56 个测试全部通过

### Phase 2: FTS5 分词升级（精确搜索） 🟡 P1

**目标**：三个 FTS5 表的中文精确搜索能力提升。

#### 2.1 共享分词函数
- 基于 `Intl.Segmenter` 实现 `tokenizeForFTS(text): string`
- 降级策略：不支持时用 2-gram

#### 2.2 三表预分词
- `stmp_nodes_fts` — insertNode 时预分词
- `local_chunks_fts` — 索引文件时预分词
- `project_search_fts` — indexForSearch 时预分词

#### 2.3 搜索时同步分词
- 查询文本同样过一遍分词，保持一致

### Phase 3: 优化与收尾 🟢 P2

#### 3.1 向量缓存
- 热门查询的向量缓存（LRU）
- 避免重复编码

#### 3.2 DreamEngine 集成
- 梦境巩固时利用向量相似度发现隐藏关联
- 替代当前的随机漫步

#### 3.3 性能基准
- 建立检索质量评估指标
- 中文/英文/混合查询的命中率对比

## 文件变更清单

| 文件 | Phase | 变更 |
|------|-------|------|
| `src/memory/stmp.ts` | 1 | Schema 迁移 + ByteEncoder 注入 + 向量搜索 + 混合检索 |
| `src/memory/stmp.test.ts` | 1 | 新增向量搜索测试 |
| `src/core/subsystems.ts` | 1 | 初始化时注入 ByteEncoder 到 STMPStore |
| `src/knowledge/local-source.ts` | 2 | 预分词 |
| `src/project/store.ts` | 2 | 预分词 |
| `src/tools/tool-retriever.ts` | 2 | 复用分词函数（已有 Intl.Segmenter） |

## 风险

- ByteEncoder 预训练权重不存在时使用随机初始化，向量质量差 → 降级为纯 FTS5
- 全量余弦扫描在 >10 万节点时可能慢 → 当前规模不需要向量索引
- Migration 需要处理已有数据（backfill embedding）→ 首次启动时后台批量编码
