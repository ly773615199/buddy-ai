# 资源感知决策修复计划

> 三脑架构的核心问题：决策系统对资源约束的感知是割裂的。
> BlendBrain 采样时不知道哪些资源可用，cascade 执行时才遇到不可用组件导致超时失败。

## 问题复现

输入：`"我是你主人，今天广州天气怎么样？"`

```
[CapabilityFallback] tryRoute: matched → skill_weather (score=0.803)
[Scheduler] metacognitive_override: cloud_llm 不可用，降级本地
[Arbiter] 裁决: rule (score=0.440)
[Brain] 反思: 任务 reasoning 执行失败 (未知原因)
```

语义识别正确（skill_weather 0.803），工具已注册，参数已提取（city=广州）。
但 cascade 策略仍尝试 cloudLLM 组件 → 超时失败 → 降级输出"本地模式"废话。

## 根因分析

### 决策链中的资源盲区

```
BlendBrain.sample(features)          ← 不知道 cloud_llm 是否可用
    ↓
mapToResources(strategy, eligible)   ← 事后过滤，但策略向量已偏向 cloud_llm
    ↓
resourceWeightsToComponentWeights    ← 回退路径用 strategyVector，cloudLLM 维度非零
    ↓
executeBlendStrategy                 ← cascade 跑到 cloudLLM → 15s 超时 → 失败
```

### 4 个具体缺陷

| # | 位置 | 问题 | 影响 |
|---|------|------|------|
| 1 | `blend-brain.ts` `sample()` | 采样时不感知资源可用性 | 策略向量偏向不存在的资源 |
| 2 | `brain.ts` `resourceWeightsToComponentWeights` | 回退路径用 strategyVector 分配权重，不检查组件可用性 | 不可用组件获得非零权重 |
| 3 | `brain.ts` `executeBlendStrategy` | cascade 不跳过不可用组件 | 15s 超时浪费，延迟增加 |
| 4 | `resource.ts` `DEFAULT_TASK_AFFINITY` | cloud_llm 的 reasoning 亲和度硬编码为 0.8 | 冷启动幻觉：系统以为 cloud_llm 是最优选择 |

### 架构原则违背

当前设计：**资源可用性是执行层的事，决策层不关心。**
正确设计：**决策层必须在第一时间知道"我有什么、擅长什么"，才能做出合理决策。**

## 修复方案

### 改动 1：ResourceHub 增加资源能力快照

**文件**: `src/brain/hub/resource-hub.ts`

新增 `getCapabilitySnapshot()` 方法，返回当前可用资源的能力摘要：

```typescript
interface CapabilitySnapshot {
  /** 各类型资源是否可用 */
  available: Record<string, boolean>;
  /** 各类型资源的平均质量 */
  quality: Record<string, number>;
  /** 各类型资源的擅长任务 */
  strengths: Record<string, string[]>;
  /** 最强的本地资源（用于降级时选择） */
  bestLocal: { id: string; type: string; quality: number } | null;
}
```

供 BlendBrain、Scheduler、executeBlendStrategy 共用，避免各自重复计算。

### 改动 2：buildFeatureVector 注入资源可用性信号

**文件**: `src/brain/hub/feature-extractor.ts`

在 feature 向量的预留区（[140, 148)）注入显式资源可用性信号：

```typescript
// [140, 148): 资源可用性信号 — 新增
const snapshot = ctx.hub.getCapabilitySnapshot();
vec[140] = snapshot.available['cloud_llm'] ? 1 : 0;  // cloud_llm 是否可用
vec[141] = snapshot.available['engine'] ? 1 : 0;      // 组装引擎是否可用
vec[142] = snapshot.available['tool'] ? 1 : 0;        // 工具是否可用
vec[143] = snapshot.available['knowledge'] ? 1 : 0;   // 知识源是否可用
vec[144] = snapshot.quality['cloud_llm'] ?? 0;        // cloud_llm 质量
vec[145] = snapshot.quality['engine'] ?? 0;           // 组装引擎质量
vec[146] = snapshot.bestLocal?.quality ?? 0;          // 最强本地资源质量
vec[147] = ctx.signal.taskType === 'reasoning' ? 1 : 0; // 是否推理任务
```

BlendBrain 的神经网络通过训练学会：当 vec[140]=0 时，降低策略向量中 cloud_llm 维度的激活。

### 改动 3：resourceWeightsToComponentWeights 资源感知回退

**文件**: `src/brain/brain.ts` `resourceWeightsToComponentWeights()`

当前回退路径：
```typescript
if (resourceWeights.size === 0) {
  for (let i = 0; i < 5; i++) {
    comp[i] = 0.8 * (strategyVector[i] ?? 0) + 0.2 * interpWeights[i];
  }
}
```

修复后：
```typescript
if (resourceWeights.size === 0) {
  const snapshot = this.resourceHub?.getCapabilitySnapshot();
  for (let i = 0; i < 5; i++) {
    comp[i] = 0.8 * (strategyVector[i] ?? 0) + 0.2 * interpWeights[i];
  }
  // cloud_llm 不可用 → 对应组件权重归零
  if (snapshot && !snapshot.available['cloud_llm']) {
    comp[4] = 0;
  }
  // 归一化
  const sum = comp.reduce((s, v) => s + v, 0);
  if (sum > 0) for (let i = 0; i < 5; i++) comp[i] /= sum;
}
```

### 改动 4：executeBlendStrategy cascade 预检

**文件**: `src/brain/brain.ts` `executeBlendStrategy()`

cascade 排序前，过滤依赖不可用资源的组件：

```typescript
// 在构建 componentDefs 后、执行前
const snapshot = this.resourceHub?.getCapabilitySnapshot();
if (snapshot) {
  componentDefs = componentDefs.filter(comp => {
    // cloudLLM 组件在 cloud_llm 不可用时跳过
    if (comp.name === 'cloudLLM' && !snapshot.available['cloud_llm']) {
      return false;
    }
    return true;
  });
}
```

有 toolProposal 时，assembly 组件优先级提升（不依赖 LLM，直接格式化）：

```typescript
if (toolProposal) {
  // 有工具结果 → assembly 组件权重提升，确保优先执行
  const asmIdx = componentDefs.findIndex(c => c.name === 'assembly');
  if (asmIdx >= 0) {
    componentDefs[asmIdx].weight = Math.max(componentDefs[asmIdx].weight, 0.6);
  }
}
```

### 改动 5：DEFAULT_TASK_AFFINITY 动态化

**文件**: `src/brain/hub/resource.ts` + `src/brain/hub/resource-hub.ts`

ResourceHub 初始化时，根据实际注册的资源类型调整默认亲和度：

```typescript
// resource-hub.ts: 在 scanAndLoad 完成后调用
adjustDefaultAffinities(): void {
  const hasCloudLLM = [...this.resources.values()].some(r => r.type === 'cloud_llm');
  if (!hasCloudLLM) {
    // 无 cloud_llm → 提升 engine 的 reasoning 亲和度
    DEFAULT_TASK_AFFINITY.engine.reasoning = 0.6;  // 原 0.4
    DEFAULT_TASK_AFFINITY.tool.reasoning = 0.3;    // 原 0.1
    DEFAULT_TASK_AFFINITY.skill.reasoning = 0.4;   // 原 0.2
  }
}
```

### 改动 6：cascade 执行增加组件可用性日志

**文件**: `src/brain/brain.ts`

在 cascade 执行时记录每个组件的可用性和执行结果，便于调试：

```typescript
if (this.verbose) {
  console.log(`[Brain] cascade 组件: ${componentDefs.map(c =>
    `${c.name}(w=${c.weight.toFixed(2)})`).join(', ')}`);
}
```

## 改动文件清单

| 文件 | 改动类型 | 风险 |
|------|----------|------|
| `src/brain/hub/resource-hub.ts` | 新增方法 | 低 — 纯新增，不影响现有逻辑 |
| `src/brain/hub/resource.ts` | 新增接口 + 修改默认值 | 低 — 默认值只在无 cloud_llm 时调整 |
| `src/brain/hub/feature-extractor.ts` | 扩展特征向量 | 低 — 使用预留区，不影响现有维度 |
| `src/brain/brain.ts` | 修改回退逻辑 + cascade 过滤 | 中 — 核心决策路径，需充分测试 |
| `src/brain/hub/blend-brain.ts` | 无改动 | — 特征向量扩展自动影响采样 |

## 验证方案

### 测试 1：天气查询（核心场景）

输入：`"今天广州天气怎么样？"`
预期：直接返回广州天气数据，不出现"本地模式"提示
验证：`skill_weather` 通过 assembly 组件直出

### 测试 2：无 LLM 时的 cascade 行为

输入：任意查询
预期：cascade 组件列表不包含 cloudLLM
验证：日志中无 cloudLLM 组件的超时记录

### 测试 3：有 LLM 时的行为不受影响

配置 LLM 后输入：`"帮我写一个排序算法"`
预期：cloudLLM 组件正常参与 cascade
验证：行为与修复前一致

### 测试 4：城市别名（附带修复）

输入：`"羊城今天天气怎么样？"`
预期：正确识别"羊城"→"广州"，返回天气数据

## 不在本次范围

- BlendBrain 神经网络重新训练（需要大量样本，后续迭代）
- 完整的资源画像自学习（已有基础，持续优化）
- 多工具 DAG 协作的资源分配优化（独立问题）
