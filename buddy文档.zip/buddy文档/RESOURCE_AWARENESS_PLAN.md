# 资源感知中间件执行计划

> **状态**: 待执行 | **优先级**: P0 | **预计工期**: 1-2 天
> **创建时间**: 2026-05-29 | **作者**: AI 分析

---

## 一、问题定义

### 1.1 现象

CLI 的 56 个斜杠命令在 `main.ts` 中硬编码为 if-else 分支，直接调用 `agent.getXxx()` 方法，完全绕过三脑架构（LawClassifier + RuleEngine + DispatchCoordinator）。

### 1.2 深层问题

**不是法则引擎的感知缺失，是整条执行链路的资源感知都缺失。**

三脑决策层做了完整的五维资源评估（budget / tool / latency / load / model），但这些信息在 `OrchestrationPlan` 返回后就**全部丢失**。执行层的三个组件全部在「盲执行」：

| 组件 | 职责 | 资源感知 |
|---|---|---|
| `plan-executor.ts` | 执行 OrchestrationPlan | ❌ `budgetRemaining: 0` 写死 |
| `ToolExecutionMiddleware` | 工具执行中间件 | ❌ 只管权限+校验+超时 |
| `ExecutionSession` | 执行会话生命周期 | ❌ 只管风险+确认 |

### 1.3 影响

| 场景 | 决策层知道 | 执行层知道 | 后果 |
|---|---|---|---|
| budget 耗尽 | ✅ | ❌ | 继续执行，超支无感知 |
| 系统高负载 | ✅ load > 80 | ❌ | 照常并发，不排队 |
| 能量低 | ✅ energy < 30 | ❌ | 照常全量输出，不简化 |
| 工具不健康 | ✅ toolHealth < 30 | ❌ | 照常调用，失败才报错 |
| 经验缓存命中 | ✅ experienceHit | ❌ | 每次重新执行 |

---

## 二、架构现状

### 2.1 资源流经全景图

```
用户输入 (CLI / WS)
       │
       ▼
┌──────────────────────────────────────────────────────┐
│  signal-collector.ts: collectResourceState()         │
│  ★ 资源信息最完整                                     │
│  budgetRemaining ← recorder.getByTimeRange() 实时    │
│  toolHealth      ← skillManager.growth.getAllHealth() │
│  experienceHit   ← intelligence.router.route()       │
│  ... 8 个维度                                         │
└──────────────────────┬───────────────────────────────┘
                       │
                       ▼
┌──────────────────────────────────────────────────────┐
│  三脑决策层 (ThreeBrain.decide)                       │
│  ★ 决策层完整使用资源信息                              │
│  ┌────────────────────────────────────────────────┐  │
│  │ 小脑: BodyState (load/energy/confusion)        │  │
│  │ 右脑: IntuitionSignal                          │  │
│  │ 左脑: LawClassifier + RuleEngine + Scheduler   │  │
│  │ 协调器: FeasibilityChecker + Coordinator       │  │
│  └────────────────────────────────────────────────┘  │
│  输出: OrchestrationPlan                             │
└──────────────────────┬───────────────────────────────┘
                       │
                       │ ★★★ 资源信息在此丢失 ★★★
                       ▼
┌──────────────────────────────────────────────────────┐
│  agent.ts: executeByPlan(plan)                       │
│  getExecContext() 返回:                              │
│    { sys, processor, ws, config, verbose, pooled }   │
│  ❌ 没有 ResourceState                               │
│  ❌ 没有 BodyState                                   │
└──────────────────────┬───────────────────────────────┘
                       │
                       ▼
┌──────────────────────────────────────────────────────┐
│  plan-executor.ts                                    │
│  budgetRemaining: 0  ← ❌ 写死                       │
│  retrieval.quality: 0.7 ← ❌ 写死                    │
│  execution.quality: 0.8 ← ❌ 写死                    │
│  ❌ 不检查 budget/toolHealth/load 就执行              │
└──────────────────────┬───────────────────────────────┘
                       │
                       ▼
┌──────────────────────────────────────────────────────┐
│  ToolExecutionMiddleware                             │
│  ✅ 权限检查 / 工具查找 / 参数校验 / 超时截断          │
│  ❌ 不检查工具健康度 / 预算 / 系统负载                 │
└──────────────────────┬───────────────────────────────┘
                       │
                       ▼
┌──────────────────────────────────────────────────────┐
│  ExecutionSession                                    │
│  ✅ autonomyLevel (风险等级) / checkpoint             │
│  ❌ 不考虑资源约束                                    │
└──────────────────────────────────────────────────────┘
```

### 2.2 已有中间件对比

**ToolExecutionMiddleware** (`src/tools/execution-middleware.ts`):

```typescript
async execute(ctx) {
  1. 权限检查 (beforeExecute)     ✅ 安全
  2. 工具查找                     ✅ 存在性
  3. 参数校验 (safeParse)         ✅ 正确性
  4. 超时执行 + 结果截断           ✅ 稳定性
  // 缺失: 资源检查 ❌
}
```

**ExecutionSession** (`src/core/execution-session.ts`):

```typescript
shouldPauseForConfirmation(tool, args) {
  1. 自主等级 (autonomyLevel)     ✅ 风险控制
  2. 检查点 (checkpoint)          ✅ 生命周期
  // 缺失: 资源约束 ❌
}
```

### 2.3 ResourceState 已有字段

```typescript
// src/brain/types.ts 第288行
export interface ResourceState {
  budgetRemaining: number;       // 剩余预算
  availableNodeCount: number;    // 可用模型节点数
  localCoverageRatio: number;    // 本地覆盖率
  localConfidence: number;       // 本地置信度
  userCorrectionCount: number;   // 用户纠正次数
  experienceHit: unknown | null; // 经验命中
  toolHealth?: ToolHealthSummary; // 工具健康度
  hasExternalLLM?: boolean;      // 是否有外部 LLM
}
```

### 2.4 BodyState 已有字段

```typescript
// src/brain/types.ts 第170行
export interface BodyState {
  energy: number;     // 0-100 精力
  load: number;       // 0-100 系统负载
  confusionLevel: number;
  hunger: number;     // 交互饥渴度
  // ...
}
```

---

## 三、执行计划

### Phase 1: 传导 — 资源信息从决策层接到执行层

**目标**: 让执行层能看到资源状态，零行为变更。

#### 改动 1.1: ExecutionContext 增加资源字段

**文件**: `src/core/plan-executor.ts` 第63行

```typescript
export interface ExecutionContext {
  sys: Subsystems;
  processor: MessageProcessor;
  ws: WSHandler;
  config: BuddyConfig;
  verbose: boolean;
  // 新增 ↓
  resources?: ResourceState;
  bodyState?: BodyState;
  signal?: TaskSignal;
  // 已有
  scheduler?: CapabilityScheduler;
  llmProfiler?: LLMProfiler;
  generationCache?: GenerationCache;
  multiPathExecutor?: MultiPathExecutor;
  pooled?: Float32Array;
}
```

#### 改动 1.2: agent.ts 传入资源

**文件**: `src/core/agent.ts` getExecContext() 方法

```typescript
private getExecContext(): ExecutionContext {
  return {
    sys: this.sys,
    processor: this.processor,
    ws: this.ws,
    config: this.config,
    verbose: this.verbose,
    pooled: this.lastPooled ?? undefined,
    resources: this.lastResources ?? undefined,        // 新增
    bodyState: this.sys.cerebellum?.getBodyState(),    // 新增
  };
}
```

#### 改动 1.3: plan-executor 使用真实资源

**文件**: `src/core/plan-executor.ts` 第378行

```typescript
// 改前:
budgetRemaining: 0,

// 改后:
budgetRemaining: ctx.resources?.budgetRemaining ?? 0,
```

**工作量**: ~30 行，3 个文件
**风险**: 零（只加字段，不改逻辑）

---

### Phase 2: 拦截 — ToolExecutionMiddleware 增加资源检查

**目标**: 工具执行前检查资源约束，资源不足时拦截或降级。

#### 改动 2.1: ToolExecutionContext 增加资源字段

**文件**: `src/tools/execution-middleware.ts`

```typescript
export interface ToolExecutionContext {
  toolName: string;
  args: Record<string, unknown>;
  source: 'llm' | 'dag' | 'chain' | 'experience';
  timeoutMs?: number;
  // 新增 ↓
  resourceState?: ResourceState;
  bodyState?: BodyState;
}
```

#### 改动 2.2: execute() 增加资源检查步骤

**文件**: `src/tools/execution-middleware.ts`

```typescript
async execute(ctx: ToolExecutionContext): Promise<ToolExecutionResult> {
  const startMs = Date.now();

  // 1. 权限检查 (已有)
  // 2. 工具查找 (已有)
  // 3. 参数校验 (已有)

  // 4. 资源检查 (新增)
  const resourceGate = this.checkResources(ctx);
  if (resourceGate.blocked) {
    return {
      success: false,
      result: `[资源拦截: ${resourceGate.reason}]`,
      durationMs: Date.now() - startMs,
      error: 'resource_blocked',
    };
  }

  // 5. 超时执行 (已有)
}

private checkResources(ctx: ToolExecutionContext): {
  blocked: boolean;
  reason?: string;
} {
  const { resourceState, bodyState, toolName } = ctx;

  // 预算耗尽 → 只允许零成本工具
  if (resourceState && resourceState.budgetRemaining <= 0) {
    const zeroCostTools = new Set([
      'read_file', 'list_files', 'search_files', 'exec',
    ]);
    if (!zeroCostTools.has(toolName)) {
      return {
        blocked: true,
        reason: '预算耗尽，仅允许本地工具',
      };
    }
  }

  // 工具不健康 → 拦截
  if (resourceState?.toolHealth) {
    const health = resourceState.toolHealth.scores[toolName];
    if (health !== undefined && health < 20) {
      return {
        blocked: true,
        reason: `工具 ${toolName} 健康度过低 (${health}/100)`,
      };
    }
  }

  // 系统高负载 → 阻止 heavy 工具
  if (bodyState && bodyState.load > 85) {
    const heavyTools = new Set(['docker_build', 'npm_install', 'cargo']);
    if (heavyTools.has(toolName)) {
      return {
        blocked: true,
        reason: `系统负载过高 (${bodyState.load}/100)`,
      };
    }
  }

  return { blocked: false };
}
```

**工作量**: ~50 行，1 个文件
**风险**: 零（只加拦截，不改已有逻辑）

---

### Phase 3: 自适应 — ExecutionSession 增加资源感知

**目标**: 执行会话根据资源状态调整确认策略。

#### 改动 3.1: ExecutionSession 增加资源字段

**文件**: `src/core/execution-session.ts`

```typescript
export interface ExecutionSessionConfig {
  id: string;
  goal: string;
  autonomyLevel: AutonomyLevel;
  maxRetries: number;
  maxSteps: number;
  checkpointInterval: number;
  // 新增 ↓
  resources?: ResourceState;
  bodyState?: BodyState;
}
```

#### 改动 3.2: shouldPauseForConfirmation 增加资源判断

**文件**: `src/core/execution-session.ts`

```typescript
shouldPauseForConfirmation(tool: string, args: Record<string, unknown>): boolean {
  // 新增: 资源约束检查
  if (this.bodyState) {
    // 低精力 → 所有写操作需确认
    if (this.bodyState.energy < 20) {
      const writeTools = new Set([
        'write_file', 'edit_file', 'exec', 'git_commit',
      ]);
      if (writeTools.has(tool)) return true;
    }
  }

  if (this.resources) {
    // 工具不健康 → 需确认
    const health = this.resources.toolHealth?.scores[tool];
    if (health !== undefined && health < 40) return true;
  }

  // 已有: 原有逻辑不变
  switch (this.autonomyLevel) {
    // ...
  }
}
```

**工作量**: ~20 行，1 个文件
**风险**: 零（只加判断，不改原有逻辑）

---

### Phase 4: 斜杠命令注入 — 统一入口

**前置条件**: Phase 1-3 完成。

**目标**: 56 个斜杠命令不再硬编码，走 agent 统一入口，获得资源感知能力。

#### 改动 4.1: main.ts 精简

**文件**: `src/main.ts`

只保留 3 个系统级命令在 main.ts：

- `/quit` / `/exit` — 退出（需要关闭 rl）
- `/help` — 帮助（纯文本输出，无需资源感知）
- `/status` — 状态（高频，保留快速通道）

其余 53 个命令全部走 `agent.handleCLIMessage(input)`。

#### 改动 4.2: ArgExtractor 注册斜杠命令

**文件**: `src/brain/left/arg-extractor.ts`

为每个斜杠命令注册 ArgExtractor，priority=100（高于所有自然语言规则）：

```typescript
// 示例: /backup 命令
exts.push({
  id: 'ext-cmd-backup',
  toolName: 'buddy_backup',
  priority: 100,
  extract(c) {
    if (c.trim() === '/backup') return {};
    return null;
  },
});
```

#### 改动 4.3: handleCLIMessage 处理斜杠命令

**文件**: `src/core/agent.ts`

在 handleCLIMessage 中增加斜杠命令识别：

```typescript
async handleCLIMessage(content: string): Promise<string> {
  // 斜杠命令快速通道
  if (content.startsWith('/')) {
    const cmdResult = await this.handleSlashCommand(content);
    if (cmdResult !== null) return cmdResult;
  }

  // 已有逻辑: perceptor → orchestrate → executeByPlan
  // ...
}
```

**工作量**: ~4-8 小时（56 个命令逐个迁移+测试）
**风险**: 中（需要回归测试，但每个命令独立，可渐进迁移）

---

## 四、实施时间线

```
Phase 1 (传导)    ─── 1-2h ───→ 立即可测
Phase 2 (拦截)    ─── 1-2h ───→ 立即可测
Phase 3 (自适应)  ─── 1h   ───→ 立即可测
Phase 4 (注入)    ─── 4-8h ───→ 需逐命令测试

总计: 7-13 小时
```

## 五、验证标准

### Phase 1 验证

```bash
# 打印 ExecutionContext 中的 resources
npx tsx src/main.ts --verbose
# 输入任何自然语言，观察日志中是否有 budgetRemaining 真实值
```

### Phase 2 验证

```bash
# 模拟工具不健康场景
# 人为将某工具 healthScore 设为 10
# 调用该工具，观察是否被拦截
```

### Phase 3 验证

```bash
# 模拟低精力场景
# 人为将 bodyState.energy 设为 15
# 执行写操作，观察是否弹出确认
```

### Phase 4 验证

```bash
# 逐命令测试
npx tsx src/main.ts
# /status → 走统一入口，输出与原来一致
# /backup → 走统一入口，检查资源感知
# "看看git状态" → 与 /status 走同一条规则
```

## 六、风险评估

| Phase | 风险 | 缓解措施 |
|---|---|---|
| 1 | 极低 | 只加字段，不改逻辑，有默认值兜底 |
| 2 | 低 | 只加拦截，不改已有逻辑，block 条件严格 |
| 3 | 低 | 只加判断，不影响原有 autonomyLevel 逻辑 |
| 4 | 中 | 56 个命令需逐个迁移+测试，建议分批 |

## 七、收益

### 即时收益 (Phase 1-3)

- 执行层不再盲执行，资源约束生效
- 工具不健康时自动拦截，减少无意义调用
- 低精力时自动要求确认，避免误操作
- 预算耗尽时自动降级到本地工具

### 长期收益 (Phase 4)

- 斜杠命令和自然语言走同一条链路，架构统一
- 命令获得记忆/学习/推荐能力
- 命令可以组合编排（"备份然后查状态" → DAG）
- 统一审计，所有命令的执行成本和成功率可追踪

---

## 附录: 涉及文件清单

| 文件 | Phase | 改动类型 |
|---|---|---|
| `src/core/plan-executor.ts` | 1 | 接口扩展 + 字段使用 |
| `src/core/agent.ts` | 1, 4 | 传参 + 命令分发 |
| `src/tools/execution-middleware.ts` | 2 | 接口扩展 + 资源检查 |
| `src/core/execution-session.ts` | 3 | 接口扩展 + 资源判断 |
| `src/main.ts` | 4 | 大幅精简 |
| `src/brain/left/arg-extractor.ts` | 4 | 注册斜杠命令提取器 |
