# 世界模型接入改造方案

> 日期: 2026-05-15
> 目标: 让世界模型从"双低触发的摆设"变为"选择困难时的决策引擎"
> 原则: 不是每步都跑，是"有多个好方案且分不清谁更好"时才跑

---

## 一、当前问题

### 1.1 触发条件反了

```typescript
// 当前 brain.ts Step 3.5
if (intuition.qualityEstimate < 0.5 && plan.confidence < 0.6) {
  // 世界模型介入
}
```

条件含义：经验匹配差 + 规则也没把握 → 才用世界模型。
但世界模型需要经验来学因果关系。**没经验时它也学不好，有经验时却不让它跑。**

### 1.2 输入是空的

```typescript
const best = this.right.bestAction([], candidates);
//                                      ^^ 空 tokens
```

`buildSceneFromTokens([])` → 空 SceneGraph（0 节点、0 边）→ GNN 在空图上跑 → 纯先验猜测。

### 1.3 只用于选模式

当前世界模型只比较 sequential / parallel / single 三种执行模式，不比较具体方案。

---

## 二、改造思路

### 2.1 核心改变

```
当前: 经验不足 → 世界模型介入 → 空图模拟 → 选执行模式
改后: 方案接近 → 世界模型介入 → 真实状态模拟 → 选最优方案
```

触发条件从"经验不足"变为"选择困难"。

### 2.2 判断漏斗

```
用户输入
  ↓
左脑输出候选方案 N 个（带置信度分数）
  ↓
┌─ N = 1 → 直接执行
├─ N ≥ 2 且最高 - 次高 > 0.3 → 用最高的
└─ N ≥ 2 且差距 ≤ 0.3 → 世界模型介入
  ↓
世界模型对每个方案模拟后果
  ↓
综合评分（完成概率 × 0.4 + (1-风险) × 0.3 + 置信度 × 0.3）
  ↓
选最优方案执行
```

### 2.3 四个介入条件

| 类型 | 条件 | 含义 |
|------|------|------|
| 触发 | 候选方案 ≥ 2 且置信度差距 ≤ 0.3 | 选择困难 |
| 触发 | 任务涉及多步操作（sequential 模式） | 执行顺序影响结果 |
| 可行 | 原型记忆有 ≥ 5 个相关样本 | 有数据可学 |
| 可行 | 任务不是简单对话（taskType ≠ 'chat'） | 复杂任务才值得模拟 |

触发条件 + 可行条件同时满足才执行。

---

## 三、具体改动

### 3.1 Scheduler 返回候选列表

**文件**: `src/brain/left/scheduler.ts`

当前 `Scheduler.decide()` 返回单个 `ExecutionPlan`。改为暴露 `decideAll()` 方法返回带分数的候选列表。

```typescript
interface ScoredPlan {
  plan: ExecutionPlan;
  score: number;        // 调度器的综合评分
  source: string;       // 来源（rule / scheduler / intuition）
}

// 新增方法
decideAll(
  signal: TaskSignal,
  resources: ResourceState,
  intuition?: IntuitionSignal,
  body?: BodyState,
): ScoredPlan[] {
  // 1. 规则匹配 → 收集所有匹配的规则输出
  // 2. 调度器路径 → 生成多个候选（不同路由策略）
  // 3. 直觉建议 → 作为候选加入
  // 4. 按 score 降序排列
  // 5. 返回全部候选
}
```

**不改** `decide()` 的现有行为——它仍然返回最高分的单个方案，向后兼容。

### 3.2 ThreeBrain.decide() 接入世界模型

**文件**: `src/brain/brain.ts`

替换当前的 Step 3.5：

```typescript
// Step 3: 左脑 — 输出候选方案
const scoredPlans = await this.left.decideAll(signal, resources, intuition, bodyState);

// Step 3.5: 世界模型 — 选择困难时介入
let plan: ExecutionPlan;
if (scoredPlans.length <= 1) {
  // 只有一个方案，直接用
  plan = scoredPlans[0].plan;
} else if (scoredPlans[0].score - scoredPlans[1].score > 0.3) {
  // 方案差距大，用最高的
  plan = scoredPlans[0].plan;
} else {
  // 选择困难 → 世界模型模拟
  const best = this.right.bestPlan(
    scoredPlans.map(sp => ({
      label: sp.plan.mode,
      reason: sp.plan.reason,
      score: sp.score,
    })),
    this.lastTokenIds,  // 从 predictFull 缓存的真实 token
  );
  
  if (best) {
    plan = scoredPlans.find(sp => sp.plan.mode === best.label)?.plan ?? scoredPlans[0].plan;
  } else {
    plan = scoredPlans[0].plan;  // 模拟失败，降级到最高分
  }
}
```

### 3.3 缓存 tokenIds

**文件**: `src/brain/brain.ts`

在 `predictFull()` 时缓存 tokenIds，供世界模型使用：

```typescript
// 新增字段
private lastTokenIds: number[] = [];

// Step 2 中保存
const multimodal = this.buildMultimodalContext(input);
intuition = await this.right.predictFull(input, signal, resources, bodyState, multimodal);
// 缓存 tokenIds（从 predictFull 的内部编码中获取）
this.lastTokenIds = this.right.getLastTokenIds();
```

**文件**: `src/brain/right/index.ts`

在 `predictFull()` 中保存 tokenIds：

```typescript
private lastTokenIds: number[] = [];

async predictFull(...): Promise<IntuitionSignal & ...> {
  const { tokenIds, textEmbedding } = encodeFeaturesV2(encodeInput, input);
  this.lastTokenIds = tokenIds;  // 缓存
  // ... 后续逻辑不变
}

getLastTokenIds(): number[] {
  return [...this.lastTokenIds];
}
```

### 3.4 RightBrain.bestPlan() 方法

**文件**: `src/brain/right/index.ts`

新增方法，用 SceneWorldModel 模拟多个方案：

```typescript
bestPlan(
  candidates: Array<{ label: string; reason: string; score: number }>,
  currentTokens: number[],
): { label: string; prediction: ScenePredictionResult } | null {
  if (candidates.length === 0) return null;

  const scene = this.buildSceneFromTokens(currentTokens);

  // 只有经验足够时才模拟
  const protoCount = this.prototypeMemory.getPrototypes().length;
  if (protoCount < 5) return null;

  const sceneCandidates = candidates.map(c => ({
    action: {
      type: c.label,
      params: new Float32Array([c.score]),  // 用调度器分数作为参数
    } as SceneAction,
    label: c.label,
  }));

  return this.sceneWorldModel.bestAction(scene, sceneCandidates);
}
```

### 3.5 LeftBrain 暴露候选列表

**文件**: `src/brain/left/index.ts`

新增 `decideAll()` 方法：

```typescript
async decideAll(
  signal: TaskSignal,
  resources: ResourceState,
  intuition?: IntuitionSignal,
  body?: BodyState,
): Promise<Array<{ plan: ExecutionPlan; score: number; source: string }>> {
  const results: Array<{ plan: ExecutionPlan; score: number; source: string }> = [];

  // 1. 规则引擎：收集所有匹配的规则
  const rulePlan = this.ruleEngine.evaluate(signal, resources, intuition);
  if (rulePlan) {
    results.push({ plan: rulePlan, score: rulePlan.confidence, source: 'rule' });
  }

  // 2. 调度器：生成候选
  const schedulerPlan = this.scheduler.schedule(signal, resources, intuition, body);
  results.push({ plan: schedulerPlan, score: schedulerPlan.confidence, source: 'scheduler' });

  // 3. 直觉建议（如果有）
  if (intuition && intuition.hit) {
    results.push({
      plan: {
        mode: 'single',
        reason: `直觉: ${intent.category}`,
        selectedNodes: [],
        confidence: intent.confidence,
        source: 'intuition',
      },
      score: intent.confidence,
      source: 'intuition',
    });
  }

  // 去重（相同 mode 的只保留最高分）
  const seen = new Map<string, typeof results[0]>();
  for (const r of results) {
    const key = r.plan.mode;
    if (!seen.has(key) || seen.get(key)!.score < r.score) {
      seen.set(key, r);
    }
  }

  return [...seen.values()].sort((a, b) => b.score - a.score);
}
```

---

## 四、改造后的能力对比

| 场景 | 当前行为 | 改后行为 |
|------|---------|---------|
| 用户: "重构这个模块" | 规则匹配 → 执行（不比较方案） | 规则+调度+直觉各出方案 → 模拟 → 选最优 |
| 用户: "优化性能" | Thompson Sampling 随机探索 | 多个方案模拟比较 → 选风险最低的 |
| 用户: "清理目录" | 规则匹配 → 直接执行 rm | 模拟 rm 的后果 → 发现有 .env → 选 trash |
| 简单任务: "读文件" | 规则匹配 → 执行 | 只有一个方案 → 直接执行（不模拟） |
| 多步任务: "改接口再改实现" | 按顺序执行 | 模拟两种顺序 → 选测试不崩的 |

---

## 五、实施顺序

| 步骤 | 内容 | 文件 | 风险 |
|------|------|------|------|
| 1 | 缓存 tokenIds | `right/index.ts` | 低 — 只加缓存逻辑 |
| 2 | `bestPlan()` 方法 | `right/index.ts` | 低 — 新增方法 |
| 3 | `decideAll()` 方法 | `left/index.ts` | 中 — 需要规则引擎暴露更多接口 |
| 4 | ThreeBrain 接入 | `brain.ts` | 中 — 改造 Step 3.5 |
| 5 | 测试 | `phase-e.test.ts` | 低 — 补充世界模型介入的测试 |

步骤 1-2 可以并行。步骤 3-4 有依赖。步骤 5 最后。

---

## 六、关键指标

| 指标 | 当前 | 目标 |
|------|------|------|
| 世界模型触发率 | ~5%（双低条件） | ~20-30%（方案接近时） |
| 多步任务成功率 | 无数据 | 提升 15%+（因果预判） |
| 风险规避率 | 无数据 | 不可逆操作前 100% 模拟 |
| 单方案任务延迟 | +0ms（不触发） | +0ms（不触发） |
| 多方案任务延迟 | +0ms（不模拟） | +5-15ms（GNN 推理） |
