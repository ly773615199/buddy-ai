# 训练架构对齐 & 权重替换计划

## 背景

训练项目 (openi.pcl.ac.cn/lewyeu/buddy-pretrain) 的 Python 训练脚本与 GitHub 源码 (github.com/ly773615199/buddy) 的 TypeScript 架构存在严重不对齐，导致训练出的权重无法被 TS 推理代码使用。

## 已修复的问题 (2026-05-28)

| 问题 | 修复前 | 修复后 |
|------|--------|--------|
| Encoder 架构 | BuddyLMEncoder (hidden=128, 2层, 4头) | ByteEncoder (hidden=256, 4层, 8头) |
| MoE 负载均衡 loss | Switch Transformer 公式, weight=0.01 | KL 散度 (对齐 TS getLoadBalanceLoss) |
| 数据流 | input+target 拼接后 SEP 切分 | encoder 接字节序列, decoder 接 BBPE tokens |
| 训练超参 | lr=0.001, batch=64, 无梯度累积 | lr=0.0003, batch=32, grad_accum=2 |

## 对齐映射

| GitHub TS 源码 | 训练项目 Python | 状态 |
|---|---|---|
| `src/brain/right/nn/decoder.ts` (DecoderConfig) | `scripts/pretrain_gcu.py` (BuddyLMDecoder) | ✅ 已对齐 |
| `src/brain/right/features/text-encoder.ts` (ByteEncoder) | `scripts/pretrain_encoder_gcu.py` (ByteEncoder) | ✅ 已对齐 |
| `src/brain/right/features/text-encoder.ts` (ByteEncoder) | `scripts/pretrain_gcu.py` (ByteEncoder) | ✅ 已对齐 |
| `src/brain/right/nn/bbpe-tokenizer.ts` | `scripts/bbpe_tokenizer.py` | ✅ 已对齐 |
| MoE load balance (KL 散度) | `scripts/pretrain_gcu.py` (MoELayer) | ✅ 已对齐 |

## 执行步骤

### Phase 1: 训练 (启智平台)

- [x] 修复训练脚本架构对齐
- [x] 推送代码到 openi.pcl.ac.cn
- [ ] 在启智平台创建训练任务
  - 软件配置: `liuzx / maca2.32-py3.10-inference`
  - 资源规格: METAX-GPGPU C500 (64GB)
  - 启动文件: `scripts/start-pretrain-gcu.py`
- [ ] 监控训练 loss 趋势
  - 预期: ce_loss 从 ~5 下降到 <1, aux_loss 从 ~11 下降到 ~1-2
  - 关注: MoE 专家使用率是否均匀 (每个专家 ~12.5%)
- [ ] 训练完成后下载 checkpoint 到 `/tmp/output/`

### Phase 2: 验证 (本地)

- [ ] 加载训练权重，跑推理测试
- [ ] 对比 TS 推理结果，确认权重兼容
- [ ] 验证 MoE 专家分化情况

### Phase 3: 替换 (GitHub)

- [ ] 从训练 checkpoint 提取 TS 格式权重
  - `decoder.weights.bin` (decoder 主权重)
  - `embedding.weights.bin` (BBPE embedding)
  - `encoder-pretrain/final.weights.bin` (encoder 权重)
  - `tokenizer/bbpe.json` (tokenizer vocab)
- [ ] 替换 GitHub 仓库的 `checkpoints/` 目录
- [ ] 推送到 GitHub
- [ ] 验证 TS 推理代码能正确加载新权重

### Phase 4: 部署

- [ ] 更新依赖新权重的下游代码
- [ ] 跑完整 e2e 测试

## 训练超参配置

```
模型: ByteEncoder(256, 4层) + BuddyLMDecoder(256, 8层, MoE×8)
数据: training-data/quality/ (10 个 jsonl, ~94MB)
硬件: MetaX C500 64GB × 1
batch_size: 32
max_seq_len: 512
lr: 0.0003 (cosine decay, warmup 500 steps)
grad_accum_steps: 2 (等效 batch=64)
epochs: 3
moe_balance_weight: 内置于 KL 散度 loss
```

## 风险

1. **MACA 兼容性**: torch_maca 可能有 op 不支持，需要降级或 workaround
2. **MoE 路由恢复**: 从旧 checkpoint resume 时 MoE 路由可能已固化，效果不确定
3. **训练时间**: 预计 8-12 小时 (3 epochs, 32 batch, C500)
