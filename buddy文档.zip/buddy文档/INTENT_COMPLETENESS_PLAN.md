# 追问系统统一重构计划

> 目标：将三套独立的追问机制（ClarificationEngine / DeliberationCouncil / KnowledgeInterviewer）
> 统一为"意图完整性评估"架构，以规则为核心，ByteEncoder 语义兜底，可选云端 LLM 增强。

## 背景分析

### 现状问题

1. **ClarificationEngine（规则层）** 覆盖窄：`VAGUE_ACTIONS` 仅 10 个动词，正则漏网多
   - "帮我总结这个文档方案" → 不追问（"总结"不在动词列表）
   - "帮我看看" → 不追问（"看看"不在动词列表）
   - 设计思路是"从动作反推缺什么"，而非"意图是否完整"

2. **DeliberationCouncil（审议层）** 只在复杂任务触发，普通消息不走
   - "帮我总结这个文档方案" 不复杂 → 不进审议 → 信息缺失被忽略

3. **KnowledgeInterviewer（知识层）** 是对话后异步追问，不阻塞当前流程

4. **三套系统各自为战**，没有统一的"信息是否充分"判断层

### 设计理念转变

从 **"动作驱动追问"** → **"意图完整性驱动追问"**

核心问题不是"用户说了什么动词"，而是"要完成这个意图，信息是否足够"。
这需要综合考虑：当前消息 + 上下文 + 任务必要条件。

---

## 架构设计

### 三层递进架构

```
┌─────────────────────────────────────────────────────┐
│                   用户消息输入                        │
└──────────────────────┬──────────────────────────────┘
                       ▼
┌──────────────────────────────────────────────────────┐
│  Layer 0: 极致规则引擎 (<1ms)                         │
│  ┌────────────────────────────────────────────────┐  │
│  │ 0a. 句法完整性检查                              │  │
│  │ 0b. 指代词检测 + 指代对象缺失                   │  │
│  │ 0c. 必要 slot 检查（任务模板）                  │  │
│  │ 0d. 目标冲突检测                               │  │
│  │ 0e. 上下文可补全检查                            │  │
│  └────────────────────────────────────────────────┘  │
│  输出: { complete: true/false, missing: [], source } │
└──────────────────────┬──────────────────────────────┘
                       │ complete=true → 放行
                       │ complete=false → 追问
                       │ uncertain ▼
┌──────────────────────────────────────────────────────┐
│  Layer 1: ByteEncoder 语义匹配 (<50ms, 纯本地)        │
│  ┌────────────────────────────────────────────────┐  │
│  │ 1a. STMP 向量检索：找历史上语义相似的消息        │  │
│  │ 1b. 检查相似消息的结局（被追问 or 直接执行）     │  │
│  │ 1c. 不完整模式库向量匹配                        │  │
│  └────────────────────────────────────────────────┘  │
│  输出: { complete: true/false, confidence, source }  │
└──────────────────────┬──────────────────────────────┘
                       │ complete=true → 放行
                       │ complete=false → 追问
                       │ uncertain ▼
┌──────────────────────────────────────────────────────┐
│  Layer 2: 云端 LLM 语义评估 (1-3s, 可选)              │
│  ┌────────────────────────────────────────────────┐  │
│  │ 2a. 轻量 prompt + structuredOutput              │  │
│  │ 2b. 提取意图 + 判断完整性                       │  │
│  └────────────────────────────────────────────────┘  │
│  输出: { sufficient: bool, missing: [], intent }     │
│  降级: 调用失败 → 静默放行                            │
└──────────────────────────────────────────────────────┘
```

### 与现有系统的关系

```
                    ┌─ ClarificationEngine ─→ 废弃，逻辑合并到 Layer 0
统一 IntentAnalyzer ┤
                    ├─ DeliberationCouncil ─→ 保留，处理复杂任务的方案生成
                    │   (不再负责"是否追问"入口判断，但保留回调通道：
                    │    执行阶段发现信息不足时 → 回调 IntentAnalyzer 发起补问)
                    │
                    └─ KnowledgeInterviewer ─→ 保留，对话后知识积累
                        (与 IntentAnalyzer 互补：一个管当下，一个管长期)
```

---

## 详细实现计划

### Phase 1: 规则引擎升级（Layer 0）

**目标**: 将 `ClarificationEngine` 从 10 个动词 + 5 条规则，升级为完整的意图完整性检查器。

**文件改动**: `src/core/clarifier.ts`（重构）

#### 1.1 句法完整性检查模块

```typescript
// 新增：动词表扩展
const ACTION_VERBS = {
  // 原有 10 个
  '改', '修', '优化', '处理', '弄', '搞', 'fix', 'improve', 'update', 'handle',
  // 新增 ~40 个
  '总结', '分析', '解释', '描述', '检查', '看看', '翻译', '重构', '迁移',
  '测试', '调试', '部署', '发布', '备份', '清理', '监控', '配置', '安装',
  '升级', '降级', '回滚', '生成', '创建', '编写', '设计', '实现', '开发',
  'review', 'analyze', 'explain', 'describe', 'check', 'translate', 'refactor',
  'migrate', 'test', 'debug', 'deploy', 'publish', 'backup', 'clean', 'monitor',
  'configure', 'install', 'upgrade', 'generate', 'create', 'write', 'design',
  'implement', 'develop', 'summarize', 'compare', 'evaluate', 'assess',
};

// 新增：句法完整性检查
interface SyntaxCheck {
  hasSubject: boolean;      // 主语（可省略，默认是"你"）
  hasVerb: boolean;         // 谓语（必须）
  hasObject: boolean;       // 宾语（大多数情况必须）
  hasComplement: boolean;   // 补语（修饰信息）
  verbSpecificity: number;  // 动词具体度 0-1
}
```

**句法规则**：
- 有动词无宾语 → 检查动词是否及物（"总结"是及物 → 缺宾语 → 追问）
- 有动词有宾语 → 完整
- 无动词 → 可能是名词短语（"那个文档"）→ 检查上下文是否能补全

#### 1.2 指代词检测模块

```typescript
const DEICTIC_WORDS = [
  // 近指
  { word: /这个|这儿|这里|this|here/, type: 'near' },
  // 远指
  { word: /那个|那儿|那里|that|there/, type: 'far' },
  // 代词
  { word: /它|它们|他|她|its?|them/, type: 'pronoun' },
  // 省略（上下文依赖）
  { word: /^(帮我|请|帮忙)?\s*(总结|分析|看看|检查|翻译)\s*$/, type: 'ellipsis' },
];

// 检查指代词是否有明确指代对象
function checkDeixis(content: string, context: ContextInfo): DeixisResult {
  // 1. 检测消息中的指代词
  // 2. 在上下文中搜索可能的指代对象
  // 3. 如果找到唯一匹配 → 补全，不追问
  // 4. 如果找到多个匹配或无匹配 → 追问
}
```

**上下文指代对象搜索**：
- 最近 3 条消息中提取名词短语
- STMP 中检索最近相关的实体/文件名
- 如果指代词 + 上下文名词能唯一匹配 → 自动补全

#### 1.3 必要 Slot 检查（任务模板）

```typescript
// 任务类型 → 必要 slot 定义
const TASK_SLOTS: Record<string, RequiredSlot[]> = {
  summarize:    [{ name: 'target', desc: '要总结的内容', required: true }],
  analyze:      [{ name: 'target', desc: '要分析的对象', required: true }],
  deploy:       [{ name: 'target', desc: '部署目标', required: true }],
  send:         [{ name: 'recipient', desc: '收件人', required: true },
                 { name: 'content', desc: '发送内容', required: false }],
  compare:      [{ name: 'a', desc: '比较对象A', required: true },
                 { name: 'b', desc: '比较对象B', required: true }],
  translate:    [{ name: 'target', desc: '翻译内容', required: true },
                 { name: 'language', desc: '目标语言', required: false }],
  create:       [{ name: 'target', desc: '创建什么', required: true }],
  delete:       [{ name: 'target', desc: '删除什么', required: true }],
  fix:          [{ name: 'target', desc: '修复什么', required: true }],
  optimize:     [{ name: 'target', desc: '优化什么', required: true }],
  // ... 更多任务类型
};

// 从消息中提取已填 slot
function extractSlots(content: string, taskType: string): Map<string, string> {
  // 1. 基于任务类型的关键词提取
  // 2. 基于句法分析提取实体
  // 3. 基于上下文补全
}

// 检查必要 slot 是否已填
function checkRequiredSlots(taskType: string, filledSlots: Map<string, string>): SlotCheckResult {
  const required = TASK_SLOTS[taskType] ?? [];
  const missing = required.filter(s => s.required && !filledSlots.has(s.name));
  return { complete: missing.length === 0, missing };
}
```

#### 1.4 上下文补全模块

```typescript
// 尝试从上下文自动补全缺失信息
function tryContextualCompletion(
  content: string,
  missing: string[],
  context: ContextInfo,
): CompletionResult {
  // 1. 最近消息中提取实体
  // 2. STMP 中检索相关记忆
  // 3. 用户 profile 中查找偏好
  // 4. 尝试用上下文信息填充 missing slots
  // 5. 填充成功 → complete，填充失败 → 不 complete
}
```

#### 1.5 决策汇总

```typescript
// 统一决策接口
interface CompletenessDecision {
  complete: boolean;           // 信息是否充分
  confidence: number;          // 判断置信度 0-1
  missing: MissingInfo[];      // 缺失信息列表
  autoCompleted: string[];     // 自动补全的信息
  source: 'syntax' | 'deixis' | 'slots' | 'conflict' | 'context'; // 判断来源
  risk: 'low' | 'medium' | 'high'; // 操作风险
}
```

**决策逻辑**（与现有类似但更精细）：
```
shouldClarify = !complete AND (
  confidence >= 0.7                                    // 高置信度直接问
  OR (confidence >= 0.5 AND risk === 'high')           // 中置信度 + 高风险
  OR (confidence >= 0.3 AND risk === 'medium' AND msg.length < 50)
  OR missing.type === 'conflict'                       // 冲突一律问
) AND sessionClarifications < maxPerSession
```

---

### Phase 2: ByteEncoder 语义层（Layer 1）

**目标**: 用本地向量检索兜底规则引擎的漏网场景。

**新增文件**: `src/core/intent-completeness.ts`

#### 2.1 不完整模式向量库

```typescript
// 预定义的"不完整表达"模式（用 ByteEncoder 编码后存入 STMP）
const INCOMPLETE_PATTERNS = [
  // 指代不明
  '帮我看看这个', '优化一下那个', '改改它',
  // 动作缺宾语
  '帮我总结一下', '分析分析', '检查检查',
  // 模糊请求
  '帮我处理一下', '弄一下', '搞一下这个',
  // 省略主语/宾语
  '继续', '然后呢', '上次那个',
  // 中英混合
  'fix 一下', 'review 下', 'check 一下',
];

// 也包含"完整表达"的模式（用于对比）
const COMPLETE_PATTERNS = [
  '帮我看看 src/main.ts 的代码',
  '总结一下 ARCHITECTURE.md 的内容',
  '把 config.ts 里的端口号改成 3000',
];
```

#### 2.2 语义匹配流程

```typescript
class SemanticCompletenessChecker {
  private incompleteEmbeddings: Float32Array[] = [];
  private completeEmbeddings: Float32Array[] = [];

  constructor(private stmp: STMPStore, private encoder: ByteEncoder) {}

  /** 初始化：编码所有模式 */
  async init(): Promise<void> {
    for (const pattern of INCOMPLETE_PATTERNS) {
      this.incompleteEmbeddings.push(this.encoder.forward(pattern));
    }
    for (const pattern of COMPLETE_PATTERNS) {
      this.completeEmbeddings.push(this.encoder.forward(pattern));
    }
  }

  /** 评估消息完整性 */
  assess(content: string): SemanticAssessment {
    const queryVec = this.encoder.forward(content);

    // 计算与不完整模式的最大相似度
    const maxIncompleteSim = Math.max(
      ...this.incompleteEmbeddings.map(e => cosineSimilarity(queryVec, e))
    );

    // 计算与完整模式的最大相似度
    const maxCompleteSim = Math.max(
      ...this.completeEmbeddings.map(e => cosineSimilarity(queryVec, e))
    );

    // 语义评估
    const gap = maxCompleteSim - maxIncompleteSim;

    return {
      complete: gap > 0.1,  // 完整模式更相似 → complete
      confidence: Math.abs(gap),
      incompleteScore: maxIncompleteSim,
      completeScore: maxCompleteSim,
    };
  }
}
```

#### 2.3 历史学习（自进化）

```typescript
// 每次追问后，将模式存入 STMP，供后续语义匹配
function recordIncompletePattern(content: string, reason: string): void {
  // 1. ByteEncoder 编码
  // 2. 存入 STMP，标记 lifecycle.source = 'clarification'
  // 3. 后续相似消息会被向量检索命中

// 每次直接执行后，将模式标记为"完整"
function recordCompletePattern(content: string): void {
  // 同上，标记为 complete
}
```

这样规则库不是静态的——用户的每一次交互都在训练语义层。

---

### Phase 3: 云端 LLM 增强（Layer 2，可选）

**目标**: 处理 Layer 0 + 1 无法确定的长尾场景。

**新增文件**: `src/core/intent-llm-checker.ts`

#### 3.1 轻量 Prompt 设计

```typescript
const INTENT_CHECK_PROMPT = `判断用户消息的信息是否足够执行。

用户消息: "{message}"
最近对话: {recentMessages}
用户上下文: {userContext}

判断标准：
1. 用户想做什么？（意图）
2. 做这件事需要什么信息？（必要条件）
3. 当前已有哪些信息？（已知信息）
4. 缺什么关键信息？（缺失信息）
5. 上下文能否补全缺失信息？

仅输出 JSON，不要其他内容。`;
```

#### 3.2 Structured Output Schema

```typescript
const IntentCheckSchema = z.object({
  sufficient: z.boolean().describe('信息是否足够执行'),
  confidence: z.number().min(0).max(1).describe('判断置信度'),
  intent: z.string().describe('用户意图摘要'),
  missing: z.array(z.object({
    slot: z.string().describe('缺失的 slot 名称'),
    description: z.string().describe('缺失信息的描述'),
    canInfer: z.boolean().describe('是否可以从上下文推断'),
  })).describe('缺失信息列表'),
  reasoning: z.string().describe('判断理由'),
});
```

#### 3.3 降级策略

```typescript
class IntentLLMChecker {
  async assess(content: string, context: ContextInfo): Promise<IntentCheckResult | null> {
    try {
      // 使用 taskType: 'background' 走轻量模型
      const result = await this.llm.structuredOutput(
        IntentCheckSchema,
        messages,
        { taskType: 'background' }
      );
      return result;
    } catch (err) {
      // 降级：静默放行，不阻塞
      if (this.verbose) console.warn('[IntentLLM] 评估失败，降级放行:', err.message);
      return null;
    }
  }
}
```

---

### Phase 4: 统一入口 + 集成

**改动文件**: `src/core/message-processor.ts`, `src/core/clarifier.ts`

#### 4.1 统一 IntentAnalyzer

```typescript
// src/core/intent-analyzer.ts
export class IntentAnalyzer {
  private ruleEngine: ClarificationEngine;        // Layer 0
  private semanticChecker: SemanticCompletenessChecker; // Layer 1
  private llmChecker: IntentLLMChecker | null;    // Layer 2（可选）
  private sessionClarifications = 0;
  private maxPerSession = 3;

  constructor(stmp: STMPStore, encoder: ByteEncoder, llm?: LLMAdapter) {
    this.ruleEngine = new ClarificationEngine();
    this.semanticChecker = new SemanticCompletenessChecker(stmp, encoder);
    this.llmChecker = llm ? new IntentLLMChecker(llm) : null;
  }

  async assess(
    content: string,
    context: ContextInfo,
  ): Promise<CompletenessDecision> {
    // 防循环
    if (this.sessionClarifications >= this.maxPerSession) {
      return { complete: true, confidence: 1, missing: [], ... };
    }

    // Layer 0: 规则引擎
    const ruleResult = this.ruleEngine.assess(content, context);
    if (ruleResult.confidence >= 0.8) {
      return ruleResult; // 高置信度直接返回
    }

    // Layer 1: 语义匹配
    const semanticResult = this.semanticChecker.assess(content);
    if (semanticResult.confidence >= 0.7) {
      return semanticResult;
    }

    // Layer 2: 云端 LLM（可选）
    if (this.llmChecker) {
      const llmResult = await this.llmChecker.assess(content, context);
      if (llmResult) return llmResult;
    }

    // 三层都不确定 → 放行
    return { complete: true, confidence: 0.5, missing: [], source: 'fallback' };
  }
}
```

#### 4.2 MessageProcessor 集成

```typescript
// message-processor.ts 改动

// 替换：
// const clarification = this.clarifier.assess(content, ...);
// if (clarification.shouldClarify) { ... }

// 改为：
const completeness = await this.intentAnalyzer.assess(content, {
  recentMessages: recentMessages.map(m => m.content),
  userContext: this.sys.cognitive.getUserPromptFragment(),
});
if (!completeness.complete) {
  this.sessionClarifications++;
  const question = this.buildCompletenessQuestion(completeness.missing);
  return { text: question, toolCalls: [] };
}
```

#### 4.3 DeliberationCouncil 调整

**核心原则**: 审议委员会不主动判断"要不要追问"，但保留回调通道。

```typescript
// 职责边界：
// - 审议委员会不再负责"是否追问"的入口判断（归 IntentAnalyzer）
// - 只负责"怎么执行"（方案生成、多角色辩论）
// - 执行阶段发现信息不足时，可通过回调请求 IntentAnalyzer 补问

// 回调机制设计：
interface DeliberationResult {
  plan: ExecutionPlan;           // 执行方案
  status: 'ready' | 'need_info'; // 状态
  missing?: MissingInfo[];       // 如果 need_info，列出缺失信息
}

// 审议委员会返回 need_info 时，IntentAnalyzer 发起追问
// 流程：IntentAnalyzer(完整) → 审议(发现不够) → 回调 → IntentAnalyzer(追问) → 审议(继续)
```

**流程图**:
```
IntentAnalyzer（入口判断）
  │
  ├─ 不完整 → 追问用户
  ├─ 完整 + 简单任务 → 直接执行
  └─ 完整 + 复杂任务 → 审议委员会
                        │
                        ├─ 信息足够 → 生成执行方案
                        └─ 信息不够(need_info) → 回调 IntentAnalyzer → 追问用户 → 重新审议
```

---

### Phase 5: 测试覆盖

**改动文件**: `src/core/clarifier.test.ts`（扩展）+ 新测试文件

#### 5.1 测试用例矩阵

```typescript
describe('IntentAnalyzer', () => {
  // Layer 0 规则引擎
  describe('句法完整性', () => {
    it('及物动词缺宾语 → 追问', () => {
      expect(assess('帮我总结')).toBeIncomplete();
      expect(assess('分析一下')).toBeIncomplete();
      expect(assess('翻译')).toBeIncomplete();
    });

    it('及物动词有宾语 → 完整', () => {
      expect(assess('帮我总结 ARCHITECTURE.md')).toBeComplete();
      expect(assess('分析 src/main.ts 的代码')).toBeComplete();
    });

    it('不及物动词 → 完整', () => {
      expect(assess('运行一下')).toBeComplete();
      expect(assess('继续')).toBeComplete();
    });
  });

  describe('指代词检测', () => {
    it('"这个"无指代对象 → 追问', () => {
      expect(assess('帮我看看这个')).toBeIncomplete();
    });

    it('"这个"有上下文指代 → 完整', () => {
      const ctx = { recentMessages: ['我在看 ARCHITECTURE.md'] };
      expect(assess('帮我看看这个', ctx)).toBeComplete();
    });
  });

  describe('必要 slot 检查', () => {
    it('部署缺目标 → 追问', () => {
      expect(assess('部署一下')).toBeIncomplete();
    });

    it('发送缺收件人 → 追问', () => {
      expect(assess('发个邮件')).toBeIncomplete();
    });

    it('比较缺第二个对象 → 追问', () => {
      expect(assess('比较一下 src/a.ts')).toBeIncomplete();
    });
  });

  describe('上下文补全', () => {
    it('上下文能补全 → 不追问', () => {
      const ctx = { recentMessages: ['我在看 package.json'] };
      expect(assess('帮我看看', ctx)).toBeComplete();
    });

    it('上下文不能补全 → 追问', () => {
      const ctx = { recentMessages: ['今天天气不错'] };
      expect(assess('帮我看看', ctx)).toBeIncomplete();
    });
  });

  describe('防循环', () => {
    it('超过会话上限 → 不再追问', () => {
      analyzer.assess('帮我看看这个', ctx); // 第 1 次
      analyzer.assess('帮我看看那个', ctx); // 第 2 次
      analyzer.assess('帮我看看它', ctx);   // 第 3 次
      const result = analyzer.assess('帮我看看', ctx); // 第 4 次
      expect(result.complete).toBe(true); // 放行
    });
  });

  // Layer 1 语义匹配（需要 ByteEncoder）
  describe('语义匹配', () => {
    it('"帮我看看这个" → 语义近似不完整模式 → 追问', () => { ... });
    it('"帮我看看 src/main.ts" → 语义近似完整模式 → 完整', () => { ... });
  });
});
```

---

## 文件清单

| 文件 | 操作 | 说明 |
|------|------|------|
| `src/core/clarifier.ts` | **重构** | 规则引擎升级：扩展动词表 + 指代检测 + slot 检查 |
| `src/core/intent-analyzer.ts` | **新增** | 统一入口：组合 Layer 0/1/2 |
| `src/core/intent-completeness.ts` | **新增** | Layer 1: ByteEncoder 语义匹配 |
| `src/core/intent-llm-checker.ts` | **新增** | Layer 2: 云端 LLM 评估（可选） |
| `src/core/message-processor.ts` | **改动 ~20 行** | 集成 IntentAnalyzer 替换原 ClarificationEngine 调用 |
| `src/core/clarifier.test.ts` | **扩展** | 新增 ~60 个测试用例 |
| `src/core/intent-analyzer.test.ts` | **新增** | 端到端测试 |

## 依赖关系

```
IntentAnalyzer
  ├── ClarificationEngine (已有，重构)
  ├── SemanticCompletenessChecker (新增)
  │     ├── STMPStore (已有)
  │     └── ByteEncoder (已有)
  └── IntentLLMChecker (新增，可选)
        └── LLMAdapter (已有)
```

**不新增任何外部依赖**。所有需要的组件（STMP、ByteEncoder、LLMAdapter）都已在 Subsystems 中。

## 实施顺序

```
Step 1: Phase 1 — 规则引擎升级
  → 扩展 clarifier.ts，新增测试
  → 验证：新规则能覆盖 "帮我总结这个文档方案" 类消息

Step 2: Phase 4.1 — IntentAnalyzer 统一入口
  → 新增 intent-analyzer.ts，先只接 Layer 0
  → 验证：message-processor 能正确调用

Step 3: Phase 2 — ByteEncoder 语义层
  → 新增 intent-completeness.ts
  → 验证：STMP 向量检索 + 模式匹配

Step 4: Phase 3 — 云端 LLM 增强（可选）
  → 新增 intent-llm-checker.ts
  → 验证：structuredOutput 正确返回

Step 5: Phase 4.2-4.3 — 系统集成
  → message-processor 替换调用
  → DeliberationCouncil 职责调整

Step 6: Phase 5 — 测试完善
  → 全量测试 + 边界 case
```

## 性能预估

| 路径 | 延迟 | 覆盖率 | 说明 |
|------|------|--------|------|
| Layer 0 规则 | <1ms | ~85% | 句法+指代+slot+冲突 |
| Layer 1 语义 | <50ms | +5% | ByteEncoder 向量匹配 |
| Layer 2 LLM | 1-3s | +8% | 云端长尾兜底 |
| **总计** | <1ms (85%) / <50ms (10%) / 1-3s (5%) | **~98%** | |

## 风险与缓解

| 风险 | 缓解措施 |
|------|----------|
| 规则引擎误判（不该问的问了） | 置信度阈值 + 用户反馈学习 |
| ByteEncoder 未初始化 | 检查可用性，不可用时跳过 Layer 1 |
| 云端 LLM 延迟高 | taskType='background' + 超时降级 |
| 追问循环 | sessionClarifications 计数器 + 上限 |
| STMP 历史数据不足 | 冷启动靠规则，热数据靠语义 |
| 审议委员会回调死循环 | 回调计数器 + 同一任务最多回调 1 次 |
