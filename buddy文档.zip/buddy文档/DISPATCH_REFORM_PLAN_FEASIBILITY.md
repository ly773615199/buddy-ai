# 调度改革补充方案：资源可行性检查

> 版本: v1.0
> 日期: 2026-05-18
> 关联: DISPATCH_REFORM_PLAN.md
> 问题: 裁决选了最优方案，但执行时发现资源不够

---

## 一、问题

当前流程：

```
各模块出方案 → 裁决选最优（纯质量评分）→ 执行 → 发现缺资源 → 降级/失败
```

三个断裂点：

| 阶段 | 问题 | 后果 |
|------|------|------|
| 出方案 | 模块不声明需要什么资源 | 裁决器无法评估可行性 |
| 裁决 | 只看 confidence，不看资源 | 选了"最好"但"做不到"的方案 |
| 执行 | ResourcePool 缺资源静默跳过 | 空转或降级，用户无感知 |

---

## 二、设计：前瞻式可行性门控

核心原则：**方案产出时就声明资源需求，裁决前做可行性过滤，不可行的方案不参与竞争。**

```
各模块出方案（附带 ResourceRequest）
        ↓
ProposalCollector 收集 + 标准化
        ↓
┌─ FeasibilityChecker 可行性检查 ─┐
│  对每个方案：                      │
│  1. 解析资源需求                   │
│  2. 对照 ResourceState 检查       │
│  3. 输出 feasible / degraded / infeasible │
└──────────────────────────────────┘
        ↓
  feasible 的方案正常评分
  degraded 的方案降权后评分
  infeasible 的方案排除（或标记为备选）
        ↓
Arbiter 裁决（质量 × 可行性）
        ↓
执行（资源已确认可用）
```

---

## 三、新增模块：FeasibilityChecker

**位置**: `src/brain/dispatch/feasibility.ts`

### 3.1 资源请求声明

方案产出时附带 `ResourceRequest`，声明执行该方案需要什么：

```typescript
/**
 * 资源请求 — 方案声明"我需要什么"
 *
 * 不是精确的资源清单，而是能力级别的声明：
 * - 需要 LLM？哪个 tier？
 * - 需要工具？哪些？
 * - 需要计算资源？多大？
 * - 对延迟的容忍度？
 */
export interface ResourceRequest {
  /** 需要的模型能力 */
  modelNeeds: {
    /** 是否需要 LLM（false = 纯本地可完成） */
    requiresLLM: boolean;
    /** LLM tier 要求: 'any' = 随便, 'fast' = 低延迟, 'capable' = 高质量 */
    llmTier?: 'any' | 'fast' | 'capable';
    /** 是否需要多模态 */
    requiresMultimodal?: boolean;
  };

  /** 需要的工具 */
  toolNeeds: {
    /** 需要的工具 ID 列表 */
    requiredTools: string[];
    /** 可选工具（有更好，没有也行） */
    optionalTools: string[];
  };

  /** 计算资源需求 */
  computeNeeds: {
    /** 预估执行时间等级: 'instant' <100ms, 'fast' <1s, 'slow' <10s, 'heavy' >10s */
    latencyClass: 'instant' | 'fast' | 'slow' | 'heavy';
    /** 是否需要 DAG 并行执行 */
    requiresDAG: boolean;
    /** 是否需要多步工具链 */
    requiresToolChain: boolean;
  };

  /** 预估开销 */
  costEstimate: {
    /** 预估 token 消耗（0 = 不需要 LLM） */
    estimatedTokens: number;
    /** 预估工具调用次数 */
    estimatedToolCalls: number;
  };
}
```

### 3.2 可行性检查器

```typescript
/**
 * 可行性检查结果
 */
export interface FeasibilityResult {
  /** 可行性状态 */
  status: 'feasible' | 'degraded' | 'infeasible';
  /** 可行性分数 0-1（用于降权计算） */
  score: number;
  /** 不可行的原因（infeasible/degraded 时有值） */
  reasons: FeasibilityIssue[];
  /** 降级建议（degraded 时的替代方案） */
  degradation?: {
    /** 建议的替代策略 */
    suggestion: string;
    /** 替代后的预估质量损失 */
    qualityLoss: number;
  };
}

export interface FeasibilityIssue {
  dimension: 'budget' | 'tool' | 'latency' | 'load' | 'model';
  severity: 'block' | 'warn';
  description: string;
  /** 具体的约束值 */
  constraint?: {
    needed: number | string;
    available: number | string;
  };
}

/**
 * 可行性检查器 — 前瞻式资源验证
 *
 * 在裁决前检查每个方案是否可行。
 * 不是精确模拟，而是基于 ResourceState + BodyState 做快速估算。
 */
export class FeasibilityChecker {

  /**
   * 检查单个方案的可行性
   *
   * @param request 方案的资源需求
   * @param resources 当前资源状态（预算、工具健康度）
   * @param bodyState 当前身体状态（精力、负载）
   * @param signal 任务信号
   */
  check(
    request: ResourceRequest,
    resources: ResourceState,
    bodyState: BodyState,
    signal: TaskSignal,
  ): FeasibilityResult {
    const issues: FeasibilityIssue[] = [];
    let score = 1.0;

    // ── 检查 1: 预算约束 ──
    const budgetCheck = this.checkBudget(request, resources);
    if (budgetCheck) {
      issues.push(budgetCheck);
      score *= budgetCheck.severity === 'block' ? 0 : 0.5;
    }

    // ── 检查 2: 工具可用性 ──
    const toolCheck = this.checkTools(request, resources);
    if (toolCheck) {
      issues.push(...toolCheck);
      score *= toolCheck.some(t => t.severity === 'block') ? 0 : 0.7;
    }

    // ── 检查 3: 延迟容忍度 ──
    const latencyCheck = this.checkLatency(request, bodyState, signal);
    if (latencyCheck) {
      issues.push(latencyCheck);
      score *= 0.8;
    }

    // ── 检查 4: 系统负载 ──
    const loadCheck = this.checkLoad(request, bodyState);
    if (loadCheck) {
      issues.push(loadCheck);
      score *= 0.8;
    }

    // ── 检查 5: 模型可用性 ──
    const modelCheck = this.checkModel(request, resources);
    if (modelCheck) {
      issues.push(modelCheck);
      score *= modelCheck.severity === 'block' ? 0 : 0.6;
    }

    // 判定状态
    const hasBlock = issues.some(i => i.severity === 'block');
    const hasWarn = issues.some(i => i.severity === 'warn');

    if (hasBlock || score <= 0) {
      return {
        status: 'infeasible',
        score: 0,
        reasons: issues,
      };
    }

    if (hasWarn || score < 0.8) {
      return {
        status: 'degraded',
        score,
        reasons: issues,
        degradation: this.suggestDegradation(request, issues),
      };
    }

    return { status: 'feasible', score: 1.0, reasons: [] };
  }

  /**
   * 批量检查多个方案的可行性
   */
  checkBatch(
    proposals: Array<{ id: string; request: ResourceRequest }>,
    resources: ResourceState,
    bodyState: BodyState,
    signal: TaskSignal,
  ): Map<string, FeasibilityResult> {
    const results = new Map<string, FeasibilityResult>();
    for (const p of proposals) {
      results.set(p.id, this.check(p.request, resources, bodyState, signal));
    }
    return results;
  }

  // ==================== 五维检查 ====================

  private checkBudget(request: ResourceRequest, resources: ResourceState): FeasibilityIssue | null {
    if (!request.modelNeeds.requiresLLM) return null; // 纯本地方案不受预算约束

    const estimatedCost = request.costEstimate.estimatedTokens * 0.0001; // 粗估
    if (resources.budgetRemaining <= 0) {
      return {
        dimension: 'budget',
        severity: 'block',
        description: '预算已耗尽，无法调用 LLM',
        constraint: { needed: estimatedCost, available: 0 },
      };
    }
    if (resources.budgetRemaining < estimatedCost * 0.5) {
      return {
        dimension: 'budget',
        severity: 'warn',
        description: '预算可能不足',
        constraint: { needed: estimatedCost, available: resources.budgetRemaining },
      };
    }
    return null;
  }

  private checkTools(request: ResourceRequest, resources: ResourceState): FeasibilityIssue[] | null {
    if (request.toolNeeds.requiredTools.length === 0) return null;

    const issues: FeasibilityIssue[] = [];
    const health = resources.toolHealth;

    for (const tool of request.toolNeeds.requiredTools) {
      if (health) {
        // 检查工具是否在不可靠列表
        if (health.unreliableTools.includes(tool)) {
          issues.push({
            dimension: 'tool',
            severity: 'warn',
            description: `工具 ${tool} 不可靠（成功率 < 50%）`,
            constraint: { needed: tool, available: `unreliable` },
          });
        }
        // 检查工具健康分
        const score = health.scores[tool];
        if (score !== undefined && score < 30) {
          issues.push({
            dimension: 'tool',
            severity: 'block',
            description: `工具 ${tool} 健康度过低 (${score}/100)`,
            constraint: { needed: 'healthy', available: score },
          });
        }
        // 检查是否在慢工具列表
        if (health.slowTools.includes(tool)) {
          issues.push({
            dimension: 'tool',
            severity: 'warn',
            description: `工具 ${tool} 响应慢（平均 >5s）`,
          });
        }
      }
    }

    return issues.length > 0 ? issues : null;
  }

  private checkLatency(
    request: ResourceRequest,
    bodyState: BodyState,
    signal: TaskSignal,
  ): FeasibilityIssue | null {
    // 用户急迫时，heavy 方案不合适
    if (request.computeNeeds.latencyClass === 'heavy' && bodyState.hunger > 70) {
      return {
        dimension: 'latency',
        severity: 'warn',
        description: '用户交互饥渴度高，heavy 方案可能体验差',
        constraint: { needed: 'fast/slow', available: 'heavy' },
      };
    }

    // 简单任务不应走 heavy 路径
    if (signal.complexity === 'simple' && request.computeNeeds.latencyClass === 'heavy') {
      return {
        dimension: 'latency',
        severity: 'warn',
        description: '简单任务用 heavy 方案过度',
      };
    }

    return null;
  }

  private checkLoad(request: ResourceRequest, bodyState: BodyState): FeasibilityIssue | null {
    // 系统高负载时，DAG 并行和 heavy 方案要慎重
    if (bodyState.load > 80) {
      if (request.computeNeeds.requiresDAG) {
        return {
          dimension: 'load',
          severity: 'warn',
          description: '系统高负载，DAG 并行可能加重压力',
          constraint: { needed: 'load < 80', available: bodyState.load },
        };
      }
      if (request.computeNeeds.latencyClass === 'heavy') {
        return {
          dimension: 'load',
          severity: 'block',
          description: '系统高负载，禁止 heavy 方案',
          constraint: { needed: 'load < 80', available: bodyState.load },
        };
      }
    }

    // 精力极低时，只允许简单方案
    if (bodyState.energy < 20 && request.computeNeeds.latencyClass !== 'instant') {
      return {
        dimension: 'load',
        severity: 'warn',
        description: '精力极低，建议用轻量方案',
        constraint: { needed: 'instant', available: request.computeNeeds.latencyClass },
      };
    }

    return null;
  }

  private checkModel(request: ResourceRequest, resources: ResourceState): FeasibilityIssue | null {
    if (!request.modelNeeds.requiresLLM) return null;

    // 需要 LLM 但本地置信度很高 → 可以降级到本地
    if (resources.localConfidence > 0.85 && request.modelNeeds.llmTier !== 'capable') {
      return {
        dimension: 'model',
        severity: 'warn',
        description: '本地置信度高，LLM 可能不必要',
      };
    }

    return null;
  }

  // ==================== 降级建议 ====================

  private suggestDegradation(
    request: ResourceRequest,
    issues: FeasibilityIssue[],
  ): { suggestion: string; qualityLoss: number } | undefined {
    const hasBudgetIssue = issues.some(i => i.dimension === 'budget');
    const hasToolIssue = issues.some(i => i.dimension === 'tool');
    const hasLoadIssue = issues.some(i => i.dimension === 'load');

    if (hasBudgetIssue) {
      return {
        suggestion: '降级到本地模型或纯规则方案',
        qualityLoss: 0.15,
      };
    }

    if (hasToolIssue) {
      const unreliableTools = issues
        .filter(i => i.dimension === 'tool')
        .map(i => i.description);
      return {
        suggestion: `工具不可靠，考虑替代工具或跳过: ${unreliableTools.join(', ')}`,
        qualityLoss: 0.1,
      };
    }

    if (hasLoadIssue) {
      return {
        suggestion: '系统负载高，降级到轻量方案',
        qualityLoss: 0.1,
      };
    }

    return undefined;
  }
}
```

---

## 四、集成方式

### 4.1 ProposalCollector 增加 ResourceRequest

方案收集时，每个模块需要声明资源需求。两种方式：

**方式 A：模块自行声明（推荐）**

```typescript
// 组装引擎出方案时
const assemblyProposal: CandidateProposal = {
  source: 'assembly',
  content: result.text,
  rawConfidence: result.assemblyConfidence,
  // 新增：声明资源需求
  resourceRequest: {
    modelNeeds: { requiresLLM: false },
    toolNeeds: { requiredTools: [], optionalTools: [] },
    computeNeeds: { latencyClass: 'fast', requiresDAG: false, requiresToolChain: false },
    costEstimate: { estimatedTokens: 0, estimatedToolCalls: 0 },
  },
};

// LLM 方案
const llmProposal: CandidateProposal = {
  source: 'llm',
  content: llmResponse,
  rawConfidence: 0.8,
  resourceRequest: {
    modelNeeds: { requiresLLM: true, llmTier: 'capable' },
    toolNeeds: { requiredTools: [], optionalTools: [] },
    computeNeeds: { latencyClass: 'slow', requiresDAG: false, requiresToolChain: false },
    costEstimate: { estimatedTokens: 2000, estimatedToolCalls: 0 },
  },
};
```

**方式 B：FeasibilityChecker 推断（兜底）**

模块没声明时，FeasibilityChecker 根据 `source` 和 `signal` 推断：

```typescript
inferResourceRequest(proposal: CandidateProposal, signal: TaskSignal): ResourceRequest {
  // 规则方案：纯本地
  if (proposal.source === 'rule' || proposal.source === 'scheduler') {
    return {
      modelNeeds: { requiresLLM: false },
      toolNeeds: { requiredTools: [], optionalTools: [] },
      computeNeeds: { latencyClass: 'instant', requiresDAG: false, requiresToolChain: false },
      costEstimate: { estimatedTokens: 0, estimatedToolCalls: 0 },
    };
  }

  // 组装方案：本地检索，不需 LLM
  if (proposal.source === 'assembly') {
    return {
      modelNeeds: { requiresLLM: false },
      toolNeeds: { requiredTools: [], optionalTools: [] },
      computeNeeds: { latencyClass: 'fast', requiresDAG: false, requiresToolChain: false },
      costEstimate: { estimatedTokens: 0, estimatedToolCalls: 0 },
    };
  }

  // LLM 方案：需要 LLM
  if (proposal.source === 'llm') {
    return {
      modelNeeds: { requiresLLM: true, llmTier: 'capable' },
      toolNeeds: { requiredTools: [], optionalTools: [] },
      computeNeeds: { latencyClass: 'slow', requiresDAG: false, requiresToolChain: false },
      costEstimate: { estimatedTokens: 2000, estimatedToolCalls: 0 },
    };
  }

  // 默认：保守估计
  return {
    modelNeeds: { requiresLLM: false },
    toolNeeds: { requiredTools: [], optionalTools: [] },
    computeNeeds: { latencyClass: 'fast', requiresDAG: false, requiresToolChain: false },
    costEstimate: { estimatedTokens: 0, estimatedToolCalls: 0 },
  };
}
```

### 4.2 Arbiter 裁决公式修正

原公式（纯质量）：

```
score = calibratedConfidence
```

新公式（质量 × 可行性）：

```
feasibilityScore = feasibility.score  // 0 / 0.5-0.8 / 1.0
qualityScore = calibratedConfidence

finalScore = qualityScore * feasibilityWeight + feasibilityScore * (1 - feasibilityWeight)

其中 feasibilityWeight:
  - feasible: 0（不影响）
  - degraded: 0.3（降权 30%）
  - infeasible: 1.0（直接归零，排除）
```

更简单的实现——直接过滤 + 降权：

```typescript
arbitrate(proposals, feasibilityResults, context) {
  // 1. 过滤 infeasible
  const viable = proposals.filter(p => {
    const f = feasibilityResults.get(p.id);
    return f?.status !== 'infeasible';
  });

  // 2. 对 degraded 降权
  const scored = viable.map(p => {
    const f = feasibilityResults.get(p.id);
    const degradationPenalty = f?.status === 'degraded' ? (1 - f.score) * 0.5 : 0;
    return {
      ...p,
      finalScore: p.calibratedConfidence * (1 - degradationPenalty),
      feasibility: f,
    };
  });

  // 3. 按 finalScore 排序，选最优
  scored.sort((a, b) => b.finalScore - a.finalScore);
  return scored[0];
}
```

### 4.3 brain.ts 集成点

在 Step 3.5 裁决前插入可行性检查：

```typescript
// Step 3: 并行出方案（现有逻辑不变）
const [ruleResult, assemblyResult] = await Promise.allSettled([...]);

// Step 3.4: 可行性检查（新增）
const feasibilityChecker = new FeasibilityChecker();
const allProposals = this.collectProposals(scoredPlans, assemblyProposal);
const feasibilityResults = feasibilityChecker.checkBatch(
  allProposals.map(p => ({
    id: p.id,
    request: p.resourceRequest ?? this.inferResourceRequest(p, signal),
  })),
  resources,
  bodyState,
  signal,
);

// 过滤 infeasible，降级 degraded
const viableProposals = allProposals.filter(p => {
  const f = feasibilityResults.get(p.id);
  return f?.status !== 'infeasible';
});

if (viableProposals.length === 0) {
  // 所有方案都不可行 → 强制走 budget_fallback
  plan = await this.left.decide(signal, resources, intuition, bodyState);
  plan = { ...plan, source: 'budget_fallback', reason: '所有方案资源不足，降级到本地' };
} else {
  // Step 3.5: 裁决（现有逻辑，但用 viableProposals 替代原始 proposals）
  // ...
}
```

---

## 五、CandidateProposal 补充字段

在 `types.ts` 的 `CandidateProposal` 接口中增加：

```typescript
export interface CandidateProposal {
  source: 'assembly' | 'nn' | 'experience' | 'rule' | 'llm';
  content: string;
  plan?: ExecutionPlan;
  rawConfidence: number;
  calibratedConfidence: number;
  latencyMs: number;
  costEstimate: number;
  metadata: Record<string, unknown>;

  // ── 新增 ──
  /** 资源需求声明（模块自述，FeasibilityChecker 用） */
  resourceRequest?: ResourceRequest;
}
```

---

## 六、与现有模块的关系

| 现有模块 | 可行性检查如何使用 | 是否修改 |
|---------|-------------------|---------|
| `ResourceState.budgetRemaining` | 预算检查 | 不修改 |
| `ResourceState.toolHealth` | 工具可用性检查 | 不修改 |
| `BodyState.load` / `energy` / `hunger` | 负载 + 延迟检查 | 不修改 |
| `ResourcePool` | 不变，执行时仍用 | 不修改 |
| `DispatchExecutor` | 不变，可行性检查在它之前 | 不修改 |
| `ConfidenceCalibrator` | 不变，校准后的分数传给 Arbiter | 不修改 |
| `brain.ts` decide() | 在 Step 3.5 前插入可行性检查 | **修改** |

---

## 七、场景验证

### 场景 1: 预算耗尽，LLM 方案被排除

```
用户输入: "写一篇技术博客"
资源: budgetRemaining = 0

方案 A: 规则方案 (confidence=0.6) → feasible ✓
方案 B: 组装方案 (confidence=0.75) → feasible ✓
方案 C: LLM 方案 (confidence=0.9) → infeasible ✗ (预算=0)

裁决: 方案 B 胜出（组装引擎，不需要 LLM）
```

### 场景 2: 工具不可靠，降级方案

```
用户输入: "查一下天气然后发邮件"
资源: toolHealth.unreliableTools = ['email_sender']

方案 A: 工具链 [weather, email_sender] (confidence=0.8) → degraded ⚠ (email 不可靠)
方案 B: 纯规则回复 (confidence=0.5) → feasible ✓

裁决: 方案 A 降权后 0.8 * 0.7 = 0.56，仍高于 B → 选 A 但标记风险
```

### 场景 3: 系统高负载，禁止 heavy 方案

```
用户输入: "帮我分析这段代码"
资源: bodyState.load = 90, bodyState.energy = 15

方案 A: DAG 并行分析 (confidence=0.85, latencyClass=heavy) → infeasible ✗ (负载 90 + heavy)
方案 B: 单线程分析 (confidence=0.7, latencyClass=fast) → degraded ⚠ (精力低)
方案 C: 直接回复 (confidence=0.5, latencyClass=instant) → feasible ✓

裁决: 方案 B 胜出（降权后仍高于 C）
```

### 场景 4: 所有方案不可行 → 强制 fallback

```
用户输入: "帮我写个爬虫"
资源: budgetRemaining = 0, toolHealth.recentFailures = 15

方案 A: LLM 生成 (infeasible, 预算=0)
方案 B: 组装 + 工具执行 (degraded, 工具大量失败)
方案 C: 规则模板 (degraded, 质量低)

裁决: B 降权后 vs C 降权后 → 选 B，但标记"可能需要用户确认"
```

---

## 八、资源协商：向用户求助

### 8.1 核心思路

不可行 ≠ 只能降级。还可以**告诉用户缺什么，让用户决定**。

但**不能什么都问用户**——只在重大决策和关键资源缺口时才打扰。

```
所有方案检查完 → 有 infeasible 的
    ↓
自动降级能解决吗？（静默，不打扰用户）
├─ 能 → 直接降级，用户无感知（大多数情况）
└─ 不能 → 这是"重大"情况吗？（见下方门控规则）
          ├─ 不是 → 用最好的可行方案，静默处理
          └─ 是 → 向用户求助
```

### 8.2 重大性门控 — 什么时候才问用户

**原则：能自己解决的自己解决，只在"不问就出大问题"时才打扰。**

```typescript
/**
 * 重大性判定 — 决定是否值得打扰用户
 *
 * 三个条件满足任一才问用户：
 * 1. 任务完全无法完成（所有方案 infeasible + 降级也不行）
 * 2. 质量差距巨大（最优 vs 可行 差 30%+，且任务重要）
 * 3. 涉及外部资源变更（充值、授权、安装工具）
 *
 * 以下情况绝不打扰：
 * - 可行方案质量 ≥ 0.6（能用就行）
 * - 只是慢一点、差一点（用户不关心细节）
 * - 系统内部状态（负载、精力）→ 用户管不了
 */
function shouldAskUser(context: {
  feasibleProposals: Array<{ quality: number }>;
  bestInfeasibleQuality: number;
  taskImportance: 'critical' | 'normal' | 'trivial';
  gapType: string;
}): boolean {
  const { feasibleProposals, bestInfeasibleQuality, taskImportance, gapType } = context;

  // 规则 1: 没有任何可行方案 → 必须问
  if (feasibleProposals.length === 0) return true;

  // 规则 2: 可行方案质量够用（≥ 0.6）→ 不问
  const bestFeasible = Math.max(...feasibleProposals.map(p => p.quality));
  if (bestFeasible >= 0.6) return false;

  // 规则 3: 质量差距大 + 任务重要 → 问
  const qualityGap = bestInfeasibleQuality - bestFeasible;
  if (qualityGap >= 0.3 && taskImportance !== 'trivial') return true;

  // 规则 4: 需要外部资源变更（充值/授权）→ 问
  if (gapType === 'budget' || gapType === 'authorization') return true;

  // 其他情况 → 不问
  return false;
}
```

**门控规则表：**

| 场景 | 自动降级？ | 问用户？ | 原因 |
|------|-----------|---------|------|
| 有可行方案，质量 ≥ 0.6 | ✅ | ❌ | 能用就行 |
| 有可行方案，质量 0.4-0.6，任务普通 | ✅ | ❌ | 凑合用 |
| 有可行方案，质量 < 0.4，任务重要 | ❌ | ✅ | 质量太差，用户应知情 |
| 最优方案质量 0.9 但不可行，可行方案 0.5，任务重要 | ❌ | ✅ | 差距 0.4，值得告诉用户 |
| 最优方案质量 0.9 但不可行，可行方案 0.7 | ✅ | ❌ | 差距只有 0.2，不值得打扰 |
| 所有方案不可行 | ❌ | ✅ | 任务完不成 |
| 预算=0，需要 LLM | ❌ | ✅ | 涉及外部资源（充值） |
| 工具不可靠 | ✅ | ❌ | 自动跳过不可靠工具 |
| 系统负载高 | ✅ | ❌ | 自动选轻量方案 |
| 精力低 | ✅ | ❌ | 用户管不了 |

**一句话总结：用户只关心"能不能做好"和"要不要花钱"，不关心"用哪个工具"和"系统负载多少"。**

### 8.3 ResourceNegotiator 模块

```typescript
/**
 * 资源协商结果
 */
export interface NegotiationResult {
  /** 协商动作 */
  action: 'ask_user' | 'auto_degrade' | 'defer' | 'proceed_with_risk';
  /** 给用户的消息（ask_user 时有值） */
  messageToUser?: string;
  /** 用户可选的回复选项 */
  options?: Array<{
    id: string;
    label: string;
    /** 选择后的后果 */
    consequence: 'retry' | 'degrade' | 'defer' | 'abort';
    description: string;
  }>;
  /** 降级方案（auto_degrade 时使用） */
  degradedPlan?: ExecutionPlan;
  /** 需要用户提供的信息（ask_user 时，补充说明） */
  requiredInfo?: string[];
}

/**
 * 资源协商器
 *
 * 核心原则：大多数情况自动降级，只在"重大"情况才打扰用户。
 *
 * 重大性门控（shouldAskUser）：
 * - 所有方案不可行 → 必须问
 * - 质量差距 ≥ 0.3 + 任务重要 → 问
 * - 需要外部资源变更（充值/授权）→ 问
 * - 可行方案质量 ≥ 0.6 → 不问（能用就行）
 * - 系统内部状态（负载/精力）→ 不问（用户管不了）
 */
export class ResourceNegotiator {

  negotiate(
    infeasibleProposals: Array<{
      id: string;
      source: string;
      confidence: number;
      feasibility: FeasibilityResult;
    }>,
    feasibleProposals: Array<{
      id: string;
      source: string;
      confidence: number;
    }>,
    resources: ResourceState,
    bodyState: BodyState,
    taskImportance: 'critical' | 'normal' | 'trivial' = 'normal',
  ): NegotiationResult {
    const bestFeasible = feasibleProposals.sort((a, b) => b.confidence - a.confidence)[0];
    const bestInfeasible = infeasibleProposals.sort((a, b) => b.confidence - a.confidence)[0];
    const bestFeasibleQuality = bestFeasible?.confidence ?? 0;
    const bestInfeasibleQuality = bestInfeasible?.confidence ?? 0;

    // ── 重大性门控 ──
    const allGaps = infeasibleProposals.flatMap(p => p.feasibility.reasons);
    const primaryGap = this.findPrimaryGap(allGaps);
    const gapType = primaryGap?.dimension ?? 'none';

    const isMajor = this.shouldAskUser({
      feasibleCount: feasibleProposals.length,
      bestFeasibleQuality,
      bestInfeasibleQuality,
      taskImportance,
      gapType,
    });

    // ── 不重大 → 静默处理 ──
    if (!isMajor) {
      // 有可行方案 → 直接用最好的
      if (bestFeasible) {
        return { action: 'auto_degrade' };
      }
      // 没有可行方案但也不重大 → 降级兜底
      return {
        action: 'auto_degrade',
        messageToUser: primaryGap ? `资源限制: ${primaryGap.description}，已自动降级。` : undefined,
      };
    }

    // ── 重大 → 向用户求助 ──
    if (feasibleProposals.length === 0 && primaryGap) {
      // 所有方案不可行
      const negotiation = this.buildNegotiation(primaryGap, resources, bodyState);
      if (negotiation) return negotiation;
    }

    if (bestInfeasible && bestInfeasibleQuality - bestFeasibleQuality >= 0.3) {
      // 最优方案远好于可行方案
      const gap = this.analyzeGap(bestInfeasible.feasibility);
      return {
        action: 'ask_user',
        messageToUser: `当前方案质量一般(${bestFeasibleQuality.toFixed(1)})，但更好的方案${gap.description}。`,
        options: [
          { id: 'use_current', label: '用当前方案', consequence: 'degrade', description: '质量差一点但能用' },
          { id: 'try_better', label: '用更好的', consequence: 'retry', description: gap.userAction },
        ],
      };
    }

    // 兜底
    return { action: 'auto_degrade' };
  }

  /**
   * 重大性判定 — 是否值得打扰用户
   */
  private shouldAskUser(ctx: {
    feasibleCount: number;
    bestFeasibleQuality: number;
    bestInfeasibleQuality: number;
    taskImportance: 'critical' | 'normal' | 'trivial';
    gapType: string;
  }): boolean {
    const { feasibleCount, bestFeasibleQuality, bestInfeasibleQuality, taskImportance, gapType } = ctx;

    // 规则 1: 没有任何可行方案 → 必须问
    if (feasibleCount === 0) return true;

    // 规则 2: 可行方案质量够用（≥ 0.6）→ 不问
    if (bestFeasibleQuality >= 0.6) return false;

    // 规则 3: 质量差距大 + 任务重要 → 问
    const qualityGap = bestInfeasibleQuality - bestFeasibleQuality;
    if (qualityGap >= 0.3 && taskImportance !== 'trivial') return true;

    // 规则 4: 需要外部资源变更（充值/授权）→ 问
    if (gapType === 'budget' || gapType === 'authorization') return true;

    // 其他 → 不问
    return false;
  }

  // ==================== 缺口分析 ====================

  private analyzeGap(feasibility: FeasibilityResult): {
    canAskUser: boolean;
    description: string;
    userAction: string;
  } {
    const issues = feasibility.reasons;

    // 预算问题 → 可以问（涉及外部资源）
    const budgetIssue = issues.find(i => i.dimension === 'budget');
    if (budgetIssue) {
      return {
        canAskUser: true,
        description: '需要 LLM 但预算不足',
        userAction: '充值预算后重试',
      };
    }

    // 模型能力不足 → 可以问（用户可以选择是否用更强的模型）
    const modelIssue = issues.find(i => i.dimension === 'model');
    if (modelIssue) {
      return {
        canAskUser: true,
        description: '本地能力不足',
        userAction: '调用云端 LLM',
      };
    }

    // 工具问题 → 不问用户（自动降级，用户管不了）
    const toolIssue = issues.find(i => i.dimension === 'tool');
    if (toolIssue) {
      return {
        canAskUser: false,
        description: `工具不可靠，已自动跳过`,
        userAction: '',
      };
    }

    // 负载/延迟 → 不问用户（系统内部状态，用户管不了）
    return {
      canAskUser: false,
      description: '系统资源限制，已自动降级',
      userAction: '',
    };
  }

  private findPrimaryGap(issues: FeasibilityIssue[]): FeasibilityIssue | null {
    // 优先级: block > warn, budget > tool > model > load > latency
    const priority: Record<string, number> = {
      'budget_block': 100,
      'tool_block': 90,
      'model_block': 80,
      'load_block': 70,
      'budget_warn': 60,
      'tool_warn': 50,
      'latency_warn': 40,
      'load_warn': 30,
      'model_warn': 20,
    };

    const sorted = issues.sort((a, b) => {
      const keyA = `${a.dimension}_${a.severity}`;
      const keyB = `${b.dimension}_${b.severity}`;
      return (priority[keyB] ?? 0) - (priority[keyA] ?? 0);
    });

    return sorted[0] ?? null;
  }

  private buildNegotiation(
    gap: FeasibilityIssue,
    resources: ResourceState,
    bodyState: BodyState,
  ): NegotiationResult | null {
    // 预算耗尽 → 问用户要不要充值
    if (gap.dimension === 'budget' && gap.severity === 'block') {
      return {
        action: 'ask_user',
        messageToUser: '这个任务需要调用云端 LLM，但预算已用完。',
        options: [
          { id: 'recharge', label: '充值后重试', consequence: 'retry', description: '充值预算，用最好的方案完成' },
          { id: 'local_only', label: '用本地方案', consequence: 'degrade', description: '不花钱，用本地能力凑合一下' },
          { id: 'skip', label: '算了', consequence: 'abort', description: '不做这个任务了' },
        ],
      };
    }

    // 模型能力不足 → 问用户要不要调用更强的模型
    if (gap.dimension === 'model') {
      return {
        action: 'ask_user',
        messageToUser: '这个问题我不太确定怎么回答。',
        options: [
          { id: 'use_llm', label: '用云端 LLM', consequence: 'retry', description: '调用更聪明的模型，需要预算' },
          { id: 'try_local', label: '先试试本地', consequence: 'degrade', description: '用本地能力回答，可能不太准' },
        ],
      };
    }

    // 工具/负载/延迟 → 不问用户，自动降级
    return null;
  }

  private buildDegradationExplanation(issues: FeasibilityIssue[]): string {
    const descriptions = issues
      .filter(i => i.severity === 'block')
      .map(i => i.description);

    if (descriptions.length === 0) return '';

    return `资源限制: ${descriptions.join('; ')}。已自动降级到可用方案。`;
  }
}
```

### 8.4 用户回复处理

```typescript
/**
 * 处理用户对资源协商的回复
 */
async handleNegotiationReply(
  reply: 'recharge' | 'local_only' | 'skip' | 'try_anyway' | 'alternative' | 'wait' | 'quick' | 'use_llm' | 'try_local',
  context: NegotiationContext,
): Promise<ExecutionPlan> {
  switch (reply) {
    case 'recharge':
      // 用户充值了 → 重新检查可行性，走正常流程
      return this.redecideWithFreshResources(context);

    case 'local_only':
    case 'try_local':
    case 'alternative':
    case 'quick':
      // 用户接受降级 → 走降级方案
      return this.executeDegraded(context);

    case 'try_anyway':
      // 用户要求冒险 → 标记 risk，正常执行
      return this.executeWithRiskFlag(context);

    case 'wait':
    case 'defer':
      // 用户愿意等 → 挂起任务
      return this.deferTask(context);

    case 'skip':
    case 'abort':
      // 用户放弃 → 返回告知
      return this.abortTask(context);

    default:
      return this.executeDegraded(context);
  }
}
```

### 8.5 与审议委员会的关系

ResourceNegotiator 可以复用审议委员会的"问用户"能力：

- 审议委员会的 `action: 'clarify'` → 问用户澄清意图
- ResourceNegotiator 的 `action: 'ask_user'` → 问用户获取资源

两者都是"需要用户输入才能继续"，可以统一走审议委员会的用户交互通道，避免重复实现消息发送。

```
审议委员会: "你的意思是？" → 用户回复 → 继续决策
资源协商器: "预算不够，要充值吗？" → 用户回复 → 继续执行
```

---

## 九、实现顺序

```
DISPATCH_REFORM_PLAN Phase 2（方案收集器 + 裁决器）
  ↓
本补充方案（可行性检查）← 紧跟 Phase 2
  ↓
Phase 3（调度协调器）
```

**工作量**: 1-2 天（新增 1 个文件 `feasibility.ts`，修改 `brain.ts` 1 处，修改 `types.ts` 1 处）

**验收标准**:
- `budgetRemaining = 0` 时，LLM 方案不参与裁决
- `toolHealth.unreliableTools` 包含某工具时，依赖该工具的方案降权
- `bodyState.load > 80` 时，heavy 方案被排除
- 所有方案 infeasible 时，走 `budget_fallback` 而非崩溃
