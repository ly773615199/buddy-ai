# ResourceHub 资源画像优化计划

> 基于 2026-05-25 代码审计发现的问题，制定系统性优化方案

---

## 📋 问题清单

| # | 问题 | 严重度 | 影响范围 |
|---|------|--------|----------|
| P1 | 云端 LLM 调用结果未记录到 ResourceHub | 🔴 高 | 云端模型评估永远是默认值 |
| P2 | 动态添加的工具/技能不同步到 ResourceHub | 🔴 高 | 新工具不会被推荐系统发现 |
| P3 | 三进制领域模型无独立 ResourceHub 画像 | 🟡 中 | 无法追踪单个领域模型表现 |
| P4 | syncResources 仅初始化时调用一次 | 🟡 中 | 运行时新增资源全部遗漏 |
| P5 | 三进制模型成长状态未接入 ResourceHub | 🟡 中 | 成长阶段与评估系统割裂 |
| P6 | MCP 工具断开后 ResourceHub 残留 | 🟢 低 | 残留资源可能误导推荐 |

---

## 🎯 优化目标

```
目标: 所有资源（静态 + 动态 + 云端 + 本地）统一纳入 ResourceHub 管理
      画像实时更新，推荐系统基于完整数据做决策
```

---

## 📐 架构设计

### 核心原则

```
┌─────────────────────────────────────────────────────────────┐
│                    资源生命周期管理                           │
├─────────────────────────────────────────────────────────────┤
│  注册 ──→ 激活 ──→ 使用 ──→ 画像更新 ──→ 推荐/淘汰         │
│    ↑                  ↑                                     │
│    │                  │                                     │
│  动态发现          反馈闭环                                  │
│  (热注册)          (recordOutcome)                           │
└─────────────────────────────────────────────────────────────┘
```

### 统一注册入口

```typescript
// 新增: ResourceRegistry — 统一资源注册中心
interface ResourceRegistry {
  // 注册资源（幂等，已存在则更新）
  register(entry: ResourceRegistration): void;
  
  // 批量同步（ToolRegistry → ResourceHub）
  syncFromToolRegistry(registry: ToolRegistry): void;
  
  // 注销资源
  unregister(resourceId: string): void;
  
  // 监听资源变化
  onResourceChange(callback: (event: ResourceEvent) => void): void;
}
```

---

## 🔧 详细优化方案

### P1: 云端 LLM 画像闭环

**问题**: `feedback()` 函数记录了工具、引擎、策略、混合策略的执行结果，但遗漏了云端 LLM。

**方案**: 在 `feedback()` 中增加云端 LLM 结果记录

**文件**: `src/brain/brain.ts`

```typescript
// 新增: 记录云端 LLM 执行结果
if (plan.source === 'cloud' || plan.source === 'cloud_compete' || 
    plan.source === 'cloud_fallback' || outcome.usedCloudLLM) {
  
  // 获取实际使用的云端模型 ID
  const cloudModelId = outcome.cloudModelId ?? `cloud_llm:${plan.cloudProvider}/${plan.cloudModel}`;
  
  this.resourceHub.recordOutcome(cloudModelId, {
    success: outcome.success,
    qualityScore: hubQualityScore,
    latencyMs: outcome.latencyMs,
    costEstimate: outcome.costEstimate,
    scenario: signal.taskType,
  });
}
```

**配套修改**:
- `DecisionOutcome` 接口增加 `usedCloudLLM?: boolean` 和 `cloudModelId?: string`
- `CloudLLMExecutor.execute()` 返回结果中携带模型 ID
- `feedback()` 函数签名增加云端模型信息

**验收标准**:
- [ ] 云端 LLM 调用后，`resourceHub.getProfile('cloud_llm:openai/gpt-4o')` 的 `totalCalls` 增加
- [ ] 多次调用后，`assessment.capability` 不再是固定的 0.5
- [ ] 失败调用会导致 `reliability` 下降

---

### P2: 动态资源热注册

**问题**: REST API / MCP / .skillmate 添加的工具只注册到 ToolRegistry，不注册到 ResourceHub。

**方案**: 创建统一的资源同步机制

**文件**: 新增 `src/brain/hub/resource-sync.ts`

```typescript
/**
 * ResourceSync — 资源热同步器
 *
 * 监听 ToolRegistry 变化，自动同步到 ResourceHub
 */
export class ResourceSync {
  private hub: ResourceHub;
  private registeredIds: Set<string> = new Set();
  
  constructor(hub: ResourceHub) {
    this.hub = hub;
  }
  
  /**
   * 全量同步 — 启动时调用一次
   */
  fullSync(tools: ToolRegistry, knowledgeSources?: KnowledgeSourceManager): void {
    // 同步工具
    for (const tool of tools.list()) {
      this.syncTool(tool);
    }
    
    // 同步知识源
    if (knowledgeSources) {
      for (const source of knowledgeSources.getSources()) {
        this.syncKnowledgeSource(source);
      }
    }
  }
  
  /**
   * 增量同步 — 单个工具注册时调用
   */
  syncTool(tool: { name: string; description?: string }): void {
    const id = `tool:${tool.name}`;
    if (this.registeredIds.has(id)) return;
    
    this.hub.register({
      id,
      type: 'tool',
      name: tool.name,
      capabilities: {
        type: 'tool',
        toolName: tool.name,
        category: this.inferCategory(tool.name),
        hasSideEffects: this.inferSideEffects(tool.name),
        requiresConfirmation: false,
        avgLatencyMs: 0,
        parameters: [],
      },
    });
    
    this.registeredIds.add(id);
  }
  
  /**
   * 注销工具 — MCP 断开 / 工具删除时调用
   */
  unsyncTool(toolName: string): void {
    const id = `tool:${toolName}`;
    this.hub.unregister(id);
    this.registeredIds.delete(id);
  }
}
```

**集成点**:

```typescript
// src/core/rest-api.ts — POST /api/config/custom-tools
sys.tools.registerMany(createHttpApiTools([newTool]));
resourceSync.syncTool(newTool);  // 新增

// src/main.ts — /mcp-connect
agent.getToolRegistry().registerMany(defs);
for (const tool of tools) {
  resourceSync.syncTool(tool);  // 新增
}

// src/main.ts — /mcp-disconnect
for (const toolName of toolNames) {
  resourceSync.unsyncTool(toolName);  // 新增
}

// src/skills/skill-manager.ts — registerAll()
registerAll(registry, resourceSync?: ResourceSync): number {
  for (const [toolName, skill] of this.skills) {
    registry.register(toolDef);
    resourceSync?.syncTool(toolDef);  // 新增
  }
}
```

**验收标准**:
- [ ] 通过 REST API 添加自定义工具后，ResourceHub 中有对应条目
- [ ] MCP 连接后，MCP 工具出现在 ResourceHub
- [ ] MCP 断开后，MCP 工具从 ResourceHub 移除
- [ ] .skillmate 文件放入目录后重启，技能出现在 ResourceHub

---

### P3: 三进制领域模型独立画像

**问题**: 三进制领域模型只注册到 LLMRouter，没有注册到 ResourceHub。

**方案**: 在 TernaryExpertRouter 中集成 ResourceHub

**文件**: `src/tools/ternary-expert.ts`

```typescript
export class TernaryExpertRouter {
  private manager: TernaryModelManager;
  private engines: Map<string, TernaryEngine> = new Map();
  private resourceHub: ResourceHub | null = null;  // 新增
  
  // 新增: 注入 ResourceHub
  setResourceHub(hub: ResourceHub): void {
    this.resourceHub = hub;
  }
  
  async init(): Promise<void> {
    await this.manager.init();
    
    const models = this.manager.list();
    for (const meta of models) {
      if (meta.growthStage === 'mature' || meta.growthStage === 'trainable') {
        await this.loadEngine(meta.domain);
      }
      
      // 新增: 注册到 ResourceHub
      this.registerToResourceHub(meta);
    }
  }
  
  // 新增: 注册单个领域模型到 ResourceHub
  private registerToResourceHub(meta: TernaryModelMeta): void {
    if (!this.resourceHub) return;
    
    this.resourceHub.register({
      id: `ternary:${meta.domain}`,
      type: 'local_model' as ResourceType,
      name: `${meta.domain} 专家`,
      capabilities: {
        type: 'local_model',
        modelType: 'buddyLM',
        parameterCount: meta.totalParams,
        supportsTools: false,
        maxContextTokens: 512,
        strengths: [meta.domain],
        weaknesses: meta.growthStage === 'seed' ? ['untrained'] : [],
      },
    });
  }
  
  // 修改: query 方法记录执行结果
  async query(domain: string, question: string): Promise<TernaryQueryResult> {
    const startTime = Date.now();
    
    try {
      const result = await this.doQuery(domain, question);
      const latencyMs = Date.now() - startTime;
      
      // 新增: 记录成功结果到 ResourceHub
      this.resourceHub?.recordOutcome(`ternary:${domain}`, {
        success: true,
        qualityScore: result.confidence,
        latencyMs,
        scenario: 'ternary_query',
      });
      
      return result;
    } catch (err) {
      const latencyMs = Date.now() - startTime;
      
      // 新增: 记录失败结果到 ResourceHub
      this.resourceHub?.recordOutcome(`ternary:${domain}`, {
        success: false,
        qualityScore: 0.1,
        latencyMs,
        scenario: 'ternary_query',
        errorMessage: (err as Error).message,
      });
      
      throw err;
    }
  }
}
```

**集成点**:

```typescript
// src/core/subsystems.ts
this.ternaryRouter.setResourceHub(this.threeBrain.resourceHub);  // 新增
await this.ternaryRouter.init();
```

**验收标准**:
- [ ] 初始化后，ResourceHub 中有 `ternary:{domain}` 条目
- [ ] 每次查询后，对应领域的 `totalCalls` 增加
- [ ] 成长阶段变化时，ResourceHub 中的 `strengths`/`weaknesses` 更新

---

### P4: 资源热同步机制

**问题**: `syncResources()` 仅在初始化时调用一次。

**方案**: 改为事件驱动的增量同步

**文件**: `src/brain/brain.ts`

```typescript
// 新增: 资源变化监听器
private resourceSync: ResourceSync;

constructor(config?: ThreeBrainConfig) {
  // ... 现有代码 ...
  
  // 初始化资源同步器
  this.resourceSync = new ResourceSync(this.resourceHub);
}

// 修改: syncResources 改为首次全量同步 + 后续增量同步
syncResources(sys: ResourceSyncSources): void {
  // 首次全量同步
  this.resourceSync.fullSync(sys.tools, sys.knowledgeSources);
  
  // 注册变化监听器（后续增量同步）
  sys.tools.onRegister?.((tool) => {
    this.resourceSync.syncTool(tool);
  });
  
  sys.tools.onUnregister?.((toolName) => {
    this.resourceSync.unsyncTool(toolName);
  });
  
  // ... 现有的平台、TTS 同步 ...
}
```

**验收标准**:
- [ ] 初始化时全量同步
- [ ] 运行时新增工具自动同步
- [ ] 运行时删除工具自动注销

---

### P5: 三进制成长状态接入

**问题**: 三进制的成长阶段（seed/sprout/growing/trainable/mature）与 ResourceHub 评估系统割裂。

**方案**: 成长阶段变化时更新 ResourceHub 评估

**文件**: `src/tools/ternary-expert.ts`

```typescript
// 新增: 成长阶段变化回调
onGrowthStageChange(domain: string, oldStage: string, newStage: string): void {
  if (!this.resourceHub) return;
  
  const profile = this.resourceHub.getProfile(`ternary:${domain}`);
  if (!profile) return;
  
  // 根据成长阶段调整评估
  const stageScores: Record<string, number> = {
    'seed': 0.1,       // 种子阶段：不可用
    'sprout': 0.3,     // 发芽阶段：勉强可用
    'growing': 0.5,    // 成长阶段：中等能力
    'trainable': 0.7,  // 可训练：较好能力
    'mature': 0.9,     // 成熟：高能力
  };
  
  const capability = stageScores[newStage] ?? 0.5;
  
  // 直接更新评估（绕过 recordOutcome，因为这不是调用结果）
  profile.assessment.capability = capability;
  profile.assessment.reliability = capability * 0.8;
  profile.assessment.confidence = 0.6;  // 成长阶段变化是可靠信号
  
  // 更新 capabilities
  if (profile.capabilities.type === 'local_model') {
    profile.capabilities.strengths = newStage === 'mature' 
      ? [domain, 'production_ready'] 
      : [domain];
    profile.capabilities.weaknesses = newStage === 'seed' 
      ? ['untrained'] 
      : newStage === 'sprout' ? ['limited_data'] : [];
  }
}
```

**集成点**:

```typescript
// src/ternary/growth.ts — evaluateGrowth()
if (newStage !== oldStage) {
  model.meta.growthStage = newStage;
  
  // 新增: 通知 ResourceHub
  this.onStageChange?.(model.meta.domain, oldStage, newStage);
  
  return { changed: true, oldStage, newStage };
}
```

**验收标准**:
- [ ] 模型从 seed → sprout 时，ResourceHub 中对应条目 `capability` 从 0.1 升至 0.3
- [ ] 模型达到 mature 时，`capability` 达到 0.9
- [ ] 成长阶段变化后，推荐系统能正确评估该模型

---

### P6: 资源注销清理

**问题**: MCP 工具断开后，ResourceHub 中残留无用条目。

**方案**: ResourceHub 增加 `unregister()` 方法

**文件**: `src/brain/hub/resource-hub.ts`

```typescript
/**
 * 注销资源 — 从 ResourceHub 中移除
 */
unregister(resourceId: string): boolean {
  const entry = this.resources.get(resourceId);
  if (!entry) return false;
  
  this.resources.delete(resourceId);
  log.info(`资源注销: ${resourceId} (${entry.type})`);
  
  return true;
}

/**
 * 批量注销指定类型的所有资源
 */
unregisterByType(type: ResourceType): number {
  const toRemove = [...this.resources.values()]
    .filter(r => r.type === type)
    .map(r => r.id);
  
  for (const id of toRemove) {
    this.resources.delete(id);
  }
  
  if (toRemove.length > 0) {
    log.info(`批量注销 ${toRemove.length} 个 ${type} 类型资源`);
  }
  
  return toRemove.length;
}

/**
 * 标记资源为待清理（延迟删除，避免误删）
 */
markForCleanup(resourceId: string): void {
  const entry = this.resources.get(resourceId);
  if (!entry) return;
  
  entry.status = 'dormant';
  entry.lastUsedAt = 0;  // 重置使用时间，加速衰减
  
  // 设置自动清理定时器（24小时后如果仍未使用则删除）
  setTimeout(() => {
    const current = this.resources.get(resourceId);
    if (current && current.status === 'dormant' && current.lastUsedAt === 0) {
      this.unregister(resourceId);
    }
  }, 24 * 3600 * 1000);
}
```

**验收标准**:
- [ ] MCP 断开后，对应工具从 ResourceHub 移除
- [ ] 自定义工具删除后，对应条目从 ResourceHub 移除
- [ ] 不会误删仍在使用的资源

---

## 📊 实施计划

### 阶段 1: 核心闭环（1-2 天）

| 任务 | 优先级 | 文件 | 预计工时 |
|------|--------|------|----------|
| P1: 云端 LLM 画像记录 | 🔴 P0 | brain.ts | 2h |
| P2: ResourceSync 创建 | 🔴 P0 | 新增 resource-sync.ts | 3h |
| P2: ToolRegistry 钩子 | 🔴 P0 | registry.ts | 1h |
| P6: unregister 方法 | 🟢 P2 | resource-hub.ts | 1h |

### 阶段 2: 三进制集成（1 天）

| 任务 | 优先级 | 文件 | 预计工时 |
|------|--------|------|----------|
| P3: 三进制模型注册 | 🟡 P1 | ternary-expert.ts | 2h |
| P3: 查询结果记录 | 🟡 P1 | ternary-expert.ts | 1h |
| P5: 成长状态接入 | 🟡 P1 | growth.ts + ternary-expert.ts | 2h |

### 阶段 3: 热同步完善（1 天）

| 任务 | 优先级 | 文件 | 预计工时 |
|------|--------|------|----------|
| P4: 事件驱动同步 | 🟡 P1 | brain.ts + subsystems.ts | 2h |
| P2: MCP 生命周期钩子 | 🔴 P0 | main.ts | 1h |
| P2: SkillManager 钩子 | 🟡 P1 | skill-manager.ts | 1h |
| P6: 延迟清理机制 | 🟢 P2 | resource-hub.ts | 1h |

### 阶段 4: 测试验证（1 天）

| 任务 | 优先级 | 文件 | 预计工时 |
|------|--------|------|----------|
| 单元测试 | 🔴 P0 | resource-sync.test.ts | 2h |
| 集成测试 | 🟡 P1 | e2e/resource-hub.test.ts | 2h |
| 手动验证 | 🟡 P1 | — | 1h |

---

## 🎯 验收场景

### 场景 1: 云端 LLM 画像更新

```
1. 配置 OpenAI API Key
2. 发送 10 次需要云端 LLM 的请求
3. 检查 ResourceHub:
   - cloud_llm:openai/gpt-4o.totalCalls === 10
   - cloud_llm:openai/gpt-4o.assessment.capability !== 0.5
   - cloud_llm:openai/gpt-4o.assessment.confidence > 0.1
```

### 场景 2: 动态工具热注册

```
1. 通过 REST API 添加自定义工具 "my_tool"
2. 检查 ResourceHub:
   - tool:my_tool 存在
   - tool:my_tool.status === 'active'
3. 调用 my_tool 3 次
4. 检查 ResourceHub:
   - tool:my_tool.totalCalls === 3
   - tool:my_tool.assessment.capability 基于实际结果
5. 删除 my_tool
6. 检查 ResourceHub:
   - tool:my_tool 不存在
```

### 场景 3: 三进制模型画像

```
1. 初始化三进制系统（有 3 个领域模型）
2. 检查 ResourceHub:
   - ternary:Go开发 存在
   - ternary:法务 存在
   - ternary:医疗 存在
3. 查询 Go开发 专家 5 次
4. 检查 ResourceHub:
   - ternary:Go开发.totalCalls === 5
   - ternary:Go开发.assessment.capability 基于查询结果
5. Go开发 模型从 trainable → mature
6. 检查 ResourceHub:
   - ternary:Go开发.assessment.capability 显著提升
```

---

## 📈 预期收益

| 指标 | 优化前 | 优化后 |
|------|--------|--------|
| ResourceHub 资源覆盖率 | 79/79 (静态) | 79 + 动态资源 |
| 云端 LLM 评估准确性 | 0% (固定默认值) | 100% (基于实际数据) |
| 新工具可发现性 | 0% (不被推荐) | 100% (立即可推荐) |
| 三进制模型可追踪性 | 0% (无画像) | 100% (独立画像) |
| 资源生命周期完整性 | 60% (只有注册) | 100% (注册→使用→注销) |

---

## 🔓 设计局限破局方案

### 局限 1: 新资源场景分默认 0.3 → 被低估

**当前代码:**
```typescript
const scenarioScore = scenarioStats && scenarioStats.hits >= 3
  ? scenarioStats.successes / scenarioStats.hits
  : 0.3;  // ← 太低，新资源被歧视
```

**改进: 渐进式信任模型**
```typescript
// 按资源类型设置差异化默认值
const DEFAULT_SCENARIO_SCORES: Record<ResourceType, number> = {
  cloud_llm:   0.6,   // 云端模型默认较高信任
  local_model: 0.5,   // 本地模型中性
  engine:      0.5,   // 引擎中性
  tool:        0.55,  // 工具略高（通常可靠）
  skill:       0.4,   // 技能包较低（质量参差）
  knowledge:   0.45,  // 知识源略低
  system:      0.6,   // 系统资源默认高信任
};

const scenarioScore = scenarioStats && scenarioStats.hits >= 3
  ? scenarioStats.successes / scenarioStats.hits
  : DEFAULT_SCENARIO_SCORES[resource.type] ?? 0.5;

// 首因效应: 首次成功给予额外加成
if (scenarioStats.hits === 1 && scenarioStats.successes === 1) {
  return 0.7;  // 首次成功 → 高于中性
}
```

**影响:** 新工具首次成功后不再被低估

---

### 局限 2: Confidence 调制系数 1.5 → 过度放大

**当前代码:**
```typescript
const modulated = (raw: number) => 0.5 + (raw - 0.5) * Math.min(1, confidence * 1.5);
// confidence=0.8 时已饱和到 1.0，没有渐进效果
```

**改进: 对数曲线调制**
```typescript
function modulated(raw: number, confidence: number): number {
  const factor = Math.log1p(confidence * 4) / Math.log1p(4);  // 归一化到 0-1
  return 0.5 + (raw - 0.5) * factor;
}

// 对比:
// confidence  当前线性    改进对数
// 0.1         0.15       0.09
// 0.3         0.45       0.24
// 0.5         0.75       0.37
// 0.8         1.00       0.53
// 1.0         1.00       0.61
```

**影响:** 高置信度时不再过度放大，保持渐进性

---

### 局限 3: Speed 基线硬编码 → 环境差异大

**当前代码:**
```typescript
const baselines: Record<ResourceType, number> = {
  cloud_llm: 3000, tool: 500, // ... 固定值
};
```

**改进: 自适应 P50/P90 基线**
```typescript
class AdaptiveBaseline {
  private samples: Map<ResourceType, number[]> = new Map();

  record(type: ResourceType, latencyMs: number): void {
    if (!this.samples.has(type)) this.samples.set(type, []);
    const arr = this.samples.get(type)!;
    arr.push(latencyMs);
    if (arr.length > 1000) arr.shift();
  }

  getBaseline(type: ResourceType): number {
    const arr = this.samples.get(type);
    if (!arr || arr.length < 10) return DEFAULT_BASELINES[type];
    const sorted = [...arr].sort((a, b) => a - b);
    return sorted[Math.floor(sorted.length * 0.5)];  // P50
  }

  getRelaxedBaseline(type: ResourceType): number {
    const arr = this.samples.get(type);
    if (!arr || arr.length < 10) return DEFAULT_BASELINES[type] * 3;
    const sorted = [...arr].sort((a, b) => a - b);
    return sorted[Math.floor(sorted.length * 0.9)];  // P90
  }
}

function normalizeLatency(latencyMs: number, type: ResourceType): number {
  const p50 = baseline.getBaseline(type);
  const p90 = baseline.getRelaxedBaseline(type);

  if (latencyMs <= p50) return 0.9 + 0.1 * (1 - latencyMs / p50);
  if (latencyMs <= p90) return 0.5 + 0.4 * (1 - (latencyMs - p50) / (p90 - p50));
  return Math.max(0, 0.5 * (1 - (latencyMs - p90) / p90));
}
```

**影响:** 不同环境自动适应，不再一刀切

---

### 局限 4: CostEfficiency 仅云端有效 → 本地资源无意义

**当前代码:**
```typescript
// 所有资源都计算 costEfficiency，本地资源永远 0.5
const costEfficiency = ex.costWindow.length > 0
  ? 1 - Math.min(1, this.weightedAvg(ex.costWindow) / this.config.maxAcceptableCost)
  : 0.5;
```

**改进: 成本感知分离**
```typescript
function computeCostEfficiency(entry: ResourceEntry): number | null {
  const noCostTypes: ResourceType[] = ['local_model', 'engine', 'system'];
  if (noCostTypes.includes(entry.type)) return null;  // 本地资源跳过

  if (entry.execution.costWindow.length === 0) return 0.5;
  const avgCost = this.weightedAvg(entry.execution.costWindow);
  return 1 - Math.min(1, avgCost / this.config.maxAcceptableCost);
}

// 推荐评分: 有成本数据时纳入，无成本数据时重新分配权重
const weights = costEff !== null
  ? { cap: 0.30, rel: 0.25, scene: 0.20, speed: 0.15, cost: 0.10 }
  : { cap: 0.33, rel: 0.28, scene: 0.22, speed: 0.17, cost: 0 };
```

**影响:** 本地资源不再被无意义的成本维度稀释

---

### 局限 5: 场景判断阈值固定 3 次 → 高低频不公平

**当前代码:**
```typescript
if (stats.hits >= 3) {  // 固定阈值，高频太容易，低频太难
  if (rate > 0.7) suitableFor.push(scenario);
  if (rate < 0.3) notSuitableFor.push(scenario);
}
```

**改进: 贝叶斯平滑 + 自适应阈值**
```typescript
// 贝叶斯平滑: 小样本时用先验，大样本时用实际数据
function bayesianRate(successes: number, hits: number): number {
  const priorAlpha = 2;  // Beta 分布先验
  const priorBeta = 2;
  return (priorAlpha + successes) / (priorAlpha + priorBeta + hits);
}

// 自适应阈值: 按场景频率动态调整
function getAdaptiveThreshold(scenario: string, totalHits: number): number {
  const baseThreshold = 3;
  const frequencyFactor = Math.log2(Math.max(1, totalHits / 10));
  return Math.max(3, Math.floor(baseThreshold + frequencyFactor));
}

// 使用:
if (stats.hits >= 1) {  // 至少 1 次就可以判断
  const rate = bayesianRate(stats.successes, stats.hits);
  const confidence = Math.min(1, stats.hits / 10);

  if (rate > 0.7 && confidence > 0.3) suitableFor.push(scenario);
  if (rate < 0.3 && confidence > 0.3) notSuitableFor.push(scenario);
}
```

**贝叶斯平滑效果:**
```
样本数  实际成功率  贝叶斯平滑后  置信度
1       1/1=100%   3/4=75%      10%
3       3/3=100%   5/6=83%      30%
5       5/5=100%   7/8=87%      50%
10      10/10=100% 12/14=86%    100%
```

**影响:** 低频场景 1 次成功也能初步判断，高频场景需要更多样本

---

### 改进优先级

| # | 局限 | 改进方案 | 优先级 | 预计工时 |
|---|------|----------|--------|----------|
| L1 | 场景分默认 0.3 | 渐进式信任 + 首因效应 | 🔴 P0 | 1h |
| L2 | 调制系数 1.5 | 对数曲线调制 | 🟡 P1 | 1h |
| L3 | Speed 基线硬编码 | 自适应 P50/P90 基线 | 🟡 P1 | 2h |
| L4 | CostEfficiency 本地无意义 | 成本感知分离 | 🟢 P2 | 1h |
| L5 | 场景阈值固定 3 次 | 贝叶斯平滑 + 自适应阈值 | 🟡 P1 | 2h |

**改进总工时: 7 小时**

### 改进效果对比

| 场景 | 改进前 | 改进后 |
|------|--------|--------|
| 新工具首次调用成功 | scenarioScore=0.3 (被低估) | scenarioScore=0.7 (首因加成) |
| 云端 LLM 延迟 2s | speed=0.87 (固定基线) | speed=P90 动态调整 |
| 本地模型无成本数据 | costEfficiency=0.5 (无意义) | costEfficiency=null (跳过) |
| 低频场景 1 次成功 | 不标记 suitableFor | 贝叶斯平滑后标记 |
| 高置信度资源 | 过度放大到 1.0 | 对数曲线限制在 0.6 |

---

## ⚠️ 风险与缓解

| 风险 | 影响 | 缓解措施 |
|------|------|----------|
| 频繁 recordOutcome 影响性能 | 🟡 中 | 批量写入 + 异步持久化 |
| 动态资源过多导致内存膨胀 | 🟢 低 | 设置上限 + LRU 淘汰 |
| 误删正在使用的资源 | 🟡 P1 | 延迟清理 + 引用计数 |
| 三进制画像与内部状态不一致 | 🟢 低 | 以 ResourceHub 为准，定期校验 |

---

## 📝 变更文件清单

```
新增文件:
├── src/brain/hub/resource-sync.ts          # 资源热同步器
├── src/brain/hub/resource-sync.test.ts     # 单元测试
└── RESOURCE_HUB_OPTIMIZATION_PLAN.md       # 本计划

修改文件:
├── src/brain/brain.ts                      # P1: 云端 LLM 记录
├── src/brain/hub/resource-hub.ts           # P6: unregister 方法
├── src/tools/ternary-expert.ts             # P3/P5: 三进制集成
├── src/ternary/growth.ts                   # P5: 成长回调
├── src/core/subsystems.ts                  # P4: 注入 ResourceHub
├── src/core/rest-api.ts                    # P2: 热注册钩子
├── src/main.ts                             # P2: MCP 生命周期
├── src/skills/skill-manager.ts             # P2: 技能同步
└── src/tools/registry.ts                   # P2: 注册事件
```

---

*计划制定时间: 2026-05-25 08:57*
*预计总工时: 4-5 天*
*优先级: P1 云端 LLM + P2 热注册 为核心，P3-P6 为增强*
