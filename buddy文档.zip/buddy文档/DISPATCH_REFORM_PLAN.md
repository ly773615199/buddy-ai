# 调度模式改革计划

> 版本: v1.0
> 日期: 2026-05-18
> 原则: **三脑骨架不动，接口不变，模式从降级改为调度**

---

## 一、改革目标

### 现状问题（降级模式）

```
组装引擎 → confidence ≥ 0.6? → 不够 → NN → confidence ≥ 0.6? → 不够 → LLM
```

- 串行瀑布，逐层降级
- 二元判断（通过/不通过），没有比较能力
- 好方案可能被阈值卡掉
- 后面模块看不到前面模块的中间成果
- 置信度阈值硬编码，语义不统一
- 选出方案后执行是单路径，大量执行基础设施（DAG/工具链/能力协同/多路执行器）闲置

### 目标状态（调度模式）

```
用户输入 → 三脑感知 → 并行出方案 → 裁决择优 → 协作执行 → 呈现
                      ├─ 组装引擎出方案 A
                      ├─ NN 出方案 B
                      ├─ 经验图谱出方案 C
                      └─ LLM 出方案 D（按需）

裁决选出最优方案后：
  简单任务 → ToolChain 串联执行
  复杂任务 → DAG 并行执行 (maxParallel=4)
  跨域任务 → 能力协同 + 多路径择优
  全程监控 → 小脑实时监控 + 熔断保护
```

- 各模块各出方案，三脑裁决选最优
- 置信度由校准网络统一校准
- 竞争模式智能触发（不是每次都并行）
- 裁决后多模块协作执行（不是单路径）
- LLM 方案反哺本地学习

---

## 二、不动的部分（骨架保护）

| 模块 | 接口 | 说明 |
|------|------|------|
| ThreeBrain | `decide()` / `feedback()` | 入口和出口签名不变 |
| LeftBrain | `decide()` / `decideAll()` / `schedule()` | 规则引擎 + 调度器接口不变 |
| RightBrain | `predict()` / `predictFull()` / `processWithAssembly()` / `generateLocal()` | 右脑各管线接口不变 |
| Cerebellum | `regulate()` / `getBodyState()` | 小脑感知融合不变 |
| ExecutionPlan | `mode / reason / selectedNodes / confidence` | 输出类型不变 |
| IntuitionSignal | `intent / tools / qualityEstimate` | 直觉信号类型不变 |
| BodyState | `mood / energy / load / ...` | 本体状态类型不变 |

**所有现有模块的类、接口、数据结构均不修改。改革通过新增模块 + 修改编排层内部流程实现。**

---

## 三、新增模块

### 3.1 DispatchCoordinator — 调度协调器

**位置**: `src/brain/dispatch/coordinator.ts`

**职责**: 替代现有的降级瀑布，协调各模块并行出方案，裁决择优。

```typescript
/**
 * 调度协调器 — 核心改革模块
 *
 * 不替代任何现有模块，只改变编排方式：
 * - 原来：A 不行 → B 不行 → C
 * - 现在：A/B/C 各出方案 → 裁决选最优
 */
export class DispatchCoordinator {
  /**
   * 调度决策 — 并行出方案，裁决择优
   *
   * 输入：与 ThreeBrain.decide() 相同
   * 输出：最优 ExecutionPlan + 裁决元数据
   */
  async dispatch(
    input: string,
    signal: TaskSignal,
    resources: ResourceState,
    intuition?: IntuitionSignal,
    bodyState?: BodyState,
  ): Promise<DispatchResult>;

  /**
   * 智能触发判断 — 决定是否值得竞争
   *
   * 不是每次都并行跑所有模块，而是根据场景选择策略：
   * - 高置信简单任务 → 本地直出（不浪费资源竞争）
   * - 中等置信 → 竞争模式（本地并行，LLM 按需）
   * - 低置信复杂任务 → LLM 为主（本地辅助）
   */
  private decideStrategy(
    signal: TaskSignal,
    resources: ResourceState,
    intuition?: IntuitionSignal,
  ): DispatchStrategy;
}
```

### 3.2 ConfidenceCalibrator — 置信度校准器

**位置**: `src/brain/dispatch/calibrator.ts`

**职责**: 统一校准所有模块的置信度输出，替换硬编码阈值。

```typescript
/**
 * 置信度校准器 — 在线校准，替代硬编码阈值
 *
 * 基于: Online Platt Scaling + Calibeating (ICML 2023)
 *
 * 核心思路：
 * - 收集各模块的原始 confidence + 实际 outcome
 * - 用在线 logistic regression 学习校准函数
 * - 校准后的 confidence 可直接比较（语义统一）
 */
export class ConfidenceCalibrator {
  /**
   * 校准原始置信度
   *
   * 输入：模块名 + 原始 confidence
   * 输出：校准后的 confidence（语义统一，可跨模块比较）
   */
  calibrate(moduleName: string, rawConfidence: number, context?: CalibrationContext): number;

  /**
   * 更新校准模型 — 每次任务完成后调用
   *
   * 输入：模块名 + 原始 confidence + 实际 outcome（成功/失败）
   */
  update(moduleName: string, rawConfidence: number, outcome: boolean): void;

  /**
   * 获取校准曲线 — 调试用
   *
   * 返回：每个模块的 "说 X 的时候实际成功率是多少"
   */
  getCalibrationCurve(moduleName: string): Array<{predicted: number; actual: number; count: number}>;
}
```

### 3.3 ProposalCollector — 方案收集器

**位置**: `src/brain/dispatch/collector.ts`

**职责**: 收集各模块的候选方案，标准化为统一格式。

```typescript
/**
 * 方案收集器 — 从各模块收集候选方案
 *
 * 每个模块的输出格式不同，ProposalCollector 统一转换为 CandidateProposal：
 */
export interface CandidateProposal {
  /** 方案来源模块 */
  source: 'assembly' | 'nn' | 'experience' | 'rule' | 'llm';
  /** 生成的文本/执行计划 */
  content: string;
  /** 执行计划（如果模块产出了） */
  plan?: ExecutionPlan;
  /** 原始置信度 */
  rawConfidence: number;
  /** 校准后置信度 */
  calibratedConfidence: number;
  /** 生成延迟 ms */
  latencyMs: number;
  /** 预估开销（token/cost） */
  costEstimate: number;
  /** 模块特有的元数据 */
  metadata: Record<string, unknown>;
}

/**
 * 从各模块并行收集方案
 *
 * 根据 DispatchStrategy 决定调用哪些模块：
 * - quick 模式：只调本地模块（<10ms）
 * - standard 模式：本地 + NN（<50ms）
 * - compete 模式：本地 + NN + LLM（<3s）
 */
async collect(
  input: string,
  signal: TaskSignal,
  resources: ResourceState,
  strategy: DispatchStrategy,
  modules: ModuleSet,
): Promise<CandidateProposal[]>;
```

### 3.4 Arbiter — 裁决器

**位置**: `src/brain/dispatch/arbiter.ts`

**职责**: 从多个候选方案中选出最优。

```typescript
/**
 * 裁决器 — 多维评估，择优呈现
 *
 * 评估维度：
 * - 质量：校准后置信度
 * - 速度：用户等得起吗
 * - 开销：预算够吗
 * - 学习价值：能反哺本地吗
 */
export class Arbiter {
  /**
   * 裁决 — 从候选方案中选最优
   *
   * 流程：
   * 1. 双世界模型模拟验证每个方案
   * 2. 基于模拟结果多维评分
   * 3. 择优输出
   */
  arbitrate(
    proposals: CandidateProposal[],
    context: ArbitrationContext,
  ): Promise<ArbitrationResult>;
}

export interface ArbitrationResult {
  /** 选中的方案 */
  selected: CandidateProposal;
  /** 裁决理由 */
  reason: string;
  /** 各方案评分（调试用） */
  scores: Array<{source: string; score: number; breakdown: Record<string, number>}>;
  /** 双世界模型模拟结果 */
  simulation?: {
    /** 各方案的模拟成功率 */
    proposalSimulations: Array<{source: string; completionProb: number; riskScore: number}>;
    /** 推理与模拟共振置信度 */
    resonatedConfidence: number;
    /** 是否需要用户确认 */
    needsUserConfirmation: boolean;
  };
  /** 是否需要缓存 LLM 结果供学习 */
  shouldCacheForLearning: boolean;
}
```

---

## 四、改革流程（分 5 个 Phase）

### Phase 1: 置信度校准器（最轻量，不改现有流程）

**改动范围**: 新增 1 个文件，修改 0 个现有文件

**新增**:
- `src/brain/dispatch/calibrator.ts` — ConfidenceCalibrator

**集成方式**:
- 在 `ThreeBrain.decide()` 的最后，对输出的 `plan.confidence` 做校准
- 不改变决策流程，只校准输出的数字
- 收集 decision-outcome 对，持续更新校准模型

**效果**:
- confidence 数字开始与实际成功率对齐
- 为后续 Phase 提供可靠的置信度基础

**验证**:
- 对比校准前后的 ECE (Expected Calibration Error)
- ECE 应下降 30%+

---

### Phase 2: 方案收集器 + 裁决器（核心架构变更）

**改动范围**: 新增 2 个文件，修改 1 个现有文件 (`brain.ts`)

**新增**:
- `src/brain/dispatch/collector.ts` — ProposalCollector
- `src/brain/dispatch/arbiter.ts` — Arbiter

**修改** (`brain.ts` 的 `decide()` 方法内部):

```
原流程（降级）：
  Step 2.5: 审议
  Step 3: left.decideAll → scoredPlans
  Step 3.5: 世界模型选择
  Step 4: 组装引擎 → localGeneration（confidence ≥ 0.6 就直接返回）

新流程（调度）：
  Step 2.5: 审议（不变）
  Step 3: 并行收集方案
    ├─ left.decideAll → 规则方案
    ├─ right.processWithAssembly → 组装方案
    ├─ right.generateLocal → NN 方案
    └─ （可选）LLM 异步方案
  Step 3.5: 校准 + 裁决
    ├─ ConfidenceCalibrator 统一校准各方案置信度
    ├─ Arbiter 多维评估选最优
    └─ 世界模型在方案接近时介入（不变）
  Step 4: 输出（ExecutionPlan 格式不变）
```

**关键**: `decide()` 的签名和返回类型不变，外部调用者无感知。

**双世界模型集成**:
- 裁决器调用 ParallelUniverseOrchestrator.decide() 模拟验证每个方案
- 推理宇宙 (ReasoningUniverse)：快速推理每个方案的逻辑推演
- 模拟宇宙 (SimulationUniverse)：场景模拟预测方案结果
- 纠缠层 (EntangleLayer)：推理 ↔ 模拟互相修正 → 坍缩为评估
- 模拟结果纳入裁决评分：completionProb 加分、riskScore 减分、共振置信度加分
- 高风险方案自动标记 needsUserConfirmation

**效果**:
- 各模块并行出方案，不再是串行降级
- 裁决基于双世界模型模拟验证，而非静态置信度
- 本地模块有机会和 LLM 竞争
- 高风险方案有模拟预警

---

### Phase 3: 调度协调器 + 竞争模式

**改动范围**: 新增 1 个文件，修改 1 个现有文件 (`brain.ts`)

**新增**:
- `src/brain/dispatch/coordinator.ts` — DispatchCoordinator

**修改** (`brain.ts` 的 `decide()` 方法):
- 用 DispatchCoordinator 替代 Step 3 的手动并行
- 根据场景智能选择策略（quick / standard / compete）

**竞争模式触发条件**:

| 条件 | 策略 | 说明 |
|------|------|------|
| novelty < 0.3 + confidence > 0.8 | quick | 简单任务，本地直出 |
| novelty 0.3-0.7 + confidence 0.5-0.8 | standard | 本地并行，选最优 |
| novelty 0.7-0.9 或 confidence 0.3-0.5 | compete | 本地 + LLM 竞争 |
| novelty > 0.9 或 confidence < 0.3 | llm_primary | LLM 为主，本地辅助 |

**效果**:
- 系统根据场景自动选择最合适的策略
- 不浪费资源在简单任务上跑竞争
- 复杂任务充分利用本地和 LLM 各自优势

---

### Phase 4: 学习闭环 — LLM 方案反哺本地

**改动范围**: 新增 1 个文件，修改 1 个现有文件 (`feedback` 流程)

**新增**:
- `src/brain/dispatch/learner.ts` — DispatchLearner

**修改** (`brain.ts` 的 `feedback()` 方法):
- 当竞争模式下 LLM 方案被选中时，将 LLM 方案蒸馏到本地模块
- 更新经验图谱、模板库、规则引擎

**效果**:
- 本地模块持续从 LLM 学习
- 随时间推移，本地方案质量提升
- 竞争模式触发频率逐渐降低（本地越来越强）

### Phase 5: 全资源协作执行 — 多模块并行完成任务

**改动范围**: 新增 3 个文件，修改 2 个现有文件 (`brain.ts` + `plan-executor.ts`)

**核心问题**：Phase 1-4 解决了"怎么选最优方案"，但裁决选完之后执行还是单路径。已有大量执行基础设施（DAG 并行执行、工具链、能力协同调度、多路执行器、执行监控），但没有接入 dispatch 流程。更关键的是：当前设计是"选一条路走"，不是"全资源协作"。

**新增**:
- `src/brain/dispatch/executor.ts` — DispatchExecutor（全资源协作执行器）
- `src/brain/dispatch/resource-pool.ts` — ResourcePool（资源池统一视图）
- `src/brain/dispatch/types.ts` — 补充执行相关类型定义

**修改**:
- `brain.ts` 的 `decide()` — 裁决选完后调用 DispatchExecutor
- `plan-executor.ts` — 接入 DispatchExecutor 的执行结果

#### 5.0 设计缺陷修正

**原设计问题**：Phase 5 是"选一条执行路径"（ToolChain / DAG / 能力协同 / 多模块协作），不是真正的全资源协作。

**修正后的设计**：不选路径，而是从资源池中动态组合资源，多资源同时参与同一任务，质量驱动迭代。

```
原设计（选路径）：
  DispatchExecutor → 选方案 A/B/C/D → 执行 → 输出
  ❌ 还是单路径

修正后（全资源协作）：
  DispatchExecutor → ResourcePool → 动态组合资源 → 多资源同时参与 → 质量迭代 → 输出
  ✅ 全资源协作
```

#### 5.1 资源池 (ResourcePool) — 所有可用资源的统一视图

```typescript
/**
 * 资源池 — 不是"选一条路"，而是"从池中取资源组合"
 *
 * 所有资源始终可用，根据任务动态组合。
 * 同一任务可以同时使用多个资源。
 */
interface ResourcePool {
  // ── 内容生成资源 ──
  assembly: AssemblyEngine;         // 组装引擎：多源检索 + 拼装 + 风格适配
  nn: IntuitionNet;                 // NN：直觉预测 + 在线学习
  templates: CodeTemplateStore;     // 模板库：结构化代码模板
  experience: ExperienceEngine;     // 经验图谱：历史经验匹配
  knowledgeGate: KnowledgeGate;     // 知识门控：结构化知识检索
  decisionMemory: DecisionMemoryR;  // 决策记忆：历史成功回复片段

  // ── 验证资源 ──
  qualityAssessor: OutputQualityAssessor;   // 质量评估：四维评估
  worldModel: ParallelUniverseOrchestrator;  // 双世界模型：推理 + 模拟
  reranker: Reranker;                       // 多维重排序

  // ── 执行资源 ──
  tools: ToolRegistry;              // 工具库：19 个工具模块
  dagExecutor: TaskExecutor;        // DAG 执行器：并行执行
  toolChain: ToolChain;             // 工具链：串联执行
  dagPlanner: DAGPlanner;           // DAG 规划器
  skillResolver: SkillResolver;     // 步骤→工具解析

  // ── 补充资源 ──
  llm: LLMAdapter;                  // LLM（按需调用）
  searchProviders: SearchProvider[]; // 11 个网络搜索源
  svgRenderer: SvgRenderer;         // SVG 渲染器
  codeIntel: CodeIntel;             // 代码智能

  // ── 监控资源 ──
  monitor: CerebellumExecutionMonitor;  // 小脑监控：熔断 / 过载 / 精力
  convergence: SignalConvergenceLayer;  // 信号汇聚：训练信号
}
```

#### 5.2 协作执行模式 — 不是选一条路，而是多资源同时参与

**模式 1: 主导-辅助模式 (Lead-Assist)**

一个模块主导执行，其他模块实时辅助（评估/补充/验证）。

```typescript
/**
 * 主导-辅助模式
 *
 * 例：组装引擎主导生成文本，NN 实时评估质量，工具执行验证
 * 不是"先生成再评估"，而是"生成过程中评估器实时反馈"
 */
async function leadAssistExecute(
  lead: () => Promise<string>,                    // 主导模块
  assistants: Array<{                             // 辅助模块
    name: string;
    execute: (context: string) => Promise<string>;
    role: 'evaluate' | 'enrich' | 'verify' | 'fallback';
  }>,
  aggregator: (lead: string, assists: Record<string, string>) => string,
): Promise<string> {
  // 主导模块先出初稿
  const leadResult = await lead();

  // 辅助模块并行贡献（基于主导模块的中间结果）
  const assistResults = await Promise.allSettled(
    assistants.map(async a => ({
      name: a.name,
      result: await a.execute(leadResult),  // 辅助模块看到主导模块的输出
    }))
  );

  // 融合所有结果
  return aggregator(leadResult, collectResults(assistResults));
}
```

**模式 2: 流水线 + 中间检查 (Pipeline-Check)**

每一步执行后，质量评估器检查，不合格则重试或换备选模块。

```typescript
/**
 * 流水线 + 中间检查
 *
 * 与普通流水线的区别：每步有质量门控，不合格可重试或换路
 * 复用 OutputQualityAssessor 做质量检查
 */
async function pipelineWithCheck(
  steps: Array<{
    name: string;
    execute: (input: string) => Promise<string>;
    check: (output: string) => Promise<{ pass: boolean; feedback: string }>;
    maxRetries: number;
    fallback?: (input: string) => Promise<string>;  // 检查不通过时的备选模块
  }>,
  initialInput: string,
): Promise<{ output: string; stepResults: StepResult[] }> {
  let current = initialInput;
  const stepResults: StepResult[] = [];

  for (const step of steps) {
    let stepOutput = '';
    let usedModule = step.name;

    for (let retry = 0; retry <= step.maxRetries; retry++) {
      stepOutput = await step.execute(current);
      const check = await step.check(stepOutput);

      if (check.pass) break;  // 达标，进入下一步

      if (retry === step.maxRetries && step.fallback) {
        // 重试用尽，换备选模块
        stepOutput = await step.fallback(current);
        usedModule = `${step.name}→fallback`;
      }
    }

    stepResults.push({ name: usedModule, output: stepOutput });
    current = stepOutput;
  }

  return { output: current, stepResults };
}
```

**模式 3: 扇出-汇聚 + 动态加权 (Fan-Out-Weighted)**

多模块并行处理同一输入，结果按质量动态加权融合。

```typescript
/**
 * 扇出-汇聚 + 动态加权
 *
 * 与普通扇出的区别：不是简单合并，而是按质量加权
 * 质量评估器实时评估每个模块的输出，高质量模块权重更大
 */
async function fanOutWeightedExecute(
  modules: Array<{
    name: string;
    execute: (input: string) => Promise<string>;
  }>,
  assessor: OutputQualityAssessor,
  context: AssessmentContext,
  input: string,
): Promise<string> {
  // 所有模块并行执行
  const results = await Promise.allSettled(
    modules.map(async m => ({
      name: m.name,
      output: await m.execute(input),
    }))
  );

  const successes = results
    .filter((r): r is PromiseFulfilledResult<{name: string; output: string}> => r.status === 'fulfilled')
    .map(r => r.value);

  // 质量评估每个结果
  const scored = successes.map(r => ({
    ...r,
    score: assessor.assess({ ...context, output: r.output, executionSuccess: true }).score,
  }));

  // 按质量加权融合（高质量结果占比更大）
  return weightedMerge(scored);
}
```

**模式 4: 质量驱动迭代 (Quality-Driven Iteration)**

执行 → 评估 → 不合格则重试/换路 → 直到达标或达到上限。

```typescript
/**
 * 质量驱动迭代
 *
 * 核心：不是"一次执行完毕"，而是"执行→评估→改进"循环
 * 复用 OutputQualityAssessor 做评估
 */
async function qualityDrivenExecute(
  task: string,
  executors: Array<{
    name: string;
    execute: (input: string, feedback?: string) => Promise<string>;
  }>,
  assessor: OutputQualityAssessor,
  context: AssessmentContext,
  maxIterations: number = 3,
  qualityThreshold: number = 0.7,
): Promise<{ output: string; iterations: number; qualityScore: number; history: IterationRecord[] }> {
  const history: IterationRecord[] = [];
  let lastOutput = '';
  let lastFeedback = '';

  for (let i = 0; i < maxIterations; i++) {
    // 用第 i 个执行器（或同一执行器不同参数）
    const executor = executors[i % executors.length];
    const output = await executor.execute(task, lastFeedback);

    // 质量评估
    const assessment = assessor.assess({
      ...context,
      output,
      executionSuccess: true,
    });

    history.push({
      iteration: i + 1,
      executor: executor.name,
      output: output.slice(0, 200),
      qualityScore: assessment.score,
      issues: assessment.issues,
    });

    // 达标就返回
    if (assessment.score >= qualityThreshold) {
      return { output, iterations: i + 1, qualityScore: assessment.score, history };
    }

    // 不达标 → 注入评估反馈到下一轮
    lastOutput = output;
    lastFeedback = assessment.suggestion ?? `质量不足(${assessment.score.toFixed(2)}): ${assessment.issues.map(i => i.description).join('; ')}`;
  }

  // 达到上限，返回最后一次结果
  const finalAssessment = assessor.assess({ ...context, output: lastOutput, executionSuccess: true });
  return { output: lastOutput, iterations: maxIterations, qualityScore: finalAssessment.score, history };
}
```

**模式 5: 动态重规划 (Adaptive Replanning)**

执行过程中发现新信息 → 重新规划后续任务。

```typescript
/**
 * 动态重规划
 *
 * 与静态 DAG 的区别：执行过程中可以修改后续任务
 * 例：执行子任务 A 时发现新依赖 → 动态添加子任务 A'
 */
async function adaptiveExecute(
  initialPlan: TaskDAG,
  executor: TaskExecutor,
  replanner: (completed: Task[], remaining: Task[], newInfo: string[]) => TaskDAG,
  monitor: ExecutionMonitor,
): Promise<ExecutionResult> {
  let dag = initialPlan;
  const newInfo: string[] = [];

  while (!isDAGComplete(dag)) {
    // 执行就绪任务
    const ready = getReadyTasks(dag);
    await executor.executeBatch(ready, monitor);

    // 收集新发现的信息
    for (const task of ready) {
      if (task.status === 'done' && task.result) {
        // 检查结果中是否有新信息（新依赖、新发现）
        const info = extractNewInfo(task);
        if (info.length > 0) newInfo.push(...info);
      }
    }

    // 检查是否需要重规划
    const completed = getCompletedTasks(dag);
    const remaining = getPendingTasks(dag);
    if (newInfo.length > 0 && shouldReplan(completed, remaining, newInfo)) {
      dag = replanner(completed, remaining, newInfo);  // 动态重规划
      newInfo.length = 0;  // 清空已消费的信息
    }
  }

  return summarize(dag);
}
```

#### 5.3 DispatchExecutor — 全资源协作执行器

```typescript
/**
 * 全资源协作执行器
 *
 * 核心理念：不是"选一条路走"，而是"从资源池中动态组合资源"
 *
 * 流程：
 * 1. 分析任务，确定需要哪些资源
 * 2. 从 ResourcePool 中取出资源组合
 * 3. 选择协作模式（主导-辅助 / 流水线-检查 / 扇出-加权 / 质量迭代 / 动态重规划）
 * 4. 执行 + 小脑监控
 * 5. 质量评估 + 迭代改进
 * 6. 结果反馈到校准器 + 能力调度器
 */
export class DispatchExecutor {
  private pool: ResourcePool;

  /**
   * 全资源协作执行
   *
   * 不再区分"简单任务走 ToolChain，复杂任务走 DAG"
   * 而是：分析任务 → 取资源 → 选协作模式 → 执行 → 迭代
   */
  async execute(
    proposal: CandidateProposal,
    signal: TaskSignal,
    resources: ResourceState,
    bodyState: BodyState,
  ): Promise<ExecutionResult> {
    // 1. 分析任务，确定资源需求
    const resourceNeeds = this.analyzeResourceNeeds(proposal, signal);

    // 2. 从资源池取资源组合
    const resourceCombo = this.pool.select(resourceNeeds);

    // 3. 选择协作模式
    const mode = this.selectCollaborationMode(proposal, resourceNeeds, resourceCombo);

    // 4. 执行（带小脑监控）
    const monitor = new CerebellumExecutionMonitor(this.pool.cerebellum);
    const result = await this.executeWithMode(mode, resourceCombo, monitor);

    // 5. 质量驱动迭代（如果质量不达标）
    if (result.qualityScore < 0.7 && result.iterations < 3) {
      const improved = await this.qualityIterate(result, resourceCombo, monitor);
      return improved;
    }

    // 6. 结果反馈
    this.feedResult(result, proposal);

    return result;
  }

  /**
   * 分析任务需要哪些资源
   *
   * 基于方案来源 + 任务信号 + 复杂度判断
   */
  private analyzeResourceNeeds(
    proposal: CandidateProposal,
    signal: TaskSignal,
  ): ResourceNeeds {
    const needs: ResourceNeeds = {
      contentGeneration: [],   // 需要哪些内容生成资源
      verification: [],        // 需要哪些验证资源
      execution: [],           // 需要哪些执行资源
      supplementary: [],       // 需要哪些补充资源
    };

    // 基于任务类型
    if (signal.taskType === 'tools') {
      needs.execution.push('tools', 'dagExecutor');
    }
    if (signal.taskType === 'reasoning') {
      needs.contentGeneration.push('assembly', 'knowledgeGate');
      needs.verification.push('qualityAssessor', 'worldModel');
    }
    if (signal.complexity === 'complex') {
      needs.execution.push('dagExecutor', 'dagPlanner');
      needs.verification.push('qualityAssessor');
    }

    // 基于方案来源
    if (proposal.source === 'assembly') {
      needs.contentGeneration.push('assembly', 'reranker');
    }
    if (proposal.source === 'llm') {
      needs.contentGeneration.push('llm');
      needs.verification.push('qualityAssessor');
    }

    return needs;
  }

  /**
   * 选择协作模式
   *
   * 不是固定选一个模式，而是根据任务特征动态选择
   */
  private selectCollaborationMode(
    proposal: CandidateProposal,
    needs: ResourceNeeds,
    combo: ResourceCombo,
  ): CollaborationMode {
    // 简单任务 + 工具为主 → 主导-辅助（工具主导，组装引擎辅助）
    if (needs.execution.length > 0 && needs.contentGeneration.length === 0) {
      return 'lead_assist';
    }

    // 内容生成为主 + 需要验证 → 流水线-检查
    if (needs.contentGeneration.length > 0 && needs.verification.length > 0) {
      return 'pipeline_check';
    }

    // 多模块可以并行 → 扇出-加权
    if (needs.contentGeneration.length >= 2) {
      return 'fan_out_weighted';
    }

    // 高质量要求 → 质量迭代
    if (proposal.rawConfidence < 0.7) {
      return 'quality_iteration';
    }

    // 复杂任务 + 多步骤 → 动态重规划
    if (needs.execution.length >= 2) {
      return 'adaptive_replan';
    }

    // 默认：主导-辅助
    return 'lead_assist';
  }
}
```

#### 5.4 子任务间信息流 — 中间结果实时影响后续执行

```typescript
/**
 * 子任务间信息流
 *
 * 与静态 DAG 的区别：子任务 A 的中间结果可以实时影响子任务 B 的执行策略
 *
 * 实现方式：
 * 1. 共享上下文 (SharedContext) — 子任务读写共享状态
 * 2. 事件总线 (EventBus) — 子任务发布/订阅事件
 * 3. 动态依赖 (DynamicDeps) — 运行时添加依赖关系
 */

// 共享上下文
interface SharedContext {
  // 子任务可以写入发现的信息
  discoveries: Map<string, string[]>;

  // 子任务可以读取其他子任务的中间结果
  intermediateResults: Map<string, string>;

  // 子任务可以请求添加新的子任务
  pendingTasks: Array<{ name: string; tool: string; args: Record<string, unknown> }>;
}

// 使用示例：子任务 A 发现新依赖 → 动态添加子任务 A'
async function executeWithSharedContext(
  dag: TaskDAG,
  executor: TaskExecutor,
  sharedCtx: SharedContext,
): Promise<ExecutionResult> {
  while (!isDAGComplete(dag)) {
    const ready = getReadyTasks(dag);

    // 执行就绪任务（传入共享上下文）
    for (const task of ready) {
      task.args._sharedCtx = sharedCtx;  // 注入共享上下文
    }
    await executor.executeBatch(ready);

    // 检查是否有新任务需要添加
    while (sharedCtx.pendingTasks.length > 0) {
      const newTask = sharedCtx.pendingTasks.shift()!;
      addTask(dag, newTask);  // 动态添加到 DAG
    }
  }

  return summarize(dag);
}
```

#### 5.5 与现有执行基础设施的关系

| 现有模块 | 在全资源协作中的角色 | 是否修改 |
|---------|-------------------|---------|
| `TaskExecutor` | DAG 并行执行引擎 | 不修改，ResourcePool 包装其接口 |
| `ToolChain` | 简单任务串联执行 | 不修改，ResourcePool 包装其接口 |
| `CapabilityScheduler` | 子任务级能力分配 | 不修改，ResourcePool 调用其 `allocate()` |
| `MultiPathExecutor` | 多路径并行择优 | 不修改，ResourcePool 调用其 `execute()` |
| `CerebellumExecutionMonitor` | 实时监控 + 熔断 | 不修改，ResourcePool 传入其作为 monitor |
| `DAGPlanner` | DAG 规划 | 不修改，ResourcePool 调用其 `plan()` |
| `DAGPipeline` | 门控验证 | 不修改，ResourcePool 调用其 `resolveDAGPipeline()` |
| `OutputQualityAssessor` | 执行结果质量评估 | 不修改，质量迭代循环的核心组件 |
| `AssemblyEngine` | 多源检索 + 拼装 | 不修改，内容生成的主导资源 |
| `SvgRenderer` | SVG 渲染 | 不修改，可视化生成资源 |
| `CodeTemplateStore` | 代码模板 | 不修改，代码生成资源 |
| `KnowledgeGate` | 知识检索 | 不修改，知识补充资源 |

**核心原则：ResourcePool + DispatchExecutor 只做编排和组合，不重新实现任何执行逻辑。**

#### 5.6 执行结果反馈闭环

```typescript
/**
 * 执行结果 → 反馈闭环
 *
 * 执行完成后，结果回流到多个系统：
 * 1. ConfidenceCalibrator — 更新置信度校准模型
 * 2. CapabilityScheduler.recordOutcome() — 更新能力分配历史
 * 3. SignalConvergenceLayer — 摄入训练信号
 * 4. DecisionRecorder — 记录决策-结果对
 * 5. QualityAssessor — 更新质量基线
 */
function feedExecutionResult(
  result: ExecutionResult,
  proposal: CandidateProposal,
  context: ExecutionContext,
): void {
  // 1. 校准器更新
  context.calibrator.update(proposal.source, proposal.rawConfidence, result.success);

  // 2. 能力调度器记录
  for (const step of result.stepResults) {
    context.capabilityScheduler.recordOutcome(step.subtask, step.allocation, step.qualityScore);
  }

  // 3. 信号汇聚层
  context.convergenceLayer.ingestFeedback({
    input: context.input,
    output: result.output,
    success: result.success,
    source: proposal.source,
  });

  // 4. 决策记录
  context.decisionRecorder.record({
    input: context.input,
    plan: proposal.plan,
    outcome: { success: result.success, latencyMs: result.totalMs },
  });

  // 5. 质量基线更新
  if (result.qualityScore > 0) {
    context.qualityBaseline.update(proposal.source, result.qualityScore);
  }
}
```

#### 5.7 场景模拟：全资源协作能做什么

**场景：「写一篇关于三脑架构的技术博客，包含架构图和代码示例」**

```
用户输入
  │
  ▼
Phase 1-3: 并行出方案 → 裁决选方案 A（组装引擎）
  │
  ▼
Phase 5: 全资源协作执行

  DispatchExecutor.execute()
    │
    ├─ 资源需求分析:
    │    contentGeneration: [assembly, templates]
    │    verification: [qualityAssessor]
    │    execution: [svgRenderer, codeIntel]
    │
    ├─ 协作模式: 流水线-检查 (pipeline_check)
    │
    ├─ Step 1: 生成博客文本（组装引擎主导）
    │    ├─ 检索: ARCHITECTURE.md + brain.ts + 知识图谱
    │    ├─ Reranker 多维重排序
    │    ├─ 段落规划 + 风格适配
    │    ├─ 质量检查: score = 0.72 ✓
    │    └─ 输出: 博客文本初稿
    │
    ├─ Step 2: 生成架构图（SvgRenderer 主导）
    │    ├─ 输入: Step 1 文本中提到的模块列表（信息流）
    │    ├─ 渲染: 模块关系 → SVG 架构图
    │    ├─ 质量检查: score = 0.65 ✗
    │    │    feedback: "缺少数据流箭头"
    │    ├─ 重试: 加数据流箭头
    │    ├─ 质量检查: score = 0.81 ✓
    │    └─ 输出: 架构图 SVG
    │
    ├─ Step 3: 生成代码示例（代码模板库主导）
    │    ├─ 输入: Step 1 文本中提到的接口（信息流）
    │    ├─ 检索: 代码模板 → 匹配接口 → 填充参数
    │    ├─ 质量检查: score = 0.78 ✓
    │    └─ 输出: 代码示例
    │
    ├─ 汇总: 文本 + 架构图 + 代码示例 → 最终博客
    │
    ├─ 整体质量检查: score = 0.82 ✓
    │
    └─ 输出: 最终博客（文本 + 架构图 + 代码示例）

  反馈闭环:
    ├─ calibrator.update('assembly', 0.72, true)
    ├─ capabilityScheduler.recordOutcome(...)
    └─ convergenceLayer.ingestFeedback(...)
```

**vs 现有流程**：

| 维度 | 现有 | 方案实现后 |
|------|------|-----------|
| 内容 | 只有文本 | 文本 + 架构图 + 代码示例 |
| 模块 | 组装引擎单模块 | 组装引擎 + SvgRenderer + 代码模板库 |
| 质量 | 无自检 | 质量评估 → 迭代改进 |
| 并行 | 无 | 子任务可并行 |
| 迭代 | 无 | 质量不达标自动重试 |
| 信息流 | 无 | 中间结果实时传递给后续步骤 |
| 监控 | 无 | 小脑全程监控 + 熔断 |

**效果**:
- 全资源协作：不是选一条路，而是从资源池动态组合
- 质量驱动迭代：执行→评估→不达标则重试/换路
- 子任务信息流：中间结果实时影响后续执行
- 动态重规划：发现新信息时调整后续任务
- 小脑全程监控：连续失败熔断、过载中止、精力极低中止

---

## 五、多 LLM 决策策略

### 5.1 现状：单 LLM 选路

```
TaskType → ModelRouter.select() → 一个 LLM → 调用
```

只选一个，选错了就错了，没有纠错机会。

### 5.2 新方案：三脑分层决策

```
用户输入
  │
  ▼
右脑：意图预测 + LLM 能力画像
  ├─ 意图分类 → 这个任务需要什么能力？
  ├─ 代码任务 → DeepSeek-Coder 擅长
  ├─ 创意写作 → Claude 擅长
  ├─ 中文对话 → DeepSeek-Chat 擅长
  ├─ 多模态 → GPT-4o / Gemini 擅长
  └─ 简单问答 → 本地就能解决，不需要 LLM
  输出: LLM 候选列表 + 置信度排序
  │
  ▼
左脑：规则约束 + 预算控制
  ├─ 预算够吗？→ 不够就降级到便宜模型
  ├─ 有速率限制吗？→ 429 就换 provider
  ├─ 任务敏感度？→ 高敏感走本地/可信 provider
  ├─ 历史成功率？→ 失败多的 provider 降权
  └─ Thompson Sampling → 同类任务多 LLM 采样选一个
  输出: 最终 LLM 选择 + 降级链
  │
  ▼
小脑：系统状态注入
  ├─ 系统负载高 → 选快模型（延迟优先）
  ├─ 网络不稳 → 选本地模型或低延迟 provider
  └─ 用户急迫 → 选响应最快的
```

### 5.3 三种多 LLM 策略

| 策略 | 触发条件 | 做法 | 开销 |
|------|---------|------|------|
| **路由选一** | 任务明确匹配某 LLM | 三脑选最合适的 1 个 LLM | 最低 |
| **竞争择优** | 中等置信度，值得对比 | 2-3 个 LLM 并行出方案，裁决选最优 | 中等 |
| **分层聚合** | 高复杂度任务 | LLM-A 出初稿 → LLM-B 审核改进 | 较高 |

#### 路由选一（最常用，80% 场景）

```
三脑决策：这个任务最适合哪个 LLM？
  ├─ 右脑：意图 → 能力匹配
  ├─ 左脑：预算 + 规则 + Thompson Sampling
  └─ 小脑：负载 + 延迟约束
→ 选 1 个 LLM，调用，返回
```

#### 竞争择优（15% 场景）

```
三脑判断：这个任务值得对比
  ├─ 选 2-3 个候选 LLM（能力相近但风格不同）
  ├─ 并行调用，复用本地检索结果
  ├─ 裁决器选最优（质量 + 相关度 + 风格 + 开销）
  └─ 未选中的结果缓存供学习
```

#### 分层聚合（5% 场景，高复杂度）

```
类似 MoA（Together AI 论文 arxiv:2406.04692）：
  Layer 1: DeepSeek 出初稿（快、便宜）
  Layer 2: Claude 看到初稿后改进（准、贵）
  Layer 3: 三脑裁决最终版本
```

### 5.4 多 LLM 裁决评分

```typescript
interface LLMScore {
  source: string;           // 'deepseek' | 'claude' | 'gpt4o'
  quality: number;          // 回答质量（组装引擎评估）
  relevance: number;        // 与用户意图的相关度
  style: number;            // 符合用户偏好的程度
  cost: number;             // 本次调用的 token 成本
  latency: number;          // 响应时间
  learningValue: number;    // 能反哺本地的价值
}

// 裁决公式（可调权重）
score = quality * 0.35
      + relevance * 0.25
      + style * 0.15
      + (1 - costNormalized) * 0.1
      + (1 - latencyNormalized) * 0.05
      + learningValue * 0.1
```

**核心原则：三脑不是比 LLM 谁更聪明，而是比谁更适合这个任务、这个用户、这个场景。**

### 5.5 双世界模型在调度中的角色

双世界模型不是独立的决策者，是裁决器的"眼睛"——帮裁决器看清楚每个方案的后果再做选择。

```
各模块出方案 A/B/C/D
  │
  ▼
双世界模型模拟验证（已有模块，不新增）
  ├─ 推理宇宙 (ReasoningUniverse)：快速推理每个方案的逻辑
  ├─ 模拟宇宙 (SimulationUniverse)：场景模拟预测结果
  └─ 纠缠层 (EntangleLayer)：推理 ↔ 模拟 → 坍缩为评估
  │
  ▼
裁决器：基于模拟结果择优
  ├─ completionProb 高的加分
  ├─ riskScore 低的加分
  ├─ 推理与模拟共振的加分（置信度更高）
  └─ 高风险方案标记 needsUserConfirmation
```

**对比：有模拟 vs 无模拟**

| 维度 | 无模拟 | 有模拟 |
|------|--------|--------|
| 裁决依据 | 校准后置信度（静态分数） | 模拟预测结果（动态推演） |
| 风险评估 | 无 | 有（SimulationUniverse 输出 riskScore） |
| 方案对比 | 比分数 | 比模拟结果 + 推理共振 |
| 用户确认 | 无 | 高风险方案自动标记 |
| 延迟 | +0ms | +10-30ms（可接受） |

### 5.6 与现有 ModelRouter 的关系

| 现有模块 | 新模块 | 关系 |
|---------|--------|------|
| ModelRouter.select() | DispatchCoordinator | ModelRouter 仍负责模型创建，DispatchCoordinator 负责选择策略 |
| ModelPool (Thompson Sampling) | Arbiter | ModelPool 的采样结果作为 Arbiter 的输入之一 |
| ProviderRegistry | 不变 | Provider 创建和能力探测不变 |
| provider-registry.ts | 不动 | |

---

## 六、新增文件结构

```
src/brain/dispatch/           ← 新增目录
├── coordinator.ts            ← 调度协调器
├── calibrator.ts             ← 置信度校准器
├── collector.ts              ← 方案收集器
├── arbiter.ts                ← 裁决器
├── executor.ts               ← 全资源协作执行器（Phase 5）
├── resource-pool.ts          ← 资源池统一视图（Phase 5）
├── learner.ts                ← 学习闭环
├── llm-selector.ts           ← 多 LLM 选择器（三脑分工选 LLM）
├── types.ts                  ← 类型定义（含执行 + 资源池类型）
└── __tests__/
    ├── coordinator.test.ts
    ├── calibrator.test.ts
    ├── collector.test.ts
    ├── arbiter.test.ts
    ├── executor.test.ts
    └── resource-pool.test.ts
```

**不修改的文件**:
- `brain.ts` — 只改 `decide()` 和 `feedback()` 内部实现，接口不变
- `left/` — 不动
- `right/` — 不动
- `cerebellum/` — 不动
- `types.ts` — 不动（可能新增类型，不改已有类型）
- `orchestrate/` — 不动（Phase 5 的 DispatchExecutor 调用其接口，不改内部）
- `tools/` — 不动（Phase 5 的 DispatchExecutor 调用其接口，不改内部）

---

## 七、风险控制

| 风险 | 应对 |
|------|------|
| Phase 2 改 `decide()` 内部可能导致行为变化 | 保留旧流程作为 fallback，通过 feature flag 切换 |
| 并行出方案增加延迟 | quick 模式不并行，只在 standard/compete 模式并行 |
| 校准器冷启动不准 | 初始用现有硬编码阈值作为先验，逐步用 outcome 校准 |
| LLM 竞争增加成本 | 只在 compete 模式触发，且有预算硬约束 |
| 裁决器选错方案 | 记录所有方案 + 裁决理由，支持事后审计和回溯 |
| Phase 5 资源池资源过多导致内存膨胀 | 资源懒加载 + LRU 缓存淘汰 + 最大并发限制 |
| Phase 5 质量迭代无限循环 | 硬编码 maxIterations=3 + 全局超时 |
| Phase 5 动态重规划导致 DAG 不收敛 | 重规划次数上限 + 死锁检测 |
| Phase 5 子任务信息流导致竞态条件 | SharedContext 用 Map（单线程 Node.js 无锁）+ 读写分离 |
| Phase 5 多模块同时修改共享状态 | 事件总线异步通知，不阻塞主流程 |

---

## 八、验收标准

| Phase | 验收指标 |
|-------|---------|
| Phase 1 | ECE 下降 30%+，现有测试全部通过 |
| Phase 2 | 同等任务质量下，LLM 调用减少 20%+ |
| Phase 3 | compete 模式下任务成功率提升 15%+ |
| Phase 4 | 连续运行 7 天后，本地方案采纳率提升 |
| Phase 5 | 全资源协作：复杂任务多模块协作完成，质量迭代后 score ≥ 0.7，简单任务无退化 |

---

## 九、复核校准（基于已实现代码）

### 9.1 已有模块复用清单

| 计划新增 | 实际已有 | 调整 |
|---------|---------|------|
| 裁决器质量评估 | `OutputQualityAssessor` (四维评估) | 直接复用，不重新实现 |
| 学习闭环 | `SignalConvergenceLayer` (4 Sink + ReplayBuffer) | 扩展 Sink，不新增 learner.ts |
| 双世界模型集成 | `bestPlanEntangled()` 已接入 `decide()` | 扩展输入类型，不新建路径 |
| 审议会集成 | `DeliberationCouncil` 已接入 Step 2.5 | 不动，proceed 后触发新流程 |
| 方案模拟 | `ParallelUniverseOrchestrator` | 复用，不新建 |
| 协作执行: DAG 并行 | `TaskExecutor.execute()` + `DAGPlanner.plan()` | 直接复用，ResourcePool 包装其接口 |
| 协作执行: 工具链串联 | `ToolChain.executeChain()` | 直接复用 |
| 协作执行: 能力协同 | `CapabilityScheduler.allocate()` + `MultiPathExecutor.execute()` | 直接复用 |
| 协作执行: 执行监控 | `CerebellumExecutionMonitor` | 直接复用，传入 DispatchExecutor |
| 协作执行: 门控验证 | `DAGPipeline` (Gate-1 + Gate-2) | 直接复用 |
| 协作执行: 资源池 | `ResourcePool`（新模块，包装所有已有资源） | 新增，不重新实现 |
| 协作执行: 质量迭代 | `OutputQualityAssessor` | 直接复用，接入迭代循环 |
| 协作执行: 可视化生成 | `SvgRenderer` | 直接复用，作为资源池资源 |
| 协作执行: 代码模板 | `CodeTemplateStore` | 直接复用，作为资源池资源 |

### 9.2 需要调整的接口

**bestPlanEntangled() 输入扩展**：

```typescript
// 现有：只接受 mode 标签
bestPlanEntangled(
  candidates: Array<{ label: string; reason: string; score: number }>,
  currentTokens: number[],
  complexity: string,
): EntangledDecision | null

// 扩展后：接受 CandidateProposal
bestPlanEntangled(
  candidates: Array<{ label: string; reason: string; score: number; proposal?: CandidateProposal }>,
  currentTokens: number[],
  complexity: string,
): EntangledDecision | null
```

**双世界模型触发条件**：

```typescript
// 现有：只在"选择困难"时触发
if (scoredPlans[0].score - scoredPlans[1].score > 0.3) {
  // 差距大，直接用最高的
} else {
  // 选择困难 → 双世界模型
}

// 新模式：所有方案都走双世界模型
const entangled = this.right.bestPlanEntangled(allProposals, ...);
```

### 9.3 Phase 依赖关系（校准后）

```
Phase 1: 置信度校准器（新增 calibrator.ts）
  ↓
Phase 2: 方案收集器 + 裁决器
  ├─ 新增: collector.ts + arbiter.ts
  ├─ 复用: OutputQualityAssessor 做质量评估
  ├─ 扩展: bestPlanEntangled() 接受 CandidateProposal[]
  └─ 保留: bestPlan() 作为 fallback
  ↓
Phase 3: 调度协调器
  ├─ 新增: coordinator.ts
  ├─ 复用: DeliberationCouncil 的 proceed 决策
  └─ 复用: ParallelUniverseOrchestrator 做方案模拟
  ↓
Phase 4: 学习闭环
  ├─ 扩展: SignalConvergenceLayer 的 Sink
  └─ 复用: 4 个 Sink + ReplayBuffer
  ↓
Phase 5: 全资源协作执行
  ├─ 新增: ResourcePool（资源池统一视图）
  ├─ 新增: DispatchExecutor（全资源协作执行器）
  ├─ 复用: TaskExecutor.execute() 做 DAG 并行
  ├─ 复用: ToolChain.executeChain() 做串联
  ├─ 复用: CapabilityScheduler.allocate() 做能力分配
  ├─ 复用: MultiPathExecutor.execute() 做多路径择优
  ├─ 复用: CerebellumExecutionMonitor 做实时监控
  ├─ 复用: DAGPlanner.plan() 做 DAG 规划
  ├─ 复用: OutputQualityAssessor 做质量迭代
  ├─ 复用: AssemblyEngine 做内容生成
  ├─ 复用: SvgRenderer 做可视化生成
  └─ 复用: CodeTemplateStore 做代码生成
```

---

## 十、时间估算

| Phase | 工作量 | 依赖 |
|-------|--------|------|
| Phase 1 | 2-3 天 | 无 |
| Phase 2 | 5-7 天 | Phase 1 |
| Phase 3 | 3-5 天 | Phase 2 |
| Phase 4 | 3-5 天 | Phase 3 |
| Phase 5 | 5-8 天 | Phase 2（不依赖 Phase 3-4，可并行开发） |
| **总计** | **18-29 天** | — |
