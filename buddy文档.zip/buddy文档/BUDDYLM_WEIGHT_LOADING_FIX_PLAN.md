# BuddyLM 权重加载修复计划

> 日期: 2026-05-27 | 状态: 进行中

## 问题概述

BuddyLM 模型输出乱码，聊天功能无法正常使用。

## 根因分析

### 1. 权重加载顺序错位

Checkpoint 的参数顺序和模型 `parameters()` 方法的顺序不一致。

**Checkpoint 顺序 (weight-bias 交替)**:
```
selfAttn: wq, bq, wk, bk, wv, bv, wo, bo, lnW, lnB
crossAttn: wq, bq, wk, bk, wv, bv, wo, bo, lnW, lnB
moe: router, router_b, expert0(w1,b1,w2,b2), ..., expert7(w1,b1,w2,b2)
```

**模型 parameters() 顺序 (weight 连续, bias 连续)**:
```
selfAttn: wq, wk, wv, wo, bq, bk, bv, bo, lnW, lnB
cca: wq, wk, wv, wo, bq, bk, bv, bo, lnW, lnB
crossAttn: wq, wk, wv, wo, bq, bk, bv, bo, lnW, lnB
moe: router, router_b, expert0(w1,b1,w2,b2), ..., expert7(w1,b1,w2,b2)
```

**关键差异**:
- Checkpoint: `wq(65536), bq(256), wk(65536), bk(256), ...` (交替)
- Model: `wq(65536), wk(65536), wv(65536), wo(65536), bq(256), bk(256), ...` (分组)
- Checkpoint 无 CCA 层，模型有 CCA 层 (额外 6 参数/block)

### 2. 加载器缺陷

原 `loadWeightsBinary()` 按顺序逐个对比 size，一旦不匹配就 skip 且不回退 model index，导致后续参数全部错位。

**实际加载结果**: 467/531 参数加载成功，但 64 个因 size 不匹配被跳过，大量参数被放错位置。

### 3. 量化影响

| 指标 | 修复前 | 预期修复后 |
|------|--------|-----------|
| 参数加载率 | 467/531 (88%) | 528/531 (99.4%) |
| 输出质量 | 完全乱码 | 可理解的中文 |
| 置信度 | ~0.07 | >0.3 |

## 修复方案

### Phase 1: 参数顺序映射 (P0)

在 `decoder.ts` 的 `loadWeightsBinary()` 中实现 checkpoint → model 的参数索引映射。

**映射规则** (每个 block):

```
Checkpoint 索引 → Model 索引

# selfAttn (10 params): ckp interleaved → model grouped
ckp[0]  → model[0]   # wq [256,256]
ckp[1]  → model[4]   # bq [256]
ckp[2]  → model[1]   # wk [256,256]
ckp[3]  → model[5]   # bk [256]
ckp[4]  → model[2]   # wv [256,256]
ckp[5]  → model[6]   # bv [256]
ckp[6]  → model[3]   # wo [256,256]
ckp[7]  → model[7]   # bo [256]
ckp[8]  → model[8]   # lnWeight [256]
ckp[9]  → model[9]   # lnBias [256]

# crossAttn (10 params): 同上模式
ckp[10+n] → model[20+n]  # (n=0..9, 同 selfAttn 映射模式)

# CCA: checkpoint 无此参数，跳过 (model[10-19] 保持随机初始化)

# moe (34 params): router + 8 experts
ckp[20] → model[30]  # router [256,8]
ckp[21] → model[31]  # router_b [8]
ckp[22+n] → model[32+n]  # experts (n=0..31, 顺序一致)
```

**每个 block**: checkpoint 54 params → model 60 params (含 CCA 6 params 未覆盖)
**8 blocks**: checkpoint 432 params → model 480 params
**lmHead**: checkpoint 3 params → model 3 params (顺序一致)
**总计**: checkpoint 435 params → model 483 params (匹配 432 个, 跳过 CCA 的 48 个)

### Phase 2: 验证测试 (P0)

1. 加载后对比每个参数的统计特征 (mean, std, min, max)
2. 生成测试输入，验证输出为可理解中文
3. 置信度应 > 0.2

### Phase 3: CCA 参数补偿 (P1)

Checkpoint 无 CCA 参数，模型的 CCA 层保持随机初始化。可选方案:
- 冻结 CCA 层 (不影响推理质量)
- 用小数据集微调 CCA 层
- 从 crossAttn 复制权重到 CCA (相似结构)

## 涉及文件

- `src/brain/right/nn/decoder.ts` — `loadWeightsBinary()` 方法
- `src/brain/right/nn/__tests__/buddylm-direct.test.ts` — 推理测试
- `src/brain/right/nn/__tests__/checkpoint-diag.test.ts` — checkpoint 诊断

## 风险

- **映射错误**: 需要逐参数验证，否则模型输出更差
- **CCA 缺失**: 可能影响 cross-attention 质量，但不致命
- **性能**: 加载时间可能增加 (需 benchmark)

## 时间线

- Phase 1: 1-2 小时
- Phase 2: 30 分钟
- Phase 3: 可选，按需
