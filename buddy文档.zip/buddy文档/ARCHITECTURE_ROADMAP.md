# BuddyLM 架构路线图 — 地基优先策略

> **目标**: 明确哪些架构决策必须在自训练开始前完成，哪些可以交给自进化系统自然生长。
>
> **核心原则**: 地基不对，进化白费。架构锁定后才能开始自训练，否则训练权重全部作废。
>
> **三层模型**: 地基层（结构）→ 预训练层（知识底座）→ 自进化层（持续精进）
>
> **创建日期**: 2026-05-21
> **更新日期**: 2026-05-21
> **关联文档**:
> - BUDDYLM_ASSEMBLY_INTEGRATION_PLAN.md — 解绑架构：组装引擎与 BuddyLM 完全独立，Brain 语义编排
> - TERNARY_DEV_PLAN.md — 三进制 10 周计划
> - MATMUL_OPTIMIZATION_PLAN.md — 算子优化方案
> - BYTEENCODER_UPGRADE_PLAN.md — ByteEncoder 自动增长 + 增量训练
> - BYTEENCODER_TRAIN_FIX_PLAN.md — 训练路径一致性修复
> - COLD_START_VALIDATION_FIX_PLAN.md — 冷启动验证闭环修复
> - SHADOW_BRAIN_EVOLUTION.md — 自进化系统设计

---

## 1. 三层分类框架

```
┌─────────────────────────────────────────────────────────┐
│  自进化层（持续）                                         │
│  领域知识积累、检索优化、工具发明、递归自改进               │
│  判定: 自进化系统有能力自主优化                            │
├─────────────────────────────────────────────────────────┤
│  预训练层（地基完成后，自训练前）                           │
│  ByteEncoder 预训练、quality_head 预训练、Decoder 预训练   │
│  判定: 冷启动必需，但架构锁定后可重复执行                   │
├─────────────────────────────────────────────────────────┤
│  地基层（现在）                                           │
│  词表、三进制、MatMul、cross-attention、MoE               │
│  判定: 自进化无法改变的结构性约束                          │
└─────────────────────────────────────────────────────────┘
```

### 1.1 必须现在规划（地基层）

**判定标准**: 自进化系统无法改变的结构性约束。训练后再改 = 推倒重来。

| 方向 | 为什么不能等 | 已有方案 |
|------|-------------|---------|
| BBPE 词表扩展 | Tokenizer 训好后改不了 | — |
| 三进制格式 + 推理引擎 | 存储和推理基础设施 | TERNARY_DEV_PLAN.md |
| MatMul 算子优化 | 训练/推理速度天花板 | MATMUL_OPTIMIZATION_PLAN.md |
| Phase 2 cross-attention 层 | Decoder 结构变更 | — |
| MoE 架构改造 | 密集改稀疏需要重训 | — |

### 1.2 预训练层（冷启动必需）

**判定标准**: 没有预训练底座，自训练连起点都没有。但架构锁定后可以重做。

| 方向 | 作用 | 已有方案 |
|------|------|---------|
| ByteEncoder 对比学习预训练 | 检索质量底座 | BYTEENCODER_UPGRADE_PLAN.md |
| ByteEncoder 训练路径修复 | 训练推理一致性 | BYTEENCODER_TRAIN_FIX_PLAN.md |
| quality_head 偏好预训练 | 裁判判断力底座 | COLD_START_VALIDATION_FIX_PLAN.md |
| Decoder 语言建模预训练 | 生成能力底座 | training-data/stages/ (212K 条) |
| 冷启动种子数据 | 首次运行不空白 | COLD_START_VALIDATION_FIX_PLAN.md |

### 1.3 可以等自进化（应用层）

**判定标准**: 自进化系统已有或即将有能力自主优化的领域。

| 方向 | 为什么能自进化 | 已有基础设施 |
|------|-------------|-------------|
| 领域专家知识积累 | CurriculumEvolver 自动识别领域边界 | ShadowBrain |
| 检索策略优化 | Phase 4 元认知自动学会何时检索 | KnowledgeGate |
| 蒸馏数据质量 | quality_head 自动过滤低质量样本 | Self-Rewarding |
| Prompt 质量 | 自动优化 prompt | PromptEvolver |
| 工具发明 | 按需创造新工具 | ToolInventor |

---

## 2. 地基层详细方案

### 2.1 BBPE 词表扩展

**现状**: 8192 vocab，英文勉强够用，中文和代码覆盖不足。

**目标**: 16K-32K vocab。

**约束**:
- 词表扩大 → Embedding 层参数增加 → 需要同步调整 hiddenDim
- 所有已训练权重的 token ID 映射会变，必须在训练前确定
- 中文分词质量直接影响中文生成效果

**影响范围**:
- `src/brain/right/nn/bbpe-tokenizer.ts` — Tokenizer 训练
- `src/brain/right/nn/bbpe-bridge.ts` — ByteEncoder ↔ BBPE 桥接
- `src/brain/right/nn/buddy-lm.ts` — Embedding 层维度
- `src/brain/right/nn/decoder.ts` — LM Head 维度

**优先级**: P0（阻塞所有后续训练）

### 2.2 三进制格式 + 推理引擎

**现状**: float32 权重，16M × 4 bytes = 64MB。

**目标**: 三进制 {-1, 0, 1}，16M × 1.58 bits ≈ 3.2MB，缩小 20 倍。

**收益**:
- 模型缩小 20 倍
- 乘法变加减法（跳过 0）
- 同样 CPU 可以跑 160M 参数的三进制模型
- 精度损失 < 5%（BitNet 论文数据）

**已有方案**: `TERNARY_DEV_PLAN.md`（10 周完整计划）+ `TERNARY_GROWTH_PLAN.md`（自然生长机制）

**核心原理**: 矩阵定义天花板，知识填充地板。三进制 {-1,0,1} 天然支持稀疏生长与叠加合并。模型创建时全零，训练驱动激活，容量自然增长。详见 TERNARY_GROWTH_PLAN.md。

**优先级**: P0（与词表扩展并行）

### 2.3 MatMul 算子优化

**现状**: 通用 matmul → 11ms/forward。

**目标**: 分块 + 缓存友好 + SIMD → 3ms，WASM SIMD → 1.3ms。

**收益**: 同硬件 8.5 倍速度提升，省出的时间可以跑更多层或更大 hidden dim。

**已有方案**: `MATMUL_OPTIMIZATION_PLAN.md`

**优先级**: P0（与词表扩展并行）

### 2.4 Phase 2 cross-attention 层

**现状**: Decoder 有 Self-Attention + Cross-Attention(Encoder) + FFN。

**目标**: 新增 ChunkedCrossAttention 层，接收检索结果作为 K/V。

**架构变更**:
```
当前 DecoderBlock:
  Self-Attention → Cross-Attention(Encoder) → FFN

改造后 DecoderBlock:
  Self-Attention → ChunkedCrossAttention(检索) → Cross-Attention(Encoder) → FFN
```

**影响范围**:
- `src/brain/right/nn/decoder.ts` — 新增 ChunkedCrossAttention 层
- `src/brain/right/nn/buddy-lm.ts` — generateWithContext 改用 cross-attention
- `src/brain/right/features/assembly-bridge.ts` — 检索结果编码为向量

**优先级**: P1（词表和算子优化完成后）

### 2.5 MoE 架构改造

**现状**: 密集 FFN，每个 token 经过全部 16M 参数。

**目标**: 8 个专家，每 token 激活 2 个，总参数 128M，有效参数 32M。

**架构变更**:
```
当前 FFN:
  Linear(128→512) → GELU → Linear(512→128)

MoE FFN:
  Router(128→8) → TopK(2) → Expert_0(128→512→128) + Expert_1(128→512→128)
```

**约束**:
- 必须在 cross-attention 层完成后进行（统一架构变更）
- 三进制 + MoE 需要特殊的稀疏存储格式
- Router 的训练需要负载均衡损失

**优先级**: P2（cross-attention 完成后）

---

## 3. 预训练层详细方案

**核心问题**: 没有预训练底座，自训练从零开始，冷启动慢且质量差。

**类比**: 预训练是从 0 分到 60 分的过程，自训练是从 60 分到 90 分的过程。

### 3.1 ByteEncoder 预训练（检索质量底座）

**现状**: 已有预训练权重（`checkpoints/encoder-pretrain/`，1.1MB），但存在训练路径不一致问题。

**问题**: `BYTEENCODER_TRAIN_FIX_PLAN.md` 发现的三条路径不一致：
- 预训练用 meanPool + L2，推理用 lastToken 无归一化
- 动态合并训练时跳过，推理时执行
- 增量训练从未真正接入

**修复顺序**:

```
Step 1: 修复训练路径一致性（BYTEENCODER_TRAIN_FIX_PLAN.md）
  ├── 统一前向路径：训练 = 推理
  ├── 统一池化方式：全部用 meanPool
  └── 统一归一化：全部 L2 normalize

Step 2: 对比学习预训练（BYTEENCODER_UPGRADE_PLAN.md）
  ├── 100M 文本对（Common Crawl / The Pile 抽取）
  ├── InfoNCE loss
  ├── 渐进式训练：先冻结底层，训顶层 → 再全量微调
  └── 目标：通用语义空间，检索召回率 > 90%

Step 3: 增量训练接入（BYTEENCODER_UPGRADE_PLAN.md）
  ├── OnlineLearner.attachByteEncoder() 真正接通
  ├── 运行时从用户交互中学习
  └── 架构自动增长：数据量增长时自动加层
```

**已有方案**: `BYTEENCODER_TRAIN_FIX_PLAN.md` + `BYTEENCODER_UPGRADE_PLAN.md`

### 3.2 quality_head 预训练（裁判判断力底座）

**现状**: quality_head 是 Self-Rewarding 的裁判，但没见过外部高质量数据。

**问题**: `COLD_START_VALIDATION_FIX_PLAN.md` 发现：
- QualityAssessor 拿到 `output=''` 时形同虚设
- A/B 测试用随机数模拟，进化锁第 3 锁基于随机数据判断
- 冷启动时 NN 权重随机初始化，前 50 次交互无意义

**预训练方案**:

```
Step 1: 修复质量评估闭环（COLD_START_VALIDATION_FIX_PLAN.md）
  ├── QualityAssessor 空输出降级处理
  ├── A/B 测试接入真实数据
  └── 进化锁第 3 锁用真实回归数据

Step 2: 偏好数据预训练
  ├── 收集 (差回答, 好回答) 人工标注对
  ├── 预训练 quality_head 做 preference classification
  ├── 已有: training-data/stages/ 212K 条分阶段数据
  └── 目标：quality_head 的打分与人类偏好相关系数 > 0.7

Step 3: 冷启动种子注入（COLD_START_VALIDATION_FIX_PLAN.md）
  ├── 从工具定义生成合成训练数据（TinyAgent 论文方法）
  ├── 每意图 15 个种子样本即可启动（ACL 2023 论文）
  └── 50 次交互内达到可用水平
```

**已有方案**: `COLD_START_VALIDATION_FIX_PLAN.md`

### 3.3 Decoder 预训练（生成能力底座）

**现状**: 已有预训练权重（`checkpoints/buddylm-pretrain/`，8.4MB decoder + 4.2MB embedding）。

**增强方案**:

```
Step 1: 大规模语言建模预训练
  ├── 语料: 中英文 + 代码（The Pile + CodeParrot + 中文维基）
  ├── 目标: 标准 next-token prediction
  ├── 训练在新架构上（三进制 + MoE + cross-attention）
  └── 产出: 通用语言能力底座

Step 2: 蒸馏灌入（架构锁定后）
  ├── 教师: DeepSeek / Qwen
  ├── 方法: 序列级蒸馏（teacher 生成 → student 学习）
  ├── 已有: training-data/stages/ 5 阶段 212K 条
  └── 目标: 在特定领域接近教师水平

Step 3: 冷启动验证
  ├── 50 次交互内 NN 输出有意义（非随机）
  ├── 种子原型 toolDist 非空
  └── 知识问答类任务可检索增强
```

### 3.4 预训练与地基层的依赖关系

```
地基层（先完成）:
  BBPE 词表 ──────┐
  三进制格式 ──────┤
  MatMul 优化 ─────┼──→ 架构锁定
  cross-attention ─┤
  MoE ────────────┘
                         │
预训练层（架构锁定后）:    ▼
  ByteEncoder 预训练 ─┐
  quality_head 预训练 ─┼──→ 冷启动完成
  Decoder 预训练 ─────┘
  种子数据注入 ────────┘
                         │
自进化层（上线后）:        ▼
  自训练闭环接管 ────────→ 持续进化
```

**关键约束**: 预训练必须在架构锁定后进行，否则架构变更导致预训练权重作废。

---

## 4. 自进化层详细方案

### 4.1 领域专家知识积累

**机制**: CurriculumEvolver 分析各领域成功率，自动分配训练重点。

**自然生长路径**:
```
seed (0-10 条知识) → sprout (10-50) → growing (50-200) → trainable (200+) → mature (500+)
```

每个领域独立成长，不互相干扰。到达 trainable 阶段后自动触发增量训练。

**不需要人工干预**: ShadowBrain 的 GapDetector + CurriculumEvolver 全自动。

### 4.2 检索策略优化

**机制**: Phase 4 的元认知控制器学会"什么时候检索、检索什么、检索多少"。

**自然生长路径**:
```
阶段 1: 固定检索（每次生成都检索）
阶段 2: 触发检索（quality_head 低时才检索）
阶段 3: 自主检索（输出 [Retrieve] token 控制）
阶段 4: 优化检索（根据检索结果质量调整查询词）
```

每个阶段通过 Self-Rewarding 自动过渡，不需要人工设计规则。

### 4.3 蒸馏管线

**机制**: 用大模型（DeepSeek/Qwen）生成高质量训练样本，灌入 BuddyLM。

**时机**: 架构锁定后（三进制 + MoE + cross-attention 全部完成），蒸馏才有意义。否则蒸馏出来的权重在架构变更后全部作废。

**自然生长**: 蒸馏数据的质量由 quality_head 自动过滤，不需要人工筛选。

---

## 5. 执行顺序

```
Phase 0: 架构决策（已完成 → PHASE0_DECISIONS.md）
  ├── ✅ 词表大小: 16384 (16K)
  ├── ✅ hiddenDim: 128（保持不变）
  ├── ✅ MoE 专家数: 8 experts, top-2
  └── ✅ 三进制精度: 1.58-bit {-1, 0, 1}

Phase 1: 地基建设（并行，4-6 周）
  ├── P0a: BBPE 词表扩展 + 重新训练 Tokenizer
  ├── P0b: 三进制格式 + 推理引擎（TERNARY_DEV_PLAN.md）
  ├── P0c: MatMul 算子优化（MATMUL_OPTIMIZATION_PLAN.md）
  └── P1:  Phase 2 cross-attention 层

Phase 2: 架构锁定（2 周）
  ├── MoE 改造（在新架构上）
  ├── 三进制 MoE 训练格式
  └── 完整架构验证

Phase 3: 预训练（架构锁定后，4-8 周）
  ├── 3a: ByteEncoder 训练路径修复 + 对比学习预训练
  │       └── BYTEENCODER_TRAIN_FIX_PLAN.md + BYTEENCODER_UPGRADE_PLAN.md
  ├── 3b: quality_head 偏好预训练 + 冷启动修复
  │       └── COLD_START_VALIDATION_FIX_PLAN.md
  ├── 3c: Decoder 语言建模预训练（新架构）
  │       └── training-data/stages/ 212K 条 → 大规模语料
  └── 3d: 种子数据注入 + 冷启动验证
          └── 50 次交互内达到可用

Phase 4: 自训练启动
  ├── ShadowBrain 在新架构上开始自训练
  ├── 蒸馏管线往新架构灌知识
  └── 自进化系统接管后续优化

Phase 5: 自进化（持续）
  ├── 领域专家自动成长
  ├── 检索策略自动优化
  ├── 工具自动发明
  └── 递归自改进
```

---

## 6. 风险评估

| 风险 | 概率 | 影响 | 缓解 |
|------|------|------|------|
| 三进制精度损失过大 | 中 | 退化到 int8 量化 | 先在小模型验证 |
| MoE 训练不收敛 | 中 | 退回密集模型 | 负载均衡损失 + 渐进式增加专家 |
| 词表扩大后中文效果下降 | 低 | 重新训练 tokenizer | 用中文语料验证 |
| 架构变更周期过长 | 中 | 延迟自训练启动 | Phase 1 并行执行 |
| 预训练数据质量不足 | 中 | 检索/生成底座弱 | 蒸馏管线兜底 |
| ByteEncoder 训练路径修复引入回归 | 中 | 检索质量下降 | 修复前后 A/B 对比 |
| 自进化方向偏离 | 低 | 进化锁 + A/B 测试 | EvolutionLock 已有 |

---

## 7. 决策记录

| 日期 | 决策 | 理由 |
|------|------|------|
| 2026-05-21 | 地基层优先于自训练 | 架构变更后训练权重作废，必须先锁定架构 |
| 2026-05-21 | 三进制 + MoE 作为终极目标 | 16M 参数 × 20 倍效率 × 8 倍稀疏 = 等效 128M-1B |
| 2026-05-21 | 自进化不碰架构层 | 结构变更需要人工验证，不能让系统自己改自己的骨架 |
| 2026-05-21 | 预训练层从地基层独立出来 | 预训练是冷启动必需，但架构锁定后可重做，与地基层性质不同 |
| 2026-05-21 | ByteEncoder 预训练前先修复训练路径 | 三条路径不一致导致预训练效果打折 |
| 2026-05-21 | quality_head 预训练用人类偏好数据 | 没见过好作品的编辑当不了好裁判 |
| 2026-05-21 | 冷启动靠蒸馏，成长靠用户，成熟靠自进化 | 三个阶段各有数据来源，不需要一步到位 |
| 2026-05-21 | **Phase 0 四个架构决策已定** | vocabSize=16K, hiddenDim=128, MoE=8, ternary=1.58bit → PHASE0_DECISIONS.md |
