# 知识图谱成长增强执行计划（v2 — 整合版）

> **版本历史**
> - v1（2026-06-06）：原始计划，独立新建 `src/brain/right/kg/` 模块
> - v2（2026-06-06）：深度代码审查后修订，整合已有 KG 实现，消除重复

## 〇、现状分析

### 冷启动种子知识库（v2 新增）

项目内置 `seed-knowledge.ts`，首次初始化时自动注入：
- **~120 个高频概念实体**：编程语言、框架、工具、AI/ML、软件工程、数据结构、协议、安全、架构等
- **~100 条结构化关系**：used_for / requires / is_a / enables / related / similar_to / improves / part_of
- **TransE 嵌入热身**：5 轮 × 32 三元组训练，让嵌入有初始区分度
- **幂等注入**：不覆盖已有实体，可安全重复调用
- **source='seed'**：种子实体可被后续提取器覆盖/增强

### 已有 KG 实现（两套并存）

项目中存在 **两套独立的 KnowledgeGraph 实现**，经代码审查发现以下问题：

#### 实现 A：`src/brain/right/features/knowledge-graph.ts`

- **已集成**：在 `RightBrain` 构造函数中初始化，被 6 个模块依赖
- **数据结构**：邻接表存储，Entity + KnowledgeEdge
- **关系类型**：10 种（`causes`, `solves`, `requires`, `improves`, `contradicts`, `related`, `part_of`, `enables`, `balances`, `metaphor`）
- **嵌入**：可选，`Float32Array` 存在 Entity 上，无 TransE 训练
- **容量**：maxEntities=10000, maxEdges=50000
- **特性**：多跳检索（`GraphExpand`）、边权重衰减、序列化/反序列化
- **依赖模块**：
  - `KnowledgeExtractor`（`src/knowledge/extractor.ts`）— LLM 提取后填充
  - `BuddyLearn`（`src/knowledge/learn.ts`）— 学习文件/URL 后填充
  - `GraphExpand`（`src/brain/right/features/graph-expand.ts`）— 多跳扩展
  - `AssemblyBridge` — 组装引擎知识源
  - `Reranker` — 重排序器
  - `RightBrain` — 直接持有并暴露 `getKnowledgeGraph()`

#### 实现 B：`src/brain/right/kg/`（v1 计划产物）

- **未集成**：独立模块，未接入任何现有系统
- **数据结构**：独立实体表 + 关系表 + 嵌入表（`Map<string, Float32Array>`）
- **关系类型**：6 种（`is_a`, `part_of`, `used_for`, `similar_to`, `solves`, `requires`）
- **嵌入**：必有 TransE 嵌入，128 维，Xavier 初始化
- **容量**：maxEntities=50000, expansionThreshold=10000
- **特性**：传递推理、同义合并、成长监控、维度扩展
- **门控融合**：`KGEnhancedEncoder` 实现了独立的门控融合网络
- **持久化**：`entities.jsonl` + `relations.jsonl` + `embeddings.bin`

### 核心冲突汇总

| # | 冲突 | 严重度 | 说明 |
|---|---|---|---|
| 1 | 两套 `KnowledgeGraph` 类，API 完全不兼容 | 🔴 | 类名相同，字段/方法不同 |
| 2 | 关系类型不兼容（10种 vs 6种） | 🔴 | 交集仅 3 种（solves/requires/part_of） |
| 3 | 新 KG 未接入现有系统 | 🔴 | 已有 6 个模块依赖旧 KG |
| 4 | 嵌入维度/策略冲突 | 🔴 | 可选256 vs 必有128+TransE |
| 5 | 门控融合与已有 KnowledgeGate 重复 | 🔴 | RightBrain 已有 KnowledgeGate |
| 6 | 实体抽取器两套并存 | 🟡 | KnowledgeExtractor vs EntityExtractor |
| 7 | 持久化路径/格式冲突 | 🟡 | 都写 checkpoints/knowledge-graph/ |

## 一、目标（修订）

**不再另起炉灶**，而是在已有 KG 基础上增强：

- **保留**已有 KG（实现 A）作为唯一核心，保持所有现有集成不变
- **迁移**新 KG（实现 B）中的有价值能力到已有 KG
- **统一**关系类型为超集（13 种）
- **新增** TransE 嵌入训练、传递推理、同义合并、成长监控
- **复用**已有 `KnowledgeGate` 替代新建的 `KGEnhancedEncoder`
- **删除** `src/brain/right/kg/` 目录，消除重复

### 架构总览（修订）

```
用户输入
  ↓
┌─────────────────────────────────────────────────┐
│                 ByteEncoder [256]                │
│  (UTF-8 → ByteEmbedding → EncoderBlock×4 → Pool) │
└──────────────────────┬──────────────────────────┘
                       ↓
┌─────────────────────────────────────────────────┐
│     KnowledgeGraph（已有 features/ 增强版）       │
│  实体检索 → TransE 嵌入 → 关系推理 → 结构编码    │
│  + 传递推理 + 同义合并 + 成长监控                 │
└──────────────────────┬──────────────────────────┘
                       ↓
┌─────────────────────────────────────────────────┐
│        KnowledgeGate（已有，增强接入）             │
│  门控融合：gate * byteVec + (1-gate) * kgVec     │
└──────────────────────┬──────────────────────────┘
                       ↓
              增强语义向量 [256]
```

## 二、分阶段执行计划（整合版）

### Phase 0：清理与统一接口（1天）

**目标**：删除重复代码，统一接口定义

**任务清单**：

- [x] 0.1 删除 `src/brain/right/kg/` 目录（已确认未被任何模块 import）✅ 2026-06-06
- [x] 0.2 统一关系类型为超集（13 种）✅ 2026-06-06
  ```typescript
  // src/brain/right/features/knowledge-graph.ts
  export type EdgeRelation =
    // 已有 10 种
    | 'causes' | 'solves' | 'requires' | 'improves'
    | 'contradicts' | 'related' | 'part_of' | 'enables'
    | 'balances' | 'metaphor'
    // 从新 KG 迁移 3 种
    | 'is_a' | 'used_for' | 'similar_to';
  ```
- [x] 0.3 为 Entity 接口扩展可选字段（向后兼容）✅ 2026-06-06
  ```typescript
  export interface Entity {
    id: string;
    name: string;
    type: string;
    description?: string;
    embedding?: Float32Array;       // 已有
    createdAt: number;
    // 新增（可选，向后兼容）
    aliases?: string[];
    confidence?: number;
    source?: 'seed' | 'extracted' | 'inferred';
    firstSeen?: number;
    lastUsed?: number;
    useCount?: number;
  }
  ```
- [x] 0.4 验证：编译通过 + 现有测试不 break ✅ 2026-06-06

### Phase 1：TransE 嵌入层（2天）

**目标**：为已有 KG 添加 TransE 嵌入训练能力

**任务清单**：

- [ ] 1.1 新建 `src/brain/right/features/kg-embedder.ts`
  ```typescript
  export class KGEmbedder {
    private entityEmbeddings: Map<string, Float32Array>;
    private relationEmbeddings: Map<string, Float32Array>;
    private dim: number;  // 默认 256，与 ByteEncoder 对齐

    // TransE 前向：h + r → 预测 t
    predictTail(headId: string, relId: string): Float32Array;

    // 相似度检索：给定向量，找最近实体
    search(query: Float32Array, k: number): KGSearchResult[];

    // 嵌入新实体（Xavier 初始化）
    addEntity(id: string): void;

    // 嵌入扩展：dim → newDim（左上角嵌入旧权重）
    expandDim(newDim: number): void;

    // TransE 训练步骤
    trainStep(triplets: Triplet[]): number;
  }
  ```
- [ ] 1.2 嵌入维度默认 256（与 ByteEncoder 一致，无需投影）
- [ ] 1.3 持久化：嵌入写入 `checkpoints/knowledge-graph/embeddings.bin`
- [ ] 1.4 与已有 KG 集成：`KnowledgeGraph` 新增 `embedder` 属性
  ```typescript
  class KnowledgeGraph {
    readonly embedder: KGEmbedder;
    // ...已有代码不变
  }
  ```
- [x] 1.5 编写单元测试：TransE 训练收敛、嵌入检索正确性 ✅ 2026-06-06

### Phase 2：传递推理与同义合并（1天）

**目标**：为已有 KG 添加推理补全能力

**任务清单**：

- [x] 2.1 在 `KnowledgeGraph` 上新增 `inferTransitive()` 方法 ✅ 2026-06-06
  ```typescript
  // 传递性推理：A→B, B→C ⇒ A→C
  // 置信度衰减：weight = w1 * w2 * 0.8
  inferTransitive(decayFactor?: number): number;
  ```
- [x] 2.2 新增 `mergeSynonyms()` 方法 ✅ 2026-06-06
  ```typescript
  // 同义实体合并：编辑距离 < 2 或共享别名
  mergeSynonyms(): number;
  ```
- [x] 2.3 新增 `inferCoOccurrence()` 方法 ✅ 2026-06-06
  ```typescript
  // 共现推理：频繁共现实体 → similar_to（阈值 > 0.7）
  inferCoOccurrence(threshold?: number): number;
  ```
- [x] 2.4 编写单元测试：传递推理正确性、同义合并不丢关系 ✅ 2026-06-06

### Phase 3：实体抽取增强（1天）

**目标**：将新 KG 的轻量抽取能力接入已有 KnowledgeExtractor

**任务清单**：

- [x] 3.1 将 `src/brain/right/kg/entity-extractor.ts` 的规则抽取逻辑
      迁移到 `src/knowledge/extractor.ts` 作为轻量降级通道 ✅ 2026-06-06
  ```typescript
  // KnowledgeExtractor 新增方法
  extractByRules(text: string): ExtractionResult {
    // 1. 英文技术术语正则
    // 2. 中文分词 + 词典匹配（Intl.Segmenter）
    // 3. 关系模式匹配（6 种正则）
    // 4. 置信度打分
  }
  ```
- [x] 3.2 扩展关系模式库，覆盖已有 KG 的 13 种关系类型 ✅ 2026-06-06
  ```typescript
  const RELATION_PATTERNS = [
    // 已有 6 种
    { pattern: /(.+?)(?:用于|用来|用于实现)(.+)/, relation: 'used_for' },
    { pattern: /(.+?)(?:是|属于)(.+?)(?:的一种|之一)/, relation: 'is_a' },
    { pattern: /(.+?)(?:解决|处理|应对)(.+)/, relation: 'solves' },
    { pattern: /(.+?)(?:依赖|需要|基于)(.+)/, relation: 'requires' },
    { pattern: /(.+?)(?:类似|相似|近似于)(.+)/, relation: 'similar_to' },
    { pattern: /(.+?)(?:包含|包括|含有)(.+)/, relation: 'part_of' },
    // 新增 7 种
    { pattern: /(.+?)(?:导致|引起|造成)(.+)/, relation: 'causes' },
    { pattern: /(.+?)(?:提升|增强|优化|改进)(.+)/, relation: 'improves' },
    { pattern: /(.+?)(?:矛盾|冲突|互斥)(.+)/, relation: 'contradicts' },
    { pattern: /(.+?)(?:使|让|赋能|使得)(.+)/, relation: 'enables' },
    { pattern: /(.+?)(?:平衡|权衡|取舍)(.+)/, relation: 'balances' },
    { pattern: /(.+?)(?:就像|好比|类比|打个比方)(.+)/, relation: 'metaphor' },
    { pattern: /(.+?)(?:相关|有关联|联系)(.+)/, relation: 'related' },
  ];
  ```
- [x] 3.3 当 LLM 不可用时自动降级到规则抽取 ✅ 2026-06-06
- [x] 3.4 编写单元测试：中英文术语抽取、13 种关系模式覆盖 ✅ 2026-06-06

### Phase 4：成长监控（1天）

**目标**：实现 KG 成长状态评估和容量驱动扩展

**任务清单**：

- [x] 4.1 新建 `src/brain/right/features/kg-growth-monitor.ts` ✅ 2026-06-06
  ```typescript
  export class KGGrowthMonitor {
    constructor(private kg: KnowledgeGraph) {}

    assess(): {
      needInfer: boolean;
      needExpand: boolean;
      urgency: 'low' | 'medium' | 'high';
      reason: string;
    };

    get metrics(): {
      entityCount: number;
      relationCount: number;
      avgConfidence: number;
      extractionRate: number;
      inferBacklog: number;
      embeddingDim: number;
      memoryBytes: number;
    };
  }
  ```
- [x] 4.2 接入 `CapacityMonitor`：新增 KG 容量指标 ✅ 2026-06-06
- [x] 4.3 容量驱动扩展： ✅ 2026-06-06
  - 实体 > 10,000 → 嵌入维度 256 → 512（左上角嵌入旧权重）
  - 关系 > 50,000 → 推理层数扩展
- [x] 4.4 LRU 淘汰低频实体（useCount < 3 且 30 天未用） ✅ 2026-06-06

### Phase 5：集成联调（2天）

**目标**：将增强后的 KG 完整接入现有系统

**任务清单**：

- [x] 5.1 接入 `OnlineLearner`
  - `collectTextSample()` 后调用 `kg.extractByRules()` + `addEdge()`
  - `update()` 后调用 `kg.inferTransitive()` ✅ 2026-06-06
- [x] 5.2 接入 `IdleTrainer`
  - `DreamEngine.tick()` 时执行 `kg.inferTransitive()` + `kg.mergeSynonyms()` + `kg.embedder.trainStep()` ✅ 2026-06-06
- [x] 5.3 接入 `KnowledgeGate`
  - KG 嵌入通过已有 `KnowledgeGate` 注入 ByteEncoder 管线
  - 不新建 `KGEnhancedEncoder` ✅ 2026-06-06
- [x] 5.4 增强 `GraphExpand`
  - 利用 TransE 嵌入计算路径得分（替代纯边权重乘积）
  - 支持语义相似度扩展（`similar_to` 关系）✅ 2026-06-06
- [x] 5.5 checkpoint 增强
  - 路径：`checkpoints/knowledge-graph/`（保持不变）
  - 新增：`embeddings.bin`（TransE 嵌入）、`growth-config.json`
  - 向后兼容：已有 `entities.json` + `edges.json` 继续可用 ✅ 2026-06-06
- [x] 5.6 E2E 测试 ✅ 2026-06-06
  - 测试即时能力：新增实体后立刻影响编码
  - 测试成长能力：模拟 1000 次交互后 KG 指标变化
  - 测试传递推理：A→B→C 自动推导 A→C
  - 测试门控融合：有 KG vs 无 KG 编码质量对比

### Phase 6：性能优化与文档（1天）

**目标**：性能优化和文档完善

**任务清单**：

- [x] 6.1 性能优化 ✅ 2026-06-06
  - KG 检索：< 1ms（HashMap 直查 + top-K 小堆）
  - 实体提取：< 5ms（规则匹配，不依赖大模型）
  - TransE 推理：< 2ms（向量加法 + 相似度）
  - 总开销：< 5ms/次（可接受）
- [x] 6.2 内存优化 ✅ 2026-06-06
  - 嵌入向量用 Float32Array 连续存储
  - LRU 淘汰低频实体
  - 预估内存：10K 实体 × 256 维 × 4 字节 = 10MB
- [x] 6.3 更新文档 ✅ 2026-06-06
  - 更新 `ARCHITECTURE.md`：增加 KG 增强层说明
  - 更新 `README.md`：新增 KG 相关描述
  - 更新本文档：标记已完成任务

## 三、时间线（修订）

```
Week 1:
  Day 1     → Phase 0（清理重复代码，统一接口）
  Day 2-3   → Phase 1（TransE 嵌入层）
  Day 4     → Phase 2（传递推理 + 同义合并）
  Day 5     → Phase 3（实体抽取增强）

Week 2:
  Day 1     → Phase 4（成长监控）
  Day 2-3   → Phase 5（集成联调）
  Day 4     → Phase 6（性能优化 + 文档）
  Day 5     → Buffer（修复/调整）
```

**总计：约 9 个工作日**（比 v1 节省 1 天，因复用已有基础设施）

## 四、风险与缓解（修订）

| 风险 | 影响 | 缓解措施 |
|---|---|---|
| 删除 kg/ 目录后遗漏依赖 | 编译失败 | Phase 0.1 前 grep 确认无 import |
| Entity 接口扩展破坏已有代码 | 运行时错误 | 所有新字段设为可选（`?`） |
| TransE 训练不收敛 | 嵌入质量差 | Xavier 初始化 + 学习率衰减 + 负采样 |
| 13 种关系模式抽取精度不足 | KG 噪声大 | 置信度阈值 + LLM 优先 + 规则降级 |
| 嵌入维度扩展后内存翻倍 | OOM | 仅在实体 >10K 时触发 + LRU 淘汰 |

## 五、成功指标（保持不变）

| 指标 | 当前（纯 ByteEncoder） | 目标（KG 增强后） |
|---|---|---|
| STS 相关性 | 0.57 | 0.75+ |
| 即时知识生效 | ❌ 需训练 | ✅ 毫秒级 |
| 同字不同义区分 | ❌ 无能力 | ✅ 门控消歧 |
| 每次交互延迟 | < 3ms | < 8ms（可接受） |
| 内存占用 | ~2MB | < 10MB |

## 六、与 v1 的关键差异

| 维度 | v1（原始计划） | v2（整合版） |
|---|---|---|
| 基础 | 新建 `src/brain/right/kg/` | 扩展已有 `features/knowledge-graph.ts` |
| 嵌入维度 | 128（需投影） | 256（与 ByteEncoder 对齐） |
| 门控融合 | 新建 KGEnhancedEncoder | 复用已有 KnowledgeGate |
| 关系类型 | 6 种 | 13 种（超集） |
| 已有集成 | 全部断开重连 | 保持不变，增量增强 |
| 实体抽取 | 独立 EntityExtractor | 接入 KnowledgeExtractor 降级通道 |
| 代码量 | ~800 行新代码 | ~400 行新增 + ~100 行修改 |
| 风险 | 高（全面替换） | 低（增量扩展） |
