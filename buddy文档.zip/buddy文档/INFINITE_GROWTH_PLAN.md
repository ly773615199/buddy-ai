# 无限成长语义编码器 — MoE 综合方案

> **版本**: v2.0（MoE 核心）  
> **日期**: 2026-06-07  
> **状态**: 待实施  
> **前序**: 替代 v1.0 的加维度/加层方案

---

## 〇、设计哲学

### 旧方案（加维度/加层）的死胡同

```
L0(128) → L1(128) → L2(128) → L3(256) → L4(256) → L5(384) → ???
                                                    ↑
                                              总线宽度改变
                                              下游全部要改
                                              到此为止
```

### 新方案（MoE）的无限路径

```
                    总线宽度永远 = 256
                           ↓
输入 → [共享 Attention] → [MoE-FFN] → 256 维输出
                         ↓
                   Expert 1 (256→512→256)
                   Expert 2 (256→512→256)
                   Expert 3 (256→512→256)
                   ...
                   Expert N (256→512→256)    ← N 可以无限增长
                         ↓
                   Router 选择 Top-K（如 K=2）
                         ↓
                   推理成本恒定，容量无限
```

### 核心原则

1. **总线宽度不变**：输出永远 256 维，下游零影响
2. **Attention 共享**：上下文理解是通用能力，不区分 expert
3. **FFN 是专家**：不同 expert 处理不同类型的语义
4. **稀疏激活**：每次推理只用 Top-K 个 expert，成本恒定
5. **无限增长**：加 expert = 加容量，无理论上限

---

## 一、架构设计

### 1.1 MoE EncoderBlock

```
输入 x [S, 256]
  ↓
MultiHeadAttention（共享，不变）
  ↓
  + residual
  ↓
LayerNorm
  ↓
Router(x) → gate_scores [S, N]   ← N = expert 数量
  ↓
Top-K 选择（K=2）
  ↓
Σ gate_i × expert_i(x)           ← 只计算被选中的 expert
  ↓
  + residual
  ↓
输出 [S, 256]
```

**参数量对比**：

| 配置 | Attention | FFN/MoE-FFN | 总参数 |
|------|-----------|-------------|--------|
| 原始 4层/ffn=1024 | 4×(256²×4+256×4) = 1.05M | 4×(256×1024×2+1024+256)×2 = 4.2M | 5.25M |
| MoE 4层/8expert/ffn=512/K=2 | 1.05M（不变） | 4×(256×512×2+512+256)×8 = 8.4M（总） | 9.45M |
| **实际推理** | 1.05M | 4×(256×512×2+512+256)×2 = 2.1M（Top-2） | **3.15M** |

**总参数 9.45M（容量大），推理参数 3.15M（成本低）。**

### 1.2 Growth Level 重新定义

```typescript
static readonly GROWTH_LEVELS = [
  // Dense 阶段（冷启动，预训练）
  { numLayers: 2, hiddenDim: 256, ffnDim: 512,  numExperts: 0, label: 'L0-Dense: 1.2M' },
  { numLayers: 4, hiddenDim: 256, ffnDim: 512,  numExperts: 0, label: 'L1-Dense: 2.4M' },
  { numLayers: 6, hiddenDim: 256, ffnDim: 512,  numExperts: 0, label: 'L2-Dense: 3.6M' },
  
  // MoE 阶段（Sparse Upcycling，无限增长）
  { numLayers: 6, hiddenDim: 256, ffnDim: 512,  numExperts: 4,  label: 'L3-MoE4: 8.4M' },
  { numLayers: 6, hiddenDim: 256, ffnDim: 512,  numExperts: 8,  label: 'L4-MoE8: 15.6M' },
  { numLayers: 6, hiddenDim: 256, ffnDim: 512,  numExperts: 16, label: 'L5-MoE16: 30M' },
  { numLayers: 6, hiddenDim: 256, ffnDim: 512,  numExperts: 32, label: 'L6-MoE32: 58.8M' },
  { numLayers: 6, hiddenDim: 256, ffnDim: 512,  numExperts: 64, label: 'L7-MoE64: 116M' },
  // ... 可以无限继续
];
```

**关键**：hiddenDim 永远是 256，ffnDim 永远是 512。只增加 numExperts。

### 1.3 Router 设计

```typescript
/**
 * Router — 轻量门控网络
 *
 * 输入: [S, 256] → 输出: [S, N] gate scores
 *
 * 结构：单层线性投影 + softmax
 * 参数量：256 × N + N（极小）
 */
class Router {
  weight: Tensor;  // [hiddenDim, numExperts]
  bias: Tensor;    // [numExperts]
  
  forward(x: Tensor, topK: number): { gates: number[]; indices: number[] };
}
```

### 1.4 Load Balancing Loss

```typescript
/**
 * 防止所有输入走同一个 expert（专家坍缩）
 *
 * L_balance = N × Σ (f_i × p_i)
 *
 * f_i = expert i 被选中的频率（前向统计）
 * p_i = expert i 的平均路由概率
 * N = expert 数量
 *
 * 目标：f_i ≈ p_i ≈ 1/N（均匀使用）
 */
```

---

## 二、分阶段执行计划

### Phase 0：MoE 基础模块（2天）

**目标**：实现 MoE-FFN 和 MoE EncoderBlock，替换 Dense FFN。

**任务清单**：

- [ ] 0.1 新建 `src/brain/right/nn/moe-ffn.ts`
  ```typescript
  /**
   * MoEFeedForward — 混合专家前馈网络
   *
   * 结构：N 个 Expert FFN + Router
   * 每个 Expert = 标准 FFN（dModel → ffnDim → dModel）
   * Router = 线性投影 + softmax
   *
   * 前向：
   * 1. Router 计算 gate scores
   * 2. Top-K 选择 expert
   * 3. 只计算被选中的 expert
   * 4. 加权求和输出
   *
   * 推理成本：K 个 expert 的计算量（不是 N 个）
   */
  export class MoEFeedForward {
    experts: FeedForward[];
    router: Router;
    topK: number;
    numExperts: number;
    
    constructor(dModel: number, ffnDim: number, numExperts: number, topK?: number);
    forward(x: Tensor): Tensor;
    parameters(): Tensor[];
    
    /** 从 Dense FFN 初始化（Sparse Upcycling） */
    static fromDense(dense: FeedForward, numExperts: number, topK?: number): MoEFeedForward;
    
    /** 添加新 expert（从已有 expert 复制 + 噪声） */
    addExpert(sourceExpertIdx?: number): void;
    
    /** 获取 expert 使用统计 */
    getUsageStats(): { expertId: number; usageCount: number; avgGate: number }[];
  }
  ```

- [ ] 0.2 新建 `src/brain/right/nn/router.ts`
  ```typescript
  /**
   * Router — 轻量门控网络
   *
   * 单层线性投影 + softmax + Top-K
   * 参数量：hiddenDim × numExperts + numExperts
   */
  export class Router {
    weight: Tensor;
    bias: Tensor;
    
    constructor(hiddenDim: number, numExperts: number);
    forward(x: Tensor, topK: number): { gates: Float32Array; indices: number[] };
    parameters(): Tensor[];
  }
  ```

- [ ] 0.3 新增 `MoEEncoderBlock`
  ```typescript
  /**
   * MoEEncoderBlock — MoE 版 EncoderBlock
   *
   * Attention 部分不变（共享）
   * FFN 部分替换为 MoE-FFN
   */
  export class MoEEncoderBlock {
    attention: MultiHeadAttention;  // 共享，不变
    moe: MoEFeedForward;            // 替换 FFN
    
    constructor(dModel: number, numHeads: number, ffnDim: number, numExperts: number, topK?: number);
    forward(x: Tensor, useCausalMask?: boolean): Tensor;
    parameters(): Tensor[];
    
    /** 从标准 EncoderBlock 转换（Sparse Upcycling） */
    static fromDense(block: EncoderBlock, numExperts: number, topK?: number): MoEEncoderBlock;
  }
  ```

- [ ] 0.4 Load Balancing Loss
  ```typescript
  /**
   * 在 MoEFeedForward 中新增：
   * - 前向时统计每个 expert 的使用频率
   * - 返回 auxLoss（Load Balancing Loss）
   * - 训练时加入总 loss
   */
  ```

- [ ] 0.5 编写单元测试
  - 测试 MoE 前向：输出维度不变（256）
  - 测试 Sparse Upcycling：Dense → MoE 后输出误差 < 1e-6
  - 测试 Top-K 稀疏激活：只计算 K 个 expert
  - 测试 Load Balancing：expert 使用率均匀
  - 测试 addExpert：新 expert 不影响已有 expert

**验收标准**：
- MoE-FFN 输出维度 = 输入维度（256）
- Sparse Upcycling 后输出误差 < 1e-6
- Top-K 激活验证：计算量 ≈ K × 单 expert 计算量

---

### Phase 1：ByteEncoder MoE 化（1天）

**目标**：将 ByteEncoder 的 EncoderBlock 替换为 MoEEncoderBlock。

**任务清单**：

- [ ] 1.1 修改 `text-encoder.ts` — 支持 MoE 配置
  ```typescript
  export interface ByteEncoderConfig {
    byteDim: number;
    hiddenDim: number;      // 永远 256
    numHeads: number;
    numLayers: number;
    ffnDim: number;          // 永远 512
    numExperts: number;      // 0 = Dense, >0 = MoE
    topK: number;            // Top-K 激活，默认 2
    // ...其他字段不变
  }
  ```

- [ ] 1.2 修改构造函数 — 根据 numExperts 选择 block 类型
  ```typescript
  constructor(config?: Partial<ByteEncoderConfig>) {
    // ...
    for (let i = 0; i < this.config.numLayers; i++) {
      if (this.config.numExperts > 0) {
        this.encoderBlocks.push(
          new MoEEncoderBlock(H, numHeads, ffnDim, numExperts, topK)
        );
      } else {
        this.encoderBlocks.push(
          new EncoderBlock(H, numHeads, ffnDim)
        );
      }
    }
  }
  ```

- [ ] 1.3 修改 `expand()` — MoE 专家扩展
  ```typescript
  /**
   * MoE 扩展：添加新 expert
   *
   * 不改层数，不改维度，只加 expert。
   * 新 expert 从已有 expert 复制 + 微小噪声（Net2Net 思想）。
   */
  expandMoE(numNewExperts: number): void {
    for (const block of this.encoderBlocks) {
      if (block instanceof MoEEncoderBlock) {
        for (let i = 0; i < numNewExperts; i++) {
          block.moe.addExpert(); // 复制随机已有 expert + 噪声
        }
      }
    }
  }
  ```

- [ ] 1.4 修改 `parameters()` — 包含 MoE 参数
  ```typescript
  // MoEEncoderBlock.parameters() 已包含所有 expert 参数
  // ByteEncoder.parameters() 无需修改（遍历 encoderBlocks）
  ```

- [ ] 1.5 修改 `loadWeightsBinary()` — MoE 权重兼容
  ```typescript
  /**
   * 加载 Dense checkpoint 到 MoE 模型（Sparse Upcycling）：
   * 1. Attention 权重：直接加载（共享）
   * 2. FFN 权重：复制到所有 expert
   * 3. Router 权重：Xavier 初始化
   */
  ```

- [ ] 1.6 编写测试
  - 测试 Dense ByteEncoder 和 MoE ByteEncoder 输出一致（Sparse Upcycling 后）
  - 测试 expandMoE 后输出维度不变

**验收标准**：
- ByteEncoder 支持 `numExperts` 配置
- Dense checkpoint 可以加载到 MoE 模型
- 输出维度永远是 256

---

### Phase 2：预训练阶梯化 + 冷启动（2天）

**目标**：实现从 Dense 到 MoE 的阶梯式预训练。

**任务清单**：

- [ ] 2.1 重构 `pretrain-encoder.ts`
  ```typescript
  /**
   * 阶梯式预训练：
   *
   * 阶段 1（Dense）：
   *   L0-Dense(2层) → 训练收敛
   *   L1-Dense(4层) → Net2DeeperNet + 训练收敛
   *   L2-Dense(6层) → Net2DeeperNet + 训练收敛
   *
   * 阶段 2（MoE 转换）：
   *   L2-Dense → Sparse Upcycling → L3-MoE4
   *   训练收敛（Router + 新 Expert）
   *
   * 阶段 3（MoE 扩展）：
   *   L3-MoE4 → addExpert → L4-MoE8
   *   训练收敛（新 Expert）
   *   L4-MoE8 → addExpert → L5-MoE16
   *   ...无限继续
   */
  async function pretrainStaircase(args: {
    targetLevel: number;
    epochsPerLevel: number;
    dataPath: string;
  }): Promise<void>;
  ```

- [ ] 2.2 课程学习数据排序
  ```typescript
  /**
   * Dense 阶段：简单数据（短文本、高重叠）
   * MoE 阶段：复杂数据（长文本、低重叠、跨语言）
   * MoE 扩展阶段：领域数据（每个 expert 可以有偏好领域）
   */
  function curriculumSort(pairs: Pair[], level: number): Pair[];
  ```

- [ ] 2.3 收敛检测
  ```typescript
  function checkConvergence(trainLog: TrainLog[]): {
    converged: boolean;
    reason: string;
  };
  ```

- [ ] 2.4 checkpoint 元数据
  ```typescript
  interface CheckpointMeta {
    growthLevel: number;
    config: ByteEncoderConfig;
    step: number;
    trainLog: TrainLog[];
    // MoE 特有
    expertStats?: {
      numExperts: number;
      topK: number;
      usageDistribution: number[];  // 每个 expert 的使用率
      loadBalanceLoss: number;
    };
  }
  ```

**验收标准**：
- `npx tsx pretrain-encoder.ts --staircase --target-level 4` 自动走完 L0→L4
- Dense 阶段和 MoE 阶段都能收敛
- checkpoint 包含 MoE 元数据

---

### Phase 3：权重加载兼容（1天）

**目标**：支持 Dense↔MoE、不同 expert 数量之间的 checkpoint 加载。

**任务清单**：

- [ ] 3.1 Dense → MoE 加载（Sparse Upcycling）
  ```typescript
  // loadWeightsBinary() 新增：
  // checkpoint 是 Dense，当前是 MoE
  // → Attention 直接加载
  // → FFN 复制到所有 expert
  // → Router Xavier 初始化
  ```

- [ ] 3.2 MoE → MoE 加载（不同 expert 数量）
  ```typescript
  // checkpoint 有 4 expert，当前有 8 expert
  // → 前 4 个 expert 直接加载
  // → 后 4 个 expert 从前 4 个复制 + 噪声
  // → Router 重新初始化（维度变了）
  ```

- [ ] 3.3 MoE → Dense 加载（降级）
  ```typescript
  // checkpoint 是 MoE，当前是 Dense
  // → 只加载第一个 expert 的 FFN 权重
  // → Attention 直接加载
  ```

- [ ] 3.4 增强 `tryLoadPretrained()`
  ```typescript
  private tryLoadPretrained(): void {
    // 1. 读取 checkpoint 元数据
    // 2. 判断 Dense/MoE 和 expert 数量
    // 3. 选择合适的加载策略
    // 4. 加载 + 打印统计
  }
  ```

- [ ] 3.5 checkpoint migration 工具
  ```typescript
  /**
   * 任意 checkpoint → 当前配置
   * 自动选择最佳加载策略
   */
  async function migrateCheckpoint(
    oldPath: string,
    currentConfig: ByteEncoderConfig,
    outputPath: string,
  ): Promise<void>;
  ```

**验收标准**：
- Dense checkpoint → MoE 模型：输出误差 < 1e-6
- MoE 4expert → MoE 8expert：前 4 expert 输出不变
- 旧格式 checkpoint 兼容加载

---

### Phase 4：容量评估与自动扩展（1天）

**目标**：实现生产环境自动 MoE 扩展。

**任务清单**：

- [ ] 4.1 `CapacityAssessor` 模块
  ```typescript
  /**
   * 容量评估信号：
   *
   * 1. Expert 使用不均匀度：
   *    - 某个 expert 使用率 > 50% → 需要更多 expert
   *    - 使用率方差 > 阈值 → expert 专业化不足
   *
   * 2. 编码质量：
   *    - 向量方差 < 0.005 → 容量不足
   *    - gap 下降 → 区分度不足
   *
   * 3. 数据量：
   *    - 累积数据 > 当前容量阈值 → 可以支撑更多 expert
   *
   * 输出：
   * - action: 'none' | 'add_experts' | 'add_layers'
   * - numNewExperts: 建议新增的 expert 数量
   * - reason: 决策原因
   */
  export class CapacityAssessor {
    assess(stats: MoECapacityStats): GrowthDecision;
  }
  ```

- [ ] 4.2 接入 CapacityMonitor
  ```typescript
  // CapacityMonitor 定期评估：
  // 1. 收集 expert 使用统计
  // 2. 调用 CapacityAssessor.assess()
  // 3. 如果 action === 'add_experts'：
  //    → encoder.expandMoE(numNewExperts)
  //    → 通知 IdleTrainer 开始训练新 expert
  ```

- [ ] 4.3 成长日志
  ```typescript
  interface MoEGrowthEvent {
    timestamp: number;
    trigger: string;
    fromExperts: number;
    toExperts: number;
    expertUsageBefore: number[];
    expertUsageAfter?: number[];
  }
  ```

**验收标准**：
- Expert 使用不均匀时自动触发扩展
- 扩展过程不影响正常推理
- 成长事件记录到日志

---

### Phase 5：EWC 防遗忘 + 新 Expert 训练（1天）

**目标**：确保新 expert 训练不破坏已有知识。

**任务清单**：

- [ ] 5.1 EWC 正则（复用 v1.0 设计）
  ```typescript
  export class EWCRegularizer {
    computeFisher(encoder: ByteEncoder, data: Pair[]): Map<Tensor, Float32Array>;
    computeLoss(params: Tensor[]): number;
    snapshot(params: Tensor[]): void;
  }
  ```

- [ ] 5.2 新 Expert 专用训练策略
  ```typescript
  /**
   * 新 expert 训练：
   *
   * 1. 冻结：Attention + 旧 Expert + Router
   * 2. 只训练：新 Expert 的 FFN 参数
   * 3. EWC 正则：保护旧 Expert 的权重
   * 4. 逐步解冻：训练 N 轮后解冻 Router（允许重新路由）
   * 5. 最终：解冻全部，联合微调
   */
  ```

- [ ] 5.3 接入 ByteEncoderBridge
  ```typescript
  // ByteEncoderBridge 新增：
  // - MoE-aware 的 newParamMask（只标记新 expert 参数）
  // - Load Balancing Loss 集成
  // - EWC 正则集成
  ```

- [ ] 5.4 接入 IdleTrainer
  ```typescript
  // IdleTrainer._tickKG() 后新增：
  // - 检查是否有待训练的新 expert
  // - 如果有 → 增量训练新 expert
  ```

**验收标准**：
- 新 expert 训练后，旧 expert 输出不变
- Router 重新路由后，整体编码质量不下降
- EWC 正则有效防止灾难性遗忘

---

### Phase 6：生产环境集成（1天）

**目标**：完整接入生产环境的自动成长管线。

**任务清单**：

- [ ] 6.1 接入 DreamEngine
  ```typescript
  // DreamEngine.dream() 中新增：
  // - 评估 expert 使用均匀度
  // - 如果不均匀 → 触发 addExpert
  ```

- [ ] 6.2 成长事件通知
  ```typescript
  // 成长完成后通知：
  // "编码器 MoE 扩展：4 expert → 8 expert"
  // "新 expert 正在闲时训练中..."
  ```

- [ ] 6.3 监控仪表盘
  ```typescript
  // CapacityMonitor 状态新增：
  // - 当前 expert 数量
  // - 每个 expert 的使用率（柱状图）
  // - Load Balance Loss
  // - 距离下一次扩展的阈值
  ```

- [ ] 6.4 Expert 专业化分析
  ```typescript
  /**
   * 分析每个 expert 的偏好：
   * - 统计每个 expert 处理的文本类型
   * - 识别 expert 的"专业领域"
   * - 可视化 expert 分工
   */
  ```

**验收标准**：
- 生产环境自动触发 MoE 扩展
- 扩展过程对话零中断
- Expert 专业化可观测

---

## 三、文件变更清单

### 新增文件

| 文件 | 用途 |
|------|------|
| `src/brain/right/nn/router.ts` | Router 门控网络 |
| `src/brain/right/nn/moe-ffn.ts` | MoE-FFN 混合专家前馈 |
| `src/brain/right/nn/moe-encoder-block.ts` | MoE EncoderBlock |
| `src/brain/right/training/capacity-assessor.ts` | 容量评估器 |
| `src/brain/right/training/ewc.ts` | EWC 正则化器 |
| `src/brain/right/nn/moe.test.ts` | MoE 单元测试 |

### 修改文件

| 文件 | 变更 |
|------|------|
| `src/brain/right/features/text-encoder.ts` | 支持 MoE 配置；expandMoE()；loadWeights MoE 兼容 |
| `src/brain/right/training/pretrain-encoder.ts` | 阶梯式预训练；Dense→MoE 转换；课程学习 |
| `src/brain/right/training/byte-encoder-bridge.ts` | MoE-aware mask；Load Balancing Loss；EWC |
| `src/brain/right/training/idle-trainer.ts` | 新 expert 训练触发 |
| `src/brain/right/training/capacity-monitor.ts` | 接入 CapacityAssessor |
| `src/brain/right/features/text-encoder.ts` | GROWTH_LEVELS 重新定义 |

---

## 四、时间线

```
Week 1:
  Day 1-2   → Phase 0（MoE 基础模块：Router + MoE-FFN + MoEEncoderBlock）
  Day 3     → Phase 1（ByteEncoder MoE 化）
  Day 4-5   → Phase 2（预训练阶梯化 + 冷启动）

Week 2:
  Day 1     → Phase 3（权重加载兼容）
  Day 2     → Phase 4（容量评估与自动扩展）
  Day 3     → Phase 5（EWC 防遗忘 + 新 Expert 训练）
  Day 4     → Phase 6（生产环境集成）
```

**总计：约 9 个工作日**

---

## 五、风险与缓解

| 风险 | 影响 | 缓解措施 |
|------|------|---------|
| Expert 坍缩（所有输入走同一 expert） | MoE 退化为 Dense | Load Balancing Loss + Router Z-loss |
| Router 训练不稳定 | 路由混乱 | Router 学习率 < Expert 学习率；Router 预热 |
| Sparse Upcycling 后精度下降 | 转换损失 | 复制 Dense FFN 到所有 expert，100% 保持 |
| 新 Expert 收敛慢 | 扩展后质量下降 | 冻结旧参数 + EWC + 逐步解冻 |
| 推理延迟增加（Router 开销） | 用户体验 | Router 是单层线性，开销 < 0.1ms |
| MoE 训练需要更多数据 | 数据不足 | 课程学习 + 数据增强 |

---

## 六、成功指标

| 指标 | 当前 | 目标 |
|------|------|------|
| 成长上限 | L5（6.9M）就到头 | **无限**（expert 数量无上限） |
| 总线宽度 | 256（不变） | 256（不变） |
| 下游影响 | 加宽时全部要改 | **零影响** |
| 推理成本 | 随容量线性增长 | **恒定**（Top-K 稀疏） |
| 冷启动 | 需要从零训练 | Sparse Upcycling（已有权重复用） |
| Expert 专业化 | N/A | 每个 expert 有明确偏好领域 |
| 自动扩展 | 手动脚本 | CapacityMonitor 自动触发 |

---

## 七、与已有组件的兼容性

| 组件 | 影响 | 说明 |
|------|------|------|
| 启智离线预训练权重 | ✅ 零影响 | Dense checkpoint 通过 Sparse Upcycling 加载到 MoE |
| KGEmbedder | ✅ 零影响 | TransE 嵌入独立，不依赖 ByteEncoder 内部结构 |
| KnowledgeGate | ✅ 零影响 | hiddenDim=256 不变 |
| ProjectionHead | ✅ 零影响 | inputDim=256 不变 |
| VectorIndex | ✅ 零影响 | dim=256 不变 |
| MultimodalFusion | ✅ 零影响 | hiddenDim=256 不变 |
| ReasoningHead | ✅ 零影响 | hiddenDim=256 不变 |
| 30+ 处硬编码 256 | ✅ 零影响 | 总线宽度永远 256 |
| ByteEncoder 内部 | ⚠️ 仅内部变更 | EncoderBlock → MoEEncoderBlock，对外接口不变 |

---

## 八、无限成长路径

```
Dense 冷启动（有限容量）：
  L0-Dense(2层) → L1-Dense(4层) → L2-Dense(6层)
  ↑ 用 Net2DeeperNet 加层，预训练收敛

MoE 转换（容量跳变）：
  L2-Dense → Sparse Upcycling → L3-MoE4
  ↑ Dense FFN 复制到 4 个 Expert

MoE 无限扩展（容量无限）：
  L3-MoE4 → addExpert → L4-MoE8
  L4-MoE8 → addExpert → L5-MoE16
  L5-MoE16 → addExpert → L6-MoE32
  L6-MoE32 → addExpert → L7-MoE64
  ...
  L(N)-MoE(2^N) → addExpert → L(N+1)-MoE(2^(N+1))
  ↑ 永远可以继续，总线宽度不变，推理成本不变
```

**理论上**：Expert 数量可以到 256、1024、甚至更多（DeepSeek-V3 用了 256 个 Expert）。
**实际上**：内存和训练数据量是瓶颈，但架构本身没有上限。
