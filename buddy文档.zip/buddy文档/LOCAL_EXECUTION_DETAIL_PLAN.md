# 本地执行能力补全计划 — 详细实施方案

> 版本: v1.0
> 日期: 2026-05-22
> 关联: LOCAL_EXECUTION_MASTERY_PLAN.md
> 原则: **基于代码现状，逐层补全，每步可验证**

---

## 零、代码现状总览

### 已有基础设施

| 组件 | 文件 | 行数 | 当前能力 | 本计划需要增强 |
|------|------|------|---------|---------------|
| 规则引擎 | `src/brain/left/rule-engine.ts` | 500+ | 输出 `{mode, selectedNodes, confidence}` | Phase 1: 输出 `ExecutablePlan` |
| 计划执行器 | `src/core/plan-executor.ts` | 400+ | `local_only` 只做文本回答 | Phase 3: 按步骤执行工具 |
| 调度学习器 | `src/brain/dispatch/learner.ts` | 476 | 三路蒸馏（信号/经验/Thompson） | Phase 4: 新增 tool call 蒸馏 |
| 经验编译器 | `src/intelligence/experience-compiler.ts` | 430 | 对话→经验单元（含 DAG） | Phase 4: 增强 tool call 提取 |
| 策略蒸馏器 | `src/brain/left/policy-distiller.ts` | 83 | 聚类→规则生成/淘汰 | Phase 6: 基于 tool call 模式生成 |
| 裁决器 | `src/brain/dispatch/arbiter.ts` | 150 | 质量×0.7+可行×0.25+成本×0.05 | Phase 5: 新增评分维度 |
| 反馈学习器 | `src/feedback/learner.ts` | 118 | 用户纠正→记忆 | 不变 |
| BuddyLM | `src/brain/right/nn/buddy-lm.ts` | 300+ | 文本生成 | Phase 2: tool call 生成 |
| ShadowBrain | `src/brain/shadow/index.ts` | 800+ | 自训练样本收集 | Phase 4: 收集 tool call 样本 |

### 关键数据流断裂点

```
reflector.ts 有完整 toolCalls: Array<{name, args, result}>
  ↓ 但传给 brain.feedback() 时只传了 toolsUsed: string[]（只有名字）
  ↓
DispatchLearner 收不到完整 tool call 数据
  ↓
无法生成 tool call 训练样本
无法提取结构化经验步骤
无法基于 tool call 模式生成规则
```

---

## Phase 1: 规则引擎产出可执行计划

### 1.1 新增类型定义

**文件**: `src/brain/types.ts`

```typescript
// ==================== 可执行计划类型（Phase 1 新增） ====================

/** 可执行步骤 */
export interface ExecutableStep {
  /** 步骤唯一 ID */
  id: string;
  /** 步骤类型 */
  type: 'tool_call' | 'reasoning' | 'decision' | 'generate' | 'verify';

  // ── tool_call 类型 ──
  /** 工具名称（type=tool_call 时必填） */
  tool?: string;
  /** 工具参数（type=tool_call 时必填，支持变量引用 ${step_N_output}） */
  args?: Record<string, unknown>;

  // ── reasoning/generate 类型 ──
  /** 提示词（type=reasoning/generate 时必填） */
  prompt?: string;
  /** 期望输出格式 */
  expectedFormat?: 'text' | 'json' | 'tool_calls';

  // ── decision 类型 ──
  /** 条件表达式（type=decision 时必填，支持 ${step_N_output} 引用） */
  condition?: string;
  /** 条件分支 */
  branches?: Array<{ value: string; nextStepId: string }>;

  // ── 通用 ──
  /** 依赖的前置步骤 ID */
  dependsOn: string[];
  /** 执行者偏好（按优先级排序） */
  preferredExecutors: Array<'local' | 'buddyLM' | 'cloudLLM'>;
  /** 超时（ms） */
  timeoutMs?: number;
  /** 失败时是否继续（默认 false） */
  continueOnError?: boolean;
}

/** 可执行计划 */
export interface ExecutablePlan {
  /** 执行步骤序列 */
  steps: ExecutableStep[];
  /** 预期输出描述（人类可读） */
  expectedOutput: string;
  /** 置信度 */
  confidence: number;
  /** 来源 */
  source: 'rule' | 'buddyLM' | 'assembly' | 'cloudLLM' | 'experience' | 'learned';
  /** 是否需要云端 LLM 增强 */
  needsCloudEnhancement: boolean;
  /** 增强原因 */
  enhancementReason?: string;
}
```

### 1.2 扩展 ExecutionPlan

**文件**: `src/types.ts`（`OrchestrationPlan` 旁边新增，不修改现有类型）

```typescript
// 在 OrchestrationPlan 接口中新增可选字段（向后兼容）
export interface OrchestrationPlan {
  // ... 现有字段不动 ...

  /** Phase 1: 可执行计划（有此字段时优先走本地执行路径） */
  executablePlan?: import('./brain/types.js').ExecutablePlan;
}
```

### 1.3 规则引擎升级

**文件**: `src/brain/left/rule-engine.ts`

策略：**渐进升级，旧格式自动转换**。新增规则直接写 `ExecutablePlan`，旧规则通过适配器转换。

```typescript
// 新增：规则 action 可以返回 ExecutablePlan
interface RuleAction {
  (signal: TaskSignal, resources: ResourceState): ExecutionPlan & {
    /** Phase 1: 可执行计划（可选，有则优先走本地） */
    executablePlan?: ExecutablePlan;
  };
}

// 新增：旧格式 → ExecutablePlan 自动转换
function toExecutablePlan(plan: ExecutionPlan): ExecutablePlan | undefined {
  // local_only 模式且有 experience 节点 → 尝试转换
  if (plan.mode === 'local_only' && plan.selectedNodes.some(n => n.type === 'experience')) {
    const node = plan.selectedNodes.find(n => n.type === 'experience')!;
    return {
      steps: [{
        id: 'step_1',
        type: 'tool_call',
        tool: node.skillId === '__web_direct_search__' ? 'search' : 'read',
        args: { query: plan.content },
        dependsOn: [],
        preferredExecutors: ['local'],
      }],
      expectedOutput: plan.reason,
      confidence: plan.confidence,
      source: 'rule',
      needsCloudEnhancement: false,
    };
  }
  return undefined; // 无法转换，走原有流程
}
```

**新增规则示例**（git status、file read 等确定性任务）：

```typescript
{
  id: 'seed_executable_git_status',
  name: 'Git 状态查询（可执行）',
  priority: 85,
  condition: (signal) => signal.domains.includes('code') && /git.*status/i.test(signal.content ?? ''),
  action: (signal, resources) => ({
    mode: 'local_only',
    reason: 'git status 查询',
    selectedNodes: [{ id: 'auto', type: 'experience' }],
    confidence: 0.9,
    source: 'rule',
    executablePlan: {
      steps: [{
        id: 'step_1',
        type: 'tool_call',
        tool: 'exec',
        args: { command: 'git status' },
        dependsOn: [],
        preferredExecutors: ['local'],
      }],
      expectedOutput: 'git 仓库状态',
      confidence: 0.9,
      source: 'rule',
      needsCloudEnhancement: false,
    },
  }),
  source: 'builtin',
},
{
  id: 'seed_executable_file_read',
  name: '文件读取（可执行）',
  priority: 80,
  condition: (signal) => /查看|读|打开|read|show|cat/.test(signal.content ?? '') && /[\w/.\-]+\.\w+/.test(signal.content ?? ''),
  action: (signal, resources) => {
    const fileMatch = signal.content!.match(/([\w/.\-]+\.\w+)/);
    const filePath = fileMatch?.[1] ?? '';
    return {
      mode: 'local_only',
      reason: `读取文件 ${filePath}`,
      selectedNodes: [{ id: 'auto', type: 'experience' }],
      confidence: 0.85,
      source: 'rule',
      executablePlan: {
        steps: [{
          id: 'step_1',
          type: 'tool_call',
          tool: 'read',
          args: { file_path: filePath },
          dependsOn: [],
          preferredExecutors: ['local'],
        }],
        expectedOutput: `文件 ${filePath} 的内容`,
        confidence: 0.85,
        source: 'rule',
        needsCloudEnhancement: false,
      },
    };
  },
  source: 'builtin',
},
```

### 1.4 agent.ts 接入

**文件**: `src/core/agent.ts`

在 `orchestrateWithThreeBrain()` 中，检查 `executablePlan`：

```typescript
// 在 decide() 返回后、plan-executor 执行前
if (decision.plan.executablePlan && decision.plan.executablePlan.confidence >= 0.5) {
  // 本地可执行计划，走新路径
  const localResult = await executeLocalPlan(ctx, decision.plan.executablePlan);
  if (localResult) {
    return {
      content: localResult.text,
      mode: 'local_only',
      reason: `本地执行: ${decision.plan.executablePlan.source}`,
      // ...
    };
  }
  // 本地执行失败，降级到原有流程
}
```

### 1.5 验收标准

- [ ] `ExecutablePlan` / `ExecutableStep` 类型定义完成
- [ ] 规则引擎至少 3 条规则能输出 `ExecutablePlan`
- [ ] 旧格式规则通过 `toExecutablePlan()` 自动转换
- [ ] `git status` / `file read` / `ls` 等简单任务零云端 LLM 执行
- [ ] 现有测试全部通过（向后兼容）

---

## Phase 2: BuddyLM 生成结构化 tool calls

### 2.1 输出格式设计

BuddyLM Decoder 输出两种模式：

```
模式 1（现有）: 自然语言文本
  "你可以运行 git status 查看状态"

模式 2（新增）: tool call JSON
  {"tool":"exec","args":{"command":"git status"}}
```

选择逻辑：
- 简单任务（经验命中）→ 模式 2（直接输出 tool calls）
- 复杂任务（需要推理）→ 模式 1（先推理再转 tool calls）

### 2.2 Tool Call Token 设计

**文件**: `src/brain/right/nn/bbpe-tokenizer.ts`

在 tokenizer 词表中新增特殊 token：

```typescript
// 新增特殊 token
const TOOL_CALL_TOKENS = {
  TOOL_START: '<tool>',     // tool call 开始
  TOOL_END: '</tool>',      // tool call 结束
  ARGS_START: '<args>',     // 参数开始
  ARGS_END: '</args>',      // 参数结束
  TOOL_CALL_EOT: '<|tool_call_eot|>',  // tool call 结束标记
};
```

### 2.3 Decoder 增强

**文件**: `src/brain/right/nn/decoder.ts`

新增 `generateWithToolCalls()` 方法：

```typescript
/** 生成 tool call JSON（模式 2） */
generateWithToolCalls(
  encoderHidden: Tensor,
  intent: number,          // intent_head 输出
  toolScores: Float32Array, // tool_head 输出（32 维）
  maxTokens = 200,
  temperature = 0.3,       // 低温保证格式正确
): { toolCalls: Array<{ tool: string; args: Record<string, unknown> }>; rawText: string } {
  // 1. 构造 tool call prompt prefix
  const promptTokens = this.tokenizer.encode('<tool>');
  
  // 2. 逐 token 生成
  const result = this.generate(encoderHidden, promptTokens[0], maxTokens, temperature);
  const rawText = this.tokenizer.decode(result.tokenIds);
  
  // 3. 解析 JSON
  const toolCalls = this.parseToolCalls(rawText);
  
  return { toolCalls, rawText };
}

/** 从生成的文本中解析 tool call JSON */
private parseToolCalls(text: string): Array<{ tool: string; args: Record<string, unknown> }> {
  const calls: Array<{ tool: string; args: Record<string, unknown> }> = [];
  
  // 匹配 {"tool":"...","args":{...}} 模式
  const jsonPattern = /\{"tool"\s*:\s*"([^"]+)"\s*,\s*"args"\s*:\s*(\{[^}]*\})\}/g;
  let match;
  while ((match = jsonPattern.exec(text)) !== null) {
    try {
      const tool = match[1];
      const args = JSON.parse(match[2]);
      calls.push({ tool, args });
    } catch { /* 格式错误跳过 */ }
  }
  
  return calls;
}
```

### 2.4 BuddyLM 集成

**文件**: `src/brain/right/nn/buddy-lm.ts`

新增 `generateWithToolCalls()` 方法：

```typescript
/** 带 tool call 的生成（根据任务复杂度选择模式） */
generateWithToolCalls(
  pooled: Float32Array,
  context?: { knowledge?: string[]; intent?: string },
): { text: string; toolCalls: Array<{ tool: string; args: Record<string, unknown> }>; mode: 'text' | 'tool_call' } {
  const encoderHidden = this.buildEncoderHidden(pooled, context);
  
  // 获取 intent 和 tool 分类
  const intentHead = this.outputHeads.intent.forward(encoderHidden);
  const toolHead = this.outputHeads.tool.forward(encoderHidden);
  
  // 判断是否走 tool call 模式
  const toolScores = toolHead.data;
  const maxToolScore = Math.max(...toolScores);
  const canUseToolCall = maxToolScore > 0.5; // 工具置信度够高
  
  if (canUseToolCall) {
    // 模式 2: 直接生成 tool call JSON
    const result = this.decoder.generateWithToolCalls(encoderHidden, intentHead.data, toolScores);
    if (result.toolCalls.length > 0) {
      return { text: result.rawText, toolCalls: result.toolCalls, mode: 'tool_call' };
    }
    // 解析失败，降级到模式 1
  }
  
  // 模式 1: 自然语言生成
  const textResult = this.generateWithContext(pooled, context);
  return { text: textResult.text, toolCalls: [], mode: 'text' };
}
```

### 2.5 训练样本格式扩展

**文件**: `src/brain/right/training/buddy-lm-trainer.ts`

```typescript
// 扩展训练样本类型
export interface BuddyLMTrainSample {
  input: string;
  output: string;
  quality: number;
  success: boolean;
  reasoningChain?: string;
  timestamp: number;
  /** Phase 2 新增: tool call 格式输出 */
  toolCallOutput?: string;  // JSON string: [{"tool":"exec","args":{"command":"git status"}}]
  /** Phase 2 新增: 输出模式 */
  outputMode?: 'text' | 'tool_call';
}

// 新增：收集 tool call 样本
collectToolCallSample(
  input: string,
  toolCalls: Array<{ tool: string; args: Record<string, unknown> }>,
  quality: number,
): void {
  if (toolCalls.length === 0) return;
  
  const toolCallJson = JSON.stringify(toolCalls);
  this.sampleBuffer.push({
    input: input.slice(0, 500),
    output: toolCallJson.slice(0, 500),
    quality,
    success: true,
    toolCallOutput: toolCallJson,
    outputMode: 'tool_call',
    timestamp: Date.now(),
  });
}
```

### 2.6 验收标准

- [ ] tokenizer 支持 `<tool>` / `</tool>` 特殊 token
- [ ] `decoder.generateWithToolCalls()` 能输出格式正确的 JSON
- [ ] `buddy-lm.generateWithToolCalls()` 根据任务复杂度自动选择模式
- [ ] tool call 格式训练样本能正常收集和训练
- [ ] 简单任务（git status、file read）BuddyLM 直接输出 tool calls

---

## Phase 3: 执行层接入本地计划

### 3.1 核心：executeLocalPlan()

**文件**: `src/core/plan-executor.ts`

新增 `executeLocalPlan()` 函数：

```typescript
/**
 * 执行本地可执行计划 — 不经过云端 LLM
 *
 * 按步骤顺序执行，支持：
 * - tool_call: 直接调用本地工具
 * - generate: BuddyLM 本地生成
 * - decision: 条件分支
 * - verify: 结果验证
 */
async function executeLocalPlan(
  ctx: ExecutionContext,
  plan: import('../brain/types.js').ExecutablePlan,
): Promise<ExecutionResult | null> {
  const stepResults = new Map<string, string>();
  const toolCalls: ExecutionResult['toolCalls'] = [];
  const startTime = Date.now();

  try {
    for (const step of plan.steps) {
      // 检查依赖
      const depsReady = step.dependsOn.every(d => stepResults.has(d));
      if (!depsReady) {
        log.warn(`步骤 ${step.id} 依赖未满足: ${step.dependsOn.filter(d => !stepResults.has(d)).join(',')}`);
        continue;
      }

      // 解析参数中的变量引用（${step_N_output}）
      const resolvedArgs = resolveStepArgs(step.args, stepResults);

      let stepResult: string;

      switch (step.type) {
        case 'tool_call': {
          if (!step.tool) { stepResult = '[error: missing tool name]'; break; }
          
          // 选择执行者
          const executor = selectExecutor(step, ctx);
          
          if (executor === 'local') {
            // 本地直接执行
            stepResult = await executeLocalTool(ctx, step.tool, resolvedArgs, step.timeoutMs);
          } else if (executor === 'buddyLM') {
            // BuddyLM 执行（未来 Phase 2 集成后）
            stepResult = await executeBuddyLMTool(ctx, step.tool, resolvedArgs);
          } else {
            // 降级到云端 LLM
            stepResult = await executeCloudTool(ctx, step.tool, resolvedArgs);
          }

          toolCalls.push({ name: step.tool, args: resolvedArgs, result: stepResult });
          break;
        }

        case 'generate': {
          // BuddyLM 本地生成
          const prompt = substituteVars(step.prompt ?? '', stepResults);
          const genResult = await ctx.sys.threeBrain?.right?.generateLocal?.(prompt);
          stepResult = genResult?.text ?? '';
          break;
        }

        case 'decision': {
          // 条件判断（规则引擎执行）
          const condition = substituteVars(step.condition ?? '', stepResults);
          stepResult = evaluateCondition(condition) ? 'true' : 'false';
          
          // 跳转到对应分支
          const branch = step.branches?.find(b => b.value === stepResult);
          if (branch?.nextStepId) {
            // 跳转逻辑：跳过非目标步骤
            // （简化实现：按顺序执行，遇到跳转标记）
          }
          break;
        }

        case 'verify': {
          // 结果验证
          const prevResult = step.dependsOn[0] ? stepResults.get(step.dependsOn[0]) : '';
          stepResult = prevResult && !prevResult.startsWith('[') ? 'pass' : 'fail';
          break;
        }

        default:
          stepResult = `[error: unknown step type ${step.type}]`;
      }

      stepResults.set(step.id, stepResult);

      // 检查是否失败
      if (stepResult.startsWith('[error') && !step.continueOnError) {
        return null; // 步骤失败，降级到原有流程
      }
    }

    // 汇总结果
    const outputText = Array.from(stepResults.values())
      .filter(r => r && !r.startsWith('['))
      .join('\n');

    return {
      text: outputText,
      source: `local_plan/${plan.source}`,
      toolCalls,
      qualityScore: plan.confidence,
    };

  } catch (err) {
    log.warn(`本地计划执行失败: ${(err as Error).message}`);
    return null; // 失败，降级到原有流程
  }
}

// ==================== 辅助函数 ====================

/** 解析步骤参数中的变量引用 */
function resolveStepArgs(
  args: Record<string, unknown> | undefined,
  stepResults: Map<string, string>,
): Record<string, unknown> {
  if (!args) return {};
  const resolved: Record<string, unknown> = {};
  for (const [key, value] of Object.entries(args)) {
    if (typeof value === 'string') {
      // 替换 ${step_N_output} 引用
      resolved[key] = value.replace(/\$\{(\w+)_output\}/g, (_, stepId) => {
        return stepResults.get(stepId) ?? '';
      });
    } else {
      resolved[key] = value;
    }
  }
  return resolved;
}

/** 选择执行者 */
function selectExecutor(
  step: ExecutableStep,
  ctx: ExecutionContext,
): 'local' | 'buddyLM' | 'cloudLLM' {
  for (const preferred of step.preferredExecutors) {
    if (preferred === 'local') return 'local';
    if (preferred === 'buddyLM' && ctx.sys.threeBrain?.right?.hasBuddyLM?.()) return 'buddyLM';
    if (preferred === 'cloudLLM' && ctx.sys.llm?.available) return 'cloudLLM';
  }
  return 'local'; // 默认本地
}

/** 本地工具执行 */
async function executeLocalTool(
  ctx: ExecutionContext,
  tool: string,
  args: Record<string, unknown>,
  timeoutMs?: number,
): Promise<string> {
  // 调用工具注册表
  const toolImpl = ctx.sys.tools?.get?.(tool);
  if (!toolImpl) return `[error: tool ${tool} not found]`;

  try {
    const result = await Promise.race([
      toolImpl.execute(args),
      timeoutMs ? new Promise<string>((_, reject) => 
        setTimeout(() => reject(new Error('timeout')), timeoutMs)
      ) : new Promise<string>(() => {}), // 不超时
    ]);
    return typeof result === 'string' ? result : JSON.stringify(result);
  } catch (err) {
    return `[error: ${(err as Error).message}]`;
  }
}
```

### 3.2 执行者选择器

**文件**: `src/core/plan-executor.ts`（内嵌在 `executeLocalPlan` 中）

```typescript
/**
 * 执行者选择逻辑:
 *
 * 1. 工具调用（read/write/exec/search）→ 本地直接执行
 * 2. 简单推理（分类/匹配/格式化）→ BuddyLM 本地执行
 * 3. 知识检索（问答/总结）→ 组装引擎本地执行
 * 4. 复杂推理（多步分析/创作）→ 云端 LLM 执行
 * 5. 条件判断 → 规则引擎本地执行
 */
```

### 3.3 验收标准

- [ ] `executeLocalPlan()` 支持 `tool_call` 类型步骤
- [ ] `exec` / `read` / `write` 工具能直接调用（不经过云端 LLM）
- [ ] 变量引用 `${step_N_output}` 正确解析
- [ ] 步骤失败时降级到原有流程
- [ ] `git status` 端到端零云端 LLM 执行

---

## Phase 4: 蒸馏闭环 — 云端 LLM 教本地

### 4.1 数据流修复（关键前置）

#### 4.1.1 DecisionOutcome 新增 toolCalls 字段

**文件**: `src/brain/types.ts`

```typescript
export interface DecisionOutcome {
  // ... 现有字段不动 ...
  toolsUsed: string[];
  
  /** Phase 4 新增: 完整工具调用序列（含 args 和 result） */
  toolCalls?: Array<{
    name: string;
    args: Record<string, unknown>;
    result: string;
  }>;
}
```

#### 4.1.2 reflector.ts 传递完整 toolCalls

**文件**: `src/core/reflector.ts`

```typescript
// 当前代码（第120行）:
toolsUsed: result.toolCalls.map(tc => tc.name),

// 改为:
toolsUsed: result.toolCalls.map(tc => tc.name),
toolCalls: result.toolCalls,  // 新增：传递完整数据
```

#### 4.1.3 brain.ts feedback() 透传 toolCalls

**文件**: `src/brain/brain.ts`

`feedback()` 方法签名不变（`outcome` 参数已包含 `toolCalls`），只需确保 `outcome` 被正确传递给 `DispatchLearner`。

### 4.2 DispatchLearner 增强

**文件**: `src/brain/dispatch/learner.ts`

#### 4.2.1 distill() 新增第三路蒸馏

```typescript
private async distill(
  proposal: CandidateProposal,
  signal: TaskSignal,
  outcome: DecisionOutcome,
  actualOutput?: string,
): Promise<void> {
  // ... 现有去重检查 ...

  try {
    // 蒸馏 1: 信号汇聚层注入（现有）
    this.injectConvergenceSignal(proposal, signal, outcome);

    // 蒸馏 2: 经验图谱（现有，增强）
    this.addExperienceNode(proposal, signal, actualOutput);

    // 蒸馏 3: tool call 序列蒸馏（新增）
    if (outcome.toolCalls && outcome.toolCalls.length > 0) {
      this.distillToolCalls(signal, outcome.toolCalls, proposal.calibratedConfidence);
    }

    // ... 现有记录逻辑 ...
  }
}
```

#### 4.2.2 新增 distillToolCalls() 方法

```typescript
/**
 * tool call 序列蒸馏 — 三路处理
 *
 * 1. 结构化经验：存入 ExperienceGraph（带步骤序列）
 * 2. BuddyLM 训练样本：输入意图 → 期望输出 tool call JSON
 * 3. 高频模式检测：≥3 次同类 → 候选自动规则
 */
private distillToolCalls(
  signal: TaskSignal,
  toolCalls: Array<{ name: string; args: Record<string, unknown>; result: string }>,
  quality: number,
): void {
  // ── 1. 结构化经验 ──
  this.addStructuredExperience(signal, toolCalls, quality);

  // ── 2. BuddyLM 训练样本 ──
  this.collectToolCallSample(signal, toolCalls, quality);

  // ── 3. 高频模式检测 ──
  this.checkAutoRuleCandidate(signal, toolCalls, quality);
}

/** 结构化经验 — 带步骤序列 */
private addStructuredExperience(
  signal: TaskSignal,
  toolCalls: Array<{ name: string; args: Record<string, unknown>; result: string }>,
  quality: number,
): void {
  if (!this.experienceGraph) return;

  const id = `llm_tool_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 6)}`;
  const keywords = this.extractKeywords(signal.content ?? '', toolCalls.map(tc => tc.name).join(' '));
  
  if (keywords.length === 0) return;

  try {
    this.experienceGraph.addNode({
      id,
      keywords,
      patterns: toolCalls.map(tc => `${tc.name}(${JSON.stringify(tc.args).slice(0, 100)})`),
      contextTags: [signal.taskType, signal.complexity, ...signal.domains],
      content: JSON.stringify(toolCalls.map(tc => ({ tool: tc.name, args: tc.args }))).slice(0, 1000),
      quality,
      usageCount: 0,
      successCount: 0,
      failCount: 0,
      createdAt: Date.now(),
      updatedAt: Date.now(),
      source: 'llm_tool_distill',
      // 新增字段（需要 ExperienceGraph 支持）
      toolCallSequence: toolCalls.map(tc => ({ tool: tc.name, args: tc.args })),
    } as any);
  } catch { /* 静默降级 */ }
}

/** BuddyLM 训练样本收集 */
private collectToolCallSample(
  signal: TaskSignal,
  toolCalls: Array<{ name: string; args: Record<string, unknown>; result: string }>,
  quality: number,
): void {
  // 通知 BuddyLMTrainer 收集 tool call 格式样本
  // 通过事件总线或直接引用
  if (this.buddyLMTrainer) {
    const toolCallJson = JSON.stringify(
      toolCalls.map(tc => ({ tool: tc.name, args: tc.args }))
    );
    this.buddyLMTrainer.collectToolCallSample(signal.content ?? '', toolCallJson, quality);
  }
}

/** 高频模式检测 — ≥3 次同类 tool call 序列 → 候选规则 */
private checkAutoRuleCandidate(
  signal: TaskSignal,
  toolCalls: Array<{ name: string; args: Record<string, unknown>; result: string }>,
  quality: number,
): void {
  const fingerprint = this.toolCallFingerprint(toolCalls);
  
  if (!this.toolCallPatternCounts.has(fingerprint)) {
    this.toolCallPatternCounts.set(fingerprint, {
      count: 0,
      successCount: 0,
      signal,
      toolCalls,
    });
  }
  
  const pattern = this.toolCallPatternCounts.get(fingerprint)!;
  pattern.count++;
  if (quality > 0.5) pattern.successCount++;
}

/** tool call 序列指纹 */
private toolCallFingerprint(
  toolCalls: Array<{ name: string; args: Record<string, unknown>; result: string }>,
): string {
  return toolCalls.map(tc => tc.name).join('→');
}
```

#### 4.2.3 新增注入字段

```typescript
export class DispatchLearner {
  // ... 现有字段 ...
  
  /** Phase 4: BuddyLM 训练器引用（用于收集 tool call 样本） */
  private buddyLMTrainer: import('../right/training/buddy-lm-trainer.ts').BuddyLMTrainer | null = null;
  
  /** Phase 4: tool call 模式计数（用于高频模式检测） */
  private toolCallPatternCounts = new Map<string, {
    count: number;
    successCount: number;
    signal: TaskSignal;
    toolCalls: Array<{ name: string; args: Record<string, unknown>; result: string }>;
  }>();

  /** 注入 BuddyLM 训练器 */
  setBuddyLMTrainer(trainer: import('../right/training/buddy-lm-trainer.ts').BuddyLMTrainer): void {
    this.buddyLMTrainer = trainer;
  }
}
```

### 4.3 ShadowBrain 增强

**文件**: `src/brain/shadow/index.ts`

`collectTrainingSamples()` 方法增强：

```typescript
private collectTrainingSamples(signal: TaskSignal, outcome: DecisionOutcome, confidence: number): void {
  if (!this.buddyLMTrainer) return;

  const input = signal.content ?? '';
  const output = outcome.actualOutput ?? '';
  if (input.length < 3 || output.length < 3) return;

  // 现有：文本格式样本
  this.buddyLMTrainer.collectSample(
    input, output, confidence, outcome.success,
    outcome.reasoningChain,
  );

  // Phase 4 新增：tool call 格式样本
  if (outcome.toolCalls && outcome.toolCalls.length > 0) {
    this.buddyLMTrainer.collectToolCallSample(
      input,
      outcome.toolCalls.map(tc => ({ tool: tc.name, args: tc.args })),
      confidence,
    );
  }
}
```

### 4.4 蒸馏触发时机

```
触发条件 1: brain.ts feedback() → DispatchLearner.onArbitration()
  → 每次云端 LLM 胜出且执行成功时触发
  → 异步执行，不阻塞主流程

触发条件 2: reflector.ts → ExperienceCompiler.learn()
  → 每次工具调用全部成功时触发
  → 编译为 ExperienceUnit

触发条件 3: ShadowBrain.onInteraction()
  → 每次交互后收集训练样本
  → 定期触发自训练
```

### 4.5 验收标准

- [ ] reflector → feedback 边界传递完整 toolCalls（name + args + result）
- [ ] `DecisionOutcome.toolCalls` 字段正确填充
- [ ] `DispatchLearner.distillToolCalls()` 三路蒸馏正常工作
- [ ] 经验图谱新增 `llm_tool_distill` 类型节点
- [ ] BuddyLMTrainer 收到 tool call 格式训练样本
- [ ] ShadowBrain.collectTrainingSamples() 收集 tool call 样本
- [ ] ≥3 次同类 tool call 序列检测到高频模式

---

## Phase 5: 竞争裁决升级

### 5.1 评分维度扩展

**文件**: `src/brain/dispatch/arbiter.ts`

```typescript
// 当前评分权重
const DEFAULT_WEIGHTS: ScoringWeights = {
  quality: 0.7,
  feasibility: 0.25,
  costEfficiency: 0.05,
};

// 升级后评分权重
const ENHANCED_WEIGHTS: ScoringWeights = {
  planQuality: 0.35,       // 方案质量（校准后置信度）
  feasibility: 0.20,       // 资源可行性
  executionSpeed: 0.15,    // 预估执行速度
  costEfficiency: 0.10,    // 是否需要云端 LLM
  reliability: 0.20,       // 来源的历史成功率
};

interface ScoringWeights {
  planQuality: number;
  feasibility: number;
  executionSpeed: number;
  costEfficiency: number;
  reliability: number;
}
```

### 5.2 评分方法增强

```typescript
private scoreProposal(
  proposal: CandidateProposal,
  feasibility: FeasibilityResult | undefined,
  context: { signal: TaskSignal; resources: ResourceState; bodyState: BodyState },
) {
  // 质量分（现有）
  const planQuality = proposal.calibratedConfidence;

  // 可行性分（现有）
  const feasibilityScore = feasibility?.score ?? 1.0;
  const status = feasibility?.status ?? 'feasible';

  // 速度分（新增）
  const executionSpeed = this.estimateSpeed(proposal);

  // 成本分（现有，权重提升）
  const costScore = proposal.costEstimate > 0
    ? Math.max(0, 1 - proposal.costEstimate / 100)
    : 1.0;

  // 可靠性分（新增）
  const reliability = this.getReliability(proposal.source);

  // 综合分数
  let finalScore =
    planQuality * this.weights.planQuality +
    feasibilityScore * this.weights.feasibility +
    executionSpeed * this.weights.executionSpeed +
    costScore * this.weights.costEfficiency +
    reliability * this.weights.reliability;

  // 本地方案加成（质量相近时优先选择本地）
  if (this.isLocalSource(proposal.source) && planQuality >= 0.5) {
    finalScore *= 1.1; // 10% 加成
  }

  // ...
}

/** 预估执行速度 */
private estimateSpeed(proposal: CandidateProposal): number {
  // 本地方案 → 1.0（最快）
  // BuddyLM → 0.8
  // 云端 LLM → 0.3（最慢）
  const speedMap: Record<string, number> = {
    'rule': 1.0, 'experience': 1.0, 'assembly': 0.8,
    'buddyLM': 0.7, 'intuition': 0.9,
    'llm': 0.3, 'deliberation': 0.2,
  };
  return speedMap[proposal.source] ?? 0.5;
}

/** 获取来源历史成功率 */
private getReliability(source: string): number {
  // 从 Thompson Sampling bandit 获取
  const bandit = this.generatorBandits?.get(source);
  if (bandit && bandit.count >= 3) {
    return bandit.alpha / (bandit.alpha + bandit.beta);
  }
  return 0.5; // 默认中等可靠性
}

/** 判断是否本地来源 */
private isLocalSource(source: string): boolean {
  return ['rule', 'experience', 'assembly', 'intuition', 'scheduler'].includes(source);
}
```

### 5.3 生成器组合级 Thompson Sampling

**文件**: `src/brain/dispatch/learner.ts`

现有 `recordStrategyOutcome()` 已记录生成器组合级统计，但 `recommendStrategy()` 只按策略名聚合。

增强：按执行者组合聚合：

```typescript
/** 按执行者组合推荐策略 */
recommendByExecutorCombo(
  candidates: string[],
): { strategy: string; executorCombo: string; expectedReward: number } | null {
  // 从 generatorComboStats 中找最佳组合
  let best: { combo: string; avgQuality: number } | null = null;
  
  for (const [combo, stats] of this.generatorComboStats) {
    if (stats.count < 3) continue;
    const avgQuality = stats.totalQuality / stats.count;
    if (!best || avgQuality > best.avgQuality) {
      best = { combo, avgQuality };
    }
  }
  
  if (!best) return null;
  
  return {
    strategy: candidates[0], // 简化
    executorCombo: best.combo,
    expectedReward: best.avgQuality,
  };
}
```

### 5.4 验收标准

- [ ] 评分公式包含 5 个维度
- [ ] 本地方案在质量相近时优先选择（10% 加成）
- [ ] `estimateSpeed()` 正确区分本地/BuddyLM/云端
- [ ] `getReliability()` 从 Thompson Sampling 获取历史成功率
- [ ] 生成器组合级 Thompson Sampling 正常工作

---

## Phase 6: 自动规则生成

### 6.1 PolicyDistiller 增强

**文件**: `src/brain/left/policy-distiller.ts`

```typescript
export class PolicyDistiller {
  private memory: DecisionMemory;
  private verbose: boolean;
  /** Phase 6: tool call 模式缓存（从 DispatchLearner 同步） */
  private toolCallPatterns: Map<string, {
    count: number;
    successCount: number;
    signal: TaskSignal;
    toolCalls: Array<{ name: string; args: Record<string, unknown> }>;
  }> = new Map();

  constructor(memory: DecisionMemory, verbose = false) {
    this.memory = memory;
    this.verbose = verbose;
  }

  /** 执行蒸馏（增强版） */
  async distill(engine: RuleEngine): Promise<DistillReport> {
    const t0 = Date.now();
    const clusterStats = this.memory.getClusterStats(3);

    let newRules = 0;
    let prunedRules = 0;
    let negations = 0;
    let toolCallRules = 0; // Phase 6 新增

    // ── 现有：基于聚类的规则生成 ──
    for (const cluster of clusterStats) {
      if (cluster.successRate > 0.8 && cluster.count >= 5) {
        // ... 现有逻辑 ...
        newRules++;
      }
      if (cluster.successRate < 0.2 && cluster.count >= 3) {
        // ... 现有逻辑 ...
        negations++;
      }
    }

    // ── Phase 6 新增：基于 tool call 模式的规则生成 ──
    toolCallRules = this.generateToolCallRules(engine);

    prunedRules = engine.prune(7 * 24 * 3600_000, 0.3);
    const durationMs = Date.now() - t0;

    return {
      newRules,
      prunedRules,
      negations,
      toolCallRules, // Phase 6 新增
      clusters: clusterStats.length,
      totalRecords: this.memory.size,
      durationMs,
    };
  }

  /**
   * Phase 6: 从 tool call 模式自动生成规则
   *
   * 条件：同一 tool call 序列出现 ≥3 次且成功率 > 0.7
   * 生成：ExecutablePlan 格式的规则
   */
  private generateToolCallRules(engine: RuleEngine): number {
    let count = 0;

    for (const [fingerprint, pattern] of this.toolCallPatterns) {
      if (pattern.count < 3) continue;
      const successRate = pattern.successCount / pattern.count;
      if (successRate < 0.7) continue;

      const signal = pattern.signal;
      const toolCalls = pattern.toolCalls;

      // 生成 ExecutablePlan
      const steps: ExecutableStep[] = toolCalls.map((tc, i) => ({
        id: `step_${i + 1}`,
        type: 'tool_call' as const,
        tool: tc.tool,
        args: tc.args,
        dependsOn: i > 0 ? [`step_${i}`] : [],
        preferredExecutors: ['local' as const],
      }));

      engine.addLearnedRule({
        id: `tool_pattern-${fingerprint.slice(0, 16)}-${Date.now()}`,
        name: `工具模式: ${fingerprint}`,
        priority: 60, // 低于内置规则，高于默认调度
        condition: (s) => this.matchToolCallPattern(s, signal),
        action: (s, r) => ({
          mode: 'local_only',
          reason: `工具模式: ${fingerprint} (成功率${(successRate * 100).toFixed(0)}%)`,
          selectedNodes: [{ id: 'auto', type: 'experience' }],
          confidence: successRate,
          source: 'learned',
          executablePlan: {
            steps,
            expectedOutput: `执行 ${fingerprint}`,
            confidence: successRate,
            source: 'learned',
            needsCloudEnhancement: false,
          },
        }),
        source: 'learned',
        stats: { hits: pattern.count, successes: pattern.successCount, lastUsed: Date.now() },
        createdAt: Date.now(),
      });
      count++;
    }

    return count;
  }

  /** 匹配 tool call 模式（基于信号特征） */
  private matchToolCallPattern(signal: TaskSignal, pattern: TaskSignal): boolean {
    // 领域匹配
    const domainMatch = signal.domains.some(d => pattern.domains.includes(d));
    // 复杂度匹配
    const complexityMatch = signal.complexity === pattern.complexity;
    // 任务类型匹配
    const typeMatch = signal.taskType === pattern.taskType;
    
    return domainMatch && (complexityMatch || typeMatch);
  }

  /** 从 DispatchLearner 同步 tool call 模式 */
  syncToolCallPatterns(patterns: Map<string, {
    count: number;
    successCount: number;
    signal: TaskSignal;
    toolCalls: Array<{ name: string; args: Record<string, unknown> }>;
  }>): void {
    this.toolCallPatterns = patterns;
  }
}
```

### 6.2 蒸馏报告扩展

**文件**: `src/brain/types.ts`

```typescript
export interface DistillReport {
  newRules: number;
  prunedRules: number;
  negations: number;
  clusters: number;
  totalRecords: number;
  durationMs: number;
  /** Phase 6 新增: 从 tool call 模式生成的规则数 */
  toolCallRules?: number;
}
```

### 6.3 DispatchLearner → PolicyDistiller 同步

**文件**: `src/brain/brain.ts`

在定期蒸馏时，将 DispatchLearner 的 tool call 模式同步给 PolicyDistiller：

```typescript
// 在 runDistill() 中
private async runDistill(): Promise<void> {
  // 现有：PolicyDistiller 蒸馏
  const report = await this.left.distill();
  
  // Phase 6 新增：同步 tool call 模式
  const toolCallPatterns = this.dispatchLearner.getToolCallPatterns();
  if (toolCallPatterns.size > 0) {
    this.left.distiller?.syncToolCallPatterns(toolCallPatterns);
    // 再次蒸馏（包含 tool call 模式规则）
    await this.left.distill();
  }
}
```

### 6.4 验收标准

- [ ] `PolicyDistiller.generateToolCallRules()` 实现
- [ ] 同一 tool call 序列 ≥3 次且成功率 > 0.7 时自动生成规则
- [ ] 自动生成的规则包含 `ExecutablePlan`（`steps[]` 格式）
- [ ] `DistillReport.toolCallRules` 正确统计
- [ ] DispatchLearner → PolicyDistiller 模式同步正常
- [ ] 自动生成的规则能命中后续同类任务

---

## 实施顺序与依赖

```
Phase 1 (ExecutablePlan 类型 + 规则引擎)
  │
  ├──────────────────┐
  ↓                  ↓
Phase 3 (执行层)    Phase 2 (BuddyLM tool calls)
  │                  │
  │    ┌─────────────┘
  ↓    ↓
Phase 4 (蒸馏闭环)
  │
  ├──────────────────┐
  ↓                  ↓
Phase 5 (裁决升级)  Phase 6 (自动规则)
```

### 最小可用版本（MVP）

**Phase 1 + Phase 3** = 规则引擎出计划 → 本地直接执行 → 零云端 LLM

预计工期：2-3 周

### 增长引擎

**Phase 2 + Phase 4** = BuddyLM 学会 tool calls → 云端 LLM 蒸馏 → 能力持续提升

预计工期：3-4 周

### 自动进化

**Phase 4 + Phase 6** = 蒸馏数据 → 自动规则 → 系统自动变强

预计工期：2 周（依赖 Phase 4）

---

## 风险与缓解

| 风险 | 影响 | 缓解 |
|------|------|------|
| BuddyLM 生成的 tool call JSON 格式错误 | 执行失败 | 格式校验 + 降级到云端 LLM |
| 规则引擎规则爆炸 | 匹配变慢 | 规则数量上限（100）+ 优先级淘汰 |
| 本地方案质量不够 | 用户体验下降 | 保持云端 LLM 作为兜底 |
| tool call 模式误匹配 | 执行错误任务 | 匹配置信度阈值 + 人工审核 |
| 变量引用解析错误 | 步骤间数据断裂 | 单元测试 + 降级到空字符串 |
| 执行超时 | 用户等待过久 | 每步 timeout + 全局 timeout |

---

## 测试策略

### 单元测试

| 模块 | 测试文件 | 测试内容 |
|------|----------|---------|
| ExecutablePlan 类型 | `types.test.ts` | 类型兼容性、序列化/反序列化 |
| 规则引擎 | `rule-engine.test.ts` | 新规则命中、旧格式转换 |
| executeLocalPlan | `plan-executor.test.ts` | 单步/多步执行、变量引用、失败降级 |
| distillToolCalls | `learner.test.ts` | 三路蒸馏、去重、高频检测 |
| generateToolCallRules | `policy-distiller.test.ts` | 模式检测、规则生成 |
| 裁决器 | `arbiter.test.ts` | 五维评分、本地加成 |

### 集成测试

| 场景 | 验证点 |
|------|--------|
| git status 端到端 | 规则引擎 → ExecutablePlan → 本地执行 → 返回结果 |
| 文件读取端到端 | 规则引擎 → read 工具 → 返回内容 |
| 云端 LLM 蒸馏闭环 | LLM 执行 → DispatchLearner → 经验图谱 + 训练样本 |
| 高频模式自动生成规则 | 3 次同类执行 → 自动生成规则 → 第 4 次命中 |

---

## 文件改动清单

| 文件 | Phase | 改动类型 | 改动量 |
|------|-------|---------|--------|
| `src/brain/types.ts` | 1,4 | 新增类型 | ~50 行 |
| `src/types.ts` | 1 | 扩展接口 | ~5 行 |
| `src/brain/left/rule-engine.ts` | 1 | 新增规则 + 适配器 | ~80 行 |
| `src/core/agent.ts` | 1 | 新增检查逻辑 | ~20 行 |
| `src/brain/right/nn/bbpe-tokenizer.ts` | 2 | 新增特殊 token | ~10 行 |
| `src/brain/right/nn/decoder.ts` | 2 | 新增 generateWithToolCalls() | ~60 行 |
| `src/brain/right/nn/buddy-lm.ts` | 2 | 新增 generateWithToolCalls() | ~40 行 |
| `src/brain/right/training/buddy-lm-trainer.ts` | 2,4 | 扩展样本类型 + 收集方法 | ~50 行 |
| `src/core/plan-executor.ts` | 3 | 新增 executeLocalPlan() | ~150 行 |
| `src/core/reflector.ts` | 4 | 传递完整 toolCalls | ~3 行 |
| `src/brain/dispatch/learner.ts` | 4 | 新增 distillToolCalls() | ~100 行 |
| `src/brain/shadow/index.ts` | 4 | 增强 collectTrainingSamples() | ~15 行 |
| `src/brain/dispatch/arbiter.ts` | 5 | 扩展评分维度 | ~60 行 |
| `src/brain/left/policy-distiller.ts` | 6 | 新增 generateToolCallRules() | ~80 行 |
| `src/brain/brain.ts` | 4,6 | 模式同步 + 蒸馏增强 | ~20 行 |

**总计**: ~740 行新增/修改代码
