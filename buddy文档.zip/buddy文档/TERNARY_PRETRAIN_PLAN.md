# 三进制模型冷启动预训练计划

> 创建日期：2026-05-31
> 状态：准备阶段
> 目标：统一容器 → GPU 预训练 → 三进制蒸馏 → 验证输出有意义 token

---

## 一、核心决策

| 决策项 | 选定值 | 理由 |
|--------|--------|------|
| vocabSize | **16384** | 256 维模型的平衡点：中文覆盖 ~85%，压缩比 64:1 |
| embedDim | **256** | 与现有容器一致，Hub-Spoke 接口不变 |
| 词表升级 | **后续支持**（自更新 + 压缩自平衡），冷启动先定死 |
| 预训练方式 | **一次性冷启动**，后续增量训练 |
| 运行环境 | 启智平台 GPU（4×A100 或 8×V100） |

---

## 二、两层架构

```
┌─────────────────────────────────────────────────────────┐
│  容器层 (Container) — GPU 预训练产出，固定基础设施        │
│  ├── Tokenizer (BBPE, 16384 vocab)                      │
│  ├── Embedding (16384 × 256 Float32)                     │
│  ├── OutputProj (256 × 16384 Float32)                    │
│  └── LayerNorm (256 gamma + 256 beta)                    │
├─────────────────────────────────────────────────────────┤
│  模型层 (Ternary) — 从容器蒸馏，完全替换                  │
│  ├── .ta 三进制权重 {-1, 0, 1}                           │
│  ├── Hub-Spoke 投影 (projIn: 256→inFeatures fp32)        │
│  ├── LoRA 层 (A: inFeatures×rank, B: rank×outFeatures)   │
│  └── ExpertHead (经验匹配，可选)                          │
└─────────────────────────────────────────────────────────┘
```

关键：两层**独立可换**。换容器不动 .ta，换 .ta 不动容器。

---

## 三、执行计划

### Phase 1: 代码改造（运行时推导）

消除硬编码 vocabSize，让所有维度从实际文件推导。

**改动文件：**
- `src/ternary/trainer.ts` — 去掉 `private vocabSize = 8192`，改为从 outputProj 维度推导
- `src/ternary/container.ts` — 支持 v2 目录加载，自动检测 vocabSize
- `src/ternary/tokenizer.ts` — 确保支持 16384 vocab

**验收：** `npm test` 全通过，现有功能不回退。

### Phase 2: 数据准备

#### 2.1 数据来源

| 来源 | 规模 | 用途 |
|------|------|------|
| 现有 training-data/ | 47MB deep-patterns + 315KB patterns | 清洗复用 |
| 现有 train.ts QA 模板 | ~60 对 | 种子数据 |
| WuDaoCorpora | ~200GB 中文语料 | 通用语言能力 |
| BELLE | ~100 中文指令集 | 指令跟随 |
| CodeSearchNet | ~6M 代码注释对 | 代码理解 |
| ShareGPT / ChatLogs | 中文对话日志 | 对话能力 |

#### 2.2 数据处理管线

```
原始数据 → 格式统一 → 质量过滤(长度/语言/重复/毒性) → BBPE 训练 → Tokenize → 打包
```

#### 2.3 规模目标

| 阶段 | 最小规模 | 理想规模 |
|------|---------|---------|
| BBPE Tokenizer 训练 | 100MB 纯文本 | 1GB |
| Embedding 预训练 | 1M 条 | 10M 条 |
| Decoder 预训练 | 10M tokens | 100M tokens |
| 总计 | ~5GB 清洗后 | ~50GB |

#### 2.4 产出脚本

- `scripts/prepare_dataset.py` — 数据清洗 + 格式统一

### Phase 3: GPU 预训练（启智平台）

#### 3.1 训练脚本

```
pretrain/
├── config.py                # 统一配置
├── train_tokenizer.py       # BBPE Tokenizer 训练 (sentencepiece)
├── train_embedding.py       # Embedding 预训练 (Causal LM)
├── train_decoder.py         # Decoder 预训练 (Causal LM)
├── data_loader.py           # 数据加载器
├── export.py                # 导出 TS 兼容格式
├── requirements.txt         # torch, sentencepiece, datasets, numpy
└── README.md                # 使用说明
```

#### 3.2 训练配置

```python
vocab_size    = 16384
embed_dim     = 256       # 与容器一致
hidden_dim    = 768       # Decoder 内部维度
num_heads     = 12
num_layers    = 12
ffn_dim       = 3072
max_seq_len   = 2048
batch_size    = 64        # 每 GPU
lr            = 3e-4
warmup_steps  = 2000
max_steps     = 100000
fp16          = True
```

#### 3.3 分阶段训练

| Stage | 内容 | 耗时预估 |
|-------|------|---------|
| 0 | BBPE Tokenizer 训练 | 1 小时 |
| 1 | Embedding + Decoder 联合预训练 | 3 天 (4×A100) |

#### 3.4 产出文件

- `checkpoints/v2/tokenizer.json` — BBPE 16384 vocab
- `checkpoints/v2/embedding.weights.bin` — 16384×256 Float32
- `checkpoints/v2/output-proj.bin` — 256×16384 Float32
- `checkpoints/v2/layernorms.bin` — 256+256 Float32
- `checkpoints/v2/meta.json` — 版本 + 配置元数据

### Phase 4: 三进制蒸馏

```
PyTorch 教师模型
  ↓ 收集 logits
教师 logits (16384 vocab × N 条)
  ↓ 渐进蒸馏
三进制学生模型 (全零初始化)
  ↓ t-SignSGD 增量训练
.ta 文件 → checkpoints/models/
```

#### 产出脚本

- `scripts/distill-from-pytorch.ts` — PyTorch → 三进制蒸馏

### Phase 5: 集成验证

| 验证项 | 方法 | 通过标准 |
|--------|------|---------|
| v2 容器加载 | `container.init()` | vocabSize=16384 |
| Embedding 质量 | 余弦相似度测试 | 语义相近词距离小 |
| 三进制推理 | `engine.complete("你好")` | 输出可读中文 |
| 生成多样性 | 同一 prompt 10 次 | ≥5 种不同输出 |
| 推理速度 | `engine.getStats()` | ≥10 tok/s (CPU) |
| 回归测试 | `npm test` | 全通过 |

---

## 四、后续增强（冷启动完成后）

### 4.1 词表自更新

```
推理时 OOV → 记录频率 → 超阈值 → 新 token 入词表
→ embedding 子词均值初始化 → outputProj 加一行
→ 微调 50 步 → 容量监控确认无退化 → 热替换
```

### 4.2 压缩自平衡

```
监控: OOV率 + outputProj loss + embedding 稀疏率
→ 联合搜索 vocab × dim × layers 最优配比
→ 自动触发扩展/收缩
```

### 4.3 模型维度升级

```
当前: vocab=16384, dim=256, layers=2, rank=4
未来: vocab=24000, dim=384, layers=4, rank=8 (按需扩展)
```

---

## 五、时间线

| 周 | Phase | 内容 |
|----|-------|------|
| 1 | 1 + 2 | 代码改造 + 数据收集清洗 |
| 2 | 3 | GPU 预训练（启智平台） |
| 3 | 4 | 三进制蒸馏 |
| 4 | 5 | 集成验证 + 修复 |

---

## 六、文件清单

### 新增

| 文件 | 用途 |
|------|------|
| `pretrain/config.py` | 预训练配置 |
| `pretrain/train_tokenizer.py` | BBPE 训练 |
| `pretrain/train_embedding.py` | Embedding 预训练 |
| `pretrain/train_decoder.py` | Decoder 预训练 |
| `pretrain/data_loader.py` | 数据加载 |
| `pretrain/export.py` | 导出 TS 格式 |
| `pretrain/requirements.txt` | Python 依赖 |
| `pretrain/README.md` | 使用说明 |
| `scripts/prepare_dataset.py` | 数据清洗 |
| `scripts/distill-from-pytorch.ts` | 蒸馏脚本 |
| `scripts/verify-v2.ts` | v2 验证 |

### 修改

| 文件 | 改动 |
|------|------|
| `src/ternary/trainer.ts` | vocabSize 运行时推导 |
| `src/ternary/container.ts` | v2 目录加载支持 |
| `src/ternary/tokenizer.ts` | 16384 vocab 支持 |

### 新增目录

| 目录 | 用途 |
|------|------|
| `pretrain/` | Python 预训练代码 |
| `checkpoints/v2/` | 新版容器文件 |

---

## 七、风险

| 风险 | 缓解 |
|------|------|
| 启智 GPU 配额不足 | 先用 tiny 架构验证流程 |
| 训练数据不够 | 优先开源数据集，用大模型合成补充 |
| 蒸馏质量差 | 增大教师 logits 采样量 |
| 旧代码不兼容 v2 | 保留 v1 fallback |
