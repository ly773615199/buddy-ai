# ByteEncoder 闲时训练方案

> 生成时间：2026-05-16
> 基于：ByteEncoder 升级计划 Task 3+5 完成后的讨论

---

## 背景

ByteEncoder 升级计划 5 个 Task 已全部完成：
- Task 1: 增量预训练 v5 ✅
- Task 2: 自动扩展系统 ✅
- Task 3: OnlineLearner 梯度回传 ✅
- Task 4: 预训练脚本增强 ✅
- Task 5: 容量监控 ✅

**遗留问题**：投喂数据只能通过 CLI `pretrain-encoder.ts`，没有聊天接口，没有闲时训练。

---

## 目标

1. 用户在聊天窗口说"训练 /path/to/folder" → 触发 ByteEncoder 增量训练
2. 训练在闲时执行，不阻塞对话响应
3. 训练完成后通知用户

---

## 设计

### 核心原则

- **learn ≠ train**：learn 是存记忆（SQLite），train 是更新 ByteEncoder 权重
- 用户主动说"训练"才触发，不自动混在 learn 流程中
- 闲时执行，不抢 CPU

### 触发方式

```
用户: "训练 /path/to/folder"
      ↓
识别意图 → 提取路径 → 加入训练队列
      ↓
回复: "收到，已加入训练队列，空闲时执行"
      ↓
闲时 → DreamEngine 空隙执行训练
      ↓
完成 → 通知用户: "训练完成，编码质量提升了"
```

### 数据转换

`learnFromFile` 已经把文件分块提取摘要。训练时需要转换为 comment↔code 配对：

```typescript
// 文件内容 → 训练对
// 摘要块 ↔ 原文块 → Pair { comment: summary, code: original }
// 或：注释 ↔ 代码 → Pair { comment: comment, code: code }
```

### 闲时执行

挂载点：`DreamEngine.shouldDream()` 的空闲检测

```
空闲检测 → 有待训练任务？
  ├─ 有 → 执行 ByteEncoder 增量训练 (1-3 epochs)
  └─ 无 → 正常做梦（记忆巩固）
```

### 训练队列

```typescript
interface TrainTask {
  id: string;
  source: string;       // 文件路径或目录
  status: 'pending' | 'running' | 'done' | 'failed';
  createdAt: number;
  startedAt?: number;
  finishedAt?: number;
  result?: {
    pairs: number;       // 训练对数
    epochs: number;
    loss: number;
    gap: number;         // 正负样本 gap
  };
  error?: string;
}
```

---

## 改动范围

| 文件 | 改动 | 工作量 |
|------|------|--------|
| `src/core/agent.ts` | 新增 `trainFromFile(path)` 方法 | 0.5h |
| `src/core/ws-handler.ts` | 识别"训练"意图，调用训练队列 | 0.5h |
| `src/brain/right/training/idle-trainer.ts` | 新增：训练队列 + 闲时执行逻辑 | 2h |
| `src/memory/dream.ts` | 接入 idle-trainer 钩子 | 0.5h |
| `src/tools/builtin.ts` | 新增 `train_encoder` 工具定义 | 0.5h |
| `src/core/capability-gate.ts` | 新增 `train_encoder` 能力权限 | 0.5h |
| 测试 | idle-trainer 单元测试 | 1h |

**总工作量**: ~5.5h

---

## 限制

| 限制 | 说明 | 缓解 |
|------|------|------|
| 非实时 | 说"训练"后要等闲时才执行 | 通知用户"已排队" |
| 一次一个 | 同时只跑一个训练任务 | 队列排队 |
| 需要空闲 | 用户一直在聊则训练一直排队 | 超时强制执行（30 分钟） |
| 数据质量 | 垃圾文件会污染编码器 | 只处理 .ts/.py/.md/.json/.jsonl |

---

## 优先级

**P2** — 不紧急，但成本低、收益中等，值得做。

---

## 验收标准

- [ ] 聊天说"训练 /path" → 回复"已加入队列"
- [ ] 空闲时自动执行训练
- [ ] 训练完成通知用户（含 loss/gap 指标）
- [ ] 训练失败不影响正常对话
- [ ] 多个训练请求排队执行
