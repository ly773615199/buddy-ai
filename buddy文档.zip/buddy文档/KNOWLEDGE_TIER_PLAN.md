# 知识分层计划：冷启动 + 按需搜索 + 自积累

> 版本: v1.0
> 日期: 2026-05-15
> 目标: 冷启动覆盖 60-70% 场景，首次交互不显得傻

---

## 一、问题现状

### 当前种子经验：15 条

| 类别 | 数量 | 覆盖 |
|------|------|------|
| Git 操作 | 3 | status/diff/log |
| 文件操作 | 3 | read/write/list |
| Web 操作 | 2 | search/fetch |
| 代码操作 | 2 | exec/analyze |
| 系统操作 | 2 | time/config |
| 其他 | 3 | tts/screen/project |

**覆盖率：日常场景 ~20%**。用户问"写个快排"、"这个报错什么意思"、"对比 React 和 Vue"全部命中不了。

### 冷启动体验模拟

```
用户: 帮我写一个 Python 快速排序
系统: [无经验命中] → LLM 回答（2-5秒延迟）
用户: 这段代码什么意思？（指向某函数）
系统: [无经验命中] → LLM 回答（2-5秒延迟）
用户: npm install 报错了怎么办
系统: [无经验命中] → LLM 回答（2-5秒延迟）
```

三次交互全部走 LLM，用户感知："这东西什么都不会"。

---

## 二、目标

| 指标 | 当前 | 目标 |
|------|------|------|
| 种子经验数 | 15 | ~100 |
| 冷启动场景覆盖率 | ~20% | ~65% |
| 首次交互命中率 | ~20% | ~60% |
| 未命中时兜底 | 无（全走 LLM） | 按需搜索 + 自动沉淀 |
| 30 天后经验数 | ~15（不增长） | ~200+（自积累） |

---

## 三、架构设计

### 三层知识体系

```
┌──────────────────────────────────────────────────────┐
│  Tier 0: 原始种子 (15条)                               │
│  已有，不改动                                          │
│  git/file/web/code 基础操作                            │
├──────────────────────────────────────────────────────┤
│  Tier 1: 能力扩展种子 (~85条)                           │
│  新增，覆盖高频编程/系统/问答场景                        │
│  冷启动即用，关键词 + 模式匹配                          │
├──────────────────────────────────────────────────────┤
│  Tier 2: 按需搜索兜底 (无限)                            │
│  新建，经验未命中时自动触发                              │
│  web_search → LLM 总结 → 成功 → 自动编译为经验          │
├──────────────────────────────────────────────────────┤
│  Tier 3: 自积累 (持续增长)                              │
│  已有管道：经验编译器 + Dream Engine + STMP             │
│  每次成功交互自动沉淀                                   │
└──────────────────────────────────────────────────────┘
```

### 知识流转图

```
用户输入
    │
    ▼
ExperienceGraph.match(input)
    │
    ├── 命中 Tier 0/1/3 ──→ 直接执行（<50ms）
    │
    └── 未命中 ──→ Tier 2: 按需搜索
                       │
                       ├── search_web(query)
                       ├── LLM 总结结果
                       ├── 执行 + 验证
                       │
                       └── 成功 ──→ ExperienceCompiler.compile()
                                        │
                                        └── 存入 ExperienceGraph（下次命中）
```

---

## 四、Tier 1 详细设计：能力扩展种子

### 4.1 种子经验分类

#### A. 代码生成（20 条）

| ID | 名称 | 触发关键词 | 工具 |
|----|------|-----------|------|
| seed_code_quicksort | 快速排序 | 快排/quicksort/排序算法 | exec(python/node) |
| seed_code_fibonacci | 斐波那契 | fibonacci/斐波那契/递归 | exec |
| seed_code_http_request | HTTP请求 | fetch/axios/request/调接口 | exec |
| seed_code_file_io | 文件读写 | 读写文件/文件操作/IO | exec |
| seed_code_regex | 正则表达式 | 正则/regex/匹配/提取 | exec |
| seed_code_json_parse | JSON解析 | json/解析/序列化 | exec |
| seed_code_datetime | 日期时间 | 日期/时间/时间戳 | exec |
| seed_code_sort_filter | 排序过滤 | 排序/过滤/sort/filter | exec |
| seed_code_csv_process | CSV处理 | csv/表格/数据处理 | exec |
| seed_code_sql_query | SQL查询 | sql/查询/数据库 | exec |
| seed_code_api_server | API服务 | api/服务器/express/fastapi | exec |
| seed_code_cli_tool | CLI工具 | 命令行/cli/参数解析 | exec |
| seed_code_unit_test | 单元测试 | 测试/test/断言 | exec |
| seed_code_web_scrape | 网页爬虫 | 爬虫/爬取/scrape | exec |
| seed_code_data_viz | 数据可视化 | 图表/可视化/plot/chart | exec |
| seed_code_email_send | 发送邮件 | 邮件/email/smtp | exec |
| seed_code_pdf_gen | 生成PDF | pdf/报告/文档生成 | exec |
| seed_code_image_process | 图片处理 | 图片/resize/裁剪/水印 | exec |
| seed_code_config_parse | 配置解析 | yaml/toml/ini/env | exec |
| seed_code_log_parse | 日志分析 | 日志/log/分析/统计 | exec |

#### B. 代码解释与调试（15 条）

| ID | 名称 | 触发关键词 |
|----|------|-----------|
| seed_explain_code | 解释代码 | 这段代码/什么意思/explain |
| seed_explain_error | 解释报错 | 报错/error/异常/traceback |
| seed_explain_concept | 解释概念 | 什么是/区别/原理/how |
| seed_debug_runtime | 运行时调试 | 挂了/崩溃/不工作/不运行 |
| seed_debug_type_error | 类型错误 | 类型/type error/TS错误 |
| seed_debug_import | 导入错误 | import/module not found |
| seed_debug_permission | 权限错误 | 权限/permission/EACCES |
| seed_debug_memory | 内存问题 | 内存/OOM/泄漏/leak |
| seed_debug_network | 网络问题 | 连接/timeout/ECONNREFUSED |
| seed_debug_dep | 依赖问题 | 依赖/版本冲突/peer dep |
| seed_perf_slow | 性能分析 | 慢/性能/优化/bottleneck |
| perf_cpu | CPU分析 | cpu/占用/profiling |
| seed_review_code | 代码审查 | review/审查/看看代码 |
| seed_refactor | 重构建议 | 重构/refactor/改进 |
| seed_security | 安全检查 | 安全/漏洞/SQL注入/XSS |

#### C. 系统操作（15 条）

| ID | 名称 | 触发关键词 |
|----|------|-----------|
| seed_sys_process | 进程管理 | 进程/ps/kill/后台 |
| seed_sys_port | 端口管理 | 端口/port/lsof/占用 |
| seed_sys_env | 环境变量 | env/环境变量/PATH |
| seed_sys_package | 包管理 | npm/pip/apt/brew install |
| seed_sys_docker | Docker | docker/容器/镜像 |
| seed_sys_cron | 定时任务 | cron/定时/计划任务 |
| seed_sys_ssh | SSH连接 | ssh/远程/连接服务器 |
| seed_sys_disk | 磁盘管理 | 磁盘/df/du/空间 |
| seed_sys_service | 服务管理 | systemctl/service/启停 |
| seed_sys_firewall | 防火墙 | 防火墙/iptables/ufw |
| seed_sys_swap | 交换空间 | swap/虚拟内存 |
| seed_sys_log | 系统日志 | syslog/journalctl/dmesg |
| seed_sys_user | 用户管理 | 用户/adduser/权限 |
| seed_sys_crontab | Crontab | crontab/定时执行 |
| seed_sys_alias | 别名管理 | alias/bashrc/zshrc |

#### D. 文档与搜索（10 条）

| ID | 名称 | 触发关键词 |
|----|------|-----------|
| seed_doc_npm | npm查询 | npm/包/库/依赖 |
| seed_doc_mdn | MDN查询 | mdn/web api/css/js |
| seed_doc_stackoverflow | SO查询 | stackoverflow/报错/解决方案 |
| seed_doc_github | GitHub查询 | github/开源/项目 |
| seed_doc_pypi | PyPI查询 | pip/python包 |
| seed_doc_dockerhub | DockerHub查询 | docker镜像/容器 |
| seed_doc_man | man手册 | man/帮助/用法 |
| seed_doc_readme | README生成 | readme/说明文档 |
| seed_doc_changelog | 变更日志 | changelog/变更/版本 |
| seed_doc_api_doc | API文档 | api文档/swagger/openapi |

#### E. 通用问答（10 条）

| ID | 名称 | 触发关键词 |
|----|------|-----------|
| seed_qa_compare | 对比分析 | 对比/vs/区别/优缺点 |
| seed_qa_recommend | 推荐建议 | 推荐/选哪个/哪个好 |
| seed_qa_translate | 翻译 | 翻译/translate/英译中 |
| seed_qa_summarize | 总结摘要 | 总结/摘要/概括 |
| seed_qa_expand | 扩展展开 | 详细说/展开/深入 |
| seed_qa_stepbystep | 步骤指导 | 怎么/步骤/教程/指南 |
| seed_qa_bestpractices | 最佳实践 | 最佳实践/规范/标准 |
| seed_qa_alternative | 替代方案 | 替代/其他方案/有没有更好的 |
| seed_qa_troubleshoot | 故障排查 | 排查/诊断/为什么不行 |
| seed_qa_estimate | 工作量评估 | 多久/复杂度/难度 |

#### F. 文件批量操作（10 条）

| ID | 名称 | 触发关键词 |
|----|------|-----------|
| seed_file_rename | 批量重命名 | 批量/重命名/rename |
| seed_file_grep | 搜索内容 | grep/搜索/查找内容 |
| seed_file_replace | 搜索替换 | 替换/replace/批量替换 |
| seed_file_compress | 压缩解压 | 压缩/zip/tar/gzip |
| seed_file_diff | 文件对比 | diff/对比/差异 |
| seed_file_merge | 文件合并 | 合并/merge/拼接 |
| seed_file_convert | 格式转换 | 转换/convert/格式 |
| seed_file_clean | 清理文件 | 清理/临时/缓存 |
| seed_file_backup | 备份 | 备份/backup/归档 |
| seed_file_symlink | 软链接 | 软链接/ln/symlink |

### 4.2 种子经验模板

每条种子经验的标准结构：

```typescript
{
  id: 'seed_<category>_<name>',
  name: '<动作名>',
  description: '<一句话描述>',
  abstractionLevel: 'concrete',
  trigger: {
    intent: '<意图标签>',
    keywords: ['<中文关键词>', '<英文关键词>'],
    contextTags: ['<领域标签>'],
    patterns: ['<正则模式>'],
  },
  steps: [
    { tool: 'exec', args: { command: '<命令>' }, description: '<步骤描述>' }
  ],
  replyTemplate: {
    sharp: '{_step_0}',
    warm: '<友好回复>：\n{_step_0}',
    chaotic: '<活泼回复>！\n{_step_0}',
    default: '{_step_0}',
  },
  stats: {
    successCount: 3,     // 冷启动初始成功率
    failCount: 0,
    confidence: 0.5,     // 中等置信度，成功后快速提升
    avgExecutionMs: 500,
    lastUsed: now,
    createdAt: now,
    extractedFrom: ['seed_v2'],
    consolidatedAt: 0,
    evolved: false,
  },
}
```

### 4.3 参数量评估

| 项目 | 值 |
|------|-----|
| 新增种子数 | ~85 条 |
| 每条平均大小 | ~500 bytes |
| 总存储增量 | ~42 KB |
| 对 ExperienceGraph 的影响 | SQLite 单表，100 条无压力 |
| 匹配性能影响 | 倒排索引已实现，100 条 <1ms |

---

## 五、Tier 2 详细设计：按需搜索兜底

### 5.1 触发条件

```
ExperienceGraph.match(input) === null
&& 无经验命中
&& 输入长度 > 5（排除纯闲聊）
&& 非重复搜索（同一 query 30 分钟内不重复搜索）
```

### 5.2 搜索流程

```
1. 构造搜索 query
   - 从用户输入提取关键词
   - 补充上下文（当前文件路径、编程语言、错误信息）

2. 执行搜索
   - search_web(query) → 返回 top 3 结果
   - fetch_url(topResult) → 提取页面内容

3. LLM 总结
   - 将搜索结果 + 用户问题发给 LLM
   - 获取结构化回答

4. 执行验证
   - 如果是代码：执行验证可运行
   - 如果是操作：执行验证成功

5. 沉淀经验
   - 成功 → ExperienceCompiler.compile()
   - 失败 → 记录失败模式，不沉淀
```

### 5.3 实现方案

#### 新建文件：`src/intelligence/on-demand-search.ts`

```typescript
export class OnDemandSearcher {
  private experienceGraph: ExperienceGraph;
  private webSearch: (query: string) => Promise<SearchResult[]>;
  private webFetch: (url: string) => Promise<string>;
  private llmCaller: LLMCaller;
  private experienceCompiler: ExperienceCompiler;
  private recentSearches: Map<string, number>; // query → lastSearchTime
  private searchCooldownMs = 30 * 60 * 1000; // 30 分钟冷却

  /**
   * 搜索兜底：经验未命中时触发
   *
   * @returns 执行结果 + 是否沉淀了新经验
   */
  async searchAndLearn(
    userInput: string,
    context: { domain?: string; filePath?: string; language?: string }
  ): Promise<{
    answer: string;
    success: boolean;
    learned: boolean;
    newExperienceId?: string;
  }> {
    // 1. 冷却检查
    if (this.isInCooldown(userInput)) {
      return { answer: '', success: false, learned: false };
    }

    // 2. 构造搜索 query
    const query = this.buildSearchQuery(userInput, context);

    // 3. 搜索
    const results = await this.webSearch(query);
    if (results.length === 0) {
      return { answer: '未找到相关信息', success: false, learned: false };
    }

    // 4. LLM 总结
    const answer = await this.summarizeResults(userInput, results);

    // 5. 尝试沉淀
    const learned = await this.tryCompileExperience(userInput, answer, context);

    return {
      answer,
      success: true,
      learned,
      newExperienceId: learned ? `exp_search_${Date.now()}` : undefined,
    };
  }

  private buildSearchQuery(input: string, context: any): string {
    // 提取关键信息，补充编程语言上下文
    let query = input;
    if (context?.language) query += ` ${context.language}`;
    if (context?.filePath) {
      const ext = context.filePath.split('.').pop();
      if (ext) query += ` .${ext}`;
    }
    return query.slice(0, 200); // 截断保护
  }

  private async summarizeResults(input: string, results: SearchResult[]): Promise<string> {
    const context = results.slice(0, 3).map((r, i) =>
      `[${i + 1}] ${r.title}\n${r.summary}\n${r.url}`
    ).join('\n\n');

    const messages = [
      { role: 'system', content: '你是技术助手。根据搜索结果回答用户问题，给出具体可执行的方案。' },
      { role: 'user', content: `问题：${input}\n\n搜索结果：\n${context}` },
    ];
    return await this.llmCaller(messages);
  }

  private async tryCompileExperience(
    input: string, answer: string, context: any
  ): Promise<boolean> {
    // 构造虚拟对话快照供编译器使用
    const snapshot = {
      userMessage: input,
      assistantReply: answer,
      toolCalls: [],
      wasSuccessful: true,
    };
    return this.experienceCompiler.canCompile(snapshot);
  }
}
```

### 5.4 集成点

在 `agent.ts` 的消息处理流程中集成：

```typescript
// 在 executeByPlan 之前，检查是否需要搜索兜底
if (!plan.selectedNodes.length || plan.mode === 'single' && plan.source === 'default') {
  const searchResult = await this.onDemandSearcher.searchAndLearn(content, {
    domain: signal.domains[0],
    language: this.detectLanguage(content),
  });
  if (searchResult.success) {
    // 使用搜索结果
    return searchResult.answer;
  }
}
```

### 5.5 防滥用机制

| 机制 | 配置 |
|------|------|
| 搜索冷却 | 同一 query 30 分钟内不重复搜索 |
| 每日上限 | 最多 50 次搜索/天 |
| 结果缓存 | 搜索结果缓存 1 小时 |
| 质量过滤 | LLM 评估结果相关度 < 0.5 则丢弃 |
| 超时保护 | 单次搜索 + LLM 总结 < 10 秒 |

---

## 六、Tier 3 自积累增强

### 6.1 现有管道

| 组件 | 功能 | 状态 |
|------|------|------|
| ExperienceCompiler | 成功对话→经验单元 | ✅ 已实现 |
| Dream Engine | 回放→提取→关联→修剪 | ✅ 已实现 |
| STMP | 时空记忆存储 | ✅ 已实现 |
| KnowledgeExporter | 领域知识包导出 | ✅ 已实现 |

### 6.2 需要增强的部分

#### A. 经验编译器触发率提升

当前：只有 `canCompile()` 通过才编译（需要工具调用全部成功）
增强：也从纯问答对话中提取知识条目（不依赖工具调用）

```typescript
// 新增：从纯问答中提取知识
compileFromQA(question: string, answer: string): KnowledgeEntry | null {
  if (answer.length < 50) return null; // 太短不值得
  if (this.isPureChat(question)) return null;

  return {
    id: `qa_${Date.now()}`,
    content: `Q: ${question}\nA: ${answer.slice(0, 500)}`,
    embedding: null, // 待 ByteEncoder 编码
    type: 'qa_knowledge',
    confidence: 0.6,
    createdAt: Date.now(),
    lastAccessed: Date.now(),
    accessCount: 1,
  };
}
```

#### B. Dream Engine 与 KnowledgeGate 联动

Dream Engine 巩固完成后，将凝结的知识注入 KnowledgeGate：

```typescript
// dream 完成后
const condensed = dreamSession.extraction.patterns;
for (const pattern of condensed) {
  const embedding = byteEncoder.forward(pattern.description);
  knowledgeGate.addEntry({
    id: `dream_${pattern.name}`,
    content: pattern.description,
    embedding,
    type: 'dream_pattern',
    confidence: 0.7,
    createdAt: Date.now(),
    lastAccessed: Date.now(),
    accessCount: 0,
  });
}
```

---

## 七、KnowledgeGate 桥接方案

### 7.1 数据源 → KnowledgeGate 流转

```
┌─────────────┐    ByteEncoder    ┌──────────────┐
│ STMP 记忆    │ ──── 编码 ────→ │              │
├─────────────┤                   │  Knowledge   │
│ 经验图谱节点 │ ──── 编码 ────→ │    Gate      │
├─────────────┤                   │  (128d 向量   │
│ 决策记忆     │ ──── 编码 ────→ │   检索库)     │
├─────────────┤                   │              │
│ Dream 凝结   │ ──── 编码 ────→ │              │
└─────────────┘                   └──────────────┘
```

### 7.2 注入时机

| 时机 | 注入内容 | 条件 |
|------|---------|------|
| predictFull() 前 | STMP 相关记忆 (top 10) | 有 domain 匹配 |
| Dream 完成后 | 凝结的模式 | 新模式数 > 0 |
| 经验编译后 | 新编译的经验 | 编译成功 |
| 心跳周期 | 过期清理 + 增量更新 | 每 10 次心跳 |

### 7.3 实现方案

#### 新建文件：`src/brain/right/nn/knowledge-bridge.ts`

```typescript
export class KnowledgeBridge {
  private knowledgeGate: KnowledgeGate;
  private byteEncoder: ByteEncoder;
  private stmp: STMPStore;
  private experienceGraph: ExperienceGraph;
  private decisionMemory: DecisionMemory;
  private maxEntries = 500;
  private verbose: boolean;

  /**
   * 从 STMP 检索相关记忆，注入 KnowledgeGate
   */
  async injectFromSTMP(domain: string, query: string): Promise<number> {
    const results = await this.stmp.retrieve(domain, {
      maxPrimary: 10,
      maxAssociative: 5,
    });

    let injected = 0;
    for (const memory of results.primary) {
      const embedding = this.byteEncoder.forward(memory.content);
      this.knowledgeGate.addEntry({
        id: `stmp_${memory.id}`,
        content: memory.content,
        embedding,
        type: 'stmp_memory',
        confidence: 1 - memory.lifecycle.decay,
        createdAt: memory.lifecycle.createdAt,
        lastAccessed: memory.lifecycle.lastAccessed,
        accessCount: memory.lifecycle.accessCount,
      });
      injected++;
    }
    return injected;
  }

  /**
   * 从经验图谱注入
   */
  injectFromExperiences(domain: string): number {
    const experiences = this.experienceGraph.findByContext(domain);
    let injected = 0;
    for (const exp of experiences.slice(0, 20)) {
      const text = `${exp.name}: ${exp.description}`;
      const embedding = this.byteEncoder.forward(text);
      this.knowledgeGate.addEntry({
        id: `exp_${exp.id}`,
        content: text,
        embedding,
        type: 'experience',
        confidence: exp.stats.confidence,
        createdAt: exp.stats.createdAt,
        lastAccessed: exp.stats.lastUsed,
        accessCount: exp.stats.successCount,
      });
      injected++;
    }
    return injected;
  }

  /**
   * 清理过期条目（置信度衰减 + LRU 淘汰）
   */
  cleanup(): number {
    const entries = this.knowledgeGate.getEntries();
    let removed = 0;

    // 淘汰超过上限的低置信度条目
    if (entries.length > this.maxEntries) {
      const sorted = entries.sort((a, b) => a.confidence - b.confidence);
      const toRemove = sorted.slice(0, entries.length - this.maxEntries);
      for (const entry of toRemove) {
        this.knowledgeGate.removeEntry(entry.id);
        removed++;
      }
    }

    return removed;
  }
}
```

---

## 八、实施计划

### Week 1: Tier 1 种子扩展

| 天 | 任务 | 产出 |
|----|------|------|
| Day 1 | 编写种子生成脚本 + 代码生成类 (20条) | seed-code-gen.ts |
| Day 2 | 代码解释类 (15条) + 系统操作类 (15条) | seed-debug.ts, seed-sys.ts |
| Day 3 | 文档搜索类 (10条) + 通用问答类 (10条) | seed-doc.ts, seed-qa.ts |
| Day 4 | 文件操作类 (10条) + 集成测试 | seed-file.ts, 测试 |
| Day 5 | KnowledgeBridge 实现 + STMP/经验图谱注入 | knowledge-bridge.ts |

### Week 2: Tier 2 搜索兜底

| 天 | 任务 | 产出 |
|----|------|------|
| Day 1 | OnDemandSearcher 核心实现 | on-demand-search.ts |
| Day 2 | 搜索结果缓存 + 防滥用机制 | 缓存层 |
| Day 3 | agent.ts 集成 + 降级策略 | 集成代码 |
| Day 4 | 搜索质量评估 + 自动沉淀 | 质量过滤 |
| Day 5 | 端到端测试 + 性能基准 | 测试报告 |

### Week 3: Tier 3 自积累增强

| 天 | 任务 | 产出 |
|----|------|------|
| Day 1 | QA 知识提取器 | qa-extractor.ts |
| Day 2 | Dream Engine ↔ KnowledgeGate 联动 | dream-bridge.ts |
| Day 3 | 经验编译器触发率提升 | 增强编译 |
| Day 4 | 知识生命周期管理（衰减/淘汰/刷新） | lifecycle.ts |
| Day 5 | 全链路测试 + 文档 | 测试报告, README |

### 里程碑

| 里程碑 | 时间 | 验收标准 |
|--------|------|---------|
| M1: Tier 1 完成 | Week 1 末 | 100 条种子，冷启动覆盖率 ≥ 60% |
| M2: Tier 2 完成 | Week 2 末 | 搜索兜底可用，自动沉淀经验 |
| M3: Tier 3 增强 | Week 3 末 | 自积累管道完整，30 天后经验 ≥ 200 |

---

## 九、验收指标

| 指标 | 测量方法 | 目标值 |
|------|---------|--------|
| 冷启动覆盖率 | 100 条标准问题，命中种子/经验的比例 | ≥ 60% |
| 首次交互延迟 | 命中种子时的端到端延迟 | < 100ms |
| 搜索兜底延迟 | 未命中时搜索+LLM 总结延迟 | < 10s |
| 搜索沉淀率 | 搜索成功后编译为经验的比例 | ≥ 30% |
| 30 天经验增长 | 30 天后的经验总数 | ≥ 200 |
| 知识准确率 | 抽样 50 条经验，人工验证正确性 | ≥ 90% |

---

## 十、风险与缓解

| 风险 | 影响 | 缓解 |
|------|------|------|
| 种子经验质量参差 | 命中但回答不好 | 每条种子需要人工审核 |
| 搜索结果不可靠 | 沉淀错误知识 | LLM 质量过滤 + 执行验证 |
| KnowledgeGate 内存爆炸 | OOM | 500 条上限 + LRU 淘汰 |
| 搜索 API 限流 | 兜底失效 | 缓存 + 每日上限 + 降级到纯 LLM |
| 经验冲突 | 新旧经验矛盾 | Dream Engine 修剪 + 置信度排序 |

---

## 十一、依赖

| 依赖 | 当前状态 | 需要 |
|------|---------|------|
| ExperienceGraph | ✅ SQLite 已实现 | 无需改动 |
| STMPStore | ✅ SQLite 已实现 | 无需改动 |
| ExperienceCompiler | ✅ 已实现 | 增强 QA 编译 |
| Dream Engine | ✅ 已实现 | 增加 KnowledgeGate 联动 |
| ByteEncoder | ✅ 已实现 | 用于知识向量化 |
| KnowledgeGate | ✅ 已实现 | 需要 KnowledgeBridge |
| search_web / fetch_url | ✅ 工具已实现 | 需要 OnDemandSearcher |
| LLM 调用 | ✅ 已实现 | 用于搜索结果总结 |
