# ByteEncoder 训练系统修复与开发计划

> 生成时间：2026-05-16
> 基于：代码深度审查 + 架构研究

---

## 一、现状诊断

### 1.1 三条路径不一致（核心架构缺陷）

训练和推理使用不同的前向路径，导致优化目标与实际推理不对应。

| 步骤 | A: pretrain-encoder.ts | B: ByteEncoder.forward() | C: ByteEncoderBridge.forward() |
|------|----------------------|-------------------------|-------------------------------|
| byteEmbedding 查表 | ✅ | ✅ | ✅ |
| 熵驱动动态合并 | ❌ 跳过 | ✅ 执行 | ✅ 执行 |
| 投影 byteDim→hiddenDim | ✅ | ✅ | ✅ |
| EncoderBlock×2 | ✅ | ✅ | ✅ |
| 池化方式 | **meanPool** | **lastToken** | **meanPool**（Tensor 内部）|
| L2 归一化 | ✅ | ❌ | ❌ |

**影响**：
- 预训练优化的是 meanPool+L2 下的余弦相似度，推理取的是 lastToken 无归一化的表示
- 动态合并在训练时跳过 ~40% 字节的独立编码，推理时却执行合并
- 增量训练如果用 ByteEncoderBridge，走的是 forwardTensor（有合并+meanPool），和推理 lastToken 不一致

### 1.2 增量训练全链路断路

```
OnlineLearner.attachByteEncoder()  ← 从未调用
    ↓
this.byteBridge = null（始终）
    ↓
collectTextSample() → 直接 return（byteBridge 为 null）
update() 中 ByteEncoder 训练逻辑 → 跳过（byteBridge 为 null）
    ↓
ByteEncoder 权重在运行时完全冻结
```

| 组件 | 代码状态 | 运行时状态 |
|------|---------|-----------|
| `pretrain-encoder.ts` | ✅ 完整 | 仅 CLI 手动，step=1145 后未再训练 |
| `ByteEncoderBridge` | ✅ 完整 | ❌ 未接入（byteBridge=null） |
| `collectTextSample()` | ✅ 完整 | ❌ 因 byteBridge=null 跳过 |
| `CapacityMonitor` | ✅ 完整 | ❌ 从未实例化 |
| `autoTriggerTraining` | ✅ 完整 | ❌ 训练的是三进制/LoRA，不是 ByteEncoder |

### 1.3 ~~预训练数据偏差~~ ✅ 已修复

> **更新于 2026-05-17**

**V1 数据（已废弃删除）**：
- `training-data/all-training-data.jsonl`（62,404 对）— 96.1% 增强数据，24% 带口语噪声后缀，76% 项目自源代码增强
- 质量过差，已删除

**V2 数据（当前使用）**：5 阶段课程数据，共 212,060 对

| 阶段 | 文件 | 数据量 | 来源 | 学习率 |
|------|------|--------|------|--------|
| Stage 0 字词 | `stage-0-dictionary.jsonl` | 117,060 | cedict 词典 | 0.003 |
| Stage 1 基础 | `stage-1-foundation.jsonl` | 19,000 | alpaca_gpt4_zh + codesearchnet | 0.002 |
| Stage 2 领域 | `stage-2-domain.jsonl` | 23,750 | belle_zh + codesearchnet | 0.001 |
| Stage 3 技术 | `stage-3-technical.jsonl` | 28,500 | belle_zh + codesearchnet | 0.0005 |
| Stage 4 泛化 | `stage-4-scale.jsonl` | 23,750 | codesearchnet (Python/JS/Java) | 0.0003 |

训练脚本：`scripts/dev-train-encoder.sh`（5 阶段增量训练，lr 递减）

### 1.4 旧 Checkpoint 质量评估 ✅ 已由 Stage 0 替代

旧 checkpoint（step=1145，Buddy 自身代码 1833 对，权重 ≈ 随机初始化）已废弃。
当前 checkpoint 为 Stage 0 字典预训练结果：

```
step: 469 | trainPairs: 5765 | epochs: 2
timestamp: 2026-05-17T01:18:27Z
sources: jsonl=5765 (cedict 词典子集)
posSim: 0.437 | negSim: 0.393 | gap: 0.044
```

作为 Stage 0 基线，后续 Stage 1-4 增量训练在此基础上继续（`--resume`）。

---

## 二、修复方案

### Phase 0：统一前向路径（优先级最高）

**目标**：训练、推理、增量学习使用同一条前向路径。

**方案**：引入 Entropy-Gated Attention Pooling，替代现有的 meanPool/lastToken/dynamicMerge 三套逻辑。

```
统一路径：
  bytes → byteEmbedding → 投影 → EncoderBlock×N → EntropyGatedAttnPool → [128]

EntropyGatedAttnPool：
  1. 复用 computeEntropies() 计算每个字节位置的熵
  2. attention_score[i] = dot(poolWeight, h[i]) + α · entropy[i]
  3. weight = softmax(attention_score)
  4. output = Σ weight[i] · h[i]
```

**改动文件**：

| 文件 | 改动 |
|------|------|
| `src/brain/right/features/text-encoder.ts` | `forward()` / `forwardTensor()` 统一用 EntropyGatedAttnPool；删除 `dynamicMerge`、`poolLast`；新增 `poolWeight` 参数 |
| `src/brain/right/training/pretrain-encoder.ts` | `forwardBackwardPair()` 使用 ByteEncoder 的统一前向（通过 `forwardTensor`），不再手写独立的前向逻辑；删除 `encodeTensor`、`meanPoolNormTensor`、`l2normTensor` |
| `src/brain/right/training/byte-encoder-bridge.ts` | `forward()` 调用 `encoder.forwardTensor()`（已有），无需改动；删除 `_meanPool`、`_l2norm` 等手写池化，改用 Tensor 的 autograd |

**新增参数**：
- `poolWeight: Tensor [hiddenDim]` — 注意力池化的可学习向量（128 个 float）
- `entropyGateAlpha: number` — 熵门控系数（默认 0.5，可学习或固定）

**向后兼容**：
- 旧 checkpoint 的 `poolWeight` 不存在 → Xavier 随机初始化
- 旧参数全部保留，只新增 p35（poolWeight）

**工作量**：3h

---

### Phase 1：接入增量训练链路

**目标**：让运行时的交互数据能训练 ByteEncoder。

**1.1 接入 ByteEncoderBridge**

文件：`src/brain/right/index.ts`

```typescript
// 构造函数中，在 byteEncoder 初始化之后添加：
this.learner.attachByteEncoder(this.byteEncoder, {
  learningRate: 0.00005,   // 比主网络低 10 倍
  maxGradNorm: 0.5,
  temperature: 0.1,
});
```

**1.2 实例化 CapacityMonitor**

文件：`src/brain/right/index.ts`

```typescript
this.capacityMonitor = new CapacityMonitor(
  this.byteEncoder,
  this.learner,
  { autoAct: true, assessInterval: 100 },
);

// 注册回调
this.capacityMonitor.onTrainRequest(async (epochs) => {
  // 触发增量训练（复用 pretrain 逻辑）
  await this.runIncrementalTrain(epochs);
});
this.capacityMonitor.onExpandRequest(async (targetLevel) => {
  return this.byteEncoder.expandToNextLevel();
});
```

**1.3 接入 CapacityMonitor.observe()**

文件：`src/brain/right/index.ts` — `learnFromOutcome()` 方法

```typescript
// 在 collectFromOutcome 之后添加：
this.capacityMonitor.observe(
  signal.content ?? '',
  outcome.success,
  // intentCorrect / toolCorrect 从 outcome 推断
);
```

**1.4 新增 runIncrementalTrain() 方法**

文件：`src/brain/right/index.ts`

```typescript
async runIncrementalTrain(epochs: number): Promise<void> {
  // 从 ByteEncoderBridge 的缓存中获取训练样本
  // 复用 pretrain-encoder.ts 的 forwardBackwardPair 逻辑
  // 1 epoch = 遍历所有缓存样本一次
  // 保存 checkpoint 到 checkpoints/encoder-pretrain/final.json
}
```

**工作量**：2h

---

### Phase 2：修复预训练脚本

**目标**：预训练使用统一路径，补充训练数据。

**2.1 预训练脚本改用统一前向**

文件：`src/brain/right/training/pretrain-encoder.ts`

- 删除 `forwardBackwardPair()` 中手写的 embedBytes → matmul → meanPool → l2norm 逻辑
- 改为调用 `encoder.forwardTensor(text)` 获取 Tensor，保留 autograd 链
- 对两个方向的 Tensor 做 meanPool → l2norm → cosineSim → MSE loss
- backward 通过 autograd 自动传播

**2.2 补充训练数据** ✅ 已完成

> **更新于 2026-05-17**

已按 5 阶段课程准备 212,060 对训练数据，存放在 `training-data/stages/`：

| 阶段 | 文件 | 数据量 | 来源 | epochs | lr |
|------|------|--------|------|--------|----|
| Stage 0 字词 | `stage-0-dictionary.jsonl` | 117,060 | cedict 中英词典 | 2 | 0.003 |
| Stage 1 基础 | `stage-1-foundation.jsonl` | 19,000 | alpaca_gpt4_zh + codesearchnet (JS/Python/Java) | 2 | 0.002 |
| Stage 2 领域 | `stage-2-domain.jsonl` | 23,750 | belle_zh + codesearchnet | 2 | 0.001 |
| Stage 3 技术 | `stage-3-technical.jsonl` | 28,500 | belle_zh + codesearchnet | 1 | 0.0005 |
| Stage 4 泛化 | `stage-4-scale.jsonl` | 23,750 | codesearchnet (Python/JS/Java) | 1 | 0.0003 |

训练脚本：`scripts/dev-train-encoder.sh`

~~旧 V1 数据 `all-training-data.jsonl`（62,404 对，96% 增强噪声）已废弃删除。~~

---

### Phase 3：开发闲时训练

**目标**：用户聊天中说"训练 /path" → 闲时自动执行 → 完成通知。

**3.1 新增 idle-trainer.ts**

文件：`src/brain/right/training/idle-trainer.ts`

```typescript
interface TrainTask {
  id: string;
  source: string;        // 文件路径或目录
  status: 'pending' | 'running' | 'done' | 'failed';
  createdAt: number;
  startedAt?: number;
  finishedAt?: number;
  result?: { pairs: number; epochs: number; loss: number; gap: number };
  error?: string;
}

class IdleTrainer {
  private queue: TrainTask[] = [];
  private running = false;

  // 添加训练任务
  enqueue(source: string): TrainTask { ... }

  // 闲时执行（挂载到 DreamEngine.shouldDream）
  async tick(): Promise<boolean> {
    if (this.running || this.queue.length === 0) return false;
    // 执行队列中第一个 pending 任务
    // 加载数据 → 增量训练 → 保存 checkpoint → 通知
  }

  // 超时强制执行（排队 >30 分钟）
  async forceRun(): Promise<void> { ... }
}
```

**3.2 接入 DreamEngine**

文件：`src/memory/dream.ts`

在 `shouldDream()` 的空闲检测中添加：
```typescript
// 优先检查训练队列
if (idleTrainer.queue.length > 0) {
  await idleTrainer.tick();
  return false; // 本次不做记忆巩固，让给训练
}
```

**3.3 ws-handler 意图识别**

文件：`src/core/ws-handler.ts`

添加"训练"意图识别：
```typescript
const trainMatch = content.match(/训练\s+(.+)/);
if (trainMatch) {
  const source = trainMatch[1];
  idleTrainer.enqueue(source);
  return { text: `收到，已将 ${source} 加入训练队列，空闲时执行` };
}
```

**3.4 新增 train_encoder 工具**

文件：`src/tools/builtin.ts`

```typescript
{
  name: 'train_encoder',
  description: '将指定文件/目录加入 ByteEncoder 训练队列',
  parameters: { path: '文件或目录路径' },
  execute: async ({ path }) => idleTrainer.enqueue(path),
}
```

**3.5 capability-gate 权限**

文件：`src/core/capability-gate.ts`

新增 `train_encoder` 能力，默认开启。

**工作量**：4h

---

### Phase 4：验证与调优

**4.1 统一路径验证**

- [ ] 新路径从零训练 500 步后，posSim > 0.6, negSim < 0.3, gap > 0.3
- [ ] 中文文本编码结果语义合理（相似文本距离近，无关文本距离远）
- [ ] 英文文本编码结果语义合理
- [ ] JSON/路径/错误信息等结构化文本编码有区分度

**4.2 增量训练端到端测试**

- [ ] `attachByteEncoder()` 后，交互产生的文本样本被收集
- [ ] `update()` 中 ByteEncoderBridge 被调用，loss 有值
- [ ] 训练后 ByteEncoder 权重发生变化（对比前后 exportWeights）

**4.3 闲时训练测试**

- [ ] 聊天说"训练 /path" → 回复"已加入队列"
- [ ] 空闲时自动执行训练
- [ ] 训练完成通知用户（含 loss/gap）
- [ ] 多个任务排队执行

**4.4 性能基准**

| 指标 | 目标 |
|------|------|
| forward() 延迟（100 字符） | <2ms（CPU） |
| forward() 延迟（500 字符） | <5ms（CPU） |
| 增量训练 1 步（batch=8） | <50ms |
| 内存增量 | <10MB |

---

## 三、执行顺序与依赖

```
Phase 0 (统一路径)  ← 最高优先级，后续所有阶段依赖此
  ↓
Phase 1 (接入链路)  ← 依赖统一路径
  ↓
Phase 2 (修复预训练) ← 依赖统一路径，可与 Phase 1 并行
  ↓
Phase 3 (闲时训练)  ← 依赖 Phase 1
  ↓
Phase 4 (验证)      ← 依赖全部
```

## 四、风险与缓解

| 风险 | 影响 | 缓解 |
|------|------|------|
| 新路径从零训练效果不确定 | 编码质量不达标 | 先用小数据集（5000 对）训练 500 步验证 posSim/negSim/gap，达标后再全量训练 |
| 50000 对数据采集耗时 | 项目延期 | 优先采集通用对话+技术文本（16000 对），其余后续补充 |
| 增量训练干扰主网络（IntuitionNet） | 意图分类/工具选择变差 | ByteEncoderBridge 学习率已设为 0.00005（主网络的 1/10），梯度独立 |
| 闲时训练占用 CPU 影响对话响应 | 用户体验下降 | 训练步之间插入 sleep(10ms)，限制单次训练 ≤3 epochs |
| 多源数据引入噪声 | 编码质量下降 | 课程学习排序（短→长，简单→困难），数据质量过滤 |

## 五、工作量汇总

| Phase | 工作量 | 优先级 |
|-------|--------|--------|
| Phase 0: 统一前向路径 | 3h | P0 |
| Phase 1: 接入增量训练 | 2h | P0 |
| Phase 2: 修复预训练 + 数据 | 8h | P1 |
| Phase 3: 闲时训练 | 4h | P2 |
| Phase 4: 验证调优 | 2h | P1 |
| **总计** | **19h** | — |
