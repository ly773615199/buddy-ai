# BlendBrain 神经网络修复计划

> 版本: v1.0
> 日期: 2026-05-23
> 前置: REINFORCE 梯度已修复 (commit 367aa0d)
> 状态: 待执行

---

## 一、问题总览

BlendBrain 是 v3.0 后加的决策路由器，被设计为旁路组件而非中枢组件。
导致 14 个信号流断裂，其中 5 个高影响、5 个中影响、4 个低影响。

**核心矛盾：BlendBrain 有 5 个输出维度，但只有 2-3 个有执行器；有 128 维输入，但只接了 3 个信号源（ResourceHub + TaskSignal + BodyState）。**

---

## 二、修复架构

### 2.1 扩展后的特征向量（128 → 180 维）

```
[0, 108)   资源画像     — 现有，ResourceHub.getActive() × 6维
[108, 116) 任务信号     — 现有，TaskSignal + ResourceState
[116, 124) 本体状态     — 现有，BodyState 子集
[124, 140) 直觉信号     — 新增，IntuitionNet 输出
[140, 148) 学习状态     — 新增，OnlineLearner 统计
[148, 156) 三进制状态   — 新增，TernaryGrowth + TernaryScheduler
[156, 164) 反馈信号     — 新增，ConvergenceLayer + DispatchLearner
[164, 172) 影子大脑     — 新增，ShadowBrain 缺口 + 进化状态
[172, 180) 预留         — 新增，扩展用
```

### 2.2 扩展后的输出维度（5 → 11 维）

```
[0, 5)   R⁵ 路由权重    — 现有
[5]      学习率乘数      — 新增，给 OnlineLearner
[6]      训练触发信号    — 新增，给 TernaryScheduler
[7]      进化方向偏好    — 新增，给 ShadowBrain
[8]      置信度阈值      — 新增，动态调整执行器门槛
[9]      探索强度        — 新增，给 BlendBandit
[10]     紧急度          — 新增，给小脑稳态调节
```

### 2.3 网络架构升级

```
现在: 128 → 64(ReLU) → 5(Softmax)           ~8.5K 参数
目标: 180 → 96(ReLU) → 48(ReLU) → 11(Softmax) ~22K 参数
```

---

## 三、执行计划

### Phase A: 扩展特征向量（2 天）

**目标：** 将 BlendBrain 的输入从 128 维扩展到 180 维，接入所有断裂的信号源。

#### A.1 重写 feature-extractor.ts

**文件:** `src/brain/hub/feature-extractor.ts`（重写 ~120 行）

```typescript
export function buildFeatureVector(ctx: {
  hub: ResourceHub;
  signal: TaskSignal;
  resources: ResourceState;
  bodyState: BodyState;
  // 新增信号源
  intuition?: IntuitionSignal;
  onlineLearner?: { recentLosses: number[]; trainCount: number; totalUpdates: number };
  ternary?: { growthStage: string; trainSteps: number; domainCount: number; coverage: number };
  convergence?: { feedbackCount: number; knowledgeCount: number; correctionRate: number };
  dispatchLearner?: { bandits: Map<string, { alpha: number; beta: number; count: number }> };
  shadow?: { gapCount: number; evolutionActive: boolean; lastEvolutionSuccess: boolean };
  prototypeMatch?: { confidence: number; isNovel: boolean };
}): Float32Array {
  const vec = new Float32Array(180);

  // [0, 108): 资源画像 — 现有逻辑不变
  // [108, 116): 任务信号 — 现有逻辑不变
  // [116, 124): 本体状态 — 现有逻辑不变

  // [124, 140): 直觉信号 — 新增
  if (ctx.intuition) {
    vec[124] = ctx.intuition.intent.confidence;
    vec[125] = ctx.intuition.hit ? 1 : 0;
    vec[126] = ctx.intuition.qualityEstimate;
    // intent 概率分布的前 8 维
    // suggestedTools 的命中数
  }

  // [140, 148): 学习状态 — 新增
  if (ctx.onlineLearner) {
    const ol = ctx.onlineLearner;
    vec[140] = Math.min(1, ol.trainCount / 1000);
    vec[141] = ol.recentLosses.length > 0
      ? ol.recentLosses[ol.recentLosses.length - 1] : 0;
    // loss 趋势（最近 10 步的斜率）
    vec[142] = computeLossTrend(ol.recentLosses);
  }

  // [148, 156): 三进制状态 — 新增
  if (ctx.ternary) {
    const stageMap: Record<string, number> = {
      seed: 0, sprout: 0.2, growing: 0.4, trainable: 0.7, mature: 1.0,
    };
    vec[148] = stageMap[ctx.ternary.growthStage] ?? 0;
    vec[149] = Math.min(1, ctx.ternary.trainSteps / 5000);
    vec[150] = ctx.ternary.coverage;
    vec[151] = Math.min(1, ctx.ternary.domainCount / 10);
  }

  // [156, 164): 反馈信号 — 新增
  if (ctx.convergence) {
    vec[156] = Math.min(1, ctx.convergence.feedbackCount / 100);
    vec[157] = Math.min(1, ctx.convergence.knowledgeCount / 500);
    vec[158] = ctx.convergence.correctionRate;
  }
  if (ctx.dispatchLearner) {
    // 最优策略的成功率
    const best = getBestStrategy(ctx.dispatchLearner.bandits);
    vec[159] = best?.successRate ?? 0.5;
    vec[160] = best?.confidence ?? 0;
  }

  // [164, 172): 影子大脑 — 新增
  if (ctx.shadow) {
    vec[164] = Math.min(1, ctx.shadow.gapCount / 10);
    vec[165] = ctx.shadow.evolutionActive ? 1 : 0;
    vec[166] = ctx.shadow.lastEvolutionSuccess ? 1 : 0;
  }

  // [172, 180): 预留 — 初始化为 0

  return vec;
}
```

#### A.2 修改 brain.ts decide() 传入新信号

**文件:** `src/brain/brain.ts`（修改 ~30 行）

在 `decide()` 中构建特征向量时，传入新增信号源：

```typescript
const features = buildFeatureVector({
  hub: this.resourceHub,
  signal, resources, bodyState,
  intuition,
  onlineLearner: this.right.getOnlineLearnerStats(),
  ternary: this.getTernaryStatus(),
  convergence: this.getConvergenceStats(),
  dispatchLearner: this.dispatchLearner,
  shadow: this.shadow ? {
    gapCount: this.shadow.gapDetector.getActionableGaps().length,
    evolutionActive: this.shadow.getStatus()?.enabled ?? false,
    lastEvolutionSuccess: true,
  } : undefined,
  prototypeMatch: intuition?.protoMatch,
});
```

#### A.3 新增辅助方法

**文件:** `src/brain/brain.ts`（新增 ~40 行）

```typescript
private getTernaryStatus(): { growthStage: string; trainSteps: number; domainCount: number; coverage: number } {
  // 从 TernaryModelManager 获取各领域模型状态
  // 返回聚合后的状态
}

private getConvergenceStats(): { feedbackCount: number; knowledgeCount: number; correctionRate: number } {
  const stats = this.convergenceLayer?.getStats();
  return {
    feedbackCount: stats?.bySource.feedback ?? 0,
    knowledgeCount: stats?.bySource.knowledge ?? 0,
    correctionRate: stats ? stats.totalIngested / Math.max(1, this.decisionCount) : 0,
  };
}
```

**验收标准:**
- [ ] buildFeatureVector() 输出 180 维向量
- [ ] 所有新增信号源正确编码
- [ ] 向后兼容：新增信号为 0 时不影响现有行为
- [ ] 单元测试覆盖

---

### Phase B: 扩展输出维度 + 协调信号（2 天）

**目标：** BlendBrain 输出从 5 维扩展到 11 维，新增协调信号驱动其他子系统。

#### B.1 升级 BlendBrain 网络架构

**文件:** `src/brain/hub/blend-brain.ts`（重写 ~80 行）

```typescript
export class BlendBrain {
  private W1: Float32Array;  // 180×96
  private b1: Float32Array;  // 96
  private W2: Float32Array;  // 96×48
  private b2: Float32Array;  // 48
  private W3: Float32Array;  // 48×11
  private b3: Float32Array;  // 11
  // ... 其他字段不变

  forward(input: Float32Array): BlendOutput {
    // Layer 1: ReLU
    const h1 = relu(matAdd(matMul(input, this.W1), this.b1));
    // Layer 2: ReLU
    const h2 = relu(matAdd(matMul(h1, this.W2), this.b2));
    // Layer 3: Split
    const logits = matAdd(matMul(h2, this.W3), this.b3);

    // 路由权重：前 5 维 softmax
    const routeWeights = softmax(logits.subarray(0, 5));
    // 协调信号：后 6 维 sigmoid（独立控制）
    const coordination = sigmoid(logits.subarray(5, 11));

    return { routeWeights, coordination };
  }
}

export interface BlendOutput {
  routeWeights: Float32Array;   // [5] R⁵ 路由权重
  coordination: Float32Array;   // [6] 协调信号
}

export interface CoordinationSignal {
  learningRateMultiplier: number;  // [0] 给 OnlineLearner: 0.1-3.0
  trainTrigger: number;            // [1] 给 TernaryScheduler: 0-1, >0.7 触发
  evolutionDirection: number;      // [2] 给 ShadowBrain: -1(收敛)到+1(探索)
  confidenceThreshold: number;     // [3] 动态置信度门槛: 0.3-0.9
  explorationIntensity: number;    // [4] 给 BlendBandit: 0-1
  urgency: number;                 // [5] 给小脑: 0-1
}
```

#### B.2 协调信号驱动其他子系统

**文件:** `src/brain/brain.ts`（修改 ~60 行）

```typescript
// 在 decide() 中，BlendBrain 输出后：
const { routeWeights, coordination } = this.blendBrain.sample(features);
const coord = parseCoordination(coordination);

// 1. 给 OnlineLearner 设置学习率乘数
this.right.setLearningRateMultiplier(coord.learningRateMultiplier);

// 2. 给 TernaryScheduler 传递训练触发
if (coord.trainTrigger > 0.7) {
  this.ternaryScheduler?.triggerFromBlend(coord.trainTrigger);
}

// 3. 给 BlendBandit 调整探索强度
this.blendBandit.setExplorationIntensity(coord.explorationIntensity);

// 4. 给小脑传递紧急度
this.cerebellum.setUrgency(coord.urgency);

// 5. 动态置信度阈值
const confidenceThreshold = 0.3 + coord.confidenceThreshold * 0.6;
```

**验收标准:**
- [ ] BlendBrain 输出 11 维（5 路由 + 6 协调）
- [ ] 协调信号正确传递到各子系统
- [ ] sigmoid 输出各维度独立控制
- [ ] 网络参数量 ~22K

---

### Phase C: 双向信号流（3 天）

**目标：** 让 BlendBrain 的输出真正影响其他子系统的行为，其他子系统的状态真正参与 BlendBrain 的决策。

#### C.1 BlendBrain → OnlineLearner（学习率调节）

**文件:** `src/brain/right/training/online-learner.ts`（修改 ~15 行）

```typescript
// 新增方法
setLearningRateMultiplier(multiplier: number): void {
  this._strategyLrMultiplier = Math.max(0.1, Math.min(3.0, multiplier));
}
```

**信号含义：**
- BlendBrain 输出 lrMultiplier > 1 → "当前任务简单，加速学习"
- BlendBrain 输出 lrMultiplier < 1 → "当前任务复杂，谨慎学习"
- BlendBrain 输出 lrMultiplier ≈ 0 → "loss 很高，暂停学习（observe-only）"

#### C.2 BlendBrain → TernaryScheduler（训练触发）

**文件:** `src/ternary/scheduler.ts`（修改 ~10 行）

```typescript
// 新增方法
triggerFromBlend(signal: number): void {
  // signal > 0.7 表示 BlendBrain 认为应该触发训练
  // 用于覆盖 shouldTrain() 的夜间窗口限制
  this._blendTrigger = signal;
}
```

**信号含义：**
- BlendBrain 看到三进制成长阶段高 + 知识积累多 → 触发训练
- BlendBrain 看到用户在相关领域频繁纠正 → 触发该领域训练

#### C.3 BlendBrain → ShadowBrain（进化方向）

**文件:** `src/brain/shadow/index.ts`（修改 ~15 行）

```typescript
// 新增方法
setEvolutionDirection(direction: number): void {
  // direction > 0: 倾向探索（发现能力缺口多）
  // direction < 0: 倾向收敛（稳定运行）
  this._evolutionDirection = direction;
}
```

#### C.4 IntuitionNet._hidden → BlendBrain（直觉信号）

**文件:** `src/brain/hub/feature-extractor.ts`（修改 ~15 行）

```typescript
// 在 [124, 140) 区域编码直觉信号
if (ctx.intuition) {
  vec[124] = ctx.intuition.intent.confidence;
  vec[125] = ctx.intuition.hit ? 1 : 0;
  vec[126] = ctx.intuition.qualityEstimate;
  vec[127] = ctx.intuition.suggestedTools.length / 32;  // 归一化
  // _hidden 向量的统计摘要（均值、方差、最大值、最小值）
  if (ctx.intuition._hidden) {
    const h = ctx.intuition._hidden;
    let sum = 0, sumSq = 0, max = -Infinity, min = Infinity;
    for (let i = 0; i < h.length; i++) {
      sum += h[i]; sumSq += h[i] * h[i];
      if (h[i] > max) max = h[i]; if (h[i] < min) min = h[i];
    }
    const mean = sum / h.length;
    const std = Math.sqrt(sumSq / h.length - mean * mean);
    vec[128] = mean;     // 隐藏向量均值
    vec[129] = std;      // 隐藏向量标准差
    vec[130] = max;      // 隐藏向量最大值
    vec[131] = min;      // 隐藏向量最小值
  }
}
```

#### C.5 OnlineLearner 状态 → BlendBrain（学习状态）

**文件:** `src/brain/right/index.ts`（新增 ~15 行）

```typescript
getOnlineLearnerStats(): { recentLosses: number[]; trainCount: number; totalUpdates: number } {
  return {
    recentLosses: this.learner.getRecentLosses(),
    trainCount: this.learner.getTrainCount(),
    totalUpdates: this.learner.getTotalUpdates(),
  };
}
```

#### C.6 ConvergenceLayer 纠正频率 → BlendBrain

**文件:** `src/brain/brain.ts`（新增 ~10 行）

在 `decide()` 中读取 ConvergenceLayer 统计：

```typescript
const convergenceStats = this.convergenceLayer?.getStats();
```

#### C.7 TernaryGrowth 成长阶段 → BlendBrain

**文件:** `src/brain/brain.ts`（新增 ~15 行）

```typescript
private getTernaryStatus(): TernaryStatus {
  // 从 TernaryModelManager 获取各领域模型状态
  // 返回聚合后的成长阶段、训练步数、覆盖度
}
```

**验收标准:**
- [ ] BlendBrain 输出的 lrMultiplier 正确传递到 OnlineLearner
- [ ] BlendBrain 输出的 trainTrigger 正确触发 TernaryScheduler
- [ ] BlendBrain 输出的 evolutionDirection 正确影响 ShadowBrain
- [ ] IntuitionNet._hidden 统计摘要正确编码到特征向量
- [ ] OnlineLearner 状态正确传递到 BlendBrain
- [ ] ConvergenceLayer 统计正确传递到 BlendBrain
- [ ] TernaryGrowth 成长阶段正确传递到 BlendBrain

---

### Phase D: 经验 + 云端执行器（3 天）

**目标：** 补齐 R⁵ 权重中的 2 个空维度（experience 和 cloudLLM），让 5 个维度都有实际执行能力。

#### D.1 experience 执行器

**文件:** `src/brain/hub/experience-executor.ts`（新增 ~100 行）

```typescript
/**
 * 经验直连执行器 — 从经验图谱中直接检索匹配的解决方案
 *
 * 输入: 用户消息 + 任务信号
 * 输出: { text, confidence } 或 null
 *
 * 数据源:
 * - DecisionMemory: 历史成功回复片段
 * - PrototypeMemory: 原型匹配的标签和工具分布
 * - ExperienceGraph: 经验图谱的路径匹配
 */
export class ExperienceExecutor {
  async execute(
    input: string,
    signal: TaskSignal,
    right: RightBrain,
  ): Promise<{ text: string; confidence: number } | null> {
    // 1. 从 DecisionMemory 检索
    const decisionMem = right.getDecisionMemoryR();
    if (decisionMem) {
      const fragments = decisionMem.retrieve(input, 3);
      if (fragments.length > 0 && fragments[0].successRate > 0.6) {
        return { text: fragments[0].text, confidence: fragments[0].successRate };
      }
    }

    // 2. 从 PrototypeMemory 检索
    const protoMatch = right.prototypeMemory.search(input, 1)[0];
    if (protoMatch && protoMatch.distance < 0.3) {
      // 用原型的工具分布构造建议
      return { text: protoMatch.prototype.label, confidence: 1 - protoMatch.distance };
    }

    return null;
  }
}
```

#### D.2 cloudLLM 执行器

**文件:** `src/brain/hub/cloud-executor.ts`（新增 ~80 行）

```typescript
/**
 * 云端 LLM 执行器 — 调用外部大模型 API
 *
 * 通过 LLMAdapter 调用已配置的云端模型。
 * 受 budgetRemaining 和 confidenceThreshold 约束。
 */
export class CloudLLMExecutor {
  async execute(
    input: string,
    signal: TaskSignal,
    resources: ResourceState,
    llmAdapter: any,  // LLMAdapter
  ): Promise<{ text: string; confidence: number } | null> {
    // 预算检查
    if (resources.budgetRemaining <= 0) return null;

    try {
      const result = await llmAdapter.chat(input, {
        maxTokens: 1024,
        temperature: 0.7,
      });
      return { text: result.text, confidence: result.confidence ?? 0.7 };
    } catch {
      return null;
    }
  }
}
```

#### D.3 集成到 executeBlendStrategy

**文件:** `src/brain/brain.ts`（修改 ~20 行）

```typescript
// 在 executeBlendStrategy 中：

// experience（新增）
if (weights[1] > THRESHOLD) {
  const expResult = await this.experienceExecutor.execute(input, signal, this.right);
  if (expResult) {
    components.push('experience');
    results.push({ ...expResult, source: 'experience' });
  }
}

// cloudLLM（新增）
if (weights[4] > THRESHOLD && this.hasExternalLLM) {
  const cloudResult = await this.cloudExecutor.execute(input, signal, resources, this.llmAdapter);
  if (cloudResult) {
    components.push('cloudLLM');
    results.push({ ...cloudResult, source: 'cloudLLM' });
  }
}
```

**验收标准:**
- [ ] ExperienceExecutor 能从 DecisionMemory/PrototypeMemory 检索
- [ ] CloudLLMExecutor 能调用外部 LLM API
- [ ] executeBlendStrategy 中 5 个维度都有执行能力
- [ ] 预算检查正确（cloudLLM 受 budgetRemaining 约束）

---

### Phase E: 加权融合 + 持久化（2 天）

**目标：** 实现真正的加权融合（不是 winner-takes-all），完善持久化。

#### E.1 加权融合

**文件:** `src/brain/brain.ts`（修改 ~40 行）

```typescript
private blendResults(
  results: Array<{ text: string; confidence: number; source: string; weight: number }>,
  blend: BlendVector,
): { text: string; confidence: number; source: string; components: string[] } {
  if (results.length === 0) return empty;

  // cascade: 按权重排序，第一个够好就用
  if (blend.executionMode === 'cascade') {
    results.sort((a, b) => (b.weight * b.confidence) - (a.weight * a.confidence));
    if (results[0].confidence >= blend.confidenceThreshold) {
      return { ...results[0], components: [results[0].source] };
    }
  }

  // compete: 质量最高的赢
  if (blend.executionMode === 'compete') {
    results.sort((a, b) => b.confidence - a.confidence);
    return { ...results[0], components: [results[0].source] };
  }

  // parallel/sequential: 加权融合（核心改进）
  // 按 weight × confidence 加权选择主输出，但用所有结果的置信度加权平均
  const totalWeight = results.reduce((s, r) => s + r.weight * r.confidence, 0);
  const primary = results.sort((a, b) => (b.weight * b.confidence) - (a.weight * a.confidence))[0];
  const blendedConfidence = totalWeight > 0
    ? results.reduce((s, r) => s + r.weight * r.confidence, 0) / results.length
    : primary.confidence;

  return {
    text: primary.text,
    confidence: blendedConfidence,
    source: results.map(r => r.source).join('+'),
    components: results.map(r => r.source),
  };
}
```

#### E.2 持久化扩展

**文件:** `src/brain/brain.ts`（修改 ~20 行）

saveBlendState() 中新增：
```typescript
coordinationHistory: this.coordinationHistory,
experienceExecutorStats: this.experienceExecutor?.getStats(),
```

**验收标准:**
- [ ] parallel 模式真正的加权融合（不是 winner-takes-all）
- [ ] cascade 模式按 weight × confidence 排序
- [ ] 持久化包含协调信号历史

---

## 四、文件改动汇总

| 文件 | 操作 | Phase | 行数 |
|------|------|-------|------|
| `src/brain/hub/feature-extractor.ts` | 重写 | A | ~120 |
| `src/brain/hub/blend-brain.ts` | 重写 | B | ~150 |
| `src/brain/hub/experience-executor.ts` | **新增** | D | ~100 |
| `src/brain/hub/cloud-executor.ts` | **新增** | D | ~80 |
| `src/brain/brain.ts` | 修改 | A/B/C/D/E | +200/-100 |
| `src/brain/right/index.ts` | 修改 | C | +15 |
| `src/brain/right/training/online-learner.ts` | 修改 | C | +10 |
| `src/ternary/scheduler.ts` | 修改 | C | +10 |
| `src/brain/shadow/index.ts` | 修改 | C | +15 |
| `src/brain/hub/blend-brain.test.ts` | 修改 | B | +30 |
| `src/brain/hub/feature-extractor.test.ts` | **新增** | A | ~60 |

**总计: ~780 行新增/修改，~200 行删除，净增 ~580 行**

---

## 五、时间线

```
Week 1: Phase A (2d) + Phase B (2d) + Phase C 前半 (1d)
        → 特征扩展 + 输出扩展 + 部分双向信号流
        → 产出: BlendBrain 输入 180d、输出 11d、部分信号流接通

Week 2: Phase C 后半 (2d) + Phase D (3d)
        → 完成双向信号流 + 经验/云端执行器
        → 产出: 全部 14 个断裂点修复、5 个维度都有执行器

Week 3: Phase E (2d) + 测试 (2d) + 影子模式验证 (1d)
        → 加权融合 + 持久化 + 全量测试
        → 产出: 完整 v3.1 可运行
```

---

## 六、验收标准总览

### Phase A 完成
- [ ] buildFeatureVector() 输出 180 维
- [ ] 直觉信号编码正确
- [ ] 学习状态编码正确
- [ ] 三进制状态编码正确
- [ ] 反馈信号编码正确
- [ ] 影子大脑状态编码正确

### Phase B 完成
- [ ] BlendBrain 输出 11 维
- [ ] 路由权重 softmax 正确
- [ ] 协调信号 sigmoid 正确
- [ ] 网络参数量 ~22K

### Phase C 完成
- [ ] 14 个断裂点全部修复
- [ ] BlendBrain → OnlineLearner 学习率调节
- [ ] BlendBrain → TernaryScheduler 训练触发
- [ ] BlendBrain → ShadowBrain 进化方向
- [ ] IntuitionNet → BlendBrain 直觉信号
- [ ] OnlineLearner → BlendBrain 学习状态
- [ ] ConvergenceLayer → BlendBrain 纠正频率
- [ ] TernaryGrowth → BlendBrain 成长阶段

### Phase D 完成
- [ ] ExperienceExecutor 可用
- [ ] CloudLLMExecutor 可用
- [ ] 5 个路由维度都有执行能力

### Phase E 完成
- [ ] parallel 模式加权融合
- [ ] cascade 模式按综合分数排序
- [ ] 持久化完整

---

## 七、风险与缓解

| 风险 | 影响 | 缓解 |
|------|------|------|
| 特征维度增加导致训练变慢 | 决策延迟增加 | 特征稀疏时跳过零值计算 |
| 协调信号干扰现有行为 | 系统退化 | 影子模式 + 渐进切换 |
| 经验执行器返回低质量结果 | 决策质量下降 | 置信度门槛 + fallback |
| 云端执行器超时 | 决策延迟增加 | 异步 + 超时 + 预算限制 |
| 网络参数增加导致过拟合 | 泛化能力下降 | LPR 防遗忘 + dropout |

---

*v1.0 — 2026-05-23 | 从断裂点分析到完整修复计划*
