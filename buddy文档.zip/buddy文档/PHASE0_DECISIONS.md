# Phase 0 架构决策记录

> **日期**: 2026-05-21
> **前置**: ARCHITECTURE_ROADMAP.md Phase 0
> **目标**: 锁定四个架构参数，后续所有训练和开发基于此配置

---

## 决策总览

```typescript
const ARCHITECTURE_DECISIONS = {
  vocabSize: 16384,        // 16K，中文+代码覆盖
  hiddenDim: 128,          // 保持不变，靠 MoE 扩展能力
  numLayers: 4,            // 保持不变
  numHeads: 4,             // 保持不变
  ffnDim: 512,             // 保持不变
  moeExperts: 8,           // 8 个专家
  moeTopK: 2,              // 每 token 激活 2 个
  ternaryBits: 1.58,       // BitNet 标准 {-1, 0, 1}
};
```

---

## 决策 1: vocabSize → 16384

**选项对比**:

| 选项 | Embedding 参数 | LM Head 参数 | 总增量 | 中文覆盖 | 代码覆盖 |
|------|---------------|-------------|--------|---------|---------|
| 8K (当前) | 1.05M | 1.05M | 基准 | 单字级 | 不足 |
| 16K | 2.1M | 2.1M | +2.1M | 词组级 | 完整 |
| 32K | 4.2M | 4.2M | +6.3M | 完整 | 完整 |

**决策**: 16K

**理由**:
- 8K → 16K: 参数增量 2.1M（三进制后 0.5MB），可接受
- 16K → 32K: 参数增量再加 4.2M，收益递减（中文词组已覆盖）
- 中文验证: "人工智能" 应为 1 个 token，不是 4 个字节
- 代码验证: "async/await", "interface", "React" 不拆成单字节

**影响文件**:
- `src/brain/right/nn/bbpe-tokenizer.ts` — vocabSize 配置
- `src/brain/right/nn/buddy-lm.ts` — Embedding 层 + LM Head 维度
- `src/brain/right/nn/bbpe-bridge.ts` — ByteEncoder ↔ BBPE 桥接
- `training-data/stages/` — 需要在新词表上重新生成训练数据

---

## 决策 2: hiddenDim → 128（不变）

**选项对比**:

| 选项 | 总参数 | 三进制存储 | CPU 推理延迟 | 等效能力 |
|------|--------|-----------|-------------|---------|
| 128 (当前) | 16.3M | 4.1MB | <25ms | 基准 |
| 256 | ~65M | 16MB | ~50ms | 4x 参数 |

**决策**: 保持 128

**理由**:
- hiddenDim 翻倍 → 参数 ×4，延迟 ×2，收益不成比例
- MoE + 检索 + 三进制的组合效率远高于单纯增大 hiddenDim
- 128 + MoE 8 专家 = 等效 500M+ 纯参数模型（通过检索进一步放大）
- 如果 MoE + 检索后仍不够，再考虑 256（但代价是全部重来）

**约束**:
- hiddenDim 是最不可逆的决策，变更 = 所有权重重来
- 如果未来必须增大，应在三进制 MoE 训练前做决定

---

## 决策 3: MoE → 8 experts, top-2

**选项对比**:

| 选项 | 总参数 | 活跃参数 | 计算量/token | 专家分工粒度 |
|------|--------|---------|-------------|------------|
| 无 MoE (当前) | 16.3M | 16.3M | 16.3M | 无 |
| 4 experts top-2 | ~25M | ~18M | 18M | 粗 |
| 8 experts top-2 | ~50M | ~18M | 18M | 细 |
| 16 experts top-2 | ~100M | ~20M | 20M | 过细（路由难） |

**决策**: 8 experts, top-2

**理由**:
- 总参数 ~50M，活跃参数 ~18M（与当前 16.3M 接近，计算量不增加）
- 8 个专家提供足够的领域分工粒度（代码/对话/知识/推理/...）
- top-2 比 top-1 更稳定（单专家故障不影响输出）
- 比 4 experts 多 1 倍存储但三进制后只多 ~5MB
- 比 16 experts 路由更简单（16 个小专家容易坍缩）

**架构变更**:
```
当前 DecoderBlock:
  Self-Attention → Cross-Attention(Encoder) → FFN(128→512→128)

MoE DecoderBlock:
  Self-Attention → Cross-Attention(Encoder) → Router(128→8) → TopK(2) → Expert_0..7(128→512→128)
```

**负载均衡**:
- 辅助损失: Router 的 entropy 正则化，防止所有 token 都选同一个专家
- 渐进式: 先 4 experts 训练稳定，再扩展到 8

---

## 决策 4: 三进制 → 1.58-bit {-1, 0, 1}

**选项对比**:

| 选项 | 每权重 bit | 存储效率 | 算法复杂度 | 论文支持 |
|------|-----------|---------|-----------|---------|
| float32 (当前) | 32 | 基准 | 基准 | — |
| int8 | 8 | 4x | 简单量化 | 广泛 |
| 1.58-bit | 2 | 16x | 乘法→加减 | BitNet (Microsoft) |
| 2-bit | 2 | 16x | 需要乘法 | 有限 |

**决策**: 1.58-bit {-1, 0, 1}

**理由**:
- BitNet 论文验证: 1.58-bit 模型在同等参数下精度损失 < 5%
- 乘法退化为加减法 + 跳零: CPU 效率最高
- 2-bit 虽然多 1 bit 精度，但失去了 BitNet 的算术简化优势
- 与 MatMul 优化配合: 加减法可以用 SIMD 并行

**存储计算**:
```
当前: 16.3M × 32bit = 65MB
三进制: 50M × 2bit = 12.5MB
+ Tokenizer + metadata ≈ 15MB 完整模型

对比:
  当前 float32: 65MB
  三进制 MoE:   15MB（4.3 倍缩小，参数量 3x 增长）
```

---

## 参数量汇总

| 组件 | 当前 (float32) | 新架构 (float32) | 新架构 (三进制) |
|------|---------------|-----------------|---------------|
| Embedding (16K×128) | 1.05M | 2.1M | 0.5MB |
| Encoder (冻结) | 297K | 297K | 0.07MB |
| Decoder Self-Attn × 4 | 524K | 524K | 0.13MB |
| Decoder Cross-Attn × 4 | 524K | 524K | 0.13MB |
| Decoder FFN × 4 | 524K | — | — |
| Decoder MoE FFN × 4 × 8 | — | 4.2M | 1.05MB |
| Decoder Router × 4 | — | 4K | 0.001MB |
| ChunkedCrossAttn (Phase 2) | — | 200K | 0.05MB |
| LM Head (128×16K) | 1.05M | 2.1M | 0.5MB |
| Output Heads | 50K | 50K | 0.01MB |
| **总参数** | **16.3M** | **~50M** | **~2.5MB** |
| **活跃参数/token** | **16.3M** | **~18M** | **~2.5MB** |

---

## 实施影响

### Phase 1 需要同步做的事

| 决策 | 影响的 Phase 1 任务 | 具体变更 |
|------|-------------------|---------|
| vocabSize 16K | P0a: BBPE 词表扩展 | 重新训练 Tokenizer，Embedding/LM Head 维度调整 |
| hiddenDim 128 | 无 | 保持不变 |
| MoE 8 experts | P1: cross-attention 层 | DecoderBlock 结构变更（MoE + cross-attention 一起做） |
| ternary 1.58-bit | P0b: 三进制格式 | .ta 格式按 2bit/weight 设计 |

### Phase 3 预训练需要的调整

| 组件 | 调整 |
|------|------|
| ByteEncoder | 不受影响（独立于 Decoder） |
| quality_head | 不受影响（OutputHeads 独立） |
| Decoder 预训练 | 必须在新架构上训练（MoE + 16K vocab） |
| 训练数据 | training-data/stages/ 需要在 16K 词表上重新 tokenize |

---

## 决策追溯

| 决策 | 日期 | 理由 | 不可逆程度 |
|------|------|------|-----------|
| vocabSize 16K | 2026-05-21 | 中文+代码覆盖，参数增量可控 | 高（Tokenizer 训好后不可改） |
| hiddenDim 128 | 2026-05-21 | 靠 MoE 扩展能力，不靠增大维度 | 极高（全部权重对应维度） |
| MoE 8 experts | 2026-05-21 | 4x 参数扩展，计算量不增加 | 中（可以减少专家数，不能增加后不重训） |
| ternary 1.58-bit | 2026-05-21 | BitNet 验证，算术简化 | 高（权重格式固定后不可逆） |
