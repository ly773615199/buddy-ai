# 修复计划：意图→决策→执行→反馈→重决策→再执行→结果呈现 全链路

> 道生一，一生二，二生三，三生万物。万物负阴而抱阳。
>
> 核心思想：三脑从"决策引擎"升级为"全链路管家"——入口是它，中间是它，出口也是它。

---

## 问题总览

| # | 层 | 问题 | 严重度 | 文件 |
|---|---|---|---|---|
| P01 | 意图 | 三套意图系统不统一，同一输入分类 6 次 | 🔴 | signal-collector.ts / intent-classifier.ts / message-processor.ts |
| P02 | 意图 | knowledge_query 映射到 ['web','writing']，writing 域无数据 | 🟡 | signal-collector.ts |
| P03 | 决策 | Gate-0 经验路由先执行副作用再验证 | 🔴 | agent.ts |
| P04 | 决策 | 单规则命中时跳过裁决器（Thompson Sampling 等全部绕过） | 🟡 | brain.ts |
| P05 | 决策 | 用户纠正计数器不可重置（单向棘轮） | 🟡 | ws-handler.ts |
| P06 | 决策 | DAG 假阳性（"然后"等高频词触发） | 🟡 | message-processor.ts |
| P07 | 执行 | 质检机制形同虚设（无拒绝格式、用 chat 模型） | 🟡 | plan-executor.ts |
| P08 | 执行 | 并行结果只拼接不融合 | 🟡 | plan-executor.ts |
| P09 | 执行 | 经验执行副作用无法回滚 | 🔴 | plan-executor.ts |
| P10 | 反馈 | reflect() 的 shouldRetry 无人消费 | 🔴 | agent.ts / ws-handler.ts |
| P11 | 反馈 | 三脑反馈用了伪造的 ResourceState | 🔴 | reflector.ts |
| P12 | 反馈 | 幻觉检测的 write_file 误判（domain 映射不一致） | 🟡 | reflector.ts |
| P13 | 重决策 | hasAlternativePaths 永远返回 false | 🔴 | brain.ts |
| P14 | 呈现 | 失败时 getFallbackReply() 绕过三脑诊断 | 🔴 | agent.ts / ws-handler.ts |
| P15 | 呈现 | 执行结果裸输出，不经过三脑润色 | 🔴 | agent.ts / ws-handler.ts |
| P16 | 呈现 | generationPlan 多生成器结果被丢弃 | 🟡 | agent.ts |
| P17 | 横向 | 同一输入被分类 6 次（计算浪费） | 🟡 | 多文件 |
| P18 | 横向 | decisionTrace 的 success 字段不反映降级路径 | 🟡 | agent.ts |

---

## Phase 0: 道 — 统一感知层（一）

> 道生一。感知只算一次，结果共享全链路。

### 0.1 新建 `PerceptionState` 统一感知结果

**文件**: `src/core/perception-state.ts`（新建）

```typescript
/**
 * 统一感知状态 — 一次计算，全链路共享
 *
 * 替代：IntentClassifier.classify / detectDomains / assessTaskComplexity
 *        / SearchArbiter.decide / classifyFromText 的多次重复调用
 */
export interface PerceptionState {
  // === 意图 ===
  intent: {
    category: IntentCategory;       // 统一分类
    confidence: number;             // 0-1
    matchedKeywords: string[];
  };
  domains: string[];                // 任务域标签
  complexity: 'simple' | 'medium' | 'complex';
  taskType: 'chat' | 'tools' | 'reasoning' | 'background' | 'domain';

  // === 搜索 ===
  search: {
    needed: boolean;
    confidence: number;
    query?: string;
  };

  // === DAG ===
  dag: {
    shouldUseDAG: boolean;
    reason: string;
  };

  // === 工具裁剪 ===
  suggestedTools: string[];         // 推荐工具子集

  // === 向量 ===
  embedding: Float32Array;          // ByteEncoder 向量（右脑复用）

  // === 元信息 ===
  timestamp: number;
  computeMs: number;                // 感知耗时
}
```

### 0.2 新建 `Perceptor` 统一感知器

**文件**: `src/core/perceptor.ts`（新建）

```typescript
/**
 * 统一感知器 — 道生一
 *
 * 所有意图识别、域检测、复杂度评估、搜索判断、工具裁剪
 * 在这里一次性完成，结果缓存供全链路使用。
 */
export class Perceptor {
  private cache: Map<string, PerceptionState> = new Map();

  perceive(content: string, context?: { recentMessages: string[] }): PerceptionState {
    // 1. 检查缓存（同一内容不重复计算）
    const cached = this.cache.get(content);
    if (cached) return cached;

    const t0 = performance.now();

    // 2. 右脑 NN 分类（一次调用）
    const intent = this.rightBrain.classifyFromText(content);

    // 3. 域检测（基于 NN 结果，不重复调用）
    const domains = this.mapDomains(intent);

    // 4. 复杂度评估（基于 NN 结果 + 内容特征）
    const { complexity, taskType, shouldUseDAG, dagReason } =
      this.assessComplexity(content, intent);

    // 5. 搜索判断（基于意图）
    const search = this.decideSearch(content, intent, domains);

    // 6. 工具裁剪（基于意图分类）
    const suggestedTools = this.filterTools(intent);

    // 7. 向量编码（一次）
    const embedding = this.rightBrain.encode(content);

    const state: PerceptionState = {
      intent, domains, complexity, taskType,
      search, dag, suggestedTools, embedding,
      timestamp: Date.now(),
      computeMs: performance.now() - t0,
    };

    this.cache.set(content, state);
    return state;
  }
}
```

### 0.3 改造调用方

| 现在 | 改为 |
|---|---|
| `agent.ts collectSignals()` 调用 `detectDomains` + `assessTaskComplexity` | 调用 `perceptor.perceive(content)` |
| `message-processor.ts buildContext()` 调用 `classifyFromText` + `IntentClassifier` | 从 `PerceptionState.suggestedTools` 取工具列表 |
| `agent.ts handleCLIMessage()` 调用 `searchArbiter.decide()` | 从 `PerceptionState.search` 取搜索决策 |
| `signal-collector.ts` 的 `collectSignals()` | 接收 `PerceptionState`，不再自行计算 |
| `orchestrate()` 内部的 `collectSignals()` + `collectResourceState()` | 第一个参数改为 `PerceptionState` |

### 0.4 修改的文件

| 文件 | 改动 |
|---|---|
| `src/core/perceptor.ts` | **新建** — 统一感知器 |
| `src/core/perception-state.ts` | **新建** — 感知状态类型 |
| `src/core/agent.ts` | `handleCLIMessage` 和 `orchestrate` 改用 `Perceptor` |
| `src/core/signal-collector.ts` | `collectSignals` 接收 `PerceptionState`，删除 `detectDomains` / `assessTaskComplexity` |
| `src/core/message-processor.ts` | `buildContext` 从 `PerceptionState` 取工具列表，删除 `IntentClassifier` 依赖 |
| `src/core/intent-classifier.ts` | **废弃** — 功能合并入 `Perceptor` |
| `src/core/ws-handler.ts` | `handleUserMessage` 改用 `Perceptor` |

---

## Phase 1: 一 — 统一决策器（二生三）

> 一生二，二生三。执行与质量是阴阳，决策是三。

### 1.1 重构 `ThreeBrain.decide()` — 统一决策输出

**文件**: `src/brain/brain.ts`

**现状**: `decide()` 内部有 5 个并行任务、3 层裁决、2 种路径（三脑/旧），输出的 `DecisionResult` 包含 `plan` + `localGeneration` + `generationPlan` + `nuggets` + `deliberationResult` + `mentalSimulation`——信息过多，下游不知道该用哪个。

**修改**:

```typescript
// 新的 DecisionResult — 只有一个统一的决策输出
interface DecisionResult {
  // 核心决策（唯一）
  action: 'execute' | 'clarify' | 'concede';

  // 执行计划（action=execute 时）
  plan?: ExecutionPlan;

  // 澄清内容（action=clarify 时）
  clarification?: {
    question: string;
    proposals?: Proposal[];
  };

  // 元信息
  meta: {
    strategy: string;           // 选择的策略名
    confidence: number;         // 校准后的置信度
    latencyMs: number;
    sources: string[];          // 参与决策的来源
    intuition?: IntuitionSignal;
    bodyState?: BodyState;
  };
}
```

### 1.2 裁决器前置 — 无论几个方案都走裁决

**文件**: `src/brain/brain.ts` `decide()` 方法

**现状**:
```typescript
if (scoredPlans.length <= 1 && !integratedProposal) {
  plan = scoredPlans[0]?.plan ?? await this.left.decide(...);
  // ← 跳过裁决器！
}
```

**修改**:
```typescript
// 始终走裁决器，即使只有一个方案
const allProposals = this.collector.merge(leftProposals, extraCandidates);
const feasibilityResults = this.feasibilityChecker.checkBatch(...);
for (const p of allProposals) {
  p.calibratedConfidence = this.calibrator.calibrate(p.source, p.rawConfidence);
}
const arbitration = this.arbiter.arbitrate(allProposals, feasibilityResults, context);
plan = arbitration.selected.plan ?? await this.left.decide(...);
```

### 1.3 审议结果统一出口

**文件**: `src/brain/brain.ts`

**现状**: `deliberationResult.action === 'refine'` 时直接 `return`，绕过了后续的质量评估和裁决。

**修改**: 审议结果也走统一的 `DecisionResult` 输出格式，由下游统一处理。

### 1.4 修改的文件

| 文件 | 改动 |
|---|---|
| `src/brain/brain.ts` | 重构 `decide()` 返回统一 `DecisionResult`；裁决器始终执行 |
| `src/brain/types.ts` | 更新 `DecisionResult` 类型 |
| `src/core/agent.ts` | `orchestrateWithThreeBrain` 适配新 `DecisionResult` |

---

## Phase 2: 阴阳 — 执行内嵌质量（负阴抱阳）

> 万物负阴而抱阳。执行时怀抱着质量，不是做完再评估。

### 2.1 执行器内嵌质量门控

**文件**: `src/core/plan-executor.ts`

**现状**: `executeSingle` / `executeParallel` / `executeDAG` 执行完直接返回，不检查质量。

**修改**: 每个执行模式的输出都经过 `QualityAssessor`：

```typescript
async function executeSingle(ctx, plan): Promise<ExecutionResult> {
  const result = await ctx.processor.processStream(plan.content, ...);

  // 新增：质量门控
  const quality = ctx.sys.threeBrain.qualityAssessor.assess({
    userRequest: plan.content,
    taskType: plan.mode,
    output: result.text,
    executionSuccess: true,
  });

  // 质量不达标 → 尝试一次重生成
  if (quality.score < 0.5) {
    const retry = await ctx.processor.processStream(
      `[改进] ${plan.content}\n\n上一次回答质量不足(${quality.score.toFixed(2)}): ${quality.issues.map(i=>i.description).join('; ')}\n请改进：`,
      ...,
    );
    if (retry.text.length > 0) {
      result.text = retry.text;
    }
  }

  return { text: result.text, source: 'single', toolCalls: result.toolCalls, qualityScore: quality.score };
}
```

### 2.2 并行结果真正融合

**文件**: `src/core/plan-executor.ts` `fuseResults()`

**现状**: 多专家结果用分割线拼接。

**修改**:
```typescript
function fuseResults(results, originalQuestion): string {
  const successful = results.filter(r => r.success && r.text.length > 0);
  if (successful.length === 0) return '所有专家均未返回有效结果。';
  if (successful.length === 1) return successful[0].text;

  // 新增：用 ResponseComposer 组织多源结果
  const nuggets: InformationNugget[] = successful.map((r, i) => ({
    id: `expert_${i}`,
    source: 'rule',
    role: i === 0 ? 'primary' : 'support',
    content: r.text,
    type: 'fact',
    confidence: r.score ?? 0.5,
    quotable: true,
  }));

  const composer = new ResponseComposer();
  const intentGoal = { needCode: false, needSteps: false }; // 从信号推断
  const composed = composer.compose(intentGoal, nuggets);

  return composed.confidence > 0.4 ? composed.text : successful[0].text;
}
```

### 2.3 DAG 子任务结果经过三脑

**文件**: `src/core/plan-executor.ts` `executeDAG()`

**现状**: `dagResult.summary` 直接返回。

**修改**:
```typescript
async function executeDAG(ctx, plan): Promise<ExecutionResult> {
  const dag = plan.resolvedDAG!;
  const result = await ctx.sys.taskExecutor.execute(dag, ...);

  // 新增：将 DAG 结果打包为 Nugget，经过 ResponseComposer
  const nuggets: InformationNugget[] = result.taskResults
    .filter(r => r.success)
    .map((r, i) => ({
      id: `dag_${r.id}`,
      source: 'rule',
      role: 'primary',
      content: r.result,
      type: 'fact',
      confidence: 0.7,
      quotable: true,
    }));

  // 新增：质量评估
  const summary = result.summary || nuggets.map(n => n.content).join('\n\n');
  const quality = ctx.sys.threeBrain.qualityAssessor.assess({
    userRequest: plan.content,
    taskType: 'tools',
    output: summary,
    executionSuccess: true,
  });

  // 用 ResponseComposer 组织
  const composer = new ResponseComposer();
  const composed = composer.compose({ needCode: false, needSteps: false }, nuggets);

  return {
    text: composed.confidence > 0.4 ? composed.text : summary,
    source: `dag/${dag.id}`,
    toolCalls: result.taskResults.map(r => ({ name: r.name, args: {}, result: r.result })),
    qualityScore: quality.score,
  };
}
```

### 2.4 修改的文件

| 文件 | 改动 |
|---|---|
| `src/core/plan-executor.ts` | `executeSingle` / `executeParallel` / `executeDAG` 内嵌质量门控；`fuseResults` 用 ResponseComposer |
| `src/core/plan-executor.ts` | `executeExperience` 失败时的安全回滚（先检查副作用再执行） |
| `src/brain/dispatch/executor.ts` | `fanOutWeightedExecute` 的结果经过 ResponseComposer |

---

## Phase 3: 三 — 统一呈现层（三生万物归一）

> 三生万物，万物归一。所有结果回到三脑润色后呈现。

### 3.1 新建 `Presenter` — 三脑呈现器

**文件**: `src/brain/presenter.ts`（新建）

```typescript
/**
 * 三脑呈现器 — 万物归一
 *
 * 所有执行结果（LLM、经验、DAG、工具、错误）都经过这里
 * 统一润色、诊断、情绪渲染后呈现给用户。
 */
export class Presenter {
  private composer: ResponseComposer;
  private qualityAssessor: OutputQualityAssessor;
  private verbose: boolean;

  /**
   * 呈现成功结果
   */
  present(result: ExecutionResult, context: {
    signal: TaskSignal;
    plan: OrchestrationPlan;
    bodyState: BodyState;
  }): { text: string; visuals?: VisualBlock[] } {
    // 1. 质量评估
    const quality = this.qualityAssessor.assess({
      userRequest: context.signal.content ?? '',
      taskType: context.signal.taskType,
      output: result.text,
      executionSuccess: true,
    });

    // 2. 低质量 → 润色改进
    if (quality.score < 0.5) {
      const improved = this.polish(result.text, quality, context);
      if (improved) return { text: improved, visuals: result.visuals };
    }

    // 3. 多源结果 → ResponseComposer 组织
    if (result.toolCalls.length > 1) {
      const composed = this.composeMultiSource(result, context);
      if (composed) return { text: composed, visuals: result.visuals };
    }

    // 4. 情绪渲染（小脑状态影响语气）
    const rendered = this.renderEmotion(result.text, context.bodyState);

    return { text: rendered, visuals: result.visuals };
  }

  /**
   * 呈现失败诊断 — 三脑如实汇报
   */
  presentFailure(error: Error, context: {
    signal: TaskSignal;
    plan?: OrchestrationPlan;
    bodyState: BodyState;
    diagnostic?: DiagnosticReport;
  }): string {
    // 1. 用三脑的 buildDiagnostic 做结构化诊断
    const diagnostic = context.diagnostic ?? this.buildDiagnostic(error, context);

    // 2. 根据诊断类别生成用户友好的回复
    const parts: string[] = [];

    // 情绪感知的开头
    const mood = context.bodyState.inferMood();
    if (mood === 'frustrated') {
      parts.push('抱歉，这次确实没做好。');
    } else if (mood === 'tired') {
      parts.push('有点累了，让我说明下情况。');
    } else {
      parts.push('遇到了一些问题：');
    }

    // 结构化诊断
    parts.push(`\n**问题**: ${diagnostic.message}`);
    if (diagnostic.detail) {
      parts.push(`**详情**: ${diagnostic.detail}`);
    }

    // 可操作的建议
    if (diagnostic.suggestions.length > 0) {
      parts.push('\n**你可以这样做**:');
      for (const s of diagnostic.suggestions) {
        const icon = s.priority === 'high' ? '🔴' : s.priority === 'medium' ? '🟡' : '⚪';
        parts.push(`${icon} **${s.label}**: ${s.description}`);
      }
    }

    return parts.join('\n');
  }

  /**
   * 润色 — 低质量结果的改进
   */
  private polish(text: string, quality: QualityAssessment, context: ...): string | null {
    // 基于质量评估的问题做针对性改进
    const issues = quality.issues;
    if (issues.some(i => i.dimension === 'completeness')) {
      // 不完整 → 补充说明
      return text + '\n\n---\n💡 以上回答可能不完整，如需深入了解请告诉我具体方向。';
    }
    if (issues.some(i => i.dimension === 'relevance')) {
      // 不相关 → 重新组织
      return null; // 交给 LLM 重试
    }
    return null;
  }

  /**
   * 多源结果组织 — 用 ResponseComposer
   */
  private composeMultiSource(result: ExecutionResult, context: ...): string | null {
    if (result.toolCalls.length <= 1) return null;

    const nuggets: InformationNugget[] = result.toolCalls.map((tc, i) => ({
      id: `tool_${i}`,
      source: 'rule',
      role: 'primary',
      content: tc.result,
      type: 'fact',
      confidence: tc.result.startsWith('[') ? 0.2 : 0.7,
      quotable: true,
    }));

    const composed = this.composer.compose(
      { needCode: false, needSteps: false },
      nuggets,
      context.bodyState,
    );

    return composed.confidence > 0.4 ? composed.text : null;
  }

  /**
   * 情绪渲染 — 小脑状态影响表达
   */
  private renderEmotion(text: string, bodyState: BodyState): string {
    const mood = bodyState.inferMood();
    // 不改变内容，只调整语气
    if (mood === 'energetic' && text.length < 100) {
      return text + ' 💪'; // 精力充沛时加点活力
    }
    if (mood === 'tired' && text.length > 500) {
      // 精力不足时简化长文
      return text.slice(0, 300) + '\n\n... (已简化，如需完整版请告诉我)';
    }
    return text;
  }
}
```

### 3.2 改造 `agent.ts` — 所有出口经过 Presenter

**文件**: `src/core/agent.ts`

**现状**:
```typescript
// 成功路径
return result.text;  // ← 裸输出

// 失败路径
const fallback = getFallbackReply(this.config.personality);
return fallback;     // ← 随机话术
```

**修改**:
```typescript
// 成功路径
const presented = this.presenter.present(result, { signal, plan, bodyState });
return presented.text;

// 失败路径 — 三脑诊断
catch (err: unknown) {
  const diagnostic = this.sys.threeBrain?.buildDiagnostic(
    signal, plan, { success: false, latencyMs: 0, ... }, undefined, [err.message]
  );
  const presented = this.presenter.presentFailure(err, {
    signal, plan, bodyState, diagnostic,
  });
  return presented;
}
```

### 3.3 改造 `ws-handler.ts` — WS 出口经过 Presenter

**文件**: `src/core/ws-handler.ts`

**现状**:
```typescript
// 成功
this.eventBus?.emit({ type: 'llm_response', content: responseText });

// 失败
const fallback = getFallbackReply(this.config.personality);
this.eventBus?.emit({ type: 'error', message: fallback });
```

**修改**:
```typescript
// 成功
const presented = this.presenter.present(result, { signal, plan, bodyState });
this.eventBus?.emit({ type: 'llm_response', content: presented.text, visuals: presented.visuals });

// 失败
const diagnostic = this.sys.threeBrain?.buildDiagnostic(...);
const presented = this.presenter.presentFailure(err, { signal, plan, bodyState, diagnostic });
this.eventBus?.emit({ type: 'error', message: presented });
```

### 3.4 修改的文件

| 文件 | 改动 |
|---|---|
| `src/brain/presenter.ts` | **新建** — 三脑呈现器 |
| `src/core/agent.ts` | `handleCLIMessage` 成功/失败路径都经过 Presenter |
| `src/core/ws-handler.ts` | `handleUserMessage` 成功/失败路径都经过 Presenter |
| `src/core/constants.ts` | `getFallbackReply` 标记废弃（仅保留为最后兜底） |

---

## Phase 4: 万物 — 修复反馈→重决策的断裂

> 反馈闭环是系统的"呼吸"——断了就窒息。

### 4.1 `shouldRetry` 接入重决策循环

**文件**: `src/core/agent.ts`

**现状**:
```typescript
await this.reflect(plan, result, signal);
// ← reflect 的返回值被丢弃
```

**修改**:
```typescript
const reflectResult = await this.reflect(plan, result, signal);

// 反馈闭环：质量不足 → 重决策
if (reflectResult.shouldRetry) {
  if (this.verbose) console.log(`  [Feedback] 质量不足，重决策: ${reflectResult.reason}`);

  // 重决策前检查替代路径
  if (this.hasAlternativePaths(signal, reflectResult.failedTools)) {
    // 重新编排（带反思信息）
    const retryPlan = await this.orchestrate(content, searchContext, {
      reflection: reflectResult.reason,
      failedTools: reflectResult.failedTools,
      previousResult: result.text,
    });

    // 只重试一次
    const retryResult = await this.executeByPlan(retryPlan);
    const retryReflect = await this.reflect(retryPlan, retryResult, signal);

    // 重试后仍失败 → 走诊断汇报
    if (retryReflect.quality > reflectResult.quality) {
      result = retryResult; // 重试更好，用重试结果
    }
    // 否则用原始结果（Presenter 会润色）
  }
}
```

### 4.2 修复 `hasAlternativePaths`

**文件**: `src/brain/brain.ts`

**现状**:
```typescript
private hasAlternativePaths(signal, failedModels?: string[]): boolean {
  if (failedModels && failedModels.length < 3) return true;
  // ← failedModels 永远是 undefined，永远返回 false
}
```

**修改**:
```typescript
private hasAlternativePaths(
  signal: TaskSignal,
  failedTools?: string[],
  currentPlan?: ExecutionPlan,
): boolean {
  // 1. 有失败工具 → 可以换路径
  if (failedTools && failedTools.length > 0) return true;

  // 2. 当前是经验路径 → 可以降级到 LLM
  if (currentPlan?.routeDecision?.path === 'exp_direct') return true;
  if (currentPlan?.routeDecision?.path === 'exp_verified') return true;

  // 3. 当前是 single → 可以试 parallel/cascade
  if (currentPlan?.mode === 'single') return true;

  // 4. 当前是 local_only → 可以试 cloud
  if (currentPlan?.mode === 'local_only') return true;

  return false;
}
```

### 4.3 修复 reflector 的 ResourceState

**文件**: `src/core/reflector.ts`

**现状**:
```typescript
await sys.threeBrain?.feedback?.(
  signal,
  { experienceHit: null } as any,  // ← 伪造
  ...
);
```

**修改**: 将真实的 ResourceState 传入 reflect：

```typescript
// reflect 函数签名变更
export async function reflect(
  sys: Subsystems,
  plan: OrchestrationPlan,
  result: { ... },
  signal: TaskSignal,
  resources: ResourceState,  // ← 新增参数
  verbose: boolean,
): Promise<ReflectResult> {
  // ...
  await sys.threeBrain?.feedback?.(
    signal,
    resources,  // ← 使用真实 ResourceState
    feedbackPlan as any,
    { success: allSuccess, latencyMs: 0, ... },
    signal.domains.join(','),
    result.toolCalls.map(tc => tc.name),
    undefined,
    undefined,
    result.text,
  );
}
```

### 4.4 修复 decisionTrace 的 success 字段

**文件**: `src/core/agent.ts`

**现状**: 只在最终成功/失败时记录，不反映降级路径。

**修改**:
```typescript
// 在 recordLastOutcome 中增加降级信息
private recordLastOutcome(
  success: boolean,
  error?: string,
  executionMs?: number,
  degraded?: boolean,      // 新增：是否经历了降级
  retryCount?: number,     // 新增：重试次数
): void {
  const last = this.decisionTrace[this.decisionTrace.length - 1];
  if (last && last.success === null) {
    last.success = success;
    if (error) last.error = error;
    if (executionMs !== undefined) last.executionMs = executionMs;
    if (degraded) last.degraded = degraded;
    if (retryCount) last.retryCount = retryCount;
  }
}
```

### 4.5 修复幻觉检测的 domain 映射

**文件**: `src/core/reflector.ts`

**现状**:
```typescript
if (call.name === 'write_file' && !signal.domains.includes('file_ops') ...)
```

**修改**:
```typescript
// domain 映射与 signal-collector 保持一致
const FILE_DOMAINS = ['code', 'file_ops']; // code 域包含文件操作
if (call.name === 'write_file' && !FILE_DOMAINS.some(d => signal.domains.includes(d)) ...)
```

### 4.6 修改的文件

| 文件 | 改动 |
|---|---|
| `src/core/agent.ts` | `handleCLIMessage` 消费 `shouldRetry`，接入重决策循环 |
| `src/brain/brain.ts` | 修复 `hasAlternativePaths`，接收 `failedTools` + `currentPlan` |
| `src/core/reflector.ts` | 接收真实 `ResourceState`；修复 domain 映射 |
| `src/core/agent.ts` | `recordLastOutcome` 增加 `degraded` / `retryCount` 字段 |
| `src/core/agent-types.ts` | `decisionTrace` 类型增加降级字段 |

---

## Phase 5: 归一 — 用户纠正恢复 + DAG 修复

### 5.1 用户纠正计数器自动衰减

**文件**: `src/core/ws-handler.ts`

**现状**: `userCorrectionCount` 只增不减。

**修改**:
```typescript
// 每次成功交互衰减一次
private userCorrectionCount = 0;
private lastCorrectionTime = 0;

// 在 handleUserMessage 成功后
if (this.userCorrectionCount > 0) {
  const timeSinceLastCorrection = Date.now() - this.lastCorrectionTime;
  if (timeSinceLastCorrection > 300_000) { // 5 分钟无纠正 → 衰减
    this.userCorrectionCount = Math.max(0, this.userCorrectionCount - 1);
  }
}
```

### 5.2 DAG 假阳性修复

**文件**: `src/core/message-processor.ts` `assessComplexity()`

**现状**: "然后" 等高频词触发 DAG。

**修改**:
```typescript
// 提高阈值 + 增加上下文验证
const shouldUseDAG = (
  markerCount >= 3 ||           // 从 2 提高到 3
  (hasParallel && clauses.length >= 2) ||
  clauses.length >= 5 ||        // 从 3 提高到 5
  (hasMultiplePaths && markerCount >= 1) ||
  (hasCondition && clauses.length >= 3) ||
  (hasQuantity && verbCount >= 2) ||
  (hasCompoundAnalysis && content.length > 100) ||  // 增加长度门槛
  (hasMultipleVerbs && content.length > 150)         // 增加长度门槛
);

// 新增：排除短句中的假阳性
if (content.length < 50 && markerCount <= 1) {
  return { shouldUseDAG: false, reason: '' };
}
```

### 5.3 Gate-0 经验路由安全加固

**文件**: `src/core/agent.ts` `orchestrate()` Gate-0

**现状**: 高置信度经验直接执行，可能有副作用。

**修改**:
```typescript
if (expDecision.path === 'exp_direct' && expSkill) {
  // 新增：副作用检查
  const hasSideEffects = expSkill.steps.some(s =>
    ['write_file', 'exec', 'git_commit', 'git_push'].includes(s.tool)
  );

  if (hasSideEffects) {
    // 有副作用 → 降级到 exp_verified（先执行再质检）
    // 或者走 llm_with_hint（经验作为参考，LLM 执行）
    if (this.verbose) console.log(`  [Gate-0] 经验有副作用，降级到验证路径`);
    // 不直接执行，继续走正常流程
  } else {
    // 无副作用（只读工具）→ 安全直接执行
    const expResult = await execExperience(...);
    // ...
  }
}
```

---

## Phase 6: 统一 — 清理冗余

### 6.1 废弃 `IntentClassifier`

- `src/core/intent-classifier.ts` → 标记 `@deprecated`
- `src/core/message-processor.ts` → 删除 `filterToolsByCategory` 对 `IntentClassifier` 的依赖
- 功能完全由 `Perceptor` 接管

### 6.2 合并 `orchestrateLegacy` 和 `orchestrateWithThreeBrain`

- 当 `threeBrain` 不可用时，用一个轻量版 `decide()` 替代 `orchestrateLegacy`
- 删除 `orchestrateLegacy` 方法（~80 行）
- A/B 对比通过 `abTestEnabled` 在 `orchestrate()` 入口处切换，不需要两个独立方法

### 6.3 清理 `buildContext` 的分层缓存

- `contextCache.static` / `semiDynamic` / `dynamic` 三层缓存 → 由 `PerceptionState` 替代静态层
- 半动态层的 `SEMI_DYNAMIC_INTERVAL = 5` 保留
- 删除 `IntentClassifier.classify` 相关的缓存逻辑

### 6.4 修改的文件

| 文件 | 改动 |
|---|---|
| `src/core/intent-classifier.ts` | 标记 `@deprecated` |
| `src/core/agent.ts` | 删除 `orchestrateLegacy`，合并入 `orchestrate` |
| `src/core/message-processor.ts` | 删除 `filterToolsByCategory`，简化 `buildContext` |

---

## 实施顺序与依赖

```
Phase 0 (道: 统一感知)
  │
  ├── 0.1 PerceptionState 类型
  ├── 0.2 Perceptor 类
  ├── 0.3 改造调用方
  └── 0.4 清理旧代码
  │
  ▼
Phase 1 (一: 统一决策)      ← 依赖 Phase 0（PerceptionState 作为输入）
  │
  ├── 1.1 统一 DecisionResult
  ├── 1.2 裁决器始终执行
  ├── 1.3 审议结果统一出口
  └── 1.4 适配调用方
  │
  ▼
Phase 2 (阴阳: 执行内嵌质量) ← 依赖 Phase 1（需要统一的 DecisionResult）
  │
  ├── 2.1 执行器内嵌质量门控
  ├── 2.2 并行结果融合
  ├── 2.3 DAG 结果经过三脑
  └── 2.4 DispatchExecutor 改造
  │
  ▼
Phase 3 (三: 统一呈现)       ← 依赖 Phase 2（需要质量评估结果）
  │
  ├── 3.1 Presenter 类
  ├── 3.2 agent.ts 出口改造
  ├── 3.3 ws-handler.ts 出口改造
  └── 3.4 废弃 getFallbackReply
  │
  ▼
Phase 4 (万物: 反馈闭环修复) ← 依赖 Phase 3（需要 Presenter 处理失败）
  │
  ├── 4.1 shouldRetry 接入重决策
  ├── 4.2 修复 hasAlternativePaths
  ├── 4.3 修复 reflector ResourceState
  ├── 4.4 修复 decisionTrace
  └── 4.5 修复幻觉检测
  │
  ▼
Phase 5 (归一: 细节修复)     ← 无强依赖，可并行
  │
  ├── 5.1 纠正计数器衰减
  ├── 5.2 DAG 假阳性修复
  └── 5.3 Gate-0 安全加固
  │
  ▼
Phase 6 (清理)               ← 依赖全部完成
  │
  ├── 6.1 废弃 IntentClassifier
  ├── 6.2 合并 orchestrate 方法
  └── 6.3 清理 buildContext 缓存
```

---

## 预期效果

| 指标 | 现在 | 修复后 |
|---|---|---|
| 意图分类次数/请求 | 6 次 | 1 次 |
| 感知延迟 | ~30ms (6 次) | ~8ms (1 次) |
| 失败时用户看到 | 随机安慰话术 | 结构化诊断 + 可操作建议 |
| 多源结果质量 | 拼接（无融合） | ResponseComposer 组织 |
| 反馈→重决策 | 断裂（shouldRetry 无人消费） | 闭环（自动重试一次） |
| hasAlternativePaths | 永远 false | 正确判断 |
| 经验副作用 | 先执行再检查 | 先检查再执行 |
| DAG 假阳性率 | 高（"然后"触发） | 低（阈值+长度门槛） |
| 用户纠正锁定 | 永久锁定 local_only | 5 分钟衰减 |

---

## 涉及文件清单（21 个文件）

| 文件 | 操作 | Phase |
|---|---|---|
| `src/core/perceptor.ts` | 新建 | 0 |
| `src/core/perception-state.ts` | 新建 | 0 |
| `src/brain/presenter.ts` | 新建 | 3 |
| `src/core/agent.ts` | 大改 | 0,1,3,4,5,6 |
| `src/core/ws-handler.ts` | 大改 | 0,3,5 |
| `src/core/message-processor.ts` | 中改 | 0,5,6 |
| `src/core/signal-collector.ts` | 中改 | 0 |
| `src/core/plan-executor.ts` | 大改 | 2 |
| `src/core/reflector.ts` | 中改 | 4 |
| `src/core/experience-loop.ts` | 小改 | 4 |
| `src/core/constants.ts` | 小改 | 3 |
| `src/core/orchestrator.ts` | 小改 | 1 |
| `src/core/agent-types.ts` | 小改 | 4 |
| `src/brain/brain.ts` | 大改 | 1,4 |
| `src/brain/types.ts` | 小改 | 1 |
| `src/brain/response-composer.ts` | 不改 | — |
| `src/brain/dispatch/executor.ts` | 中改 | 2 |
| `src/brain/left/scheduler.ts` | 不改 | — |
| `src/brain/left/rule-engine.ts` | 不改 | — |
| `src/core/intent-classifier.ts` | 废弃 | 6 |
| `src/core/agent.ts` (orchestrateLegacy) | 删除 | 6 |

**总改动量估算**：~1200 行新增 + ~400 行修改 + ~200 行删除
