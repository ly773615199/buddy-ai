# 字典排列组合 + 世界模型择优 — 优化计划

> 目标：让规则引擎从"选 1 条路径"变成"原子级排列组合 → 世界模型模拟 → 需求相关度择优"，
> 实现媲美 LLM 的流畅文字/代码生成能力。

## 核心设计原则

```
原则 1: 颗粒度最小化 — 一个字、一个词、一个 token 是组合的基本单元
原则 2: 评判标准唯一 — 用户需求相关度，不是 novelty/coherence/style
原则 3: 世界模型只模拟 — 不评判好坏，只推演"执行后会怎样"
原则 4: 最终输出必须与任务结果高度相关
```

## 架构总览

```
┌─────────────────────────────────────────────────────────────┐
│                    用户输入                                    │
│                       ↓                                      │
│              ByteEncoder → 128d 查询向量                       │
│                       ↓                                      │
│  ┌──────────────────────────────────────────────────────┐    │
│  │              字典层 (Dictionary Layer)                 │    │
│  │  ┌─────┐ ┌─────┐ ┌──────┐ ┌──────┐ ┌──────┐        │    │
│  │  │字库 │ │词库 │ │连接词│ │句式位│ │token │        │    │
│  │  └──┬──┘ └──┬──┘ └──┬───┘ └──┬───┘ └──┬───┘        │    │
│  │     └───────┴───────┴────────┴────────┘              │    │
│  │                    ↓ 排列组合                          │    │
│  │              N³ 量级候选原子序列                        │    │
│  └──────────────────────────────────────────────────────┘    │
│                       ↓                                      │
│  ┌──────────────────────────────────────────────────────┐    │
│  │              模拟层 (Simulation Layer)                 │    │
│  │              SceneWorldModel.predict()                 │    │
│  │              纯结构推演，不懂语义                        │    │
│  └──────────────────────────────────────────────────────┘    │
│                       ↓                                      │
│  ┌──────────────────────────────────────────────────────┐    │
│  │              评判层 (Evaluation Layer)                 │    │
│  │              唯一标准：用户需求相关度                    │    │
│  │              ByteEncoder(query) · ByteEncoder(candidate)│   │
│  └──────────────────────────────────────────────────────┘    │
│                       ↓                                      │
│              Top-1 输出（与任务结果高度相关）                    │
└─────────────────────────────────────────────────────────────┘
```

---

## Phase 1: 字典层 (Dictionary Layer)

### 1.1 原子字典 (AtomDictionary)

**新建文件**: `src/brain/right/features/atom-dictionary.ts`

最小有意义单元的统一存储：

```typescript
export interface Atom {
  id: string;
  /** 原子类型 */
  type: 'character' | 'word' | 'connector' | 'slot' | 'token' | 'operator';
  /** 原子文本值 */
  text: string;
  /** 语义向量 (ByteEncoder 编码) */
  embedding: Float32Array;
  /** 语言/领域 */
  domain: string;  // 'zh' | 'en' | 'code_ts' | 'code_py' | 'code_bash'
  /** 使用频率 (从反馈学习) */
  frequency: number;
  /** 成功率 (从 EvolutionaryLoop 反馈) */
  successRate: number;
  /** 词性/角色标注 */
  pos?: string;  // 'noun' | 'verb' | 'adj' | 'adv' | 'prep' | ...
}

export class AtomDictionary {
  private atoms: Map<string, Atom>;
  private byDomain: Map<string, Atom[]>;      // 按语言/领域索引
  private byPos: Map<string, Atom[]>;          // 按词性索引
  private byType: Map<string, Atom[]>;         // 按类型索引
  private embeddingIndex: VectorIndex;          // 向量检索

  /** 从用户输入提取原子 */
  extractFromInput(input: string): Atom[];

  /** 按领域+词性检索原子 */
  query(domain: string, pos?: string, topK?: number): Atom[];

  /** 语义检索：找与目标向量最相近的原子 */
  semanticQuery(embedding: Float32Array, topK?: number): Atom[];

  /** 从反馈更新原子权重 */
  updateFeedback(atomIds: string[], positive: boolean): void;

  /** 持久化 */
  serialize(): ArrayBuffer;
  static deserialize(data: ArrayBuffer): AtomDictionary;
}
```

**数据来源**:
- 中文: 从 `ConnectorInsertor.CONNECTORS` 提取连接词原子（已有 35 个）
- 中文: 从 `MultiSentenceSkeleton` 提取句式位原子
- 英文: 停用词表 + 常用词表
- 代码: 从 `CodeTemplateStore.BUILTIN_TEMPLATES` 提取 token 原子
- 运行时: 从用户输入动态提取新原子（`extractFromInput`）

### 1.2 句式位模板 (SlotTemplate)

**新建文件**: `src/brain/right/features/slot-template.ts`

比 `MultiSentenceSkeleton` 更细的模板——每个槽位是一个原子位：

```typescript
export interface SlotTemplate {
  id: string;
  /** 槽位序列: 每个槽位定义允许的原子类型 */
  slots: Array<{
    role: string;           // 'subject' | 'verb' | 'object' | 'modifier' | 'connector' | ...
    allowedTypes: string[]; // 允许的原子类型
    required: boolean;
  }>;
  /** 适用的意图 */
  intent: string;
  /** 适用的复杂度 */
  complexity: 'simple' | 'medium' | 'complex';
}
```

**数据来源**:
- 从 `MultiSentenceSkeleton` 的 10 个骨架拆解为原子位
- 从 `CodeTemplateStore` 的 15 个代码模板拆解为 token 位
- 从 `ConnectorInsertor` 的连接词规则扩展为连接位

---

## Phase 2: 组合生成器 (CombinatorialGenerator)

### 2.1 候选工厂

**新建文件**: `src/brain/right/features/combinatorial-generator.ts`

```typescript
export interface CandidateSentence {
  /** 候选文本 */
  text: string;
  /** 组成原子 ID 序列 */
  atomIds: string[];
  /** 使用的句式位模板 ID */
  templateId: string;
  /** 生成策略 */
  strategy: 'exhaustive' | 'random' | 'guided' | 'mutate';
}

export class CombinatorialGenerator {
  private dictionary: AtomDictionary;
  private templates: SlotTemplate[];

  /**
   * 核心方法：从原子字典排列组合生成候选
   *
   * @param query 用户输入（用于相关度过滤）
   * @param intent 意图类别
   * @param maxCandidates 最大候选数（控制组合爆炸）
   * @returns 候选句子列表
   */
  generate(
    query: string,
    intent: string,
    maxCandidates?: number,  // 默认 50
  ): CandidateSentence[];

  /**
   * 策略 1: 穷举组合（小规模时用）
   * 每个槽位 × 所有允许的原子 = N1 × N2 × ... × Nk 种
   * 用 early pruning 控制爆炸
   */
  private exhaustiveCombination(template: SlotTemplate, domain: string): CandidateSentence[];

  /**
   * 策略 2: 随机采样（大规模时用）
   * 每个槽位随机选原子，重复 M 次
   */
  private randomCombination(template: SlotTemplate, domain: string, samples: number): CandidateSentence[];

  /**
   * 策略 3: 语义引导（ByteEncoder 做初筛）
   * 用查询向量在每个槽位选语义最相关的原子
   */
  private guidedCombination(template: SlotTemplate, queryVec: Float32Array): CandidateSentence[];

  /**
   * 策略 4: 变异（从已有成功候选做微调）
   * 替换 1-2 个原子，保持整体结构
   */
  private mutate(existing: CandidateSentence): CandidateSentence[];

  /**
   * 快速相关度过滤（ByteEncoder 余弦相似度）
   * 在候选进入世界模型前，先粗筛掉明显不相关的
   */
  prefilter(candidates: CandidateSentence[], queryVec: Float32Array, topK: number): CandidateSentence[];
}
```

### 2.2 代码候选工厂

**新建文件**: `src/brain/right/features/code-combinatorial.ts`

```typescript
export interface CodeCandidate {
  code: string;
  atomIds: string[];
  language: string;
  strategy: string;
}

export class CodeCombinatorialGenerator {
  private dictionary: AtomDictionary;

  /**
   * 从代码 token 原子组合生成候选实现
   *
   * 同一个"读文件"意图:
   *   readFile(path) / fs.readFileSync(path) / await fs.promises.readFile(path)
   *   function read() {} / const read = () => {} / class FS { read() {} }
   *   try/catch / optional chaining / .catch()
   */
  generate(intent: string, language: string, context?: string): CodeCandidate[];
}
```

---

## Phase 3: 世界模型适配

### 3.1 场景图构建器

**修改文件**: `src/brain/right/features/assembly-world-bridge.ts`

当前 `fragmentsToScene()` 在片段级工作。需要改为在原子级工作：

```typescript
// 新增方法
atomsToScene(atoms: Atom[], query: string): SceneGraph {
  // 每个原子 → 一个节点
  // 原子之间的语义相似度 → 边
  // 原子与查询的相关度 → importance
}

// 修改 generateCandidates() — 从排列扰动改为原子组合
generateCandidates(atoms: Atom[], combinations: CandidateSentence[]): Array<{
  action: SceneAction;
  label: string;
}> {
  // 每个候选原子序列 → 一个 SceneAction
  // 不再是 5 个排列扰动，而是 N 个原子组合
}
```

### 3.2 世界模型不需要改

`SceneWorldModel.predict()` 和 `bestAction()` 接口不变：
- 输入：SceneGraph + SceneAction → 输出：下一 SceneGraph + completionProb + riskScore
- 它只管模拟，不理解语义，不评判好坏

`bestAction()` 的评分函数 `completionProb * 0.4 + (1-riskScore) * 0.3 + confidence * 0.3` **也不改**——这是模拟输出的综合指标，不是"文本质量"评分。

---

## Phase 4: 评判层 (Relevance Evaluator)

### 4.1 需求相关度评估器

**新建文件**: `src/brain/right/features/relevance-evaluator.ts`

```typescript
export interface RelevanceScore {
  /** 查询与候选的语义相似度 (ByteEncoder 余弦) */
  semanticSimilarity: number;
  /** 关键词重叠度 (FragmentExtractor 现有能力) */
  keywordOverlap: number;
  /** 意图匹配度 (候选是否回应了意图) */
  intentMatch: number;
  /** 综合相关度 (加权) */
  total: number;
}

export class RelevanceEvaluator {
  private byteEncoder: ByteEncoder;

  /**
   * 评估单个候选与用户需求的相关度
   */
  evaluate(
    query: string,
    queryVec: Float32Array,
    candidate: string,
    intent: string,
  ): RelevanceScore;

  /**
   * 批量评估 + 排序
   */
  rank(
    query: string,
    candidates: Array<{ text: string; atomIds: string[] }>,
    intent: string,
  ): Array<{ text: string; relevance: RelevanceScore }>;
}
```

**评判标准分解**:
- `semanticSimilarity`: `ByteEncoder(query) · ByteEncoder(candidate)` — 翻译官做语义对齐
- `keywordOverlap`: `FragmentExtractor` 已有能力，关键词重叠度
- `intentMatch`: 意图类别与候选内容的匹配（如 code_operations 意图 → 候选含代码关键词加分）

**权重**: `semanticSimilarity * 0.6 + keywordOverlap * 0.25 + intentMatch * 0.15`

### 4.2 EvolutionaryLoop 接入

**修改文件**: `src/brain/right/features/evolutionary-loop.ts`

当前 `EvolutionaryLoop` 只记录反馈。需要新增：

```typescript
/** 从历史成功模式中获取原子权重 */
getAtomWeights(): Map<string, number>;

/** 获取某个意图下的成功原子组合 */
getSuccessfulCombinations(intent: string, topK: number): string[][];
```

这给 `CombinatorialGenerator` 的策略 4（变异）提供方向：往成功过的原子组合方向变异。

---

## Phase 5: 串联 — 修改 InformationIntegrationEngine

### 5.1 修改 `processSingle()`

**修改文件**: `src/brain/right/features/integration-engine.ts`

当前流程:
```
检索 → ContentSelector → FragmentExtractor → DiscourseChain → assemble → 输出
```

改为:
```
检索 → ContentSelector → FragmentExtractor (保留，提取关键词)
  ↓
CombinatorialGenerator.generate(query, intent) → N 个候选
  ↓
prefilter (ByteEncoder 粗筛) → Top-K 候选
  ↓
SceneWorldModel.bestAction(scene, candidates) → 模拟排序
  ↓
RelevanceEvaluator.rank(query, candidates, intent) → 最终排序
  ↓
Top-1 输出
```

### 5.2 修改 `assemble()`

从"选 1 个骨架填片段"改为"从候选中选最相关的"：

```typescript
// 旧
private assemble(query, intent, fragments, complexity): string {
  const template = this.skeleton.selectSkeleton(intent, complexity);
  // ... 选 1 个骨架，填片段，返回
}

// 新
private assemble(query, intent, fragments, complexity): string {
  const queryVec = this.byteEncoder.forward(query);

  // 1. 组合生成
  const candidates = this.combinatorialGenerator.generate(query, intent);

  // 2. 世界模型模拟
  const scene = this.buildSceneFromFragments(fragments);
  const best = this.assemblyWorldBridge?.optimize(candidates, scene);

  // 3. 需求相关度择优
  const ranked = this.relevanceEvaluator.rank(query, candidates, intent);

  return ranked[0].text;
}
```

---

## Phase 6: 代码生成侧

### 6.1 修改 CodeTemplateStore

**修改文件**: `src/brain/right/features/code-templates.ts`

- 替换 `quickEmbed` 为 `ByteEncoder`（让代码模板做真正的语义检索）
- 扩展模板库：从 15 个到 100+ 个（自动从成功代码中学习）
- 新增 `generateCombinations()` 方法

### 6.2 代码生成流程

```
用户: "写一个读取文件的函数"
  ↓
ByteEncoder(query) → 128d
  ↓
CodeCombinatorialGenerator.generate('read_file', 'typescript')
  → 候选:
    function readFile(path: string): string { ... }
    const readFile = (path: string): string => { ... }
    async function readFile(path: string): Promise<string> { ... }
    class FileReader { read(path: string): string { ... } }
    import { readFileSync } from 'fs'; ...
    try { readFileSync(path, 'utf-8') } catch { ... }
    ...
  ↓
WorldModel 模拟每种候选的场景图变化
  ↓
RelevanceEvaluator: 哪个最能"读取文件"？
  ↓
Top-1 输出
```

---

## Phase 7: 反馈闭环

### 7.1 数据流

```
用户输入 → 生成 → 输出
                ↓
         用户反馈 (满意/不满意)
                ↓
         EvolutionaryLoop.record()
                ↓
         更新 AtomDictionary 原子权重
         更新 CombinatorialGenerator 生成策略
         更新 SceneWorldModel 训练数据
```

### 7.2 训练循环

```
每次交互后:
  1. EvolutionaryLoop.record(output, feedback, atomIds)
  2. 正反馈 → 提升相关原子的 successRate
  3. 负反馈 → 降低相关原子的 successRate
  4. CombinatorialGenerator 下次生成时优先选高 successRate 的原子
  5. 定期用积累的 (scene_before, action, scene_after) 训练 SceneWorldModel
```

---

## 实施顺序

| 阶段 | 文件 | 工作量 | 依赖 |
|------|------|--------|------|
| **P1** | `atom-dictionary.ts` (新建) | 中 | ByteEncoder |
| **P1** | `slot-template.ts` (新建) | 小 | MultiSentenceSkeleton |
| **P2** | `combinatorial-generator.ts` (新建) | 大 | P1 |
| **P2** | `code-combinatorial.ts` (新建) | 中 | P1, CodeTemplateStore |
| **P3** | `assembly-world-bridge.ts` (修改) | 中 | P2 |
| **P4** | `relevance-evaluator.ts` (新建) | 中 | ByteEncoder |
| **P4** | `evolutionary-loop.ts` (修改) | 小 | - |
| **P5** | `integration-engine.ts` (修改) | 大 | P2, P3, P4 |
| **P6** | `code-templates.ts` (修改) | 中 | ByteEncoder |
| **P7** | 反馈闭环 (修改) | 中 | 全部 |

**总计**: 4 个新文件，4 个修改文件，~3000 行代码

---

## 验证指标

| 指标 | 当前 | 目标 |
|------|------|------|
| 候选数量 | 1 (assemble) / 5 (world model) | 50-100 |
| 组合颗粒度 | 片段级 | 字/词/token 级 |
| 评判标准 | 无 / 多维混合 | 用户需求相关度 |
| 代码模板数 | 15 | 100+ |
| 代码变体数 | 1 | 10+ |
| 反馈闭环 | 记录但不接入生成 | 原子权重实时更新 |

---

## Phase 8: 扩展场景（后续）

Phase 1-7 覆盖文本生成和代码生成。以下场景用同一套架构扩展：

### 8.1 结构化数据生成

JSON/YAML/SQL/配置文件——颗粒度比自然语言更明确：

```
SQL:  SELECT {columns} FROM {table} WHERE {conditions} {order} {limit}
JSON: { "{key}": {value}, "{key}": {value} }
YAML: {key}: {value} / - {item}
```

- 字典: 字段名库 × 值类型库 × 操作符库 × 嵌套结构模板
- 组合: 同一个查询意图可以组装出十几种等价 SQL
- 择优: 执行计划模拟（EXPLAIN）= 世界模型，相关度 = 是否回答了查询意图

### 8.2 多语言混合生成

技术文档常见中英混杂场景：

- 字典: 中文字库 + 英文词库 + 技术术语库
- 组合: 中文句式中嵌入英文技术术语
- 择优: 术语准确度 + 语句通顺度

### 8.3 对话策略生成

多轮对话的话轮组合：

- 原子: 话轮类型（提问/回答/确认/补充/转折/总结）
- 组合: 话轮序列模板（Q→A→Confirm / A→Detail→Example）
- 择优: 对话连贯性 + 用户满意度历史

### 8.4 语音/TTS 输出

原子级韵律+停顿+语气组合：

- 原子: 韵律标记（重音/停顿/升降调/语速）
- 组合: 文本 × 韵律方案
- 择优: 自然度 + 情感匹配度

---

## 学术参考

### 高度贴合的研究

| 论文 | 年份 | 核心思想 | 与本项目的关系 |
|------|------|----------|---------------|
| **AlphaCode** (DeepMind) | 2022 | 百万级候选生成 + 测试用例过滤 + 择优 | 证明"生成弱+筛选强"可行 |
| **RPM-MCTS** (AAAI 2026) | 2025 | MCTS 树搜索 + 知识检索做中间步骤评估 | SceneWorldModel 就是中间状态模拟器 |
| **Iterative Self-Training for Reranking** (ECIR 2025) | 2025 | 13.4B reranker > 33B generator，快 3 倍 | 筛选能力 > 生成能力 |
| **WKM** (NeurIPS 2024) | 2024 | 世界模型提供全局先验 + 局部动态知识 | SceneWorldModel 的 bestAction() |
| **TWISTER** | 2025 | Transformer 世界模型 + 对比预测编码 | pretrain-encoder.ts 的 InfoNCE 对比学习 |
| **DreamerV3** | 2023 | 潜空间世界模型 + 想象规划 | 项目 WorldModel 的理论基础 |

### 关键洞察

> **AlphaCode 证明了一件事：生成能力可以弱，但筛选能力必须强。**

本方案比 AlphaCode 更激进——连候选生成都不依赖 LLM，纯靠字典排列组合。
代价是候选质量参差不齐，但筛选器够好时，这反而是优势：
候选空间更大，不被 LLM 的概率分布限制。

**本质：用搜索代替生成，用模拟代替推理，用相关度代替概率。**
