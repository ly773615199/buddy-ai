# BuddyLM 权重加载问题 — 深度分析报告

> 分析日期: 2026-05-27 | 状态: 持续排查中

## 一、问题概述

BuddyLM 模型加载 256d 预训练权重后输出乱码，置信度极低 (~0.07)。

## 二、架构演进时间线

| 日期 | 事件 | 维度 | 架构 |
|------|------|------|------|
| 5/19 | 启智平台 GPU 训练完成 (26950 steps, loss 18.3→1.34) | 128d | 无 CCA/MoE |
| 5/19 | `export_weights_lite.py` 导出单文件 decoder.weights.bin | 128d | grouped |
| 5/21 | PHASE0: +MoE +CCA (128d, 4层) | 128d | CCA+MoE |
| 5/25 | 激活 CCA+MoE 配置 | 128d | CCA+MoE |
| 5/26 | **引入 part1+part2 分片权重 (来自训练产出)** | 256d | CCA+MoE |
| 5/26 | decoder 配置同步: hiddenDim 128→256, numLayers 4→8 | 256d | CCA+MoE |
| 5/27 | 诊断: 467/531 顺序加载, 64 跳过 | — | — |

## 三、关键发现

### 3.1 Checkpoint 结构 (实测)

**总参数: 531 = 8 blocks × 66 + lmHead(3)**

每 block 66 参数，**全部为 interleaved 排列** (wq,bq,wk,bk,wv,bv,wo,bo,lnW,lnB):

```
Block[i]:
  [0-9]   selfAttn   interleaved: wq(65536),bq(256),wk(65536),bk(256),wv(65536),bv(256),wo(65536),bo(256),lnW(256),lnB(256)
  [10-19] CCA        interleaved: wq(65536),bq(256),wk(65536),bk(256),wv(65536),bv(256),wo(65536),bo(256),lnW(256),lnB(256)
  [20-29] crossAttn  interleaved: wq(65536),bq(256),wk(65536),bk(256),wv(65536),bv(256),wo(65536),bo(256),lnW(256),lnB(256)
  [30-31] MoE router: wGate(2048), bGate(8)
  [32-63] MoE experts: 8×(w1(262144),b1(1024),w2(262144),b2(256))
  [64-65] MoE lnW(256), lnB(256)

LMHead:
  [528] w(2097152=256×8192)  [529] lnW(256)  [530] lnB(256)
```

**CCA 层特征**: bias 全为 0, lnW 全为 1 → **CCA 未经训练** (保持随机初始化)

### 3.2 Model parameters() 排列

```
selfAttn:  wq,wk,wv,wo,bq,bk,bv,bo,lnW,lnB  → grouped
CCA:       wq,bq,wk,bk,wv,bv,wo,bo,lnW,lnB  → interleaved (与 checkpoint 一致!)
crossAttn: wq,wk,wv,wo,bq,bk,bv,bo,lnW,lnB  → grouped
MoE:       1:1 (一致)
lmHead:    1:1 (一致)
```

### 3.3 排列差异总结

| 层 | Checkpoint | Model | 需要重排? |
|----|-----------|-------|----------|
| selfAttn | interleaved | grouped | ✅ 需要 |
| CCA | interleaved | interleaved | ❌ 1:1 |
| crossAttn | interleaved | grouped | ✅ 需要 |
| MoE | — | — | ❌ 1:1 |
| lmHead | — | — | ❌ 1:1 |

### 3.4 映射表

```typescript
// interleaved → grouped (10 params)
// ckp: wq[0] bq[1] wk[2] bk[3] wv[4] bv[5] wo[6] bo[7] lnW[8] lnB[9]
// mdl: wq[0] wk[1] wv[2] wo[3] bq[4] bk[5] bv[6] bo[7] lnW[8] lnB[9]
const attnRemap = [0, 4, 1, 5, 2, 6, 3, 7, 8, 9];

// 每 block: selfAttn 用 attnRemap, CCA 1:1, crossAttn 用 attnRemap, MoE 1:1
```

## 四、当前状态

### 已实现

- `decoder.ts` `loadWeightsBinary()` 已改造:
  - 读取所有 checkpoint 参数到内存
  - 构建映射表 (selfAttn/crossAttn: interleaved→grouped, CCA/MoE/lmHead: 1:1)
  - 按映射加载
  - **531/531 参数全部加载成功** ✅

### 未解决

- **输出仍乱码** ❌ (置信度 ~0.07, 正常应 >0.3)
- `countParams()` 返回 NaN — 可能有参数被错误覆盖
- 可能存在的额外问题:
  1. **权重转置**: PyTorch `[out,in]` vs TS `[in,out]` — 256×256 方阵无法通过 shape 检测
  2. **训练管线差异**: 分片权重的来源可能不是 TS `exportWeightsBinary()`
  3. **模型 forward 逻辑变化**: 训练时的 forward 可能与当前不同

## 五、下一步

1. 检查 `countParams()` 返回 NaN 的原因
2. 验证是否需要 transpose (对比 checkpoint 和模型初始化的 wq 值)
3. 检查训练时的模型架构是否与当前一致
4. 考虑用旧 `decoder.weights.bin` (128d) + 当前模型 128d 配置做对照测试

## 六、涉及文件

- `src/brain/right/nn/decoder.ts` — `loadWeightsBinary()` (已修改)
- `src/brain/right/nn/__tests__/checkpoint-diag.test.ts` — 诊断测试
- `src/brain/right/nn/__tests__/buddylm-direct.test.ts` — E2E 推理测试
- `checkpoints/buddylm-pretrain/decoder_part1.weights.bin` (99MB)
- `checkpoints/buddylm-pretrain/decoder_part2.weights.bin` (68MB)
- `scripts/export_weights_lite.py` — 旧导出脚本 (128d, grouped)
- `scripts/unified-pretrain.ts` — 训练脚本
