# 细粒度意图层 — 详细执行计划

> 基于 ByteEncoder 语义理解能力，为三脑决策系统提供精准的工具路由信号

## 进度概览 (2026-06-07)

| Phase | 状态 | 完成度 | 说明 |
|-------|------|--------|------|
| Phase 1: 基础框架 | ✅ 已完成 | 100% | 核心类 + 种子库 + LRU缓存 + 测试, 30/30 通过 |
| Phase 2: 系统集成 | ✅ 已完成 | 100% | perceptor / brain / subsystems 全部接入 |
| Phase 3: 在线学习 | ✅ 已完成 | 100% | addSeed 钩子 + 持久化 + 衰减 + flush + 缓存失效 |
| Phase 4: 评估调优 | ✅ 已完成 | 100% | 评估数据集 + 阈值调优 + 性能基准 + LRU缓存命中 |

## 1. 定位

### 是什么

细粒度意图层是一个**辅助感知模块**，位于 Perceptor（感知器）和 RuleEngine（规则引擎）之间，消费 ByteEncoder 的语义向量输出，为三脑决策系统提供更精确的任务分类信号。

### 不是什么

- **不是决策层** — 不决定如何执行任务，只告诉三脑"这个任务是什么"
- **不是 LLM 替代** — 处理不了的输入会 fallback 到三脑/LLM
- **不是独立系统** — 是右脑 ByteEncoder 能力的一个消费者

### 与现有组件的关系

```
ByteEncoder (感知基座, 已有)
  ↓ 256维语义向量
┌─────────────────────────────────────┐
│ 细粒度意图层 (新增)                  │
│ 消费 ByteEncoder 向量               │
│ 输出: { intent, tool, score, args } │
└──────────────┬──────────────────────┘
               ↓ 信号
┌─────────────────────────────────────┐
│ 三脑决策系统 (已有)                  │
│ RuleEngine / Scheduler / ThreeBrain │
│ 根据信号 + 资源状态 → 决策方案       │
└─────────────────────────────────────┘
```

## 2. 核心设计

### 2.1 混合匹配策略

纯语义向量匹配存在两个问题：
- **语义漂移**: ByteEncoder 学到的是通用文本相似度，不是意图相似度
  - "帮我写代码" vs "广州天气" 余弦相似度 0.54（不应这么高）
- **语义遗漏**: 间接表达的语义距离太远
  - "需要带伞吗" vs "天气查询" 余弦相似度 0.47（应命中天气）

解法：**语义粗筛 + 关键词精排**

```
score = semanticScore × 0.4         (质心余弦)
      + nearestScore × 0.6          (最近邻余弦)
      + keywordBoost                 (关键词加分)
      + excludePenalty               (排除词减分)
```

### 2.2 意图定义结构

```typescript
interface IntentDefinition {
  /** 意图名称 */
  name: string;
  /** 对应工具名 */
  tool: string;
  /** 参数提取策略 */
  argExtractor: ArgExtractor;
  /** 语义种子语料 (10-20句) */
  seeds: string[];
  /** 关键词增强规则 */
  keywordBoosts: KeywordBoost[];
  /** 排除词规则 */
  excludes: ExcludeRule[];
  /** 匹配阈值 */
  threshold: number;
}

interface KeywordBoost {
  pattern: RegExp;
  boost: number;       // 正值 = 加分
}

interface ExcludeRule {
  pattern: RegExp;
  penalty: number;     // 负值 = 降权
}

type ArgExtractor = (input: string) => Record<string, unknown>;
```

### 2.3 初始意图种子库

| 意图 | 工具 | 种子数 | 关键词增强 | 排除词 |
|------|------|--------|-----------|--------|
| weather | skill_weather | 20 | 天气/气温/雨/雪/台风/伞/穿/湿度/紫外线 | 搜索/搜/百度/google |
| time | get_time | 10 | 几点/时间/日期/星期 | — |
| search | search_web | 12 | 搜索/搜/百度/google/查找 | 天气/气温 |
| file_read | read_file | 10 | 文件/file/读取/打开 | — |
| file_write | write_file | 8 | 写入/创建/保存/write | — |
| git_status | git_status | 8 | git/状态/status/提交 | — |
| exec | exec | 10 | 执行/运行/run/命令 | — |
| web_fetch | fetch_url | 8 | 抓取/爬取/fetch/访问网页 | — |

## 3. 架构设计

### 3.1 模块结构

```
src/brain/right/features/
├── text-encoder.ts          ← ByteEncoder (已有)
├── semantic-intent-index.ts ← 新增: 混合意图索引核心
├── intent-seeds.ts          ← 新增: 种子语料库定义
└── arg-extractor.ts         ← 新增: 参数提取器
```

### 3.2 SemanticIntentIndex 类

```typescript
// src/brain/right/features/semantic-intent-index.ts

export interface IntentMatch {
  intent: string;
  tool: string;
  score: number;
  semanticScore: number;
  nearestScore: number;
  args: Record<string, unknown>;
  confidence: number;       // 归一化到 0-1
}

export class SemanticIntentIndex {
  private encoder: ByteEncoder;
  private intents: Map<string, CompiledIntent>;
  private cache: LRUCache<string, IntentMatch[]>;

  constructor(encoder: ByteEncoder) { ... }

  /**
   * 注册意图定义
   */
  register(intent: IntentDefinition): void { ... }

  /**
   * 批量注册
   */
  registerAll(intents: IntentDefinition[]): void { ... }

  /**
   * 构建索引 (编码所有种子, 计算质心)
   * 调用时机: 启动时 + 种子更新时
   */
  build(): void { ... }

  /**
   * 查询输入 → 排序后的意图匹配列表
   * 调用时机: 每次用户输入
   * 性能目标: < 5ms (ByteEncoder 前向 + 向量比较)
   */
  match(input: string): IntentMatch[] { ... }

  /**
   * 查询输入 → 最佳匹配 (score >= threshold) 或 null
   */
  matchBest(input: string, threshold?: number): IntentMatch | null { ... }

  /**
   * 动态添加种子 (在线学习)
   * 三脑执行成功后, 将 input→tool 映射加入种子库
   */
  addSeed(intent: string, input: string): void { ... }

  /**
   * 统计信息
   */
  stats(): { intents: number; totalSeeds: number; cacheHitRate: number };
}
```

### 3.3 参数提取器

```typescript
// src/brain/right/features/arg-extractor.ts

/**
 * 参数提取策略:
 * 1. 正则提取 (城市、文件路径等结构化参数)
 * 2. 语义提取 (ByteEncoder 编码关键词, 与参数模板匹配)
 * 3. 默认值 (兜底)
 */

// 天气意图: 提取城市名
const weatherExtractor: ArgExtractor = (input) => {
  // 1. 已知城市列表匹配
  const city = matchKnownCity(input);
  if (city) return { city };

  // 2. 正则提取 "XX天气" 中的 XX
  const match = input.match(/([\u4e00-\u9fa5]{2,4})(?:的|今天|明天)?(?:天气|温度|气温)/);
  if (match) return { city: match[1] };

  // 3. 默认
  return { city: '北京' };
};

// 时间意图: 无参数
const timeExtractor: ArgExtractor = () => ({});

// 搜索意图: query = 输入原文
const searchExtractor: ArgExtractor = (input) => ({ query: input });

// 文件读取: 提取文件路径
const fileReadExtractor: ArgExtractor = (input) => {
  const pathMatch = input.match(/([\w/\\.-]+\.\w{1,5})/);
  return pathMatch ? { path: pathMatch[1] } : {};
};
```

### 3.4 与 Perceptor 的集成

```typescript
// src/core/perceptor.ts — 修改 perceive() 方法

perceive(content: string, context?): PerceptionState {
  // ... 现有逻辑 ...

  // 新增: 细粒度意图识别
  const intentMatch = this.semanticIntentIndex.matchBest(content);

  return {
    ...state,
    // 新增字段
    fineIntent: intentMatch ? {
      intent: intentMatch.intent,
      tool: intentMatch.tool,
      score: intentMatch.score,
      args: intentMatch.args,
    } : null,
  };
}
```

### 3.5 与 ThreeBrain 的集成

```typescript
// src/brain/brain.ts — 修改 decide() 方法

decide(signal, resources, bodyState) {
  // ① 现有: 法则引擎
  const executableRule = this.left.evaluateExecutableRule(signal, ...);

  // ② 新增: 细粒度意图快路径
  if (!executableRule && signal.fineIntent?.score >= 0.5) {
    const { tool, args, score } = signal.fineIntent;

    // 三脑仍然参与决策: 检查资源、权限、状态
    const canExecute = this.checkResources(tool, resources)
                    && this.checkPermission(tool, bodyState)
                    && score >= this.getThreshold(tool);

    if (canExecute) {
      // 三脑决策通过, 生成执行计划
      return {
        mode: 'local_only',
        reason: `细粒度意图匹配: ${signal.fineIntent.intent} (${score.toFixed(2)})`,
        executablePlan: {
          steps: [{ id: 'step_1', type: 'tool_call', tool, args }],
          confidence: score,
          source: 'semantic_intent',
          needsCloudEnhancement: false,
        },
      };
    }
    // 资源不足或权限不够, 继续走完整决策流程
  }

  // ③ 现有: 语义路由 fallback
  const capResult = this.capabilityFallback.tryRoute(...);

  // ④ 现有: 三脑协作
  return this.fullDecision(signal, resources, bodyState);
}
```

## 4. 执行步骤

### Phase 1: 基础框架 ✅ 已完成

- [x] 创建 `src/brain/right/features/semantic-intent-index.ts` (710 行)
  - SemanticIntentIndex 类核心实现
  - 混合匹配算法 (质心 + 最近邻 + 关键词 + 排除)
  - **LRU 缓存** (256 条, 命中时跳过 ByteEncoder 编码)
  - 持久化: create() 工厂方法 / loadFromDisk() / saveToDisk() / flush()
  - 原子写入 (tmp + rename), 节流保存 (5s), 版本校验
  - 缓存失效: addSeed / rebuild / decay 时自动清空
- [x] 创建 `src/brain/right/features/intent-seeds.ts` (550+ 行)
  - 8 个意图, **364 条种子** (原 82 条, +344%)
  - 三层种子结构: 核心★ / 泛化~ / 长尾…
  - 参数提取器内联实现 (天气城市/文件路径/命令/URL)
  - 关键词增强规则 8 组, 排除词规则 7 组
- [x] ~~创建 `src/brain/right/features/arg-extractor.ts`~~ → 合并入 intent-seeds.ts
  - 参数提取器接口
  - 天气/时间/搜索/文件/命令/URL 的具体实现
- [x] 单元测试: `src/brain/right/features/__tests__/semantic-intent-index.test.ts`
  - 30 个测试全部通过
  - 覆盖: 构建/天气/时间/搜索/文件/排除词/排序/在线学习/统计/性能/LRU缓存/种子衰减/全局排除/confidence/参数提取

### Phase 2: 系统集成 ✅ 已完成

- [x] 修改 `src/core/perceptor.ts`
  - perceive() 中调用 SemanticIntentIndex
  - PerceptionState 新增 fineIntent 字段
- [x] 修改 `src/core/perception-state.ts`
  - 新增 FineIntent 类型定义
- [x] 修改 `src/brain/brain.ts`
  - decide() 中新增细粒度意图快路径
  - 资源检查 + 权限检查集成
- [x] 修改 `src/core/subsystems.ts`
  - 初始化 SemanticIntentIndex.create()
  - 注入 ByteEncoder 实例

### Phase 3: 在线学习 ✅ 已完成

- [x] 实现 addSeed() 方法
  - 三脑执行成功后, 将 input→tool 映射加入种子库
  - 增量更新质心向量 (EMA, 学习率 0.1)
  - 去重: 余弦 > 0.95 的种子自动跳过
- [x] 种子持久化
  - 保存到 `~/.buddy/intent-seeds.json`
  - 原子写入 (tmp + rename 防崩溃损坏)
  - 节流保存 (5s 间隔, 防高频 IO)
  - 启动时自动加载 (create() 工厂方法)
  - 版本号: version: 1 (预留格式升级)
- [x] 种子衰减
  - 每条种子记录最后访问时间 (seedAccessTimes)
  - decay() 移除 30 天未访问的种子
  - 每意图上限 200 条, 超限按访问时间淘汰
  - match() 命中时自动更新访问时间
- [x] 钩子接入
  - brain.ts fineIntent 执行成功后调用 addSeed()
  - agent.ts shutdown 前调用 flush()

### Phase 4: 评估与调优 ✅ 已完成

- [x] 构建评估数据集
  - 8 意图 × 113 条测试语料
  - 每意图包含 direct/indirect/english/negative 四类
  - 含 19 条通用 negative (不应命中任何意图)
- [x] 阈值调优
  - 统一阈值 0.65 (从 0.50-0.60 上调)
  - 新增全局排除规则 (教程/原理/代码生成类)
  - 各意图增加通用闲聊排除词
- [x] 性能基准
  - match() 平均延迟 < 5ms ✅
  - matchBest() 平均延迟 < 5ms ✅
  - addSeed() 平均延迟 < 60ms (含 ByteEncoder.forward())
  - decay() 平均延迟 < 100ms ✅
- [x] 评估结果
  - direct 准确率: 90%+ ✅
  - indirect 准确率: 60%+ ✅
  - english 准确率: 40%+ ✅
  - negative 准确率: 84% ✅
  - 总体准确率: 81.4%
  - 误匹配率: 15.8% (含教程/原理类 hard case)

## 5. 性能预算

| 环节 | 耗时目标 | 说明 |
|------|----------|------|
| ByteEncoder.forward() | < 3ms | 预训练权重, CPU 推理 |
| **LRU 缓存命中** | **< 0.01ms** | **重复查询跳过编码+向量比较** |
| 质心余弦 × 8 意图 | < 0.1ms | 256维 × 8 = 2048 次乘法 |
| 最近邻 × 364 种子 | < 1ms | 256维 × 364 = 93184 次乘法 |
| 关键词匹配 | < 0.1ms | 8 × 5 = 40 次正则 |
| 参数提取 | < 0.2ms | 1-2 次正则 |
| **总计 (无缓存)** | **< 5ms** | 比 LLM 调用快 400 倍 |
| **总计 (有缓存)** | **< 0.1ms** | **缓存命中时 50 倍加速** |

## 6. 风险与对策

| 风险 | 影响 | 对策 |
|------|------|------|
| ByteEncoder 语义漂移 | 误匹配 | 关键词精排兜底, 阈值调优 |
| 种子库冷启动 | 覆盖不足 | 初始 8 意图 × 45 种子 (364条), 在线学习扩展, 持久化跨会话积累 |
| 阈值过高 | 漏匹配 | 分意图设阈值, fallback 到规则引擎 |
| 阈值过低 | 误匹配 | 排除词降权, 三脑资源检查兜底 |
| 新意图出现 | 无法处理 | addSeed() 在线学习, fallback 到 LLM |
| 性能退化 | 响应变慢 | LRU 缓存 (256条), 种子数量上限, 增量更新 |

## 7. 成功指标

| 指标 | 基线 (纯规则) | 目标 (混合意图) |
|------|--------------|----------------|
| 天气查询成功率 | 40% (正则覆盖) | 85% |
| "今天热不热" 命中率 | 0% | 80% |
| "需要带伞吗" 命中率 | 0% | 70% |
| 英文天气查询 | 0% | 60% |
| 误匹配率 | N/A | < 5% |
| 平均路由延迟 | < 1ms (规则) | < 5ms (语义) |
| LLM 调用减少 | 基线 | -30% |

## 8. 文件清单

```
新增 (Phase 1 + Phase 4):
  src/brain/right/features/semantic-intent-index.ts  — 核心类 + LRU缓存 + 持久化 + 衰减 + 全局排除 (710 行)
  src/brain/right/features/intent-seeds.ts           — 8意图 368种子 + 参数提取器 + 阈值调优 (468 行)
  src/brain/right/features/__tests__/semantic-intent-index.test.ts — 30 个单元测试 (341 行)
  src/brain/right/features/__tests__/eval-dataset.ts — 114 条评估数据集 (190 行)
  src/brain/right/features/__tests__/semantic-intent-eval.test.ts — 13 个评估+性能+缓存测试 (277 行)
  FINE_GRAINED_INTENT_PLAN.md (本文件)

已修改 (Phase 2 + Phase 3):
  src/core/perception-state.ts   — 新增 FineIntent 类型定义
  src/core/perceptor.ts          — perceive() 集成 SemanticIntentIndex
  src/brain/brain.ts             — decide() 快路径 + addSeed 在线学习钩子
  src/core/subsystems.ts         — 初始化 SemanticIntentIndex.create()
  src/core/agent.ts              — shutdown 前 flush() (已有)

运行时生成:
  ~/.buddy/intent-seeds.json     — 已学习种子持久化文件 (自动创建)
```
