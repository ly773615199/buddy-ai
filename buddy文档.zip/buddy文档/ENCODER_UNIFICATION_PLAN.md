# 语义编码器统一架构方案

## 1. 现状分析

### 1.1 编码器矩阵

| 编码器 | 维度 | 训练状态 | 用途 | 实例管理 |
|--------|------|----------|------|----------|
| ByteEncoder | 256d | ✅ 离线预训练(code pairs 54MB) + ✅ 在线增量 | 核心文本编码 | 单例(getByteEncoder) + 4处fallback new |
| ProjectionHead | 256→128d | ✅ InfoNCE(362KB 同义对) | 通用语义增强 | 独立加载 |
| KGEmbedder | 256d | ✅ 在线 TransE | 知识图谱实体嵌入 | 独立实例，与ByteEncoder无关联 |
| VisionEncoder | 256d | ❓ | 图像理解 | IntuitionNet内部创建 |
| AudioEncoder | 256d | ❓ | 音频理解 | IntuitionNet内部创建 |
| SceneEncoder | token IDs | 规则编码 | 场景图编码 | 无状态函数 |
| SpatialEncoder | token IDs | 规则编码 | 空间坐标编码 | 无状态函数 |
| BBPE Embedding | 128d | ❌ 缺预训练 | BuddyLM Decoder | 独立实例 |

### 1.2 问题清单

**P0: 实例泄漏**
- DreamEngine.initCondenser() → `new ByteEncoder()` 独立实例
- DreamEngine.setLLMCaller() → `new KnowledgeCondenser(new ByteEncoder(), ...)` 独立实例
- atom-dictionary/outline-generator/text-pipeline/integration-engine → fallback `new ByteEncoder()`
- 各实例有独立LRU缓存、独立权重副本，内存浪费

**P1: 向量空间不互通**
- 5个编码器输出都是256d，但各自独立训练，语义空间不对齐
- "天气"在ByteEncoder空间的向量 ≠ KGEmbedder空间的"天气"实体向量
- KnowledgeGate做注意力交互时，query和key来自不同空间，无意义

**P2: 训练信号不共享**
- ByteEncoder ← contrastive loss (code pairs)
- KGEmbedder ← TransE margin loss (triplets)
- ProjectionHead ← InfoNCE (synonym pairs)
- 梯度不互通，backbone学不到知识图谱和多模态的语义信号

**P3: 缺预训练**
- ByteEncoder预训练数据是code pairs，中文自然语言区分度弱
- ProjectionHead训练数据仅362KB，不足以覆盖中文细粒度语义
- BBPE缺大规模中文语料的BPE合并规则训练

---

## 2. 目标架构

### 2.1 核心原则

**一个共享语义空间，多个模态入口。**

```
不是：5个编码器 → 5个独立空间 → 下游硬融合
而是：1个语义空间 → 多个模态投影器 → 天然对齐
```

### 2.2 架构图

```
┌─────────────────────────────────────────────────────────────┐
│                   Shared Semantic Space (256d)               │
│                                                              │
│   ByteEncoder (backbone, 唯一文本语义源)                      │
│     UTF-8 bytes → byteEmbedding → EncoderBlock×4 → Pool      │
│                                                              │
│   ProjectionHead (可选增强, 256→128d)                         │
│     通用语义场景使用，InfoNCE训练                               │
└──────────────────────────┬──────────────────────────────────┘
                           │
        ┌──────────────────┼──────────────────┐
        │                  │                  │
  ┌─────┴──────┐    ┌──────┴──────┐    ┌──────┴──────┐
  │ Text Path  │    │ Vision Path │    │ Audio Path  │
  │            │    │             │    │             │
  │ UTF-8 bytes│    │ Patch前端   │    │ Mel前端     │
  │ → backbone │    │ → 对齐投影  │    │ → 对齐投影  │
  │ → 256d     │    │ → 256d      │    │ → 256d      │
  └────────────┘    └─────────────┘    └─────────────┘
                           │
                    ┌──────┴──────┐
                    │ KGEmbedder  │
                    │             │
                    │ 实体初始化:  │
                    │ ByteEncoder │
                    │ (name+desc) │
                    │ TransE:     │
                    │ 关系偏移学习 │
                    └─────────────┘
```

### 2.3 训练信号统一

```
统一 loss = L_text + λ₁·L_kg + λ₂·L_align + λ₃·L_projection

L_text:       ByteEncoder自身对比学习（保留）
L_kg:         TransE loss，梯度回传到ByteEncoder（知识增强文本表示）
L_align:      模态对齐loss（Vision/Audio → 共享空间）
L_projection: ProjectionHead InfoNCE（保留）
```

---

## 3. 实施计划

### P0: 统一ByteEncoder实例管理

**目标**：消灭所有散落的 `new ByteEncoder()`，统一依赖注入。

**改动清单**：

| 文件 | 改动 |
|------|------|
| `src/memory/dream.ts` | DreamEngine 接受注入的 ByteEncoder，不再自己 new |
| `src/brain/right/features/atom-dictionary.ts` | 构造函数必须传入 encoder，去掉 fallback |
| `src/brain/right/features/outline-generator.ts` | 同上 |
| `src/brain/right/features/text-pipeline.ts` | 同上 |
| `src/brain/right/features/integration-engine.ts` | 同上 |
| `src/core/subsystems.ts` | 初始化时注入 rightBrain.byteEncoder 到所有组件 |

**验证**：
- 运行时只有1个ByteEncoder实例
- 所有组件共享同一个LRU缓存
- 内存占用降低

### P1: KGEmbedder 对齐到共享空间

**目标**：KG实体嵌入初始化用ByteEncoder，TransE只学关系偏移。

**改动清单**：

| 文件 | 改动 |
|------|------|
| `src/brain/right/features/kg-embedder.ts` | 构造函数接受ByteEncoder；实体首次嵌入用encoder.forward(name+desc)初始化；TransE训练时冻结entity embedding只训练relation |
| `src/brain/right/features/knowledge-graph.ts` | 传递ByteEncoder到KGEmbedder |
| `src/brain/right/index.ts` | 传递byteEncoder到KnowledgeGraph/KGEmbedder |

### P2: 语料共享 + ProjectionHead接入

**已完成**：
- `intent-sync.ts`：SemanticIntentIndex种子→CapabilityRouter utterance注入
- `semantic-intent-index.ts`：ProjectionHead接入（128d通用语义路径）
- `subsystems.ts`：启动时加载ProjectionHead + 调用syncOnStartup

### P3: 多模态对齐 + 统一训练（后续）

- VisionEncoder/AudioEncoder对齐到ByteEncoder空间
- 统一训练循环，跨模态梯度共享
- 扩展ProjectionHead训练数据

---

## 4. 编码器实例注册表（P0实现）

引入 `EncoderRegistry`，集中管理所有编码器实例的生命周期。

```typescript
// src/brain/right/features/encoder-registry.ts
export class EncoderRegistry {
  private static instance: EncoderRegistry | null = null;
  private byteEncoder: ByteEncoder | null = null;
  private projectionHead: ProjectionHead | null = null;

  static getInstance(): EncoderRegistry { ... }
  getByteEncoder(): ByteEncoder { ... }
  getProjectionHead(): ProjectionHead | null { ... }
  setProjectionHead(head: ProjectionHead): void { ... }
}
```

所有组件通过 `EncoderRegistry.getInstance().getByteEncoder()` 获取实例，不再自行创建。
