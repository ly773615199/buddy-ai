# ResourceHub 资源画像系统修复计划

> 生成时间: 2026-06-06
> 基于: 代码深度分析发现的注册/反馈/状态同步断联问题

## 问题总览

ResourceHub 设计为"资源智能中心"，但实际运行中与多个子系统存在断联：

| # | 问题 | 影响范围 | 严重度 |
|---|------|---------|:------:|
| 1 | ModelPool ↔ ResourceHub 完全断联 | cloud_llm 画像失效 | 🔴 Critical |
| 2 | CloudLLMExecutor 吞掉错误 | 三脑无法感知 LLM 失败原因 | 🔴 Critical |
| 3 | cloudModelId 从未被设置 | ResourceHub 画像记到错误模型 | 🔴 Critical |
| 4 | 工具反馈使用整体成功而非逐工具 | 工具画像被污染 | 🟡 High |
| 5 | 知识源无 feedback | knowledge 画像是死的 | 🟡 High |
| 6 | 平台/TTS 无 feedback | system 画像是死的 | 🟡 Medium |
| 7 | 未知资源自动注册类型错误 | engine 被注册为 tool | 🟡 Medium |
| 8 | 资源能力不更新（成长/断连） | 画像过时 | 🟡 Medium |
| 9 | MCP 工具异步注册时序问题 | 启动时可能漏同步 | 🟠 Low |
| 10 | feedToolHealth 覆盖式更新 | 丢失 bandit 历史学习 | 🟠 Low |

---

## Phase 1: ModelPool ↔ ResourceHub 同步桥 (Critical)

### 1.1 创建 ModelPoolResourceBridge

**文件**: `src/brain/hub/model-pool-sync.ts` (新建)

```typescript
/**
 * ModelPoolResourceBridge — ModelPool ↔ ResourceHub 双向同步桥
 *
 * 解决: ModelPool 激活/去激活/发现/状态变更时，ResourceHub 不知道。
 *
 * 职责:
 * 1. ModelPool → ResourceHub: 模型激活/去激活/发现/访问状态变更时同步
 * 2. ResourceHub → ModelPool: 执行反馈回流到 ModelPool stats
 * 3. 定时对账: 心跳时检查两边状态一致性
 */
export class ModelPoolResourceBridge {
  private pool: ModelPool;
  private hub: ResourceHub;
  private verbose: boolean;

  constructor(pool: ModelPool, hub: ResourceHub, verbose?: boolean) {
    this.pool = pool;
    this.hub = hub;
    this.verbose = verbose ?? false;
  }

  /**
   * 全量同步 — 启动时调用一次
   * 将 ModelPool 中所有 active 模型注册到 ResourceHub
   */
  fullSync(): void {
    const profiles = this.pool.getAllProfiles();
    let registered = 0;
    let skipped = 0;

    for (const profile of profiles) {
      if (profile.active === false) {
        // 去激活的模型: 如果 ResourceHub 中有，标记为 dormant
        this.deactivateInHub(profile);
        skipped++;
        continue;
      }
      this.syncProfileToHub(profile);
      registered++;
    }

    if (this.verbose) {
      console.log(`[ModelPoolSync] 全量同步: ${registered} 注册, ${skipped} 跳过`);
    }
  }

  /**
   * 单个模型同步到 ResourceHub
   */
  syncProfileToHub(profile: ModelProfile): void {
    const id = this.toResourceHubId(profile);

    // 映射 accessStatus → ResourceHub status
    const status = this.mapAccessStatus(profile);

    this.hub.register({
      id,
      type: 'cloud_llm',
      name: profile.displayName,
      capabilities: {
        type: 'cloud_llm',
        provider: profile.platform,
        model: profile.id,
        supportsTools: profile.capabilities.toolCalling,
        supportsStreaming: profile.capabilities.streaming,
        maxContextTokens: profile.maxContextTokens,
        maxOutputTokens: profile.maxOutputTokens,
        strengths: this.inferStrengths(profile),
        weaknesses: this.inferWeaknesses(profile),
        costPer1kInput: profile.costPer1kInput,
        costPer1kOutput: profile.costPer1kOutput,
      },
    });

    // 如果有访问状态，同步到 ResourceHub
    if (profile.accessStatus === 'denied' || profile.accessStatus === 'broken') {
      const entry = this.hub.getProfile(id);
      if (entry) {
        entry.status = 'unavailable';
      }
    }
  }

  /**
   * 模型去激活 → ResourceHub 标记 dormant
   */
  deactivateInHub(profile: ModelProfile): void {
    const id = this.toResourceHubId(profile);
    const entry = this.hub.getProfile(id);
    if (entry) {
      this.hub.markForCleanup(id);
    }
  }

  /**
   * 模型注销 → ResourceHub 注销
   */
  removeFromHub(profileId: string): void {
    // profileId 格式: 'platform/model-name'
    const hubId = `cloud_llm:${profileId}`;
    this.hub.unregister(hubId);
  }

  /**
   * 访问状态变更同步
   * 当 ModelPool.recordAccessFailure/Success 时调用
   */
  syncAccessStatus(modelId: string): void {
    const profile = this.pool.getProfile(modelId);
    if (!profile) return;

    const id = this.toResourceHubId(profile);
    const entry = this.hub.getProfile(id);
    if (!entry) return;

    const newStatus = this.mapAccessStatus(profile);
    if (entry.status !== newStatus) {
      const oldStatus = entry.status;
      entry.status = newStatus;
      if (this.verbose) {
        console.log(`[ModelPoolSync] ${id} 状态: ${oldStatus} → ${newStatus}`);
      }
    }
  }

  /**
   * ResourceHub 执行反馈回流到 ModelPool
   * 当 brain.ts feedback() 记录 cloud_llm 结果时调用
   */
  feedbackToPool(
    resourceHubId: string,
    outcome: { success: boolean; qualityScore: number; latencyMs: number; costEstimate?: number; scenario?: string },
  ): void {
    // 从 ResourceHub ID 反推 ModelPool ID
    // resourceHubId 格式: 'cloud_llm:platform/model-name'
    const modelId = resourceHubId.replace(/^cloud_llm:/, '');
    const profile = this.pool.getProfile(modelId);
    if (!profile) return;

    // 回流到 ModelPool 的 Thompson Sampling
    const taskType = (outcome.scenario ?? 'chat') as import('../../core/model-router.js').TaskType;
    this.pool.recordFeedback(
      modelId,
      taskType,
      outcome.success,
      outcome.latencyMs,
      outcome.costEstimate ?? 0,
      outcome.qualityScore,
    );
  }

  /**
   * 心跳对账 — 定期检查两边状态一致性
   */
  reconcile(): void {
    const profiles = this.pool.getAllProfiles();
    for (const profile of profiles) {
      const hubId = this.toResourceHubId(profile);
      const hubEntry = this.hub.getProfile(hubId);

      // ModelPool 中有但 ResourceHub 中没有 → 注册
      if (!hubEntry && profile.active !== false) {
        this.syncProfileToHub(profile);
        continue;
      }

      // ModelPool 中去激活但 ResourceHub 中还是 active → 标记 dormant
      if (profile.active === false && hubEntry && hubEntry.status === 'active') {
        this.deactivateInHub(profile);
      }

      // 访问状态不同步 → 同步
      if (hubEntry) {
        const expected = this.mapAccessStatus(profile);
        if (hubEntry.status !== expected && hubEntry.status !== 'dormant') {
          hubEntry.status = expected;
        }
      }
    }

    // ResourceHub 中有 cloud_llm 但 ModelPool 中没有 → 标记 dormant
    const hubCloudLLMs = this.hub.getByType('cloud_llm');
    for (const entry of hubCloudLLMs) {
      const modelId = entry.id.replace(/^cloud_llm:/, '');
      if (!this.pool.getProfile(modelId)) {
        this.hub.markForCleanup(entry.id);
      }
    }
  }

  // ==================== 内部工具 ====================

  private toResourceHubId(profile: ModelProfile): string {
    // ModelProfile.id: 'platform/model-name'
    // ResourceHub id: 'cloud_llm:platform/model-name'
    return `cloud_llm:${profile.id}`;
  }

  private mapAccessStatus(profile: ModelProfile): import('./resource-hub.js').ResourceStatus {
    switch (profile.accessStatus) {
      case 'denied':
      case 'broken':
        return 'unavailable';
      case 'available':
        return 'active';
      default:
        // unknown: 如果有历史成功记录，标记 active
        if (profile.stats.successes > 0) return 'active';
        return 'registering';
    }
  }

  private inferStrengths(profile: ModelProfile): string[] {
    const strengths: string[] = [];
    if (profile.capabilities.reasoning > 0.7) strengths.push('reasoning');
    if (profile.capabilities.code > 0.7) strengths.push('code');
    if (profile.capabilities.chinese > 0.7) strengths.push('chinese');
    if (profile.capabilities.creative > 0.7) strengths.push('creative');
    if (profile.capabilities.toolCallingMode === 'native') strengths.push('native_tool_calling');
    if (profile.tier === 'free') strengths.push('free');
    return strengths;
  }

  private inferWeaknesses(profile: ModelProfile): string[] {
    const weaknesses: string[] = [];
    if (profile.capabilities.reasoning < 0.4) weaknesses.push('weak_reasoning');
    if (profile.capabilities.code < 0.4) weaknesses.push('weak_code');
    if (!profile.capabilities.toolCalling) weaknesses.push('no_tool_calling');
    if (!profile.capabilities.vision) weaknesses.push('no_vision');
    if (profile.stats.totalCalls > 0) {
      const successRate = profile.stats.successes / profile.stats.totalCalls;
      if (successRate < 0.5) weaknesses.push('low_reliability');
    }
    return weaknesses;
  }
}
```

### 1.2 集成到 Subsystems 初始化

**文件**: `src/core/subsystems.ts`

在 ModelPool 初始化完成后、ResourceHub scanAndRegister 之后，创建 Bridge 并执行全量同步：

```typescript
// 在 initializeFromProviders 完成后
const bridge = new ModelPoolResourceBridge(pool, threeBrain.resourceHub, verbose);
bridge.fullSync();

// 注入到 brain.ts 供 feedback 使用
threeBrain.setModelPoolBridge(bridge);
```

### 1.3 集成到 ModelPool 状态变更

**文件**: `src/core/model-pool.ts`

在以下方法中添加 Bridge 回调：

```typescript
// ModelPool 新增 bridge 回调
private bridgeCallback: ((modelId: string, action: string) => void) | null = null;

setBridgeCallback(cb: (modelId: string, action: string) => void): void {
  this.bridgeCallback = cb;
}

// 在 setActive / toggleActive / recordAccessFailure / recordAccessSuccess 中调用
setActive(id: string, active: boolean): boolean {
  const profile = this.profiles.get(id);
  if (!profile) return false;
  profile.active = active;
  this.saveUnifiedState();
  this.bridgeCallback?.(id, active ? 'activate' : 'deactivate');  // ← 新增
  return true;
}

recordAccessFailure(modelId: string, errorType: ModelAccessErrorType): void {
  // ... 现有逻辑 ...
  this.bridgeCallback?.(modelId, 'access_status_change');  // ← 新增
}

recordAccessSuccess(modelId: string): void {
  // ... 现有逻辑 ...
  this.bridgeCallback?.(modelId, 'access_status_change');  // ← 新增
}
```

### 1.4 集成到 REST API

**文件**: `src/core/rest-api.ts`

toggle/batch-toggle/refresh 端点中，操作 ModelPool 后触发 Bridge 同步：

```typescript
// PATCH /api/model-pool/toggle
const result = unifiedPool.setActive(id, active ?? true);
// setActive 内部已通过 bridgeCallback 自动同步到 ResourceHub
```

### 1.5 心跳对账

**文件**: `src/brain/brain.ts` — 在 heartbeat 中调用

```typescript
// 在 decay() 之后
this.modelPoolBridge?.reconcile();
```

---

## Phase 2: 修复 Cloud LLM 反馈断联 (Critical)

### 2.1 CloudLLMExecutor 返回错误信息

**文件**: `src/brain/hub/cloud-executor.ts`

```typescript
// 修改 ExecutorResult 接口
export interface ExecutorResult {
  text: string;
  confidence: number;
  source: string;
  // 新增:
  modelId?: string;
  latencyMs?: number;
  error?: { type: string; message: string };
}

// 修改 execute 方法
async execute(
  input: string,
  signal: TaskSignal,
  resources: ResourceState,
): Promise<ExecutorResult | null> {
  if (!this.caller) return null;
  if (resources.budgetRemaining <= 0) return null;

  this.callCount++;
  const startTime = Date.now();

  try {
    const result = await this.caller.chat(input, {
      maxTokens: 1024,
      temperature: 0.7,
    });
    return {
      text: result.text,
      confidence: result.confidence ?? 0.7,
      source: 'cloudLLM',
      latencyMs: Date.now() - startTime,  // ← 新增
    };
  } catch (err) {
    this.errorCount++;
    const errorType = this.classifyError(err);  // ← 新增错误分类
    return {
      text: '',
      confidence: 0,
      source: 'cloudLLM',
      latencyMs: Date.now() - startTime,
      error: { type: errorType, message: (err as Error).message },
    };
  }
}

private classifyError(err: unknown): string {
  const msg = err instanceof Error ? err.message.toLowerCase() : String(err).toLowerCase();
  if (msg.includes('401') || msg.includes('403')) return 'auth';
  if (msg.includes('402') || msg.includes('balance') || msg.includes('quota')) return 'payment';
  if (msg.includes('404')) return 'not_found';
  if (msg.includes('429')) return 'rate_limit';
  if (msg.includes('timeout') || msg.includes('econnrefused')) return 'network';
  if (msg.includes('400')) return 'capability_mismatch';
  return 'unknown';
}
```

### 2.2 LLMCaller 接口扩展

**文件**: `src/brain/hub/cloud-executor.ts`

```typescript
export interface LLMCaller {
  chat(input: string, opts?: { maxTokens?: number; temperature?: number }): Promise<{
    text: string;
    confidence?: number;
    modelId?: string;      // ← 新增: 实际使用的模型 ID
  }>;
}
```

### 2.3 注入实际 modelId

**文件**: `src/core/subsystems.ts`

```typescript
this.threeBrain.cloudExecutor.setLLMCaller({
  chat: async (input, opts) => {
    const text = await llmCallService.call(input, {
      taskType: 'chat',
      maxSteps: 1,
    });
    // 获取实际使用的模型 ID
    const lastSelection = this._llm.consumeLastSelection();
    const modelId = lastSelection?.profile.id;
    return { text, confidence: 0.7, modelId };
  },
});
```

### 2.4 Brain feedback 中使用真实 modelId

**文件**: `src/brain/brain.ts`

```typescript
// 修改 feedback() 中 cloud LLM 记录部分
if (plan.source === 'cloudLLM' || outcome.usedCloudLLM) {
  // 优先使用 outcome.cloudModelId，其次用 lastCloudResult.modelId
  const cloudModelId = outcome.cloudModelId
    ?? this.lastCloudResult?.modelId
    ?? this.resolveCloudModelId();

  if (cloudModelId) {
    // 确保 ResourceHub 中有这个模型（可能是 ModelPool 发现但未注册的）
    if (!this.resourceHub.getProfile(cloudModelId)) {
      this.modelPoolBridge?.syncProfileToHub(/* 从 pool 获取 profile */);
    }

    this.resourceHub.recordOutcome(cloudModelId, {
      success: outcome.success,
      qualityScore: hubQualityScore,
      latencyMs: outcome.latencyMs,
      costEstimate: outcome.costEstimate,
      scenario: signal.taskType,
    });

    // 回流到 ModelPool
    this.modelPoolBridge?.feedbackToPool(cloudModelId, {
      success: outcome.success,
      qualityScore: hubQualityScore,
      latencyMs: outcome.latencyMs,
      costEstimate: outcome.costEstimate,
      scenario: signal.taskType,
    });
  }
}
```

---

## Phase 3: 逐工具反馈 (High)

### 3.1 修改 brain.ts feedback() 工具记录逻辑

**文件**: `src/brain/brain.ts`

当前问题: 所有工具共享 `outcome.success`。

修改方案: 从 `outcome.toolCalls` 中获取每个工具的实际成功/失败状态。

```typescript
// 现有 (有问题):
for (const tool of outcome.toolsUsed) {
  this.resourceHub.recordOutcome(`tool:${tool}`, {
    success: outcome.success,  // ← 整体成功
    ...
  });
}

// 修改为:
const toolCallResults = outcome.toolCalls ?? [];
for (const tc of toolCallResults) {
  // 判断单个工具是否成功: result 不以 '[' 开头表示成功
  const toolSuccess = !tc.result?.startsWith('[');
  this.resourceHub.recordOutcome(`tool:${tc.name}`, {
    success: toolSuccess,
    qualityScore: toolSuccess ? hubQualityScore : 0.2,
    latencyMs: outcome.latencyMs / Math.max(1, toolCallResults.length),
    costEstimate: (outcome.costEstimate ?? 0) / Math.max(1, toolCallResults.length),
    scenario: signal.taskType,
  });
}

// 兼容: 如果没有 toolCalls 详情，回退到整体记录
if (toolCallResults.length === 0) {
  for (const tool of outcome.toolsUsed) {
    this.resourceHub.recordOutcome(`tool:${tool}`, {
      success: outcome.success,
      qualityScore: hubQualityScore,
      latencyMs: outcome.latencyMs / Math.max(1, outcome.toolsUsed.length),
      scenario: signal.taskType,
    });
  }
}
```

---

## Phase 4: 知识源/平台/TTS 反馈 (High/Medium)

### 4.1 知识源查询反馈

**文件**: `src/intelligence/knowledge-convergence.ts` 或相关知识汇聚模块

在知识源被查询后记录结果：

```typescript
// 知识汇聚完成后
this.resourceHub?.recordOutcome(`knowledge:${sourceId}`, {
  success: result.entries.length > 0,
  qualityScore: result.confidence ?? 0.5,
  latencyMs: result.latencyMs,
  scenario: 'knowledge_retrieval',
});
```

### 4.2 平台消息发送反馈

**文件**: `src/core/agent.ts` 或平台适配器

在平台发送消息后记录：

```typescript
// 消息发送完成后
this.resourceHub.recordOutcome(`platform:${platformId}`, {
  success: sendResult.success,
  qualityScore: sendResult.success ? 0.8 : 0.2,
  latencyMs: sendResult.latencyMs,
  scenario: 'message_delivery',
});
```

### 4.3 TTS 合成反馈

**文件**: `src/voice/tts.ts`

在 TTS 合成完成后记录：

```typescript
// TTS 合成完成后
this.resourceHub?.recordOutcome(`tts:${backendName}`, {
  success: synthesisResult.success,
  qualityScore: synthesisResult.success ? 0.8 : 0.2,
  latencyMs: synthesisResult.latencyMs,
  scenario: 'tts_synthesis',
});
```

---

## Phase 5: 自动注册类型修正 (Medium)

### 5.1 修改 recordOutcome 自动注册逻辑

**文件**: `src/brain/hub/resource-hub.ts`

当前问题: 所有未知资源都注册为 `type: 'tool'`。

```typescript
// 现有:
if (!entry) {
  this.register({
    id: resourceId,
    type: 'tool',  // ← 硬编码
    ...
  });
}

// 修改为:
if (!entry) {
  const inferredType = this.inferResourceType(resourceId);
  this.register({
    id: resourceId,
    type: inferredType,
    name: resourceId,
    capabilities: this.createDefaultCapabilities(inferredType, resourceId),
  });
}

private inferResourceType(id: string): ResourceType {
  if (id.startsWith('cloud_llm:')) return 'cloud_llm';
  if (id.startsWith('local_model:') || id.startsWith('ternary:')) return 'local_model';
  if (id.startsWith('engine:')) return 'engine';
  if (id.startsWith('tool:')) return 'tool';
  if (id.startsWith('skill:')) return 'skill';
  if (id.startsWith('knowledge:')) return 'knowledge';
  if (id.startsWith('platform:') || id.startsWith('tts:')) return 'system';
  return 'tool'; // 兜底
}
```

---

## Phase 6: 资源能力动态更新 (Medium)

### 6.1 TernaryExpert 成长阶段同步

**文件**: `src/tools/ternary-expert.ts`

在成长阶段变化回调中，更新 ResourceHub 的 capabilities：

```typescript
private onGrowthStageChange(domain: string, oldStage: string, newStage: string): void {
  if (!this.resourceHub) return;

  const profile = this.resourceHub.getProfile(`ternary:${domain}`);
  if (!profile) return;

  // 更新 strengths/weaknesses
  const stageStrengths: Record<string, string[]> = {
    seed: ['untrained'], sprout: ['basic_knowledge'], growing: ['active_learning'],
    trainable: ['fine_tuning_ready'], mature: ['production_ready'],
  };
  const caps = profile.capabilities as LocalModelCapabilities;
  caps.strengths = [domain, ...(stageStrengths[newStage] ?? [])];
  caps.weaknesses = newStage === 'seed' ? ['untrained'] : [];

  // 更新 status
  if (newStage === 'mature' || newStage === 'trainable') {
    profile.status = 'active';
  } else if (newStage === 'seed') {
    profile.status = 'registering';
  }
}
```

### 6.2 KnowledgeSource 可用性同步

**文件**: `src/brain/hub/resource-sync.ts`

在 ResourceSync 中添加知识源健康检查：

```typescript
syncKnowledgeSourceAvailability(sourceId: string, isAvailable: boolean): void {
  const id = `knowledge:${sourceId}`;
  const entry = this.hub.getProfile(id);
  if (!entry) return;

  const caps = entry.capabilities as KnowledgeCapabilities;
  caps.freshness = isAvailable ? 0.7 : 0.1;
  entry.status = isAvailable ? 'active' : 'unavailable';
}
```

---

## Phase 7: 集成与测试 (Low)

### 7.1 集成检查清单

- [ ] `ModelPoolResourceBridge` 创建并注入到 ThreeBrain
- [ ] `ModelPool.setBridgeCallback` 在所有状态变更点调用
- [ ] `CloudLLMExecutor` 返回错误信息和 modelId
- [ ] `brain.ts feedback()` 使用逐工具成功判断
- [ ] `brain.ts feedback()` 使用真实 cloudModelId
- [ ] 知识源查询后记录 feedback
- [ ] 平台/TTS 使用后记录 feedback
- [ ] `recordOutcome` 自动注册类型修正
- [ ] TernaryExpert 成长阶段同步
- [ ] 心跳中调用 `bridge.reconcile()`

### 7.2 测试场景

| 场景 | 预期行为 |
|------|---------|
| 添加新 API 端点，发现 50 个模型 | ResourceHub 中出现所有 active 模型 |
| 用户 toggle 去激活一个模型 | ResourceHub 中该模型标记 dormant |
| 模型返回 402 余额不足 | ResourceHub 中该模型标记 unavailable |
| 模型被标记 denied 后充值恢复 | ResourceHub 中恢复为 active |
| 3 个工具执行，1 个失败 | 只有失败的工具被标记 success=false |
| Ternary 模型从 seed 训练到 mature | ResourceHub 中 strengths 更新 |
| MCP 服务器断开 | ResourceHub 中对应工具注销 |

---

## 执行顺序

```
Phase 1 (ModelPool ↔ ResourceHub Bridge)
  ├── 1.1 创建 ModelPoolResourceBridge
  ├── 1.2 集成到 Subsystems
  ├── 1.3 集成到 ModelPool 状态变更
  ├── 1.4 集成到 REST API
  └── 1.5 心跳对账

Phase 2 (Cloud LLM 反馈修复) — 依赖 Phase 1
  ├── 2.1 CloudLLMExecutor 返回错误信息
  ├── 2.2 LLMCaller 接口扩展
  ├── 2.3 注入实际 modelId
  └── 2.4 Brain feedback 使用真实 modelId

Phase 3 (逐工具反馈) — 独立
  └── 3.1 修改 feedback() 工具记录逻辑

Phase 4 (知识源/平台/TTS 反馈) — 独立
  ├── 4.1 知识源查询反馈
  ├── 4.2 平台消息发送反馈
  └── 4.3 TTS 合成反馈

Phase 5 (自动注册类型修正) — 独立
  └── 5.1 修改 recordOutcome 自动注册逻辑

Phase 6 (资源能力动态更新) — 独立
  ├── 6.1 TernaryExpert 成长阶段同步
  └── 6.2 KnowledgeSource 可用性同步

Phase 7 (集成与测试) — 依赖所有 Phase
```

**预估工作量**: Phase 1-2 约 2-3 天，Phase 3-6 约 1-2 天，Phase 7 约 1 天。
**总计**: 约 4-6 天。
