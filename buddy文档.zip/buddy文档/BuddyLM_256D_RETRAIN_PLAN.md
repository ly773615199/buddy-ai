# BuddyLM 256d 权重重建计划

> 日期: 2026-05-28 | 状态: 待执行

## 一、问题根因

BuddyLM 当前无法工作，根本原因不是"加载顺序错位"，而是**训练源头缺失**：

| 来源 | 架构 | 状态 |
|------|------|------|
| `scripts/buddylm.pt` (PyTorch checkpoint) | **128d / 4层 / 无CCA / 无MoE** | 旧架构，与当前代码不兼容 |
| `checkpoints/buddylm-pretrain/part1+part2` | **256d / 8层 / CCA+MoE** | 仅 500 步，来源是 TS 本地 CPU 预训练 |
| 当前代码 `decoder.ts` | **256d / 8层 / CCA+MoE** | 架构已定 |

**核心矛盾**：项目里没有 256d 的 PyTorch 训练脚本。GPU 训练用的是 128d 旧架构，256d 只在 TS 端做过 500 步 CPU 训练。所有权重加载问题（interleaved/grouped、transpose、乱码）都是这个矛盾的表象。

## 二、目标

从根源解决：**建立 256d PyTorch 训练管线 → GPU 训练 → 正确导出 → TS 加载**。

## 三、执行步骤

### Phase 1: 编写 256d PyTorch 训练脚本

**产出**: `scripts/train_buddylm_256d.py`

需要做的事情：
1. 参照 `src/brain/right/nn/decoder.ts` 的 TS 架构，在 PyTorch 中实现完全对齐的 256d 模型
2. 架构参数：hiddenDim=256, ffnDim=1024, numHeads=8, numLayers=8, vocabSize=8192, numExperts=8, moeTopK=2, useCCA=true
3. 包含 CCA (ChunkedCrossAttention) 和 MoE (Mixture of Experts) 层
4. BBPE Tokenizer 与 TS 端共享 `checkpoints/tokenizer/bbpe-vocab.json`
5. 训练数据格式与 `training-data/stages/` 兼容

**关键对齐项**（确保导出权重与 TS `parameters()` 一致）：

| 项目 | PyTorch 实现要求 |
|------|-----------------|
| Attention 参数顺序 | 导出时必须按 `wq,wk,wv,wo,bq,bk,bv,bo,lnW,lnB`（grouped）排列 |
| 矩阵 shape | PyTorch Linear `[out,in]` → 导出时 transpose 为 TS 的 `[in,out]` |
| CCA 参数 | 与 selfAttn 相同的 10 参数结构 |
| MoE 参数 | router(wGate,bGate) + 8×expert(w1,b1,w2,b2) + lnW,lnB |
| LM Head | 单层 Linear (不含 bias)，与 TS LMHead 对齐 |
| 参数总数 | 每 block 66 参数 × 8 blocks + LMHead 3 = 531 |

### Phase 2: 权重导出脚本（重写）

**产出**: `scripts/export_weights_v2.py`

基于现有的 `export_weights_lite.py`，但需要：
1. 按 TS 模型 `parameters()` 的精确顺序逐个导出
2. 处理 PyTorch `[out,in]` → TS `[in,out]` 转置
3. 处理 `in_proj_weight` (合并的 QKV) 拆分为独立的 wq, wk, wv
4. 导出为分片格式 `decoder_part1.weights.bin` + `decoder_part2.weights.bin`
5. 同时导出 `embedding.weights.bin` 和 `meta.json`
6. 导出后自动验证：逐参数对比 shape 和统计值

### Phase 3: GPU 训练

**前置**: Phase 1 + Phase 2 完成

1. 在启智平台 (OpenI) 或其他 GPU 环境运行 `train_buddylm_256d.py`
2. 5 阶段课程训练（复用 `training-data/stages/` 数据）
3. 训练目标：loss < 1.5（参照旧 128d 模型 26950 步达到 loss 1.34）
4. 导出权重：`export_weights_v2.py --buddylm checkpoints/buddylm-256d.pt --output checkpoints/buddylm-pretrain/`

### Phase 4: TS 端加载验证

1. `decoder.ts` 的 `loadWeightsBinary()` 恢复为简单顺序加载（无需映射）
2. 运行验证测试：输入中文句子，确认输出可理解的文本
3. 置信度应 > 0.3（当前乱码时 ~0.07）

### Phase 5: 清理

1. 删除 `buddylm.pt`（128d 旧产物）
2. 删除 `scripts/export_weights_lite.py`（旧导出脚本）
3. 删除 `BUDDYLM_WEIGHT_LOADING_FIX_PLAN.md`（问题已根治）
4. 删除 `WEIGHT_LOADING_DEEP_ANALYSIS.md`（问题已根治）
5. 更新 `BUDDYLM_DESIGN.md` 和 `BUDDYLM_PROGRESS.md`

## 四、涉及文件

| 操作 | 文件 |
|------|------|
| 新建 | `scripts/train_buddylm_256d.py` — 256d PyTorch 训练脚本 |
| 重写 | `scripts/export_weights_v2.py` — 对齐导出脚本 |
| 修改 | `src/brain/right/nn/decoder.ts` — 简化 loadWeightsBinary() |
| 删除 | `scripts/buddylm.pt` — 128d 旧权重 |
| 删除 | `scripts/export_weights_lite.py` — 旧导出脚本 |
| 删除 | `BUDDYLM_WEIGHT_LOADING_FIX_PLAN.md` — 过时 |
| 删除 | `WEIGHT_LOADING_DEEP_ANALYSIS.md` — 过时 |
| 更新 | `BUDDYLM_DESIGN.md` — 标注 Phase 0 状态 |
| 更新 | `BUDDYLM_PROGRESS.md` — 更新进度 |

## 五、阻塞项

1. **GPU 环境**：需要启智平台或其他 GPU 训练环境
2. **训练数据**：`training-data/stages/` 共 212K 条，已就绪
3. **BBPE Tokenizer**：`checkpoints/tokenizer/bbpe-vocab.json` 已就绪（vocab size 异常小，需确认）

## 六、风险

| 风险 | 缓解 |
|------|------|
| 256d CPU 训练太慢 | 必须用 GPU，Phase 3 阻塞 |
| PyTorch 架构与 TS 不完全对齐 | Phase 2 导出后逐参数验证 shape |
| CCA/MoE 在 PyTorch 中实现复杂度高 | 参照 TS 代码逐行翻译，不做创新 |
