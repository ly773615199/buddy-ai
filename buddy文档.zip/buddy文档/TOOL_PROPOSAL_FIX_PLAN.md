# ToolProposal 信息流修复计划

## 问题摘要

当前 toolProposal（工具执行结果）被注册为组装引擎的**向量检索源**，经过 ByteEncoder 编码 → cosine 匹配 → ContentSelector 筛选 → FragmentExtractor 提取关键句 → 拼装。存在三个断裂点：

1. **语义鸿沟**：工具输出 embedding 与用户 query embedding 不匹配时被筛掉
2. **信息损耗**：FragmentExtractor 只提取关键句，结构化信息被破坏
3. **多余路径**：确定性结果走了概率性的向量检索

## 目标信息流

```
toolProposal 到手
    ↓
ToolProposalRouter.classify(toolName, toolOutput)
    ↓ 判断类型
    ├── JSON 结构化 → formatToolOutput()          → localGeneration
    ├── 文件/长文本 → MapReduceProcessor.process() → localGeneration
    ├── 多工具结果  → summarize(fragments)         → localGeneration
    └── 已可读文本  → 直接透传 / summarize()       → localGeneration

置信度 < 0.5 → 降级走组装引擎完整管线（保留向量检索作为兜底）
```

## 改动清单

### 改动 1：brain.ts — 新增 routeToolProposal 方法

位置：ThreeBrain 类内部（建议在 processWithAssemblyCompetitive 附近）

新增 **async** 私有方法 `routeToolProposal()`，复用已有的 `composeToolResult`：
- 输入：toolProposal + 用户原始 input + signal + intuition
- 输出：`{ text: string; confidence: number; path: string }`
- 路由逻辑：
  1. 单工具长文本 (>1500字) → `MapReduceProcessor.process()`（composeToolResult 未覆盖）
  2. 复用 `composeToolResult()`：
     - 单工具 JSON → `formatToolOutput()`
     - 多工具 → `summarize(fragments)`
     - 兜底 → `composeStructured()`
  3. 返回 null → 指示走完整管线

### 改动 2：brain.ts — 修改 3 处 toolProposal 注册逻辑

**位置 A**：~L1314（decide 方法，并行任务阶段）
- 删除 `registerAssemblySource('tool_proposal', ...)` 
- 改为调用 `routeToolProposal()`，结果直接设置 localGeneration
- 如果 routeToolProposal 返回 null，降级走组装引擎完整管线

**位置 B**：~L2019（executeBlendStrategy 方法，assembly 组件内）
- 删除 `registerAssemblySource('tool_proposal', ...)`
- 改为调用 `routeToolProposal()`，结果直接返回

**位置 C**：~L1417（decide 方法，裁决后取组装产出）
- 简化：routeToolProposal 已经直接产出 localGeneration，不需要再从 localProposals 中找

### 改动 3：assembly-bridge.ts — 暴露 MapReduceProcessor

新增 getter：
```typescript
getMapReduceProcessor(): MapReduceProcessor { return this.engine.getMapReduceProcessor(); }
```

### 改动 4：integration-engine.ts — 暴露 MapReduceProcessor

新增 getter：
```typescript
getMapReduceProcessor(): MapReduceProcessor { return this.mapReduceProcessor; }
```

### 改动 5：清理残留

- 删除 3 处 `unregisterAssemblySource('tool_proposal')` 调用
- 更新相关注释

## 不改动的部分

- `agent.ts`：消费 localGeneration 的逻辑不变
- `AssemblyBridge` 的 formatToolOutput / summarize / composeStructured：已有实现，直接复用
- `MapReduceProcessor`：已有实现，直接复用
- `ToolOutputCache`：保留，用于缓存历史工具输出（与 Router 互补）
- `IntegrationEngine` 的 retrieve 管线：保留，作为 Router 的降级兜底

## 验证方式

1. TypeScript 编译通过：`npx tsc --noEmit`
2. 现有测试通过：`npx vitest run`
3. 功能验证：toolProposal 走直接路由，不再经过向量检索
