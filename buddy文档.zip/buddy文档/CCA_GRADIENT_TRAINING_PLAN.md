# CCA 梯度流打通 — 训练方案

> ⚠️ **状态**: 本方案基于旧的耦合架构（组装引擎 → encodeFragments → CCA）。在新的解绑架构下（见 BUDDYLM_ASSEMBLY_INTEGRATION_PLAN.md），CCA 是 BuddyLM 自己的上下文机制，不接收外部检索片段。CCA 的梯度训练仍然需要，但 K/V 来源改为 BuddyLM 内部上下文。

> **目标**: 打通 ByteEncoder → CCA → Decoder 的梯度流，让检索信息参与训练
> **前置**: 四层架构中层次 1/3/4 已实现，层次 2 架构接通但梯度断开
> **预计耗时**: 2-2.5 小时（代码改动 ~95 行）

---

## 1. 现状分析

### 1.1 架构已通，梯度未通

```
组装引擎检索 → ByteEncoder.encodeFragments() → [totalTokens, 128] Tensor
                                                       ↓
                                            Decoder CCA (K/V) ← 手动矩阵运算，无 autograd
                                                       ↓
                                            生成增强后的 hidden state
```

| 组件 | 推理时 | 训练时 |
|------|--------|--------|
| ByteEncoder → retrievedChunks | ✅ encodeFragments() | 🔴 训练时不调用 |
| CCA forward | ✅ 手动矩阵运算 | 🔴 无 autograd 链 |
| CCA 参数梯度 | — | 🔴 forwardTrain 不传 retrievedChunks |
| ByteEncoder 梯度 | — | 🔴 完全断开 |

### 1.2 关键断点

**断点 1**: `forwardTrain()` / `forwardTrainStep()` 调用 `block.forward()` 时传 `undefined` 作为 `retrievedChunks`

```typescript
// decoder.ts:1486 — 当前训练前向
const result = this.blocks[i].forward(
  currentHidden, encoderHidden, undefined, undefined, i,
  //                                              ^^^^^^^^ retrievedChunks = undefined
);
```

**断点 2**: CCA forward 是手动 for 循环，没用 autograd tensor 操作

```typescript
// chunked-cross-attention.ts:155 — 手动矩阵乘法
for (let n = 0; n < N; n++) {
  for (let h = 0; h < H; h++) {
    let sum = this.bk.data[h];
    for (let c = 0; c < this.chunkDim; c++) {
      sum += retrievedChunks.data[n * this.chunkDim + c] * this.wk.data[c * H + h];
    }
    kData[n * H + h] = sum;
  }
}
```

**断点 3**: `BuddyLMTrainer` 不持有 ByteEncoder 引用，无法编码训练样本的检索片段

---

## 2. 训练方案：三阶段渐进

### Stage 1：冻结 Encoder，训 Decoder + CCA

**原理**: CCA 参数已在 `decoder.parameters()` 中，只要 `forwardTrain` 传入 `retrievedChunks`，CCA 就能通过 autograd 收到梯度。

```
ByteEncoder (冻结) ──encodeFragments()──→ retrievedChunks [N, 128]
                                               ↓
BBPEEmbedding (训练) ──forwardTensor()──→ encoderHidden [S, 128]
                                               ↓
                        DecoderBlock.forward(encoderHidden, ..., retrievedChunks)
                                               ↓
                                          CCA.forward() ← autograd 梯度回传
                                               ↓
                                          CE loss → 反向传播 → CCA 参数更新
```

**改动清单**:

#### 改动 1: `decoder.ts` — forwardTrain 支持 retrievedChunks

```typescript
// 现在:
forwardTrain(encoderHidden: Tensor, inputTokenIds: number[]): Tensor {

// 改为:
forwardTrain(encoderHidden: Tensor, inputTokenIds: number[], retrievedChunks?: Tensor): Tensor {
  // ...
  for (let i = 0; i < this.config.numLayers; i++) {
    const result = this.blocks[i].forward(
      currentHidden, encoderHidden, undefined, undefined, i,
      retrievedChunks,  // 新增
    );
    currentHidden = result.output;
  }
  // ...
}
```

#### 改动 2: `decoder.ts` — forwardTrainStep 支持 retrievedChunks

```typescript
forwardTrainStep(encoderHidden: Tensor, tokenId: number, retrievedChunks?: Tensor): Tensor {
  // ...
  for (let i = 0; i < this.config.numLayers; i++) {
    const result = this.blocks[i].forward(
      currentHidden, encoderHidden, this.selfKVCache, undefined, i,
      retrievedChunks,  // 新增
    );
    currentHidden = result.output;
  }
  // ...
}
```

#### 改动 3: `buddy-lm-trainer.ts` — 构造函数注入 ByteEncoder

```typescript
constructor(
  decoder: BuddyLMDecoder,
  embedding: BBPEEmbedding,
  tokenizer: BBPETokenizer,
  config: Partial<BuddyLMTrainConfig>,
+ byteEncoder?: ByteEncoder,  // 可选：用于编码训练检索片段
) {
  // ...
+ this.byteEncoder = byteEncoder;
}
```

#### 改动 4: `buddy-lm-trainer.ts` — computeCrossEntropyAutograd 传入检索片段

```typescript
private computeCrossEntropyAutograd(
  input: string,
  target: string,
+ retrievedChunks?: Tensor,
): { loss: Tensor; count: number } | null {
  // ...
- let logitsTensor = this.decoder.forwardTrain(encoderHidden, [targetIds[0]]);
+ let logitsTensor = this.decoder.forwardTrain(encoderHidden, [targetIds[0]], retrievedChunks);
  // ...
- logitsTensor = this.decoder.forwardTrainStep(encoderHidden, targetIds[i + 1]);
+ logitsTensor = this.decoder.forwardTrainStep(encoderHidden, targetIds[i + 1], retrievedChunks);
  // ...
}
```

#### 改动 5: `buddy-lm-trainer.ts` — 训练循环编码检索片段

```typescript
private trainIncremental(): BuddyLMTrainResult {
  // ...
  for (const sample of batch) {
+   // 编码训练样本的检索片段（冻结 ByteEncoder，不走 autograd）
+   let retrievedChunks: Tensor | undefined;
+   if (this.byteEncoder && sample.input) {
+     const fragments = this.extractFragments(sample.input);
+     if (fragments.length > 0) {
+       retrievedChunks = this.encodeFragmentsForTrain(fragments);
+     }
+   }
-   const result = this.computeCrossEntropyAutograd(sample.input, sample.output);
+   const result = this.computeCrossEntropyAutograd(sample.input, sample.output, retrievedChunks);
    // ...
  }
}

/** 从训练样本提取检索片段（简化版：用输入文本本身） */
private extractFragments(input: string): string[] {
  // 简单切分：按段落/句子分块
  return input.split(/\n\n|。|！|？/).filter(s => s.trim().length > 10).slice(0, 8);
}

/** 编码检索片段（冻结 ByteEncoder，无梯度） */
private encodeFragmentsForTrain(fragments: string[]): Tensor {
  // 复用 BuddyLM.encodeFragments() 的逻辑
  const hiddenDim = 128;
  const allHidden: Float32Array[] = [];
  let totalTokens = 0;

  for (const frag of fragments) {
    const hidden = this.byteEncoder!.forward(frag);
    const S = Math.min(hidden.shape[0], 64);
    const chunkData = new Float32Array(S * hiddenDim);
    chunkData.set(hidden.data.subarray(0, S * hiddenDim));
    allHidden.push(chunkData);
    totalTokens += S;
  }

  const out = new Float32Array(totalTokens * hiddenDim);
  let offset = 0;
  for (const h of allHidden) { out.set(h, offset); offset += h.length; }

  return new Tensor(out, [totalTokens, hiddenDim]);
}
```

**预期效果**:
- CCA 参数从随机初始化 → 学会有意义的注意力模式
- Decoder 学会利用检索信息辅助生成
- ByteEncoder 冻结不变（Stage 2 再解冻）

---

### Stage 2：辅助 loss 联合训练

**原理**: 用已有的 `ByteEncoderBridge`，将 Decoder 的生成质量信号作为辅助 loss 反传给 ByteEncoder 顶层。

```
Decoder 生成质量 (quality_head score)
        ↓
ByteEncoderBridge.computeAuxLoss()
        ↓
ByteEncoder 顶层参数更新（小学习率 1e-4）
```

**改动清单**:

#### 改动 6: `buddy-lm-trainer.ts` — 解冻 ByteEncoder 顶层

```typescript
private unfreezeEncoderTopLayers(layers: number = 2): void {
  if (!this.byteEncoder) return;
  const allParams = this.byteEncoder.parameters();
  // 解冻最后 N 层
  const toUnfreeze = allParams.slice(-layers * 10); // 估算每层 ~10 个参数
  for (const p of toUnfreeze) {
    p.requiresGrad = true;
  }
}
```

#### 改动 7: `buddy-lm-trainer.ts` — 接入 ByteEncoderBridge 辅助 loss

```typescript
private trainWithJointLoss(sample: BuddyLMTrainSample): void {
  // 主 loss: Decoder CE
  const mainResult = this.computeCrossEntropyAutograd(sample.input, sample.output, retrievedChunks);

  // 辅助 loss: ByteEncoder 编码质量
  if (this.byteEncoderBridge && this.byteEncoder) {
    const quality = sample.quality ?? 0.5;
    const auxLoss = this.byteEncoderBridge.computeAuxLoss(sample.input, quality);
    // 联合 loss = 主 loss + 0.1 * 辅助 loss
    const jointLoss = add(mainResult.loss, scale(auxLoss, 0.1));
    autogradBackward(jointLoss);
  } else {
    autogradBackward(mainResult.loss);
  }
}
```

**预期效果**:
- ByteEncoder 学会为"生成质量高"的样本编码更精准的向量
- 检索质量↑ → 生成质量↑ → 编码质量↑ 正向循环
- 梯度流间接打通（辅助 loss 通道）

---

### Stage 3：端到端微调（可选，Stage 1+2 够用时跳过）

**原理**: 将 CCA forward 改为 autograd 版本，全链路梯度回传。

**改动**: 将 `chunked-cross-attention.ts` 的手动 for 循环替换为 `matmul`/`add` 等 autograd 操作。

```typescript
// 改前: 手动矩阵乘法（无 autograd）
for (let n = 0; n < N; n++) { ... }

// 改后: autograd tensor 操作
const k = matmul(retrievedChunks, this.wk);  // [N, H]，autograd 链
const kWithBias = add(k, this.bk);
```

**预期效果**:
- 全链路梯度: 生成 loss → Decoder → CCA → retrievedChunks → ByteEncoder
- ByteEncoder 深层参数也能收到梯度

**风险**: 改动量大（~200 行 CCA 重写），需要验证 autograd 版本的数值稳定性

---

## 3. 训练数据

### 3.1 数据来源

| 来源 | 格式 | 用途 |
|------|------|------|
| `training-data/stages/` | JSONL (input→output 对) | 增量预训练 |
| `memory/*.md` | 对话记录 | 自我奖励训练 |
| `DecisionMemory` | 决策记录 | STaR 推理链训练 |
| 源码注释↔代码 | 提取对 | ByteEncoder 对比学习 |

### 3.2 检索片段生成

训练时需要为每个样本生成检索片段（模拟推理时的组装引擎检索）：

**方案 A（简单）**: 用输入文本本身分块
```typescript
const fragments = input.split(/\n\n|。|！|？/).filter(s => s.trim().length > 10).slice(0, 8);
```

**方案 B（精确）**: 用组装引擎离线检索
```typescript
const { trace } = await engine.process(input);
const fragments = trace.selected.map(f => f.content);
```

**方案 C（最优）**: 预计算检索结果存入训练数据
```json
{"input": "...", "output": "...", "fragments": ["片段1", "片段2", ...]}
```

**推荐**: Stage 1 用方案 A（快速验证），Stage 2 切方案 C（最优质量）

---

## 4. 超参数

| 参数 | Stage 1 | Stage 2 | Stage 3 |
|------|---------|---------|---------|
| ByteEncoder | 冻结 | 解冻顶层 (2层) | 全部解冻 |
| Decoder LR | 1e-3 | 1e-3 | 5e-4 |
| CCA LR | 1e-3 | 1e-3 | 5e-4 |
| ByteEncoder LR | 0 | 1e-4 | 5e-5 |
| 辅助 loss 权重 | 0 | 0.1 | 0.05 |
| Batch size | 4 | 4 | 4 |
| Max tokens/sample | 64 | 64 | 64 |
| 检索片段数 | 4-8 | 4-8 | 4-8 |
| 每片段最大 tokens | 64 | 64 | 64 |

---

## 5. 验证指标

### 5.1 Stage 1 验证

```bash
# 1. CCA 参数有梯度
npx vitest run src/brain/right/nn/__tests__/cca-gradient.test.ts

# 2. 训练 loss 下降
npx tsx src/brain/right/training/buddy-lm-trainer.ts --mode incremental --epochs 5

# 3. CCA 注意力权重可视化（检索片段应获得非均匀注意力）
```

**通过标准**:
- [ ] CCA 所有参数（wq/wk/wv/wo）grad 非零
- [ ] 训练 5 epochs 后 loss 下降 > 10%
- [ ] CCA 注意力分布不是均匀的（学会区分片段重要性）

### 5.2 Stage 2 验证

```bash
# 1. ByteEncoder 顶层参数有梯度
npx vitest run src/brain/right/training/__tests__/joint-train.test.ts

# 2. 编码质量提升（相同样本，训练后余弦相似度更合理）
npx tsx src/brain/right/training/pretrain-encoder.ts --eval-only
```

**通过标准**:
- [ ] ByteEncoder 顶层参数 grad 非零
- [ ] 正样本相似度提升 > 0.05
- [ ] 向量方差未坍缩（> 0.005）

---

## 6. 风险与缓解

| 风险 | 概率 | 影响 | 缓解 |
|------|------|------|------|
| CCA 梯度爆炸 | 中 | 训练不稳定 | 梯度裁剪 maxGradNorm=1.0 |
| ByteEncoder 解冻后遗忘 | 低 | 编码质量下降 | LPR 近端约束 + 小学习率 |
| 训练数据无检索片段 | 高 | CCA 学不到东西 | 方案 A 先行，方案 C 后续 |
| autograd 数值不稳定 | 低 (Stage 3) | NaN/Inf | Stage 3 可选，Stage 1+2 够用 |

---

## 7. 实施顺序

```
Stage 1 (1.5h)
  ├─ 改 decoder.ts: forwardTrain/forwardTrainStep +retrievedChunks    [20min]
  ├─ 改 buddy-lm-trainer.ts: 注入 ByteEncoder + 编码片段            [30min]
  ├─ 写 cca-gradient.test.ts: 验证 CCA 参数有梯度                    [30min]
  └─ 跑 5 epochs 验证 loss 下降                                      [10min]

Stage 2 (45min)
  ├─ 改 buddy-lm-trainer.ts: 解冻顶层 + ByteEncoderBridge 辅助 loss  [30min]
  ├─ 写 joint-train.test.ts: 验证联合训练                             [15min]
  └─ 评估编码质量变化                                                 [验证]

Stage 3 (可选, 2h)
  └─ 重写 chunked-cross-attention.ts 为 autograd 版本
```

---

## 8. 文件清单

| 文件 | 改动类型 | Stage |
|------|---------|-------|
| `src/brain/right/nn/decoder.ts` | 修改 (forwardTrain/forwardTrainStep) | 1 |
| `src/brain/right/training/buddy-lm-trainer.ts` | 修改 (注入+编码+联合loss) | 1, 2 |
| `src/brain/right/nn/__tests__/cca-gradient.test.ts` | 新增 | 1 |
| `src/brain/right/training/__tests__/joint-train.test.ts` | 新增 | 2 |
| `src/brain/right/nn/chunked-cross-attention.ts` | 重写 (可选) | 3 |
