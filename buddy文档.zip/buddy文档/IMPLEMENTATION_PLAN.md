# 三脑改造详细实施计划

> 基于全量代码审计 + THREE_BRAIN_EVOLUTION_PLAN.md
> 日期: 2026-05-15

---

## 一、现状代码审计总结

### ✅ 已实现的基础设施

| 模块 | 文件 | 状态 | 备注 |
|------|------|------|------|
| NN 骨架 | `right/nn/model.ts` | ✅ 完整 | Embedding → Encoder×2 → Pool → 5 Heads，~300K 参数 |
| 注意力机制 | `right/nn/attention.ts` | ✅ 完整 | Multi-Head Self-Attention，Pre-LN + Residual |
| FFN | `right/nn/ffn.ts` | ✅ 完整 | GELU 激活 |
| 5 个输出头 | `right/nn/output-heads.ts` | ✅ 完整 | intent(softmax)/tool(sigmoid)/quality/spatial/scene |
| 特征编码器 | `right/features/encoder.ts` | ✅ 完整 | 结构化 token ID 编码，含空间/图像/场景 |
| 图像编码器 | `right/features/image-encoder.ts` | ⚠️ 初级 | **仅像素统计**（均色/方差/边缘），无语义理解 |
| GNN 层 | `scene/gnn-layer.ts` | ✅ 完整 | Message Passing，含 MessageFunction + UpdateFunction |
| 场景世界模型 | `scene/scene-world-model.ts` | ✅ 完整 | GNN 驱动，实体注册 + 预测 |
| 知识桥接 | `scene/knowledge-bridge.ts` | ✅ 完整 | 知识→训练样本转换 |
| 原型记忆 | `right/prototype-memory.ts` | ✅ 完整 | hidden[128] 空间余弦匹配，新颖性检测 |
| LPR | `training/lpr.ts` | ✅ 完整 | **全局 λ**（非分层） |
| 在线学习器 | `training/online-learner.ts` | ✅ 完整 | ReplayBuffer + SGD + 安全阀 |
| 蒸馏器 | `training/distiller.ts` | ✅ 完整 | 温度蒸馏 |
| 左脑 | `left/index.ts` | ✅ 完整 | 规则引擎 + 调度器 + 策略蒸馏 + 决策记忆 |
| 小脑 | `cerebellum/` | ✅ 完整 | 感知融合 + 稳态调节 |
| 信号采集 | `core/signal-collector.ts` | ⚠️ 初级 | **classifyFromText() 是纯关键词匹配** |
| 梦境引擎 | `memory/dream.ts` | ✅ 完整 | 四阶段巩固：回放→提取→关联→修剪 |
| 三脑协作 | `brain/brain.ts` | ✅ 完整 | 信号流 + 决策融合 + 反馈闭环 |

### ❌ 关键缺口（与方案一致）

1. **TextEncoder** — 无文本编码器，`classifyFromText()` 是 7 组关键词规则
2. **Cross-Head Attention** — 5 个输出头完全独立，无信息交互
3. **KnowledgeGate** — 知识检索用 FTS5 全文搜索，无向量检索
4. **ReasoningHead** — 无多步推理能力
5. **Generator** — 100% 依赖外部 LLM 生成回复
6. **分层 LPR** — 全局 λ，非每层独立
7. **VisionEncoder** — 仅像素统计，无语义理解
8. **AudioEncoder** — 无音频处理

---

## 二、详细实施计划

### Phase 0: 概念表征空间（Week 1-2）

**目标**: 用 ByteEncoder 替代关键词匹配，建立 128 维语义空间

#### 0.1 ByteEncoder — 字节级文本编码器

**新建文件**: `src/brain/right/features/text-encoder.ts`

```typescript
/**
 * ByteEncoder — 字节级文本编码器
 *
 * UTF-8 字节 → ByteEmbedding(256, 32) → DynamicMerge → EncoderBlock×2 → [S', 128]
 *
 * 设计原则：
 * 1. 不依赖外部分词器（BPE/SentencePiece），直接处理 UTF-8 字节
 * 2. 熵驱动的动态合并：高熵字节保留独立 token，低熵字节合并
 * 3. 输出 128 维向量，与现有 NN hiddenDim 对齐
 * 4. 参数量 ~145K，CPU 推理 <3ms
 */

export class ByteEncoder {
  // ByteEmbedding: 256 个字节值 → 32 维向量
  byteEmbedding: Tensor; // [256, 32]

  // 投影层: 32 → 128（与 NN hiddenDim 对齐）
  projWeight: Tensor; // [32, 128]

  // 2 层 EncoderBlock（复用现有实现）
  encoderBlocks: EncoderBlock[]; // d=128, h=4, ffn=256

  // 熵估计器（无参数，纯计算）
  // 动态合并：根据字节熵值决定合并边界

  forward(text: string): Float32Array {
    // 1. 文本 → UTF-8 字节序列
    const bytes = new TextEncoder().encode(text);

    // 2. ByteEmbedding 查表: [S] → [S, 32]
    let h = this.embedBytes(bytes);

    // 3. 熵驱动动态合并: [S, 32] → [S', 32] (S' < S)
    h = this.dynamicMerge(h, bytes);

    // 4. 投影到 hiddenDim: [S', 32] → [S', 128]
    h = matmul(h, this.projWeight);

    // 5. EncoderBlock×2: [S', 128] → [S', 128]
    for (const block of this.encoderBlocks) {
      h = block.forward(h, true);
    }

    // 6. 池化: [S', 128] → [128]
    return this.poolLast(h);
  }
}
```

**DynamicMerge 核心逻辑**:
- 计算每个字节位置的熵: `H(i) = -sum(p * log(p))` 基于局部窗口的字节分布
- 高熵阈值 (>0.7): 保留独立 token（如 "部" "署" "d" "e" "p" "l" "o" "y"）
- 低熵阈值 (<0.3): 与相邻合并（如 "的" "the" "a" "是"）
- 中等熵: 与最近的高熵边界合并

**参数量核算**:
| 组件 | 参数 |
|------|------|
| ByteEmbedding(256, 32) | 8,192 |
| Proj(32→128) | 4,096 |
| EncoderBlock×2 (d=128, h=4, ffn=256) | ~133,000 |
| **总计** | **~145K** |

#### 0.2 接入现有 backbone

**修改文件**: `src/brain/right/features/encoder.ts`

- 新增 `encodeFeaturesV2(input, rawText?)` — 有原始文本时走 TextEncoder 路径
- 保持 `encodeFeatures()` 向后兼容

**修改文件**: `src/brain/right/nn/model.ts`

- 新增 `forwardWithText(tokenIds, textEmbedding)` — 混合路径
- 结构化 embedding + 文本 embedding 拼接后通过现有 encoder blocks
- 实现方式：`pooled = concat(structuredPooled, textEmbedding) → proj → heads`

#### 0.3 替换 classifyFromText

**修改文件**: `src/brain/right/index.ts`

- `classifyFromText()` 从关键词匹配改为 ByteEncoder + NN 推理
- 降级策略：ByteEncoder 未加载时仍用关键词规则

#### 0.4 训练数据来源

不需额外标注，复用三个现有信号：
1. **对话意图标签**: 用户消息 → LLM 回复 → 从回复反推意图
2. **工具使用结果**: 用户说"读文件" → 系统执行 read_file → 成功/失败
3. **蒸馏**: 外部 LLM 的决策 → 软标签蒸馏到 TextEncoder

#### 0.5 实施步骤

```
Day 1-2: 实现 ByteEncoder 类（embedding + dynamic merge + encoder blocks）
Day 3:   实现 forward() + poolLast()，单元测试
Day 4:   接入 encoder.ts（encodeFeaturesV2）
Day 5:   接入 model.ts（forwardWithText）
Day 6:   替换 classifyFromText()，集成测试
Day 7:   训练循环验证 + 性能基准
```

#### 0.6 验收标准

| 指标 | 改造前 | 目标 |
|------|--------|------|
| 中文意图分类准确率 | ~40% | ~70% |
| 英文意图分类准确率 | ~50% | ~75% |
| 中英混合输入 | 失效 | ~60% |
| 推理延迟增加 | — | <3ms |
| 参数增量 | — | +145K (300K→445K) |

---

### Phase 1: 跨头交互（Week 3）

**目标**: 三个输出头信息互通，决策一致性提升

#### 1.1 CrossHeadLayer

**修改文件**: `src/brain/right/nn/output-heads.ts`

当前 `OutputHeads.forward()` 对 5 个头独立前向。改为两阶段：

```typescript
// Stage 1: 各头独立前向 → 初始 logits
const initial = {
  intent: this.intentHead.forward(pooled),
  tools: this.toolHead.forward(pooled),
  quality: this.qualityHead.forward(pooled),
};

// Stage 2: 初始 logits 拼接 → CrossAttention → 最终 logits
const crossHeadInput = concat([
  initial.intent,   // [numIntents]
  initial.tools,    // [numTools]
  initial.quality,  // [1]
]);
// → proj → self-attention → proj back → 各头 logits
```

**CrossHeadLayer 实现**:
- 投影到统一 64 维: `[numIntents + numTools + 1] → [64]`
- 单层 Self-Attention（复用 MultiHeadAttention）
- 投影回各头维度
- 参数量: ~15K

#### 1.2 实施步骤

```
Day 1: 实现 CrossHeadLayer 类
Day 2: 修改 OutputHeads.forward() 为两阶段
Day 3: 集成测试 + 验证一致性提升
```

#### 1.3 验收标准

| 指标 | 改造前 | 目标 |
|------|--------|------|
| intent-tool 一致性 | ~60% | ~80% |
| 推理延迟增加 | — | <1ms |
| 参数增量 | — | +15K (445K→460K) |

---

### Phase 2: KnowledgeGate（Week 4-5）

**目标**: 知识从被动存储到主动向量检索

#### 2.1 知识向量化

**新建文件**: `src/brain/right/nn/knowledge-gate.ts`

```typescript
export class KnowledgeGate {
  // 复用 TextEncoder 编码知识条目 → 128 维向量
  // 用户输入向量和知识向量在同一空间 → 注意力交互
  // 门控融合：原始 query + 检索知识

  knowledgeIndex: Map<string, Float32Array>; // 知识条目 → 向量
  gateWeight: Tensor; // [256, 128] 门控投影

  forward(queryEmbedding: Float32Array, knowledge: Float32Array[]): {
    enhanced: Float32Array;  // 增强后的 query
    gate: number;            // 门控值 0-1
  };
}
```

#### 2.2 知识来源

复用现有知识存储：
- `STMPStore` 记忆节点
- `ExperienceGraph` 经验图谱
- `KnowledgeExtractor` 提取的知识

知识同步在 dream 或 heartbeat 时执行向量化。

#### 2.3 接入 IntuitionNet

**修改文件**: `src/brain/right/nn/model.ts`

- 新增 `forwardWithKnowledge(pooled, textEmbedding, knowledgeVectors)`
- 知识向量与 pooled 拼接后过投影层

#### 2.4 实施步骤

```
Day 1-2: 实现 KnowledgeGate 类（向量索引 + 注意力检索 + 门控融合）
Day 3:   接入 dream.ts 知识向量化
Day 4:   接入 model.ts（forwardWithKnowledge）
Day 5:   集成测试 + 验证命中率提升
```

#### 2.5 验收标准

| 指标 | 改造前 | 目标 |
|------|--------|------|
| 知识问答命中率 | ~30% | ~55% |
| 推理延迟增加 | — | <5ms |
| 参数增量 | — | +50K (460K→510K) |

---

### Phase 3: ReasoningHead（Week 6-7）

**目标**: 复杂问题分步推理

#### 3.1 推理头架构

**新建文件**: `src/brain/right/nn/reasoning-head.ts`

```typescript
export class ReasoningHead {
  stepEmbedding: Tensor;    // [8, 64] 步骤编号嵌入
  stepEncoder: EncoderBlock; // 步骤间注意力
  confidenceHead: OutputHead; // 每步置信度 [128→64→1, sigmoid]
  skipGate: Tensor;          // [128, 1] skip gate 判断
  maxSteps: 5;

  forward(pooled: Float32Array): {
    reasoning: Float32Array[];  // 每步的推理向量
    confidences: number[];      // 每步置信度
    skipped: boolean[];         // 每步是否跳过
    finalDecision: Float32Array; // 最终决策向量
  };
}
```

#### 3.2 Skip Gate（Skip-Thinking 论文）

- 判断当前步骤是否需要推理
- 简单问题：skipGate 全为 1 → 跳过所有推理步
- 复杂问题：skipGate 为 0 → 执行推理

#### 3.3 并行推理模式（NoThinking 论文）

- 中等复杂度：同时生成 N=3 条短推理路径
- 用 quality_head 的变体选最好的

#### 3.4 实施步骤

```
Day 1-2: 实现 ReasoningHead 类（step embedding + encoder + confidence + skip gate）
Day 3:   实现并行推理模式
Day 4:   接入 model.ts（forwardWithReasoning）
Day 5:   训练信号：从 LLM 蒸馏推理链
Day 6-7: 集成测试 + 验证复杂任务提升
```

#### 3.5 验收标准

| 指标 | 改造前 | 目标 |
|------|--------|------|
| 复杂任务成功率 | ~40% | ~55% |
| 推理延迟 | — | +5-15ms |
| 参数增量 | — | +80K (510K→590K) |

---

### Phase 4: StructuredGenerator（Week 8）

**目标**: 60-70% 日常交互本地生成，不调用 LLM

#### 4.1 模板引擎 + 槽位填充

**新建文件**: `src/brain/right/nn/generator.ts`

```typescript
export class StructuredGenerator {
  templateSelector: OutputHead; // 模板选择头
  templates: Template[];         // 模板库

  // 槽位值来源：
  // - knowledge 中提取实体名
  // - intent 推断动词
  // - toolResult 提取数值
  generate(pooled: Float32Array, context: GenerateContext): {
    text: string;
    confidence: number;
    templateId: string;
  };
}
```

#### 4.2 模板自动学习

从成功对话中自动编译模板：
1. 找到 assistant 的成功回复
2. 提取骨架（去除具体实体/数值）
3. 识别槽位
4. 与已有模板合并或创建新模板

#### 4.3 降级策略

- `confidence >= 0.6` → 直接本地生成
- `confidence >= 0.4` → 本地骨架 + LLM 补完
- `confidence < 0.4` → 全权交给 LLM

#### 4.4 实施步骤

```
Day 1: 实现 Template 类 + 模板选择头
Day 2: 实现槽位填充逻辑
Day 3: 实现模板自动学习（从成功对话编译）
Day 4: 接入 brain.ts 决策流 + 降级策略
Day 5: 集成测试 + 验证本地完成率
```

#### 4.5 验收标准

| 指标 | 改造前 | 目标 |
|------|--------|------|
| 本地完成率 | 0% | ~60% |
| 平均响应延迟 | 2-5s | <20ms（本地） |
| LLM 调用成本 | 100% | ~40% |
| 参数增量 | — | +30K (590K→620K) |

---

### Phase 5: 元学习（Week 9）

**目标**: 学习效率随时间增长

#### 5.1 分层 LPR

**修改文件**: `src/brain/right/training/lpr.ts`

当前 LPR 是全局 λ。升级为每层独立 λ：

```typescript
export class LayerwiseLPR {
  // 每层独立的 λ 和快照
  layerConfigs: Map<Tensor, {
    lambda: number;      // 浅层小 λ，深层大 λ
    snapshot: Float32Array;
  }>;

  // ByteEmbedding: λ=0.01（允许大量学习新语言）
  // EncoderBlock: λ=0.05-0.1
  // OutputHeads: λ=0.2（严格保护已学好能力）
  // ReasoningHead: λ=0.05（新模块，允许快速学习）
}
```

#### 5.2 学习策略选择器

**新建文件**: `src/brain/right/training/meta-learner.ts`

三种策略：
- **fast_memorize**: 高学习率、单步更新、低 LPR
- **deep_understand**: 低学习率、多步 replay、高 LPR
- **analogy_transfer**: 从相似经验中迁移

MetaLearner 自身也在线学习 → 策略选择越来越准。

#### 5.3 实施步骤

```
Day 1: 改造 LPR 为分层版本
Day 2: 实现 MetaLearner 类
Day 3: 集成测试 + 验证适应速度提升
```

#### 5.4 验收标准

| 指标 | 改造前 | 目标 |
|------|--------|------|
| 新领域适应速度 | ~50 次交互 | ~20 次交互 |
| 遗忘率 | ~15% | ~5% |
| 参数增量 | — | +5K (620K→625K) |

---

### Phase 6: 多模态扩展（Week 10-11）

**目标**: 支持图片理解和语音输入

#### 6.1 VisionEncoder — 替换像素统计

**修改文件**: `src/brain/right/features/image-encoder.ts`

当前实现只提取像素级统计量（avgColor, variance, edgeStrength）。替换为：

```typescript
export class VisionEncoder {
  // 学习式 patch 投影
  patchProj: Tensor; // [patchSize*channels, embedDim]

  // 2 层 Transformer（复用 EncoderBlock）
  encoderBlocks: EncoderBlock[];

  // 对齐投影：确保视觉向量和文本向量在同一 128 维空间
  alignProj: Tensor; // [visualDim, 128]

  forward(image: RawImage): Float32Array {
    // 1. 图像 → patches → 学习式投影
    // 2. 位置编码
    // 3. Transformer×2
    // 4. 池化 → 对齐到 128 维
  }
}
```

**参数量**: ~180K

#### 6.2 AudioEncoder

**新建文件**: `src/brain/right/features/audio-encoder.ts`

```typescript
export class AudioEncoder {
  // Mel 滤波器（可学习）
  melFilter: Tensor;

  // 卷积压缩
  convWeights: Tensor[];

  // 1 层 Transformer
  encoderBlock: EncoderBlock;

  // 对齐到文本空间
  alignProj: Tensor; // [audioDim, 128]

  forward(audio: Float32Array, sampleRate: number): Float32Array;
}
```

**参数量**: ~120K

#### 6.3 实施步骤

```
Day 1-2: 实现 VisionEncoder（patch projection + transformer + align）
Day 3:   替换 image-encoder.ts，保持 encodeImage() 接口兼容
Day 4-5: 实现 AudioEncoder（mel + conv + transformer + align）
Day 6:   统一多模态融合（交叉注意力）
Day 7:   集成测试
```

#### 6.4 验收标准

| 指标 | 改造前 | 目标 |
|------|--------|------|
| 图片理解 | 看色块 | 识别物体/场景/文字 |
| 语音输入 | 不支持 | 支持（~80% 准确率） |
| 参数增量 | — | +300K (625K→925K) |

---

### Phase 7: 知识凝结（Week 12）

**目标**: 知识从零散变为系统化

#### 7.1 概念聚类

**修改文件**: `src/memory/dream.ts`

扩展 dream.ts 的 Phase 2（提取）：
- 获取所有知识条目的向量（复用 TextEncoder）
- 在 128 维空间中做层次聚类
- 每个簇生成一个高层概念

#### 7.2 知识层次提升

```
Level 0 (原始经验) → Level 1 (模式) → Level 2 (规则) → Level 3 (原理)
```

- Level 0→1: 聚类
- Level 1→2: 规则提取（复用 PolicyDistiller）
- Level 2→3: LLM 辅助归纳

#### 7.3 实施步骤

```
Day 1-2: 扩展 dream.ts 概念聚类
Day 3:   实现知识层次提升
Day 4:   集成测试 + 验证检索精度提升
```

#### 7.4 验收标准

| 指标 | 改造前 | 目标 |
|------|--------|------|
| 知识检索精度 | ~55% | ~70% |
| 参数增量 | — | +0K（算法层面） |

---

## 三、总览

### 参数预算

| Phase | 累计参数 | int8 大小 | 延迟增加 |
|-------|---------|----------|---------|
| 当前 | 300K | ~300KB | — |
| Phase 0 | 445K | ~445KB | +3ms |
| Phase 1 | 460K | ~460KB | +1ms |
| Phase 2 | 510K | ~510KB | +5ms |
| Phase 3 | 590K | ~590KB | +5-15ms |
| Phase 4 | 620K | ~620KB | +2ms |
| Phase 5 | 625K | ~625KB | +0ms |
| Phase 6 | 925K | ~925KB | +5ms |
| Phase 7 | 925K | ~925KB | +0ms |

### 文件变更清单

| 操作 | 文件 | Phase |
|------|------|-------|
| **新建** | `src/brain/right/features/text-encoder.ts` | 0 |
| **修改** | `src/brain/right/features/encoder.ts` | 0 |
| **修改** | `src/brain/right/nn/model.ts` | 0, 2, 3, 4 |
| **修改** | `src/brain/right/index.ts` | 0 |
| **修改** | `src/brain/right/nn/output-heads.ts` | 1 |
| **新建** | `src/brain/right/nn/knowledge-gate.ts` | 2 |
| **新建** | `src/brain/right/nn/reasoning-head.ts` | 3 |
| **新建** | `src/brain/right/nn/generator.ts` | 4 |
| **修改** | `src/brain/right/training/lpr.ts` | 5 |
| **新建** | `src/brain/right/training/meta-learner.ts` | 5 |
| **修改** | `src/brain/right/features/image-encoder.ts` | 6 |
| **新建** | `src/brain/right/features/audio-encoder.ts` | 6 |
| **修改** | `src/memory/dream.ts` | 7 |
| **修改** | `src/brain/brain.ts` | 全程 |

### 风险与缓解

| 风险 | 概率 | 影响 | 缓解措施 |
|------|------|------|---------|
| ByteEncoder 中文效果差 | 中 | 高 | 动态 merge 的熵阈值可调；备选方案：用现有 Embedding + Conv1D |
| Cross-Head Attention 过拟合 | 低 | 中 | Dropout + L2 正则；单头 fallback |
| KnowledgeGate 向量检索慢 | 低 | 中 | 限制知识条目数 (≤1000)；ANN 索引 |
| ReasoningHead 训练数据不足 | 中 | 高 | 从 LLM 蒸馏推理链；NoThinking 并行采样 |
| Generator 模板质量低 | 中 | 中 | 初期手工模板 + 自动学习渐进 |
| VisionEncoder 参数过多 | 低 | 中 | 减少层数/维度；MobileViT 混合架构 |
| 分层 LPR 实现复杂 | 低 | 低 | 现有 LPR 已工作，分层是渐进改进 |

### 回滚策略

每个 Phase 独立可回滚：
1. 通过 feature flag 控制新模块启用
2. 旧路径（关键词匹配/独立头/像素统计）保留为 fallback
3. 新模块通过 `扩展` 接入，不修改现有 forward() 签名
