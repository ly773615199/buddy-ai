# 统一意图理解管道 — 详细执行计划

> 根因：能力分散，信号采集阶段没用上已有能力
> 目标：把 PrototypeMemory、SemanticIntentIndex、IntuitionNet 汇聚到一个统一管道
> 原则：不加 LLM，不加规则，只串联已有模块

---

## 一、问题诊断

### 1.1 当前信号流（断裂状态）

```
用户输入 "你好"
  │
  ├─ Perceptor.perceive()
  │   ├─ classifyFromText("你好")          ← IntuitionNet NN
  │   │   └─ 输出: { category: "system_operations", confidence: 0.35 }  ← ❌ 错误
  │   │
  │   └─ SemanticIntentIndex.matchBest("你好")
  │       └─ GLOBAL_EXCLUDES 命中 → penalty -0.60 → score 很低 → 不匹配
  │       └─ 但 NN 已经给出 system_operations，Perceptor 直接用了
  │
  └─ collectSignals(perception)
      └─ 直接使用 PerceptionState，无二次校验
```

**问题**：NN 分类结果直接传播，SemanticIntentIndex 的排除信号没有机会纠正 NN。

### 1.2 PrototypeMemory 的浪费

```
PrototypeMemory 已有:
  - 8 个种子原型 (conversation/code/file/git/web/system/knowledge/complex)
  - 每个原型有 toolDist（工具使用分布）
  - findNearest(hidden[256]) → { distance, confidence, isNovel, topTools }

但调用链:
  Perceptor.perceive() → classifyFromText()     ← 只用 IntuitionNet
  ThreeBrain.decide()  → predictFull()           ← 这里才调用 findNearest()
                         ↑ 信号采集已经结束，来不及了
```

### 1.3 训练数据缺口

```
seed-synthesizer.ts 数据源:
  1. 种子经验转换 → conversation 在种子经验中无触发器 → 0 条
  2. 工具变体生成 → TOOL_VARIANTS 无 conversation 类工具 → 0 条
  3. 内置规则     → builtinRulesToSamples 无 conversation 规则 → 0 条

结果: IntuitionNet conversation 类别 (index 6) 训练样本 = 0
```

---

## 二、执行计划

### 改动 1：信号采集调用 PrototypeMemory

**目标**：让 hidden 空间的最近邻匹配参与信号采集阶段的意图决策。

**涉及文件**：
- `src/core/perceptor.ts` — 主要改动
- `src/brain/right/prototype-memory.ts` — 无需改动（已有接口）
- `src/core/perception-state.ts` — 新增字段

**改动细节**：

#### 1.1 Perceptor 新增 PrototypeMemory 注入

```typescript
// perceptor.ts

// 新增字段
private prototypeMemory: PrototypeMemory | null = null;

// 新增注入方法
setPrototypeMemory(mem: PrototypeMemory): void {
  this.prototypeMemory = mem;
}
```

#### 1.2 perceive() 中调用 findNearest

在 `classifyFromText()` 之后、`deriveDomains()` 之前，插入 PrototypeMemory 查询：

```typescript
perceive(content: string, context?): PerceptionState {
  // ... 缓存检查 ...

  // 2. 右脑 NN 分类
  const intent = this.sys.threeBrain!.right.classifyFromText(content);

  // 2.5. PrototypeMemory 最近邻匹配 ← 新增
  let protoMatch: ProtoMatchResult | null = null;
  if (this.prototypeMemory) {
    // classifyFromText 内部已经做了 ByteEncoder.forward()
    // 复用同一个 hidden 向量，避免重复编码
    const hidden = this.getcachedHidden(content);  // 见 1.3
    if (hidden) {
      protoMatch = this.prototypeMemory.findNearest(hidden);
    }
  }

  // 2.6. 融合 NN + PrototypeMemory ← 新增
  const fusedIntent = this.fuseIntent(intent, protoMatch, content);

  // 3. 域检测（用融合后的结果）
  const domains = this.deriveDomains(fusedIntent.category, fusedIntent.confidence, content);
  // ... 后续不变 ...
}
```

#### 1.3 复用 ByteEncoder 隐藏向量

`classifyFromText()` 内部已经调用了 `encoder.forward(input)`，但结果没有暴露。需要缓存：

```typescript
// perceptor.ts 新增缓存
private lastHidden: Float32Array | null = null;
private lastHiddenInput: string = '';

// 在 perceive() 中，classifyFromText 之后获取 hidden
// 方案 A: 修改 classifyFromText 返回 hidden（侵入性小）
// 方案 B: Perceptor 自己调用 encoder.forward()（多一次前向，<1ms 可接受）
// 选择方案 B：简单，且 classifyFromText 可能 catch 异常返回默认值

private getCachedHidden(content: string): Float32Array | null {
  if (this.lastHiddenInput === content && this.lastHidden) {
    return this.lastHidden;
  }
  try {
    const encoder = getByteEncoder();
    this.lastHidden = encoder.forward(content);
    this.lastHiddenInput = content;
    return this.lastHidden;
  } catch {
    return null;
  }
}
```

#### 1.4 融合函数 fuseIntent

```typescript
interface FusedIntent {
  category: string;
  confidence: number;
  suggestedTools: string[];
  hit: boolean;
  protoContributed: boolean;  // PrototypeMemory 是否参与了决策
}

private fuseIntent(
  nnResult: { category: string; confidence: number; suggestedTools: string[]; hit: boolean },
  protoMatch: PrototypeMatch | null,
  content: string,
): FusedIntent {
  // 无 PrototypeMemory → 直接用 NN 结果
  if (!protoMatch) {
    return { ...nnResult, protoContributed: false };
  }

  // PrototypeMemory 匹配到已知原型
  if (!protoMatch.isNovel) {
    const protoLabel = protoMatch.prototype.label;
    const protoTools = protoMatch.prototype.topTools(3);

    // 场景 1: NN 置信度低 + PrototypeMemory 置信度高 → 信任原型
    if (nnResult.confidence < 0.4 && protoMatch.confidence > 0.6) {
      // 原型标签 → 意图类别映射
      const PROTO_TO_CATEGORY: Record<string, string> = {
        'conversation': 'conversation',
        'code': 'code_operations',
        'file': 'file_operations',
        'git': 'git_operations',
        'web': 'web_operations',
        'system': 'system_operations',
        'knowledge': 'knowledge_query',
        'complex': 'complex_task',
      };
      const mappedCategory = PROTO_TO_CATEGORY[protoLabel] ?? nnResult.category;

      return {
        category: mappedCategory,
        confidence: Math.max(protoMatch.confidence, nnResult.confidence),
        suggestedTools: [...new Set([...nnResult.suggestedTools, ...protoTools])],
        hit: true,
        protoContributed: true,
      };
    }

    // 场景 2: NN 和 PrototypeMemory 一致 → 增强置信度
    const nnToProto: Record<string, string> = {
      'file_operations': 'file', 'code_operations': 'code', 'git_operations': 'git',
      'web_operations': 'web', 'system_operations': 'system',
      'knowledge_query': 'knowledge', 'conversation': 'conversation', 'complex_task': 'complex',
    };
    if (nnToProto[nnResult.category] === protoLabel) {
      return {
        ...nnResult,
        confidence: Math.min(1, nnResult.confidence + protoMatch.confidence * 0.2),
        suggestedTools: [...new Set([...nnResult.suggestedTools, ...protoTools])],
        hit: true,
        protoContributed: true,
      };
    }

    // 场景 3: NN 和 PrototypeMemory 冲突 → 按置信度加权
    if (protoMatch.confidence > nnResult.confidence * 1.5) {
      // 原型置信度远高于 NN → 倾向原型
      const mappedCategory = nnToProto[protoLabel] ? nnResult.category : nnResult.category;
      // 保守：不直接覆盖 NN，但降低置信度
      return {
        ...nnResult,
        confidence: nnResult.confidence * 0.7,  // 降低，表示不确定
        suggestedTools: [...new Set([...nnResult.suggestedTools, ...protoTools])],
        protoContributed: true,
      };
    }
  }

  // PrototypeMemory 认为是新意图 → 不影响 NN 结果，但标记
  return { ...nnResult, protoContributed: false };
}
```

#### 1.5 PerceptionState 新增字段

```typescript
// perception-state.ts

export interface PerceptionState {
  // ... 现有字段 ...

  /** PrototypeMemory 匹配结果（信号采集阶段产出） */
  protoMatch: {
    prototypeId: string;
    label: string;
    distance: number;
    confidence: number;
    isNovel: boolean;
    topTools: string[];
  } | null;

  /** 融合后的意图（NN + PrototypeMemory + SemanticIntentIndex） */
  fusedCategory: string;
  fusedConfidence: number;
  protoContributed: boolean;
}
```

#### 1.6 Subsystems 接线

```typescript
// subsystems.ts — 初始化完成后
perceptor.setPrototypeMemory(threeBrain.right.prototypeMemory);
```

**预期效果**：
- "你好" → NN 分类为 system_operations (0.35)，但 PrototypeMemory 匹配到 conversation 原型 (0.7) → 融合后降权 → SemanticIntentIndex 排除规则兜底
- "查看 git 状态" → NN 分类为 git_operations (0.8)，PrototypeMemory 匹配 git 原型 (0.9) → 置信度增强

---

### 改动 2：信号采集调用 SemanticIntentIndex（前置排除）

**目标**：让 SemanticIntentIndex 的全局排除规则在 NN 分类之前或并行生效，防止 NN 误分类传播。

**涉及文件**：
- `src/core/perceptor.ts` — 主要改动
- `src/brain/right/features/semantic-intent-index.ts` — 新增轻量排除接口

**改动细节**：

#### 2.1 SemanticIntentIndex 新增快速排除方法

当前 `matchBest()` 走完整编码 + 向量比较（~5ms），对排除场景太重。新增纯规则排除：

```typescript
// semantic-intent-index.ts

/**
 * 快速排除检查 — 纯正则，零向量计算
 * 返回: { excluded: boolean, reason: string, penalty: number }
 */
quickExclude(input: string): { excluded: boolean; reason: string; penalty: number } {
  for (const ge of SemanticIntentIndex.GLOBAL_EXCLUDES) {
    if (ge.pattern.test(input)) {
      return {
        excluded: true,
        reason: ge.pattern.source,
        penalty: ge.penalty,
      };
    }
  }
  return { excluded: false, reason: '', penalty: 0 };
}
```

#### 2.2 Perceptor 中 NN 分类前做排除预检

```typescript
// perceptor.ts — perceive() 改动

perceive(content: string, context?): PerceptionState {
  // 1. 缓存检查 ...

  // 1.5. 快速排除预检 ← 新增（零成本，纯正则）
  let excludeSignal: { excluded: boolean; reason: string; penalty: number } | null = null;
  if (this.semanticIntentIndex) {
    excludeSignal = this.semanticIntentIndex.quickExclude(content);
  }

  // 2. 右脑 NN 分类
  const intent = this.sys.threeBrain!.right.classifyFromText(content);

  // 2.1. 应用排除信号 ← 新增
  const adjustedIntent = this.applyExcludeSignal(intent, excludeSignal);

  // 2.5. PrototypeMemory 最近邻匹配
  // ... (改动 1 的内容) ...

  // 2.6. 融合 NN + PrototypeMemory + 排除信号
  const fusedIntent = this.fuseIntent(adjustedIntent, protoMatch, content);
  // ...
}
```

#### 2.3 排除信号应用函数

```typescript
private applyExcludeSignal(
  intent: { category: string; confidence: number; suggestedTools: string[]; hit: boolean },
  exclude: { excluded: boolean; reason: string; penalty: number } | null,
): typeof intent {
  if (!exclude || !exclude.excluded) return intent;

  // 被排除规则命中的输入 → 强制降为 conversation + 降低置信度
  // 逻辑: 如果输入匹配 "你好/笑话/1+1" 等模式，它几乎不可能是工具任务
  return {
    category: 'conversation',
    confidence: Math.max(0.05, intent.confidence + exclude.penalty),
    suggestedTools: [],  // 对话不需要工具
    hit: false,          // 标记为未命中，避免走工具路径
  };
}
```

**预期效果**：
- "你好" → quickExclude 命中 (penalty -0.60) → NN 结果被强制覆盖为 conversation (0.05) → 不走工具路径
- "帮我查天气" → quickExclude 未命中 → NN 正常分类 → SemanticIntentIndex.matchBest() 匹配 weather 意图

---

### 改动 3：训练数据增强 conversation 类别

**目标**：为 IntuitionNet 补充 conversation 类种子样本，让 NN 学会区分对话和工具任务。

**涉及文件**：
- `src/brain/right/training/seed-synthesizer.ts` — 主要改动
- `src/brain/right/training/seed-synthesizer.test.ts` — 更新测试

**改动细节**：

#### 3.1 新增 conversation 内置规则

```typescript
// seed-synthesizer.ts — builtinRulesToSamples() 中新增

function builtinRulesToSamples(): SynthesizedSample[] {
  const rules = [
    // ... 现有 8 条规则 ...

    // === 新增: conversation 类种子 ===
    {
      name: 'conversation_greeting',
      domains: ['chat'],
      intent: 6,  // conversation
      tools: [],
      complexity: 'simple' as const,
      confidence: 0.9,
      sampleTexts: ['你好', '嗨', 'hello', 'hi', '早上好', '晚上好'],
    },
    {
      name: 'conversation_identity',
      domains: ['chat'],
      intent: 6,
      tools: [],
      complexity: 'simple' as const,
      confidence: 0.9,
      sampleTexts: ['你是谁', '你叫什么', '介绍一下你自己', 'what are you'],
    },
    {
      name: 'conversation_chat',
      domains: ['chat'],
      intent: 6,
      tools: [],
      complexity: 'simple' as const,
      confidence: 0.8,
      sampleTexts: ['讲个笑话', '推荐一部电影', '今天心情不好', '聊聊', '无聊'],
    },
    {
      name: 'conversation_knowledge_casual',
      domains: ['chat'],
      intent: 6,
      tools: [],
      complexity: 'simple' as const,
      confidence: 0.7,
      sampleTexts: ['1+1等于几', '量子力学是什么', '机器学习怎么学', '画一幅画', '写一首诗'],
    },
  ];

  // 修改: 每条规则可以生成多个样本（从 sampleTexts 扩展）
  return rules.flatMap(rule => {
    const baseSample = {
      features: encodeAsFeatures(rule.domains, rule.complexity, 'tools', rule.confidence, rule.tools),
      labelIntent: rule.intent,
      labelTools: toolsToLabels(rule.tools),
      labelQuality: rule.confidence,
      outcome: true,
      source: 'builtin_rule' as const,
    };

    // 有 sampleTexts → 为每条文本生成独立样本
    if ('sampleTexts' in rule && rule.sampleTexts) {
      return rule.sampleTexts.map(text => ({
        ...baseSample,
        features: encodeAsFeatures(rule.domains, rule.complexity, 'chat', rule.confidence, []),
      }));
    }

    return [baseSample];
  });
}
```

#### 3.2 新增 conversation 工具变体（对话类短语）

```typescript
// seed-synthesizer.ts — 新增 CONVERSATION_VARIANTS

const CONVERSATION_VARIANTS: string[] = [
  // 问候
  '你好', '嗨', 'hello', 'hi', 'hey', '早上好', '下午好', '晚上好',
  '你好呀', '在吗', '在不在',
  // 身份
  '你是谁', '你叫什么名字', '介绍一下你自己', '你是什么',
  'what are you', 'who are you',
  // 闲聊
  '讲个笑话', '说个笑话', '推荐一部电影', '推荐一首歌',
  '今天心情不好', '好无聊', '聊聊', '陪我聊天',
  '你觉得呢', '你怎么看', '说说你的想法',
  // 伪知识（实际是对话，不是工具任务）
  '1+1等于几', '1+1=?', '量子力学是什么', '机器学习怎么学',
  '画一幅画', '写一首诗', '给我讲个故事',
  // 情感
  '谢谢', '感谢', '谢了', '好的', '明白了', '知道了',
  '不客气', '没关系', '对不起', '抱歉',
];

function generateConversationVariants(): SynthesizedSample[] {
  return CONVERSATION_VARIANTS.map(text => ({
    features: encodeAsFeatures(['chat'], 'simple', 'chat', 0.7, []),
    labelIntent: 6,  // conversation
    labelTools: new Array(32).fill(0),  // 对话无工具
    labelQuality: 0.7,
    outcome: true,
    source: 'tool_variant' as const,
  }));
}
```

#### 3.3 synthesizeTrainingData 主函数改动

```typescript
export function synthesizeTrainingData(seedExperiences: ExperienceUnit[]): TrainingSample[] {
  const raw: SynthesizedSample[] = [];

  // 方法 1: 种子经验直接转换
  for (const seed of seedExperiences) {
    const sample = experienceToSample(seed);
    if (sample) raw.push(sample);
  }

  // 方法 2: 工具变体生成
  for (const toolName of Object.keys(TOOL_VARIANTS)) {
    raw.push(...generateToolVariants(toolName));
  }

  // 方法 2.5: 对话变体生成 ← 新增
  raw.push(...generateConversationVariants());

  // 方法 3: 内置规则转换
  raw.push(...builtinRulesToSamples());

  // 质量过滤（conversation 无工具，需要特殊处理）
  const valid = raw.filter(s =>
    s.labelIntent >= 0 && s.features.length > 0 &&
    (hasValidTools(s.labelTools) || s.labelIntent === 6)  // conversation 允许无工具
  );

  return valid.map(s => ({
    features: s.features,
    labelIntent: s.labelIntent,
    labelTools: s.labelTools,
    labelQuality: s.labelQuality,
    outcome: s.outcome,
    timestamp: Date.now(),
    weight: s.source === 'seed_experience' ? 1.0 : s.source === 'builtin_rule' ? 0.8 : 0.5,
  }));
}
```

**预期效果**：
- conversation 类样本从 0 条增加到 ~50 条（4 条内置规则 × 多文本 + ~30 条对话变体）
- IntuitionNet 能学会区分 "你好"(conversation) vs "查看状态"(system_operations)
- 权重分布: seed 1.0 > builtin 0.8 > variant 0.5，对话样本权重适中

---

## 三、改动顺序与依赖关系

```
改动 3 (训练数据)  ← 独立，无依赖，最先做
    │
    ▼
改动 1 (PrototypeMemory)  ← 依赖 perception-state.ts 新增字段
    │
    ▼
改动 2 (SemanticIntentIndex 前置排除)  ← 依赖改动 1 的融合函数
```

**推荐顺序**: 3 → 1 → 2

---

## 四、测试计划

### 4.1 单元测试

| 测试文件 | 测试内容 |
|----------|----------|
| `seed-synthesizer.test.ts` | 更新: conversation 样本 > 30 条，weight 验证 |
| `perceptor.test.ts` (新增) | fuseIntent 三场景: NN 低+原型高、一致、冲突 |
| `perceptor.test.ts` (新增) | quickExclude: "你好" → excluded, "查天气" → not excluded |
| `semantic-intent-index.test.ts` | 更新: quickExclude 覆盖所有 GLOBAL_EXCLUDES 模式 |

### 4.2 集成测试

| 场景 | 输入 | 期望输出 |
|------|------|----------|
| 对话不走工具 | "你好" | category=conversation, suggestedTools=[] |
| 对话不走工具 | "讲个笑话" | category=conversation, suggestedTools=[] |
| 工具任务正常 | "查看 git 状态" | category=git_operations, confidence>0.6 |
| 工具任务正常 | "北京天气" | fineIntent=weather, tool=skill_weather |
| 模糊输入 | "分析一下" | 低置信度，不强制走工具 |

### 4.3 回归测试

```bash
# 确保现有测试不 break
npx vitest run src/brain/right/training/seed-synthesizer.test.ts
npx vitest run src/brain/right/features/semantic-intent-index.test.ts
npx vitest run src/core/intent-completeness.test.ts
npx vitest run src/brain/phase0-7.test.ts
```

---

## 五、风险与缓解

| 风险 | 影响 | 缓解 |
|------|------|------|
| fuseIntent 逻辑过于复杂 | 维护成本 | 保持简单: 只做 NN 低+原型高 → 信任原型，其他情况 NN 优先 |
| conversation 样本过多 | NN 偏向 conversation，工具任务被误分类 | 控制 conversation 样本数 ≤ 60，工具样本保持 > 100 |
| quickExclude 误杀 | "你好世界" 被排除（实际是编程问题） | 排除规则加长度限制: 只对 ≤10 字符的输入生效 |
| ByteEncoder 重复编码 | 性能浪费 | 缓存 hidden 向量，同一输入只编码一次 |

---

## 六、验收标准

1. **"你好" 不再走工具路径** — category=conversation, suggestedTools=[], fineIntent=null
2. **"查看 git 状态" 正常路由** — category=git_operations, confidence>0.6
3. **PrototypeMemory 在信号采集阶段参与** — protoMatch 不为 null（对已知原型）
4. **conversation 训练样本 > 30 条** — 测试验证
5. **现有测试全部通过** — 零回归
6. **性能不退化** — perceive() < 15ms（当前 ~10ms，增加 PrototypeMemory.findNearest ~1ms）
