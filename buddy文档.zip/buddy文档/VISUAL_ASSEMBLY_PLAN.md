# 可视化组装计划：从纯文本到图文混排

> **目标**：让组装引擎能输出思维导图、流程图、架构图、知识图谱等可视化内容，而不只是纯文本。
>
> **核心原则**：零外部服务、零付费、最小依赖、服务端渲染。

---

## 一、问题分析

### 1.1 现状

组装引擎是纯文本管线：

```
检索 → Reranker → ContentSelector → ParagraphPlanner → string
                                                          ↑
                                                    唯一输出格式
```

**已有但未利用的数据**：
- `KnowledgeGraph` — 实体 + 边，天然就是图结构
- `GraphExpand` — 多跳扩展，能生成子图
- `ExplorationMap` (前端) — 能展示节点列表，但不是自动生成的图

**缺失**：
- 没有"图结构 → 可视化描述"的转换层
- `AssemblyResult` 只有 `text: string`，无法携带图
- 没有服务端 SVG/PNG 渲染能力

### 1.2 项目现有渲染引擎分析

项目有一套完整的 Three.js 精灵渲染系统，但**无法复用于通用绘图**：

| 组件 | 职责 | 能复用吗 |
|-----|------|---------|
| `BuddyRenderer` | Three.js 核心（场景/相机/灯光/后处理） | ❌ 角色专用 |
| `OrbMesh` | GLSL Shader 光团（Fresnel + 呼吸脉动） | ❌ 角色专用 |
| `HumanoidMesh` | 基因驱动顶点变形（球体→人形） | ❌ 角色专用 |
| `HumanoidSkeleton` | 骨骼动画（尾巴/翅膀/耳朵） | ❌ 角色专用 |
| `ParticleSystem` | 情绪驱动粒子特效 | ❌ 角色专用 |
| `CostumeRenderer` | 服饰渲染（程序化 mesh + 模板） | ❌ 角色专用 |
| `Canvas2DFallback` | WebGL 不可用时的降级方案 | ❌ 仅画光团 |
| `Playwright` | E2E 测试截图 | ✅ **可复用** |

**`Canvas2DFallback` 详细分析**：
- `draw()` 方法仅包含 `arc()` + `createRadialGradient()`
- 硬编码画多层径向渐变圆（发光球体）+ 粒子
- 没有 `lineTo()`、`fillRect()`、`fillText()`、`stroke()` 等通用绘图 API
- 无法扩展为通用 Canvas2D 引擎

**结论**：除 Playwright 外，现有渲染引擎全部是角色专用，无法复用于图表/设计稿/素描等通用绘图场景。

### 1.2 需要支持的可视化类型

| 类型 | 场景 | 数据源 |
|-----|------|--------|
| **思维导图** | 概念梳理、知识总结 | Outline 结构 |
| **流程图** | 步骤说明、决策树 | 检索到的步骤/流程文本 |
| **架构图** | 系统设计、模块关系 | KnowledgeGraph entities/edges |
| **知识图谱** | 实体关系可视化 | KnowledgeGraph.exportData() |
| **时间线** | 事件序列 | 检索到的时间线数据 |
| **表格对比** | 多方案对比 | ContentSelector 输出的多组数据 |

---

## 二、方案对比

### 2.1 渲染方案选型

| 方案 | 外部依赖 | 费用 | 输出格式 | 质量 | 服务端可用 | 复杂度 |
|-----|---------|------|---------|------|-----------|--------|
| **A. 纯 SVG 字符串拼接** | 零 | 免费 | SVG | 手控 | ✅ | 高（需手写布局） |
| **B. Mermaid 语法 + jsdom 渲染** | `mermaid` + `jsdom` | 免费 | SVG | ⭐⭐⭐⭐⭐ | ✅ | 中 |
| **C. Mermaid CLI (mmdc)** | `@mermaid-js/mermaid-cli` (含 Chromium) | 免费 | SVG/PNG | ⭐⭐⭐⭐⭐ | ✅ | 低（但包大） |
| **D. Graphviz (dot)** | 系统包 `graphviz` | 免费 | SVG/PNG | ⭐⭐⭐⭐ | ✅ | 低 |
| **E. D3.js** | `d3` + `jsdom` | 免费 | SVG | ⭐⭐⭐⭐⭐ | ✅ | 高 |
| **F. 外部 API (Mermaid.ink 等)** | 网络请求 | 免费（有限额） | PNG | ⭐⭐⭐⭐ | ⚠️ 依赖外部 | 极低 |

### 2.2 推荐方案：B + A 混合

**主要方案：Mermaid 语法 + jsdom 渲染**

理由：
- `mermaid` 是 npm 包，纯 JS，**不需要 Chromium**
- `jsdom` 提供 DOM 环境，项目已有类似依赖（Playwright 用于测试）
- Mermaid 语法简洁，天然适合思维导图/流程图/架构图
- 输出 SVG，可直接嵌入或转 PNG

**辅助方案：纯 SVG 字符串拼接**

用于 Mermaid 覆盖不了的场景（自定义布局、特殊图表）。

**不采用的方案**：
- ❌ mmdc (Mermaid CLI)：包含 Chromium，体积太大（~300MB）
- ❌ 外部 API：违反零外部依赖原则
- ❌ D3：太重，学习曲线高，Mermaid 已覆盖大部分场景
- ❌ Graphviz：需要系统级安装，增加部署复杂度

---

## 三、依赖分析

### 3.1 需要新增的 npm 包

| 包 | 用途 | 大小 | 是否必须 |
|---|------|------|---------|
| `mermaid` | 图表渲染引擎 | ~2MB (gzipped) | ✅ 核心 |
| `jsdom` | 服务端 DOM 环境 | ~1MB | ✅ 核心 |

**总计：~3MB**，对比 mmdc 的 ~300MB，极轻量。

### 3.2 不需要的

| 项目 | 原因 |
|-----|------|
| 外部 API | 零外部依赖原则 |
| Chromium/Puppeteer | jsdom 替代 |
| 系统级包 | 纯 npm 方案 |
| 付费服务 | 全部开源免费 |

### 3.3 费用总结

| 项目 | 费用 |
|-----|------|
| npm 包 (mermaid, jsdom) | **¥0**（开源免费） |
| 外部 API 调用 | **¥0**（不使用） |
| 系统级安装 | **¥0**（不需要） |
| 运行时开销 | **极低**（SVG 渲染是 CPU 操作，无网络） |

**结论：零成本，零外部依赖，纯本地运算。**

---

## 四、架构设计

### 4.1 核心思想

**组装引擎是三脑的执行器，不是决策者。**

可视化决策在三脑侧完成：
- **右脑**（直觉）：感知内容是否有图表特征，输出 `IntuitionSignal.visualHint`
- **左脑**（规则引擎）：根据显式请求或直觉提示，决策是否可视化，输出 `ExecutionPlan.visualDirective`
- **组装引擎**（执行）：接收 `visualDirective`，翻译数据 → Mermaid 语法 → SVG，不做任何判断

```
三脑决策层：
  右脑 IntuitionSignal { visualHint?: { kind, confidence } }
    ↓
  左脑 RuleEngine → ExecutionPlan { visualDirective?: { kind, data } }
    ↓
组装引擎执行层：
  process(input, pooled, context, visualDirective)
    ↓
  VisualAssembler（纯翻译：data → Mermaid 语法）
    ↓
  SvgRenderer（Mermaid → SVG）
    ↓
  AssemblyResult { text, visuals[] }
```

### 4.2 文件结构

```
src/brain/right/features/
├── visual-assembler.ts          # 核心：知识结构 → Mermaid 语法
├── svg-renderer.ts              # Mermaid → SVG（jsdom + mermaid）
├── visual-types.ts              # 类型定义
└── __tests__/
    ├── visual-assembler.test.ts # 组装逻辑测试
    └── svg-renderer.test.ts     # 渲染测试
```

### 4.3 类型定义

```typescript
// visual-types.ts

/** 可视化块类型 */
export type VisualKind = 'mindmap' | 'flowchart' | 'graph' | 'timeline' | 'table';

/** 可视化块 */
export interface VisualBlock {
  /** 类型 */
  kind: VisualKind;
  /** Mermaid 语法 或 SVG 字符串 */
  content: string;
  /** 渲染后的 SVG（由 SvgRenderer 填充） */
  svg?: string;
  /** 可选标题 */
  title?: string;
  /** 元数据 */
  metadata?: Record<string, unknown>;
}

/** 扩展 AssemblyResult */
export interface AssemblyResult {
  text: string;
  visuals?: VisualBlock[];   // 新增
  path: 'assembly' | 'nn' | 'hybrid';
  assemblyConfidence: number;
  nnConfidence?: number;
  trace?: PipelineTrace;
}
```

### 4.4 VisualAssembler 核心逻辑

**纯翻译器，不做任何判断。** 所有方法都是：输入数据 → 输出 Mermaid 语法。

```typescript
// visual-assembler.ts

export class VisualAssembler {

  /**
   * KnowledgeGraph → Mermaid graph 语法
   * 由三脑通过 visualDirective.data 传入
   */
  graphToMermaid(data: GraphData, direction?: 'LR' | 'TD' | 'RL' | 'BT'): string { ... }

  /**
   * 大纲结构 → Mermaid mindmap 语法
   */
  outlineToMindmap(root: string, sections: OutlineSection[]): string { ... }

  /**
   * 纯文本 → 思维导图（自动提取大纲）
   */
  textToMindmap(text: string): string { ... }

  /**
   * 步骤列表 → Mermaid flowchart 语法
   */
  stepsToFlowchart(steps: string[], direction?: 'TD' | 'LR'): string { ... }

  /**
   * 纯文本 → 流程图（自动提取步骤）
   */
  textToFlowchart(text: string): string { ... }

  /**
   * 时间线事件 → Mermaid timeline 语法
   */
  eventsToTimeline(title: string, events: TimelineEvent[]): string { ... }

  /**
   * 纯文本 → 时间线（自动提取事件）
   */
  textToTimeline(text: string): string { ... }

  /**
   * 交互描述 → Mermaid sequenceDiagram 语法
   */
  interactionsToSequence(interactions: Array<{from, to, message, note?}>): string { ... }

  /**
   * 比例数据 → Mermaid pie 语法
   */
  dataToPie(title: string, slices: Array<{label, value}>): string { ... }
}
```

**注意：`shouldVisualize()` 已移除** — 判断逻辑在三脑左脑规则引擎中（`rule-engine.ts` 的 `builtin-visual-request` 规则），不在组装引擎。

### 4.5 SvgRenderer 核心逻辑

```typescript
// svg-renderer.ts

import { JSDOM } from 'jsdom';
import mermaid from 'mermaid';

export class SvgRenderer {
  private dom: JSDOM;

  constructor() {
    // jsdom 提供 DOM 环境
    this.dom = new JSDOM('<!DOCTYPE html><html><body></body></html>');
    // mermaid 初始化（绑定到 jsdom 的 window）
    mermaid.initialize({
      startOnLoad: false,
      theme: 'default',
      securityLevel: 'loose',
    });
  }

  /**
   * Mermaid 语法 → SVG 字符串
   */
  async render(mermaidSyntax: string): Promise<string> {
    const id = `mermaid-${Date.now()}-${Math.random().toString(36).slice(2)}`;
    const { svg } = await mermaid.render(id, mermaidSyntax);
    return svg;
  }

  /**
   * SVG 字符串 → PNG Buffer（可选）
   * 使用 sharp（如果安装了）或直接返回 SVG
   */
  async toPng?(svg: string): Promise<Buffer> {
    // sharp 是可选依赖
    // 如果没有 sharp，直接返回 SVG 也行
  }
}
```

### 4.6 与三脑的集成

**决策流（三脑 → 组装引擎）**：

```
用户输入
  ↓
小脑（感知融合）→ 右脑（直觉）
  ↓
IntuitionSignal {
  intent: { category, confidence },
  visualHint?: { kind: 'mindmap', confidence: 0.7 }  ← 新增
}
  ↓
左脑 RuleEngine.evaluate(signal, resources, intuition)
  ↓
规则匹配：
  - 显式请求（"画个架构图"）→ 直接命中
  - visualHint.confidence >= 0.6 → 命中
  - 都不满足 → 无 visualDirective
  ↓
ExecutionPlan {
  mode: 'single',
  visualDirective: { kind: 'mindmap', data: {...} }  ← 新增
}
  ↓
组装引擎 process(input, pooled, context, plan.visualDirective)
  ↓
executeVisual(directive) → VisualAssembler 翻译 → SvgRenderer 渲染
  ↓
AssemblyResult { text, visuals[] }
```

**组装引擎不包含任何判断逻辑**，只做：
1. 检查 `visualDirective` 是否存在
2. 根据 `kind` 调用对应的翻译方法
3. 调用 `SvgRenderer.render()` 渲染 SVG
4. 渲染失败 → 返回空 visuals，不阻断文本输出

---

## 五、实现步骤

### Phase 1：基础设施（types + SvgRenderer）

**文件**：`src/brain/right/features/visual-types.ts`
- 定义 `VisualKind`, `VisualBlock`, 扩展 `AssemblyResult`

**文件**：`src/brain/right/features/svg-renderer.ts`
- jsdom + mermaid 初始化
- `render(mermaidSyntax) → SVG string`
- 单元测试：输入 Mermaid 语法 → 输出有效 SVG

**依赖安装**：
```bash
npm install mermaid jsdom
npm install -D @types/jsdom
```

### Phase 2：VisualAssembler 核心

**文件**：`src/brain/right/features/visual-assembler.ts`

按优先级实现：
1. `graphToMermaid()` — KnowledgeGraph → 图（最直接，数据已有）
2. `outlineToMindmap()` — 大纲 → 思维导图
3. `stepsToFlowchart()` — 步骤 → 流程图
4. `eventsToTimeline()` — 时间线
5. 翻译方法（9 种图表类型）

**测试**：`src/brain/right/features/__tests__/visual-assembler.test.ts`
- mock KnowledgeGraph 数据 → 验证 Mermaid 语法正确性
- 各类型输入 → 验证输出格式

### Phase 3：组装引擎集成

**改动文件**：`src/brain/right/features/assembly-bridge.ts`
- `AssemblyResult` 类型扩展（加 `visuals` 字段）
- `process()` 方法末尾加入可视化逻辑
- 渲染失败不阻断文本输出（graceful degradation）

**改动文件**：`src/brain/right/features/integration-engine.ts`
- `process()` 返回值扩展

### Phase 4：前端渲染

**改动文件**：前端组件
- 新增 `VisualBlock` 渲染组件
- 接收 SVG 字符串直接渲染（或用 `dangerouslySetInnerHTML`）
- 思维导图/流程图/架构图 各一个展示组件

### Phase 5：智能判断优化

**改进 `shouldVisualize()`**：
- 左脑规则引擎 `builtin-visual-request` 规则
- 右脑直觉 `visualHint` 信号
- 规则引擎可学习（`addLearnedRule` 支持用户偏好）

---

## 六、Mermaid 语法示例

### 6.1 思维导图

```mermaid
mindmap
  root((搜索重构))
    基础设施
      类型定义
      意图路由
      分数标准化
    Provider
      Wikipedia
      StackOverflow
      GitHub
      MDN
    集成
      注册检索源
      SearchArbiter 适配
```

### 6.2 流程图

```mermaid
flowchart TD
  A[用户输入] --> B{需要搜索?}
  B -->|是| C[IntentRouter 路由]
  B -->|否| D[本地检索]
  C --> E[并发查询多个源]
  E --> F[分数标准化 z-score]
  F --> G[Reranker 排序]
  D --> G
  G --> H[ContentSelector 去重]
  H --> I[组装引擎输出]
```

### 6.3 知识图谱

```mermaid
graph LR
  ML[机器学习] -->|包含| SL[监督学习]
  ML -->|包含| UL[无监督学习]
  ML -->|包含| RL[强化学习]
  SL -->|使用| NN[神经网络]
  SL -->|使用| SVM[支持向量机]
  NN -->|变体| CNN[卷积网络]
  NN -->|变体| RNN[循环网络]
  CNN -->|应用于| CV[计算机视觉]
  RNN -->|应用于| NLP[自然语言处理]
```

### 6.4 时间线

```mermaid
timeline
  title 搜索重构里程碑
  Phase 1 : 基础设施 : types + router + normalizer
  Phase 2 : Provider : 9 个源实现
  Phase 3 : 引擎接入 : registerAssemblySource
  Phase 4 : Arbiter 适配 : execute 改造
  Phase 5 : 分数标准化 : z-score
  Phase 6 : 旧代码清理
  Phase 7 : 测试
```

---

## 七、风险与缓解

| 风险 | 影响 | 缓解 |
|-----|------|------|
| jsdom 兼容性问题 | mermaid 渲染失败 | 降级到纯 SVG 字符串拼接 |
| Mermaid 语法复杂 | 生成的语法不合法 | 语法校验 + 简化模板 |
| 图太大导致渲染慢 | 用户体验差 | 限制节点数（最多 20 个）|
| 服务端内存占用 | jsdom + mermaid 开销 | 懒初始化 + 复用实例 |
| 中文显示问题 | 乱码 | 指定字体 fallback |

---

## 八、里程碑

| 阶段 | 内容 | 预估工作量 |
|-----|------|----------|
| Phase 1 | 基础设施（types + SvgRenderer） | 小 |
| Phase 2 | VisualAssembler（4 种图类型） | 中 |
| Phase 3 | 组装引擎集成 | 小 |
| Phase 4 | 前端渲染组件 | 中 |
| Phase 5 | 智能判断优化 | 小 |

---

## 九、费用总结

| 项目 | 费用 | 说明 |
|-----|------|------|
| npm 包 (mermaid, jsdom) | **¥0** | 开源免费 |
| @types/jsdom (devDep) | **¥0** | 开源免费 |
| 外部 API | **¥0** | 不使用 |
| 系统级安装 | **¥0** | 不需要 |
| 运行时网络请求 | **¥0** | 纯本地 SVG 渲染 |
| **总计** | **¥0** | 零成本方案 |

**新增依赖**：`mermaid` (~2MB) + `jsdom` (~1MB) = **~3MB**
**对比**：如果用 Mermaid CLI (mmdc)，需要 ~300MB（含 Chromium）

---

## 十、扩展性

### 10.1 未来可加的图表类型

| 类型 | Mermaid 支持 | 复杂度 |
|-----|-------------|--------|
| 甘特图 | ✅ `gantt` | 低 |
| 状态图 | ✅ `stateDiagram` | 低 |
| 序列图 | ✅ `sequenceDiagram` | 低 |
| 饼图 | ✅ `pie` | 极低 |
| ER 图 | ✅ `erDiagram` | 低 |

### 10.2 与搜索模块的联动

搜索模块（`SEARCH_REFACTOR_PLAN.md`）的 KnowledgeGraph 数据可以直接喂给 VisualAssembler：
- 搜索结果中的实体关系 → 知识图谱可视化
- 搜索到的步骤 → 流程图
- 搜索到的分类 → 思维导图

**两个计划互补，不是竞争关系。**

### 10.3 设计稿/线框图渲染（扩展能力）

除 Mermaid 结构化图表外，可复用 Playwright 实现 HTML → PNG 截图：

```
设计数据（JSON）→ HTML/CSS 模板 → Playwright 渲染 → PNG 截图
```

| 项目 | 说明 |
|-----|------|
| 依赖 | `@playwright/test`（已有 devDependency） |
| 费用 | ¥0 |
| 外部服务 | 不需要 |

**能做的**：线框图、低保真 UI 原型、卡片布局、表单布局
**不能做的**：高保真视觉稿（需要精细排版和品牌设计）

**实现方式**：
1. 新增 `HtmlTemplateRenderer` — 设计数据 → HTML/CSS 字符串
2. 复用 Playwright — 启动 headless Chromium → 截图 → PNG Buffer
3. 返回 `VisualBlock { kind: 'design', content: html, svg?: png_base64 }`

**注意**：Playwright 目前是 devDependency，生产环境使用需要将其移到 dependencies 或用独立的 `playwright` 包（非 `@playwright/test`）。

---

## 十一、能力边界总结

| 能力 | 方案 | 可行性 | 依赖/费用 |
|-----|------|--------|----------|
| 流程图/思维导图/架构图 | Mermaid + jsdom | ✅ 可行 | mermaid, jsdom（免费） |
| 知识图谱可视化 | KnowledgeGraph → Mermaid graph | ✅ 可行 | 同上 |
| 时间线/甘特图/序列图 | Mermaid 原生支持 | ✅ 可行 | 同上 |
| 设计稿/线框图 | HTML/CSS + Playwright 截图 | ✅ 可行 | 已有（免费） |
| 素描/插画/自由绘画 | 需要 AI 图片生成 API | ❌ 需付费+外部依赖 | — |
| 高保真视觉稿 | 需要设计工具 API (Figma 等) | ❌ 需付费+外部依赖 | — |

**不可行项说明**：
- **素描/插画**：需要调用 DALL-E / Stable Diffusion / 通义万相等外部 API，需 API Key + 付费 + 网络依赖
- **高保真视觉稿**：需要 Figma/Sketch 等设计工具的 API，需付费账号 + 外部依赖
- **项目现有渲染引擎**（BuddyRenderer/Canvas2DFallback）：全部是角色专用，无法复用于通用绘图
