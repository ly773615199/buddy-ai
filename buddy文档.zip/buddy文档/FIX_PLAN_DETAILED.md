# Buddy 代码质量修复计划

> 基于 2026-05-17 全量代码审查 + 前后端断链分析。
> 每个 Phase 独立可交付，不依赖其他 Phase。
> 最后更新：2026-05-17 19:57

---

## Phase 0：安全补丁（紧急，1-2 天）

### 0.1 SVG XSS 修复

**问题**：`MessageBubble.tsx:362` 直接 `dangerouslySetInnerHTML={{ __html: v.svg }}`，后端返回的 SVG 如果包含 `<script>` 或 `onload` 会执行。

**修复**：
```bash
npm install dompurify @types/dompurify
```

```typescript
// frontend/src/utils/sanitize.ts
import DOMPurify from 'dompurify';

const SVG_CONFIG: DOMPurify.Config = {
  USE_PROFILES: { svg: true, svgFilters: true },
  ALLOWED_TAGS: [
    'svg', 'g', 'path', 'rect', 'circle', 'ellipse', 'line', 'polyline', 'polygon',
    'text', 'tspan', 'defs', 'linearGradient', 'radialGradient', 'stop', 'clipPath',
    'pattern', 'mask', 'image', 'switch', 'foreignObject', 'br', 'p', 'span', 'div',
    'a', 'ul', 'ol', 'li', 'hr', 'pre', 'code', 'table', 'tr', 'td', 'th',
    'thead', 'tbody', 'tfoot', 'caption', 'col', 'colgroup',
    'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'strong', 'em', 'del', 'sub', 'sup',
    'marker', 'symbol', 'use', 'view',
  ],
  ALLOWED_ATTR: [
    'viewBox', 'xmlns', 'width', 'height', 'x', 'y', 'dx', 'dy',
    'fill', 'stroke', 'stroke-width', 'stroke-dasharray', 'stroke-dashoffset',
    'opacity', 'transform', 'font-size', 'font-family', 'font-weight', 'font-style',
    'text-anchor', 'dominant-baseline', 'alignment-baseline',
    'd', 'cx', 'cy', 'r', 'rx', 'ry', 'x1', 'y1', 'x2', 'y2',
    'points', 'href', 'xlink:href', 'id', 'class', 'style',
    'offset', 'stop-color', 'stop-opacity', 'gradientUnits', 'gradientTransform',
    'patternUnits', 'patternTransform', 'maskUnits', 'clip-path',
    'marker-start', 'marker-mid', 'marker-end', 'refX', 'refY',
    'markerWidth', 'markerHeight', 'orient', 'preserveAspectRatio',
    'role', 'aria-label', 'aria-hidden',
  ],
  FORBID_TAGS: ['script', 'iframe', 'object', 'embed', 'form', 'input', 'button'],
  FORBID_ATTR: ['onerror', 'onload', 'onclick', 'onmouseover', 'onfocus', 'onblur'],
};

export function sanitizeSvg(svg: string): string {
  return DOMPurify.sanitize(svg, SVG_CONFIG);
}

export function sanitizeHtml(html: string): string {
  return DOMPurify.sanitize(html, { USE_PROFILES: { html: true } });
}
```

```tsx
// MessageBubble.tsx — 修改
import { sanitizeSvg } from '../utils/sanitize';

{v.svg
  ? <div dangerouslySetInnerHTML={{ __html: sanitizeSvg(v.svg) }} style={{ textAlign: 'center' }} />
  : <pre ...>{v.content}</pre>
}
```

**文件改动**：
- 新增 `frontend/src/utils/sanitize.ts`
- 修改 `frontend/src/components/MessageBubble.tsx`
- 修改 `frontend/src/utils/markdown.tsx`

### 0.2 highlight.js 输出净化加固

**问题**：`sanitizeHighlight()` 用正则过滤，可能被绕过。

**修复**：改用 DOMPurify：
```typescript
import { sanitizeHtml } from './sanitize';

function sanitizeHighlight(html: string): string {
  return sanitizeHtml(html);
}
```

---

## Phase 1：可视化管线全链路修复（关键，2-3 天）

> **这是最严重的断链**：visualDirective → visuals 的数据流在 4 个节点全部断裂。
> 整个 VISUAL_ASSEMBLY_PLAN 的 Phase 1-5 虽然代码完整，但永远不会被触发。

### 1.1 断链诊断

```
rule-engine.ts:196   生成 visualDirective: { kind, data: null }
       ↓ ❌ 未传递
brain.ts:657         调用 processWithWebSearch() — 无此参数
       ↓ ❌ 未传递
right/index.ts:536   processWithAssembly(input, pooled, context) — 无此参数
       ↓ ❌ 未传递
assembly-bridge.ts:158  process(..., visualDirective?) — 永远是 undefined
       ↓
executeVisual(undefined) → return []  ← 永远空
```

即使上述修复后，还有 2 个丢弃点：
```
brain.ts:667    localGeneration = { text, confidence, templateId }  — 无 visuals
agent.ts:749    return { content, mode, reason... }                  — 无 visuals
ws-handler.ts   发送 llm_response / response_end                    — 无 visuals
```

### 1.2 修复方案

**Step 1**：`brain.ts` — 将 `plan.visualDirective` 传入组装管线

```typescript
// brain.ts — 修改 processWithWebSearch 签名
async processWithWebSearch(
  input: string,
  pooled?: Float32Array,
  context?: GenerateContext,
  visualDirective?: { kind: string; data: unknown; title?: string },
) {
  this.updateEnvironmentContext(input);
  return this.right.processWithAssembly(input, pooled, context, visualDirective);
}
```

```typescript
// brain.ts L657 — 传递 plan.visualDirective
const assemblyResult = await this.processWithWebSearch(
  input, intuition._hidden, {
    userInput: input,
    intent: intuition.intent.category,
    taskType: signal.taskType,
    timestamp: Date.now(),
  },
  plan.visualDirective,  // ← 新增
);
```

**Step 2**：`right/index.ts` — `processWithAssembly` 接受并转发 visualDirective

```typescript
processWithAssembly(
  input: string,
  pooled?: Float32Array,
  context?: GenerateContext,
  visualDirective?: { kind: string; data: unknown; title?: string },
): AssemblyResult {
  return this.assemblyBridge.process(input, pooled, context, visualDirective);
}
```

**Step 3**：`brain.ts` — `DecisionResult.localGeneration` 增加 visuals 字段

```typescript
// brain.ts L65-69
localGeneration?: {
  text: string;
  confidence: number;
  templateId: string;
  visuals?: import('./right/features/visual-types.js').VisualBlock[];  // ← 新增
};
```

```typescript
// brain.ts L667-672 — 保留 visuals
localGeneration = {
  text: assemblyResult.text,
  confidence: assemblyResult.assemblyConfidence,
  templateId: `assembly_${assemblyResult.path}`,
  visuals: assemblyResult.visuals,  // ← 新增
};
```

**Step 4**：`agent.ts` — 转发 visuals 到返回对象

```typescript
// agent.ts L749-769 — 增加 visuals
return {
  content: decision.localGeneration.text,
  visuals: decision.localGeneration.visuals,  // ← 新增
  mode: decision.plan.mode,
  reason: `本地组装引擎命中 (${decision.localGeneration.templateId})`,
  // ... 其余字段不变
};
```

**Step 5**：`ws-handler.ts` — 在 llm_response / response_end 事件中携带 visuals

```typescript
// 发送响应时附带 visuals
this.eventBus?.emit({
  type: 'llm_response',
  content: result.content,
  visuals: result.visuals,  // ← 新增
});
```

**Step 6**：前端 `BuddyEvent` 类型 — `llm_response` 增加 visuals

```typescript
// frontend/src/types/buddy.ts
| { type: 'llm_response'; content: string; streaming?: boolean; visuals?: VisualBlock[] }
```

**Step 7**：前端 `useWebSocket.ts` — `llm_response` case 保留 visuals

```typescript
case 'llm_response': {
  // ... 现有逻辑 ...
  const visuals = (event as Record<string, unknown>).visuals as VisualBlock[] | undefined;
  // 在构建 ChatMessage 时附带 visuals
  return [...filtered.slice(0, -1), {
    ...last,
    content: respContent || last.content,
    streaming: false,
    visuals: visuals?.length ? visuals : undefined,  // ← 新增
  }];
}
```

### 1.3 验证

修复后，发送包含"画个图"/"思维导图"/"流程图"等关键词的消息，应触发：
1. 右脑直觉 `visualHint` → 左脑规则引擎 `visualDirective`
2. 组装引擎 `executeVisual()` 翻译 → SvgRenderer 渲染
3. WS 事件携带 `visuals` 字段
4. 前端 MessageBubble 渲染 SVG 图表

---

## Phase 2：BuddyGenome 类型统一（中等，1 天）

### 2.1 断链诊断

- 5 个前端 renderer 文件 `import type { BuddyGenome } from '../../pet/genome'`
- `frontend/src/pet/` 目录不存在，路径指向后端 `src/pet/genome.ts`
- 前端 `types/buddy.ts` 已有独立定义（65 字段），后端 `src/pet/genome.ts` 有 56 字段
- 两份定义不同步

### 2.2 修复方案

**方案 A（推荐）**：前端 renderer 统一引用 `types/buddy.ts`

```typescript
// 5 个文件全部改为：
import type { BuddyGenome } from '../types/buddy';
```

**文件改动**：
- `frontend/src/renderer/BuddyRenderer.ts`
- `frontend/src/renderer/meshes/humanoid-mesh.ts`
- `frontend/src/renderer/costume/CostumeRenderer.ts`
- `frontend/src/renderer/costume/template-loader.ts`
- `frontend/src/renderer/skeleton/humanoid-skeleton.ts`

**方案 B**：抽取共享类型包

将 `BuddyGenome` 移到 `shared/types.ts`，前后端都引用。适合长期维护但改动更大。

---

## Phase 3：tsconfig 配置修复（简单，半天）

### 3.1 断链诊断

`frontend/tsconfig.app.json` exclude 了 `src/vision`, `src/voice`, `src/sensors`，
但 `VisionPanel.tsx` 和 `useVoiceEmotion.ts` 仍然 import 这些目录。

结果：TypeScript 不检查这些文件的类型错误，但 Vite 仍然打包。

### 3.2 修复方案

从 exclude 中移除这三个目录（它们是运行时需要的）：

```json
// frontend/tsconfig.app.json
{
  "compilerOptions": { ... },
  "include": ["src"],
  "exclude": []  // 移除 src/vision, src/voice, src/sensors
}
```

或者，如果不想让 tsc 检查这些文件（比如它们有独立的类型系统），则在入口处加 `// @ts-nocheck`。

---

## Phase 4：useWebSocket 拆分（重要，3-5 天）

### 4.1 拆分方案

将 1120 行的上帝函数拆成 5 个独立 hook：

```
useWebSocket.ts (1120行)
  ↓ 拆分为
├── useConnection.ts      — WS 连接、断连恢复、token 刷新、多标签页共享
├── useChatMessages.ts    — 消息管理、流式拼接、去重、搜索
├── useOrchestration.ts   — 编排任务流、折叠逻辑
├── useBuddyState.ts      — 精灵状态、情绪、进化、养成
└── useTools.ts           — 工具面板、记忆面板、知识面板、三进制专家
```

### 4.2 事件分发器

用 pub/sub 替代 switch-case：

```typescript
// event-bus.ts
type EventHandler = (event: BuddyEvent) => void;
const handlers = new Map<string, Set<EventHandler>>();

export function on(type: string, handler: EventHandler) { ... }
export function off(type: string, handler: EventHandler) { ... }
export function emit(event: BuddyEvent) { ... }
```

每个 hook 注册自己关心的事件类型，不再在一个 switch 里处理所有 56 个 case。

---

## Phase 5：setTimeout 泄漏修复（简单，半天）

### 5.1 统一 timer 管理

```typescript
// useTimers.ts
export function useTimers() {
  const timersRef = useRef<Map<string, ReturnType<typeof setTimeout>>>(new Map());

  const setTimer = useCallback((key: string, fn: () => void, ms: number) => {
    if (timersRef.current.has(key)) {
      clearTimeout(timersRef.current.get(key)!);
    }
    timersRef.current.set(key, setTimeout(() => {
      timersRef.current.delete(key);
      fn();
    }, ms));
  }, []);

  useEffect(() => {
    return () => {
      timersRef.current.forEach(timer => clearTimeout(timer));
      timersRef.current.clear();
    };
  }, []);

  return { setTimer };
}
```

---

## Phase 6：前端性能优化（1-2 天）

### 6.1 Tab 懒加载

```tsx
const ToolPanel = React.lazy(() => import('./components/ToolPanel'));
const MemoryPanel = React.lazy(() => import('./components/MemoryPanel'));
// ...

{activeTab === 'tools' && (
  <Suspense fallback={<TabSkeleton />}>
    <ToolPanel ... />
  </Suspense>
)}
```

### 6.2 BuddyCanvas 挂载控制

```tsx
{activeTab === 'chat' || activeTab === 'stats' ? (
  <BuddyCanvas ... />
) : (
  <div style={{ width: 280, height: 260, background: 'var(--bg-secondary)' }}>
    <span style={{ opacity: 0.3 }}>🐾</span>
  </div>
)}
```

---

## Phase 7：类型安全 + 小修复（半天）

### 7.1 消除 `as any`

```typescript
// useWebSocket.ts L636
cognitive: event.profile as Record<string, unknown> | undefined,

// L836
diagnostic: diag as DiagnosticReport,
```

### 7.2 消息去重指纹改进

```typescript
const contentKey = `${event.type}:${hashCode(String(event.content ?? event.text ?? ''))}`;

function hashCode(s: string): number {
  let h = 0;
  for (let i = 0; i < s.length; i++) h = ((h << 5) - h + s.charCodeAt(i)) | 0;
  return h;
}
```

### 7.3 删除未使用类型

```typescript
// frontend/src/types/buddy.ts — 删除 TernaryTrainCompleteEvent（0 引用）
```

### 7.4 处理 evolution_log 事件

```typescript
// useWebSocket.ts — 新增 case
case 'evolution_log':
  // 后端已发送，前端静默忽略（或展示日志）
  break;
```

---

## Phase 8：deprecated 代码清理（1-2 天）

### 8.1 清理清单

| 文件 | 标记 | 操作 |
|------|------|------|
| `src/core/model-pool-scheduler.ts` | `@deprecated Phase 2` | 删除 |
| `src/core/model-pool-unified.ts` | `@deprecated 统一模型池` | 删除 |
| `src/core/model-router.ts` L195-218 | 4 个 `@deprecated` | 删除旧注入路径 |
| `src/core/llm.ts` L596-644 | 4 个 `@deprecated` | 删除旧初始化路径 |
| `src/core/subsystems.ts` L149,158 | 2 个 `@deprecated` | 确认无调用后删除 |
| `src/brain/brain.ts` L385 | `@deprecated` 旧检索源 | 删除 |

### 8.2 验证

```bash
grep -rn "import.*model-pool-scheduler" src/ --include="*.ts" | grep -v test
grep -rn "import.*model-pool-unified" src/ --include="*.ts" | grep -v test
npm test
```

---

## Phase 9：localStorage + 音频（半天）

### 9.1 localStorage schema 版本管理

```typescript
const STORAGE_KEY = 'buddy_visual_seed';
const STORAGE_VERSION = 2;

interface StoredSeed { version: number; data: VisualSeed; }

// 读取时校验版本
const parsed = JSON.parse(stored) as StoredSeed;
if (parsed.version !== STORAGE_VERSION) {
  setShowOnboarding(true); // 版本不匹配，重新生成
}
```

### 9.2 音频自动播放提示

```tsx
{audioBlocked && (
  <div onClick={() => { new AudioContext().resume(); setAudioBlocked(false); }}
    style={{ position: 'fixed', bottom: 16, right: 16, ... }}>
    🔇 点击开启音效
  </div>
)}
```

---

## 执行优先级总览

```
Phase 1 (可视化管线)  ████████████████ 最严重 — 整个可视化系统是死代码
Phase 0 (安全补丁)    ████████████     紧急 — XSS 漏洞
Phase 2 (Genome类型)  ████████         中等 — 类型断裂
Phase 3 (tsconfig)    ████████         简单 — 配置问题
Phase 5 (timer泄漏)   ████████         简单 — 半天搞定
Phase 7 (类型安全)    ████████         简单 — 半天搞定
Phase 9 (localStorage+音频) ██████     简单 — 半天搞定
Phase 6 (性能优化)    ██████           中等 — 首屏优化
Phase 4 (useWebSocket拆分) ████        重要但大 — 需要仔细
Phase 8 (deprecated清理)  ████         低风险 — 逐步清理
```

**建议执行顺序**：1 → 0 → 2 → 3 → 5 → 7 → 9 → 6 → 4 → 8

**核心原则**：先修断链（让功能生效），再修安全，再做工程优化。
