# 专家经验模型 — 三进制技术方案 v3.0

> 2026-05-31 — 知识汇聚 + 碰撞涌现
>
> 核心定位：三进制 = 知识的可学习索引
> 不是文本生成器，不是规则检索器，是"凭直觉找知识"的专家模型。

---

## 〇、核心认知

### 知识的定义

**任何能帮助回答用户问题的东西都是知识。** 不按存储位置分类，按对用户意图的有用性定义。

| 来源 | 例子 | 知识类型 |
|------|------|---------|
| 网络搜索 | `search_web("Redis 缓存策略")` | 实时知识，外部获取 |
| STMP | 六类隐性知识（决策规则/例外/模式） | 积累知识，内部存储 |
| 经验图谱 | ExperienceUnit (steps + reasoning) | 程序知识，从交互编译 |
| 三进制模型 | knowledge.ta / code.ta / conversation.ta | 蒸馏知识，从大模型压缩 |
| 对话上下文 | 当前对话中提到的信息 | 临时知识，会话级 |
| 文件/URL | 用户让学习的文档 | 注入知识，外部来源 |
| KnowledgeGraph | 概念之间的关系 | 结构知识，关系网络 |

### 当前问题：知识按来源隔离

```
search_web → 结果直接返回，不进入知识系统
STMP → 存了但不和 ExperienceUnit 关联
knowledge.ta → 独立运行，不和其他知识碰撞
ExperienceUnit → 只有 steps，没有概念知识
对话上下文 → 用完即丢
```

用户问一个问题，系统从**某一个**来源找答案。但最好的答案往往需要**多个来源的知识组合**。

### 目标：知识汇聚 + 碰撞

```
用户意图
    ↓
┌──────────────────────────────────────────────┐
│  知识汇聚层（Knowledge Convergence）           │
│                                               │
│  网络搜索结果 ──┐                             │
│  STMP 知识 ─────┤                             │
│  经验图谱 ──────┼──→ 向量化 → 碰撞 → 综合方案  │
│  三进制模型 ────┤                             │
│  对话上下文 ────┤                             │
│  文件/URL ──────┤                             │
│  KnowledgeGraph ┘                             │
│                                               │
└──────────────────────────────────────────────┘
```

---

## 一、当前实现状态（基于代码审查）

### 已完成（Phase 0-4）

| Phase | 内容 | 状态 | 代码证据 |
|-------|------|------|---------|
| 0 | 清理检索系统 | ✅ | 9 个检索文件已删除 |
| 1 | 输出头改造 | ✅ | `exp-head.ts` ExpertHead 三头架构 |
| 2 | 训练管线改造 | ✅ | `exp-bridge.ts` + `trainer.ts` trainExpert() |
| 3 | 集成到经验路由 | ✅ | `experience-router.ts` setTernaryPredict() |
| 4 | 评估与调优 | ✅ | `eval.ts` NDCG@K + calibration |

### 模型状态

| 模型 | 架构 | 参数量 | 阶段 | 训练步数 |
|------|------|--------|------|---------|
| code.ta | small (384d, 6层) | 233K | growing | 193 |
| knowledge.ta | small (384d, 6层) | 233K | growing | 182 |
| conversation.ta | small (384d, 6层) | 233K | growing | 138 |
| experience.ta | nano (256d, 2层) | 4K | sprout | 25 |

### 在线学习闭环状态

已接通：evolver → setTernarySampleCallback → scheduler.onExperienceResult → bridge.onExecutionResult → buffer

未接通：buffer → 自动触发 trainExpert()（需 Phase 8）

---

## 二、Phase 5：知识汇聚层

### 5.1 目标

建立统一的知识汇聚层，让所有来源的知识都能被向量化、索引、碰撞。

### 5.2 知识节点（KnowledgeNode）统一抽象

```typescript
// src/intelligence/knowledge-node.ts (新建 ~80行)

/**
 * 统一知识节点 — 所有来源的知识都实现这个接口
 *
 * 不关心知识从哪来，只关心它能帮用户做什么。
 */
export interface KnowledgeNode {
  /** 唯一标识 */
  id: string;

  /** 来源类型 */
  source: 'web' | 'stmp' | 'experience' | 'ternary' | 'conversation' | 'file' | 'knowledge_graph';

  /** 知识向量 — 统一的语义表示 (256维) */
  vector: Float32Array;

  /** 原始内容（用于碰撞后读出） */
  content: string;

  /** 关联的概念 */
  concepts: string[];

  /** 置信度 / 可信度 */
  confidence: number;

  /** 时效性（网络搜索有时效，经验没有） */
  freshness?: number;

  /** 来源元数据 */
  metadata: Record<string, unknown>;
}
```

### 5.3 知识汇聚器（KnowledgeConvergence）

```typescript
// src/intelligence/knowledge-convergence.ts (新建 ~200行)

/**
 * 知识汇聚器 — 从所有来源收集知识，统一向量化
 *
 * 用户提问时：
 * 1. 从每个来源获取相关知识
 * 2. 统一转为 KnowledgeNode
 * 3. 放入同一个向量空间
 * 4. 碰撞引擎在统一空间中操作
 */
export class KnowledgeConvergence {
  /**
   * 汇聚所有来源的知识
   *
   * @param input 用户输入
   * @param contextTags 上下文标签
   * @returns 统一的 KnowledgeNode 列表
   */
  async converge(input: string, contextTags: string[] = []): Promise<KnowledgeNode[]> {
    const nodes: KnowledgeNode[] = [];

    // 并行从所有来源获取
    const [webResults, stmpNodes, experiences, ternaryResults, contextNodes, fileNodes] =
      await Promise.all([
        this.fromWeb(input),
        this.fromSTMP(input),
        this.fromExperience(input, contextTags),
        this.fromTernary(input),
        this.fromConversation(),
        this.fromFiles(input),
      ]);

    nodes.push(...webResults, ...stmpNodes, ...experiences,
               ...ternaryResults, ...contextNodes, ...fileNodes);

    // 统一向量化（如果来源没有提供向量）
    for (const node of nodes) {
      if (!node.vector || node.vector.length === 0) {
        node.vector = this.vectorize(node.content);
      }
    }

    return nodes;
  }

  /**
   * 网络搜索 → KnowledgeNode[]
   */
  private async fromWeb(input: string): Promise<KnowledgeNode[]> {
    // 调用 search_web 工具
    // 将搜索结果转为 KnowledgeNode
    // 每个搜索结果 = 一个知识节点
    // confidence = 搜索结果的相关性分数
    // freshness = 当前时间（网络知识有时效）
  }

  /**
   * STMP → KnowledgeNode[]
   */
  private async fromSTMP(input: string): Promise<KnowledgeNode[]> {
    // 从 STMP 中检索相关知识
    // 每个 STMP 节点 = 一个知识节点
    // confidence = STMP 节点的置信度
  }

  /**
   * 经验图谱 → KnowledgeNode[]
   */
  private async fromExperience(input: string, contextTags: string[]): Promise<KnowledgeNode[]> {
    // 从 ExperienceGraph.match() 获取相关经验
    // 每个 ExperienceUnit = 一个知识节点
    // content = reasoning + steps 描述
    // confidence = ExperienceUnit.stats.confidence
  }

  /**
   * 三进制模型 → KnowledgeNode[]
   */
  private async fromTernary(input: string): Promise<KnowledgeNode[]> {
    // 从 container.predict() 获取 ExpertHead 结果
    // top-K 匹配的经验 = 知识节点
    // confidence = ExpertHead 的 experience score
  }

  /**
   * 对话上下文 → KnowledgeNode[]
   */
  private async fromConversation(): Promise<KnowledgeNode[]> {
    // 从 conversation_history 提取最近的对话上下文
    // 每轮对话 = 一个知识节点
    // freshness = 对话时间（越新越重要）
  }

  /**
   * 文件/URL → KnowledgeNode[]
   */
  private async fromFiles(input: string): Promise<KnowledgeNode[]> {
    // 如果用户最近学习了文件/URL，从中提取相关片段
    // confidence = 文件与输入的相关性
  }

  /**
   * 统一向量化 — 将文本编码为 256 维向量
   *
   * 复用三进制容器的 tokenizer + embedding
   * 与 engine.ts 的 decodePooled() 逻辑一致
   */
  private vectorize(text: string): Float32Array {
    // tokenizer.encode → token IDs
    // embedding[token IDs] → 均值池化 → 256 维向量
  }
}
```

### 5.4 接入 ExperienceGraph

```typescript
// src/intelligence/experience-graph.ts — 修改

class ExperienceGraph {
  /**
   * 混合匹配：关键词 + 向量 + 置信度
   *
   * 不仅在 ExperienceUnit 中搜索，而是在所有 KnowledgeNode 中搜索。
   * KnowledgeConvergence 负责汇聚，这里只做排序。
   */
  matchHybrid(input: string, knowledgeNodes: KnowledgeNode[], topK = 5): KnowledgeNode[] {
    // 关键词匹配 × 0.3 + 向量相似度 × 0.5 + 置信度 × 0.2
  }
}
```

### 5.5 验收标准

- [ ] KnowledgeNode 统一抽象，所有来源都能转为 KnowledgeNode
- [ ] KnowledgeConvergence 从 6 个来源并行汇聚知识
- [ ] 所有知识节点都有 256 维向量
- [ ] matchHybrid() 在统一空间中排序

---

## 三、Phase 6：碰撞引擎

### 6.1 目标

在统一的知识空间中，让不同来源的知识互相碰撞，涌现出新组合。

### 6.2 碰撞类型

| 类型 | 条件 | 行为 | 产出 |
|------|------|------|------|
| 湮灭 (fusion) | 向量相似度 > 0.85 | 合并两个知识节点的内容 | 一个更完整的知识 |
| 裂变 (emergence) | 向量相似度 < 0.3 | 两个差异大的知识碰撞 | 新的组合方案 |
| 弹性 (scattering) | 中间地带 | 互相深化 | 优化后的知识 |

### 6.3 跨来源碰撞（核心价值）

不同来源的知识碰撞，产出最有价值的组合：

```
网络搜索: "Redis 6.0 支持多线程 IO"
    ×
经验图谱: "上次用连接池优化 API 的 steps"
    =
裂变涌现: "用 Redis 6.0 多线程 + 连接池的组合方案"
    → 这个方案在任何单一来源中都不存在
```

```
STMP 知识: "数据库索引能加速查询但拖慢写入"
    ×
经验图谱: "批量写入时先关闭索引再重建"
    =
弹性碰撞: "读多写少的表建索引，写多读少的表用缓存"
    → 从矛盾中涌现出分层策略
```

```
对话上下文: "用户说这个服务在国内访问慢"
    ×
网络搜索: "CDN 加速方案"
    ×
STMP 知识: "之前用 CDN 解决过类似问题的经验"
    =
多路碰撞: "针对国内访问的 CDN + 边缘节点方案"
    → 三个来源的知识融合
```

### 6.4 实现

```typescript
// src/intelligence/collision-engine.ts (新建 ~300行)

export interface CollisionResult {
  type: 'fusion' | 'emergence' | 'scattering';
  participants: KnowledgeNode[];  // 参与碰撞的知识节点
  output: CollisionOutput;
  novelty: number;  // 产出的新颖度 0-1
  sources: string[];  // 参与碰撞的来源类型（跨来源碰撞更有价值）
}

export interface CollisionOutput {
  /** 碰撞后的知识向量 */
  vector: Float32Array;
  /** 碰撞后的内容（融合各方的内容） */
  content: string;
  /** 可执行的步骤（如果有） */
  steps?: ExperienceStep[];
  /** 原理说明 */
  reasoning: string;
  /** 关联的概念 */
  concepts: string[];
}

export class CollisionEngine {
  /**
   * 碰撞主入口
   *
   * @param nodes 汇聚的知识节点（来自所有来源）
   * @param inputVector 输入的向量
   * @param temperature 碰撞温度
   */
  collide(nodes: KnowledgeNode[], inputVector: Float32Array,
          temperature: number): CollisionResult[] {
    const results: CollisionResult[] = [];

    // 生成碰撞对（优先跨来源碰撞）
    const pairs = this.generateCollisionPairs(nodes, temperature);

    for (const [a, b] of pairs) {
      const sim = this.cosineSim(a.vector, b.vector);

      if (sim > 0.85) {
        results.push(this.fuse(a, b));
      } else if (sim < 0.3) {
        results.push(this.emerge(a, b, inputVector, temperature));
      } else {
        results.push(this.scatter(a, b, inputVector, temperature));
      }
    }

    // 跨来源碰撞加权（优先保留跨来源的结果）
    results.sort((a, b) => {
      const crossA = a.sources.length > 1 ? 1.5 : 1.0;
      const crossB = b.sources.length > 1 ? 1.5 : 1.0;
      return (b.novelty * crossB) - (a.novelty * crossA);
    });

    return results;
  }

  /**
   * 生成碰撞对 — 优先跨来源碰撞
   *
   * 同来源的碰撞产出有限（都是相似知识）。
   * 跨来源的碰撞才能涌现新组合。
   */
  private generateCollisionPairs(
    nodes: KnowledgeNode[], temperature: number
  ): Array<[KnowledgeNode, KnowledgeNode]> {
    const pairs: Array<[KnowledgeNode, KnowledgeNode]> = [];
    const maxPairs = Math.min(15, nodes.length * 2);

    // 优先：跨来源对
    for (let i = 0; i < nodes.length && pairs.length < maxPairs; i++) {
      for (let j = i + 1; j < nodes.length && pairs.length < maxPairs; j++) {
        if (nodes[i].source !== nodes[j].source) {
          // 跨来源对 — 高优先级
          pairs.push([nodes[i], nodes[j]]);
        }
      }
    }

    // 补充：同来源对（如果跨来源对不够）
    for (let i = 0; i < nodes.length && pairs.length < maxPairs; i++) {
      for (let j = i + 1; j < nodes.length && pairs.length < maxPairs; j++) {
        if (nodes[i].source === nodes[j].source) {
          pairs.push([nodes[i], nodes[j]]);
        }
      }
    }

    return pairs;
  }

  /**
   * 湮灭 — 合并相似知识
   */
  private fuse(a: KnowledgeNode, b: KnowledgeNode): CollisionResult {
    // 向量：加权平均
    // 内容：拼接去重
    // 步骤：取更完整的那个
    // 概念：并集
  }

  /**
   * 裂变 — 差异大的知识碰撞，涌现新组合
   */
  private emerge(a: KnowledgeNode, b: KnowledgeNode,
                 input: Float32Array, temperature: number): CollisionResult {
    // 新向量 = α × A - β × B + noise
    // 内容：从双方各取关键片段重组
    // 步骤：从双方 steps 中按输入相关性选取
    // 原理：融合双方的 reasoning
  }

  /**
   * 弹性 — 互相深化
   */
  private scatter(a: KnowledgeNode, b: KnowledgeNode,
                  input: Float32Array, temperature: number): CollisionResult {
    // a 的内容被 b 的原理优化，反之亦然
  }
}
```

### 6.5 碰撞 → 执行

```
碰撞产出 CollisionOutput
    ↓
CollisionOutput.steps 存在？
    ├── 是 → ExperienceExecutor.execute(steps)
    └── 否 → CollisionOutput.content 作为 LLM 参考
```

### 6.6 验收标准

- [ ] CollisionEngine 支持所有来源的知识碰撞
- [ ] 跨来源碰撞优先级高于同来源碰撞
- [ ] 碰撞产出可被 ExperienceExecutor 执行（有 steps 时）
- [ ] 碰撞产出可被 LLM 参考（无 steps 时）

---

## 四、Phase 7：E=mc² 指标

### 4.1 目标

用 E=mc² 衡量系统是否变聪明。

### 4.2 实现

```typescript
// src/ternary/emc2.ts (新建 ~100行)

export class EMC2Calculator {
  /**
   * 计算三进制模型的 E=mc²
   *
   * m = 知识总量
   *   = Σ(知识节点置信度 × log₂(命中次数 + 2)) × log₂(向量维度)
   *
   * c² = 转换效率
   *   = 碰撞产出的区分度（不同输入 → 不同输出的能力）
   *   = avg(输出距离 / 输入距离) × 10
   *
   * E = m × c²
   */
  calculate(nodes: KnowledgeNode[], collisionResults: CollisionResult[]): EMC2Metrics {
    // m: 所有知识节点的信息量总和
    // c²: 碰撞产出的区分度
    // E = m × c²
  }
}
```

### 4.3 验收标准

- [ ] EMC2Calculator 能计算 m/c²/E
- [ ] E 增长 = 系统变聪明
- [ ] 接入 ShadowBrain MetaLearner

---

## 五、Phase 8：自动训练触发

### 5.1 目标

接通在线学习闭环。

### 5.2 实现

```typescript
// src/ternary/scheduler.ts — 修改 onExperienceResult()

onExperienceResult(input: string, experienceId: string, success: boolean, quality?: number): void {
  this.bridge.onExecutionResult(input, experienceId, success, quality);

  // 新增：自动触发训练
  const stats = this.bridge.getStats();
  if (stats.total >= this.config.autoTrainThreshold && !this.state.isTraining) {
    const domain = this.inferDomain(experienceId);
    if (domain) {
      this.trainExpert(domain).catch(err => {
        console.warn(`[Scheduler] Auto train failed: ${err.message}`);
      });
    }
  }
}
```

### 5.3 验收标准

- [ ] 缓冲区达到阈值后自动触发 trainExpert()
- [ ] 训练完成后自动保存模型
- [ ] 有防抖机制

---

## 六、Phase 9：知识汇聚 + 碰撞接入 ExperienceRouter

### 6.1 目标

将知识汇聚和碰撞接入 ExperienceRouter 的路由决策。

### 6.2 路由流程

```
用户输入
    ↓
ExperienceRouter.route()
    ↓
1. 元认知检查（qualityEstimate）
    └── 极低信心 → llm_only
    ↓
2. 知识汇聚（KnowledgeConvergence.converge()）
    └── 从所有来源收集知识节点
    ↓
3. 碰撞（CollisionEngine.collide()）
    └── 跨来源碰撞优先
    ↓
4. 碰撞结果评估
    ├── 有 steps + 高置信度 → exp_direct（直接执行）
    ├── 有 steps + 中置信度 → exp_verified（执行 + LLM 质检）
    ├── 无 steps + 高新颖度 → llm_with_hint（LLM 参考碰撞结果）
    └── 碰撞失败 → fallback 到原有逻辑
    ↓
5. 执行 + 反馈
    └── 碰撞路径强化/削弱
```

### 6.3 实现

```typescript
// src/intelligence/experience-router.ts — 修改 route()

route(input: string, contextTags: string[] = [], qualityEstimate?: number): RouteDecision {
  // ... 元认知检查 ...

  // ── 新增：知识汇聚 + 碰撞 ──
  const knowledgeNodes = await this.convergence.converge(input, contextTags);

  if (knowledgeNodes.length >= 2) {
    const inputVector = this.convergence.vectorize(input);
    const collisions = this.collisionEngine.collide(knowledgeNodes, inputVector, temperature);

    if (collisions.length > 0) {
      const best = collisions[0];  // 已按 novelty × 跨来源加权排序

      if (best.output.steps && best.output.steps.length > 0) {
        // 有可执行步骤
        if (best.novelty < 0.3) {
          return { path: 'exp_direct', skill: this.collisionToSkill(best), ... };
        } else {
          return { path: 'exp_verified', skill: this.collisionToSkill(best), ... };
        }
      } else {
        // 无步骤，用内容作为 LLM 参考
        return { path: 'llm_with_hint', skill: this.collisionToSkill(best), ... };
      }
    }
  }

  // ── fallback：原有逻辑 ──
  const candidates = this.matchCandidates(input, contextTags);
  // ... Thompson Sampling ...
}
```

### 6.4 验收标准

- [ ] route() 先汇聚知识，再碰撞，再路由
- [ ] 跨来源碰撞的结果优先级最高
- [ ] 碰撞有 steps 时走经验路径，无 steps 时走 LLM 参考

---

## 七、执行顺序

```
Phase 5: 知识汇聚层
  5.1 定义 KnowledgeNode 统一抽象
  5.2 实现 KnowledgeConvergence（6 个来源的汇聚器）
  5.3 统一向量化（复用容器 embedding）
  5.4 接入 ExperienceGraph.matchHybrid()
  5.5 验证：所有来源的知识都能转为 KnowledgeNode + 向量
    ↓
Phase 6: 碰撞引擎
  6.1 实现 CollisionEngine（三种碰撞类型）
  6.2 跨来源碰撞优先排序
  6.3 碰撞 → ExperienceExecutor 执行链路
  6.4 碰撞路径反馈接入 feedback()
  6.5 验证：跨来源碰撞产出可执行的新方案
    ↓
Phase 7: E=mc² 指标
  7.1 实现 EMC2Calculator
  7.2 接入 trainExpert() 返回值
  7.3 接入 ShadowBrain MetaLearner
  7.4 验证：E=mc² 指标能反映系统是否变聪明
    ↓
Phase 8: 自动训练触发
  8.1 scheduler.onExperienceResult() 自动触发 trainExpert()
  8.2 配置 autoTrainThreshold + interval
  8.3 验证：执行经验后自动训练
    ↓
Phase 9: 知识汇聚 + 碰撞接入 ExperienceRouter
  9.1 route() 中接入 KnowledgeConvergence + CollisionEngine
  9.2 碰撞结果优先于单经验匹配
  9.3 验证：端到端流程——用户提问 → 汇聚 → 碰撞 → 执行 → 反馈
```

---

## 八、文件变更清单

### 新建

| 文件 | 行数 | 说明 |
|------|------|------|
| `src/intelligence/knowledge-node.ts` | ~80 | 统一知识节点抽象 |
| `src/intelligence/knowledge-convergence.ts` | ~200 | 知识汇聚器（6 来源） |
| `src/intelligence/collision-engine.ts` | ~300 | 碰撞引擎 |
| `src/ternary/emc2.ts` | ~100 | E=mc² 计算器 |

### 修改

| 文件 | 改动 |
|------|------|
| `src/intelligence/experience-router.ts` | route() 接入汇聚 + 碰撞 |
| `src/intelligence/experience-graph.ts` | 新增 matchHybrid() |
| `src/intelligence/experience-evolver.ts` | onSuccess 触发向量更新 |
| `src/ternary/trainer.ts` | trainExpert() 返回 emc2 |
| `src/ternary/scheduler.ts` | onExperienceResult() 自动触发训练 |
| `src/core/subsystems.ts` | 初始化 KnowledgeConvergence, CollisionEngine |
| `src/brain/shadow/index.ts` | MetaLearner 使用 emc2 |

---

## 九、与 Lewye (Python 原型) 的关系

| Lewye 概念 | Buddy 实现 | 移植难度 |
|-----------|-----------|---------|
| 碰撞引擎（湮灭/裂变/弹性） | Phase 6 CollisionEngine | 中 — 需适配 KnowledgeNode |
| 归元编码器（128维哈希投影） | Phase 5 KnowledgeConvergence.vectorize() | 低 — 复用容器 embedding |
| E=mc² 框架 | Phase 7 EMC2Calculator | 低 — 纯计算 |
| 模式记忆三阶段 | 已有 ExperienceUnit.stats.confidence | 无需移植 |
| 7 路反馈信号 | 已有 9 路 | 无需移植 |
| 元认知 | 已有 MetaLearner + SelfModifier | 无需移植 |

---

*v3.0 — 2026-05-31 — 知识汇聚 + 碰撞涌现*
*核心变化：知识不再按来源隔离，所有来源的知识在统一空间中碰撞*
