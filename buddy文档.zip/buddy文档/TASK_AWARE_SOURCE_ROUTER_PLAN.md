# TaskAwareSourceRouter — 精准源路由执行计划

> **目标**: 根据意图(TaskSignal)、任务(ExecutionPlan)、经验(RouteDecision)精准选择数据源，替代当前"囫囵吞枣式全查"。
>
> **创建日期**: 2026-06-10
> **关联模块**: `src/search/` `src/intelligence/knowledge-convergence.ts` `src/brain/`

---

## 1. 问题诊断

### 1.1 当前三层断裂

```
断裂 1: TaskSignal (domains, taskType, complexity)
         → Coordinator 用它选策略
         → 但不传给源选择

断裂 2: ExecutionPlan (mode, routeDecision)
         → PlanExecutor 用它选执行路径
         → 但不传给 KnowledgeConvergence

断裂 3: KnowledgeConvergence.converge()
         → searchWeb(query) 把原始 query 丢给所有 SearchProvider
         → 不知道 domains / taskType / 有没有经验
         → 10+ 源全查，大海捞针
```

### 1.2 具体影响

| 场景 | 当前行为 | 问题 |
|------|---------|------|
| 用户问 "Python asyncio 怎么用" | 查 Wikipedia + Bing + DDG + GitHub + SO + MDN + npm + PyPI + Arxiv + SemanticScholar | 10 个请求，8 个无关 |
| 用户问 "今天的新闻" | 查所有源包括 GitHub/PyPI/Arxiv | 技术源对新闻无用 |
| 本地经验已命中 (exp_direct) | 仍然查所有网络源 | 浪费时间和带宽 |
| 预算耗尽 | 不查网络（✓ 这个做对了） | — |
| 用户问 "transformer 论文" | 查所有源包括 npm/PyPI/SO | 非学术源返回噪音 |

### 1.3 已有基础设施（不需要重建）

| 组件 | 位置 | 能力 | 状态 |
|------|------|------|------|
| **TaskSignal** | `src/brain/types.ts:282` | domains, taskType, complexity, fineIntent | ✅ 完整 |
| **ExecutionPlan** | `src/brain/types.ts:64` | mode, routeDecision, selectedNodes | ✅ 完整 |
| **RouteDecision** | `src/intelligence/types.ts` | path, skill, confidence, novelty | ✅ 完整 |
| **ResourceState** | `src/brain/types.ts:303` | localCoverageRatio, budgetRemaining | ✅ 完整 |
| **IntentRouter** | `src/search/intent-router.ts` | classifyQueryIntent, routeProviders | ✅ 完整 |
| **SearchProvider** | `src/search/types.ts` | 统一接口, 10 个实现 | ✅ 完整 |
| **KnowledgeConvergence** | `src/intelligence/knowledge-convergence.ts` | 多源汇聚 | ✅ 完整 |
| **SourceFeedbackLoop** | 不存在 | 源质量反馈 | ❌ 需新建 |

**结论**: 90% 的基础设施已就绪，缺的是**胶水层**。

---

## 2. 架构设计

### 2.1 整体数据流

```
用户输入
  ↓
┌─────────────────────────────────────────────────────────────────┐
│  Perception 层 (已有)                                            │
│  FineIntentIndex → TaskSignal { domains, taskType, complexity } │
└──────────────────────────┬──────────────────────────────────────┘
                           ↓
┌──────────────────────────▼──────────────────────────────────────┐
│  Decision 层 (已有)                                              │
│  Coordinator → ExecutionPlan { mode, routeDecision }            │
│  ExperienceRouter → RouteDecision { path, skill, novelty }      │
└──────────────────────────┬──────────────────────────────────────┘
                           ↓
┌──────────────────────────▼──────────────────────────────────────┐
│  ★ TaskAwareSourceRouter (新增)                                  │
│                                                                   │
│  输入:                                                            │
│    - TaskSignal { domains, taskType, complexity }                │
│    - ExecutionPlan { mode, routeDecision }                       │
│    - ResourceState { localCoverageRatio, budgetRemaining }       │
│                                                                   │
│  处理:                                                            │
│    1. needsExternal? → 是否需要查网络                             │
│    2. selectCandidates → 从映射表选候选源                         │
│    3. rankByCapability → 按历史表现排序                           │
│    4. applyConstraints → 资源约束 + 数量控制                      │
│                                                                   │
│  输出:                                                            │
│    SourceDecision { sources, skip, strategy, reason }            │
└──────────────────────────┬──────────────────────────────────────┘
                           ↓
┌──────────────────────────▼──────────────────────────────────────┐
│  KnowledgeConvergence.converge() (改造)                          │
│                                                                   │
│  当前: searchWeb(query) → 全查                                    │
│  改造: fromSelectedSources(query, sourceDecision) → 精准查       │
│                                                                   │
│  sequential 模式: 按优先级逐个查，质量够就停                      │
│  parallel 模式: 并行查选中的源                                    │
└──────────────────────────┬──────────────────────────────────────┘
                           ↓
┌──────────────────────────▼──────────────────────────────────────┐
│  SourceFeedbackLoop (新增)                                       │
│                                                                   │
│  记录每次查询的: hitCount, avgRelevance, latencyMs, userAccepted │
│  更新源的 reliability 分数                                       │
│  下次路由时作为排序依据                                           │
└─────────────────────────────────────────────────────────────────┘
```

### 2.2 信息流对照表

| 信息 | 来源 | 当前用途 | 新增用途 |
|------|------|---------|---------|
| `signal.domains` | FineIntentIndex | Coordinator 选策略 | **→ 源选择: domain→源映射** |
| `signal.taskType` | MessageProcessor | Coordinator 选策略 | **→ 源选择: taskType→源映射** |
| `signal.complexity` | Coordinator | 选执行模式 | **→ 源选择: 控制源数量** |
| `plan.mode` | Coordinator | PlanExecutor 选路径 | **→ 源选择: local_only 时不查网络** |
| `plan.routeDecision` | ExperienceRouter | PlanExecutor 走经验 | **→ 源选择: exp_direct 时不查网络** |
| `resources.localCoverageRatio` | ResourceHub | Coordinator 判断 | **→ 源选择: 覆盖率高时不查网络** |
| `resources.budgetRemaining` | ResourceHub | Coordinator 判断 | **→ 源选择: 预算耗尽不查网络** |

---

## 3. 文件清单

### 3.1 新建文件

| 文件 | 行数 | 职责 |
|------|------|------|
| `src/search/source-capability.ts` | ~120 | 源能力声明 + 注册表 |
| `src/search/task-aware-router.ts` | ~250 | 核心路由器: 信号→源决策 |
| `src/search/source-feedback.ts` | ~100 | 源质量反馈闭环 |
| `src/search/__tests__/task-aware-router.test.ts` | ~200 | 单元测试 |

### 3.2 改造文件

| 文件 | 改动 | 影响范围 |
|------|------|---------|
| `src/intelligence/knowledge-convergence.ts` | `converge()` 新增 `sourceDecision` 参数 | 调用方需传入 |
| `src/search/providers/index.ts` | 每个 Provider 增加 `capabilities` 声明 | 不破坏现有接口 |
| `src/search/types.ts` | `SearchProvider` 接口增加 `capabilities()` 可选方法 | 向后兼容 |
| `src/core/subsystems.ts` | 初始化 TaskAwareSourceRouter + 注入到 Convergence | 初始化流程 |
| `src/brain/brain.ts` | 在 `decide()` 中调用 router 并传入 convergence | 核心调用链 |

### 3.3 不动的文件

| 文件 | 原因 |
|------|------|
| `src/search/intent-router.ts` | 已有分类逻辑，TaskAwareRouter 内部复用 |
| `src/brain/dispatch/coordinator.ts` | 策略选择逻辑不变 |
| `src/brain/right/features/integration-engine.ts` | 组装引擎不变，数据来源由 Convergence 控制 |
| `src/knowledge/web-source.ts` | KnowledgeSource 接口不变，只是不再被 Convergence 直接调用 |

---

## 4. 详细设计

### 4.1 `src/search/source-capability.ts` — 源能力声明

```typescript
/**
 * 源能力声明 + 注册表
 *
 * 每个源声明自己擅长什么（taskType + domain），
 * 系统根据历史表现动态更新 reliability。
 */

// ── 类型 ──

export interface SourceCapability {
  /** 源 ID（与 SearchProvider.id 一致） */
  id: string;
  /** 源显示名 */
  name: string;
  /** 源类型 */
  type: 'local' | 'web' | 'api' | 'rss';

  /** 任务适配度: taskType → 0-1 分数 */
  taskAffinity: Record<string, number>;
  /** 领域覆盖度: domain → 0-1 分数 */
  domainCoverage: Record<string, number>;

  /** 平均延迟 ms（初始值，后续从反馈学习） */
  avgLatencyMs: number;
  /** 可靠性 0-1（从反馈闭环学习） */
  reliability: number;
  /** 国内是否可达 */
  chinaAvailable: boolean;
  /** 是否需要 API Key */
  needsApiKey: boolean;
  /** 是否需要代理 */
  needsProxy: boolean;
}

// ── 默认能力表 ──
// 初始值，后续由 SourceFeedbackLoop 动态更新

export const DEFAULT_CAPABILITIES: SourceCapability[] = [
  {
    id: 'bing',
    name: 'Bing 搜索',
    type: 'web',
    taskAffinity: { chat: 0.2, tools: 0.3, reasoning: 0.7, background: 0.3, domain: 0.6 },
    domainCoverage: { code: 0.5, data: 0.6, factual: 0.8, creative: 0.3, knowledge: 0.8, academic: 0.4 },
    avgLatencyMs: 3000,
    reliability: 0.8,
    chinaAvailable: true,
    needsApiKey: false,
    needsProxy: false,
  },
  {
    id: 'github',
    name: 'GitHub 搜索',
    type: 'web',
    taskAffinity: { chat: 0.0, tools: 0.9, reasoning: 0.4, background: 0.1, domain: 0.7 },
    domainCoverage: { code: 0.95, data: 0.3, factual: 0.2, creative: 0.1, knowledge: 0.3, academic: 0.1 },
    avgLatencyMs: 4000,
    reliability: 0.6,
    chinaAvailable: true,
    needsApiKey: false,
    needsProxy: false,
  },
  {
    id: 'stackoverflow',
    name: 'StackOverflow',
    type: 'web',
    taskAffinity: { chat: 0.0, tools: 0.8, reasoning: 0.6, background: 0.1, domain: 0.5 },
    domainCoverage: { code: 0.9, data: 0.2, factual: 0.3, creative: 0.0, knowledge: 0.4, academic: 0.1 },
    avgLatencyMs: 3500,
    reliability: 0.7,
    chinaAvailable: true,
    needsApiKey: false,
    needsProxy: false,
  },
  {
    id: 'wikipedia',
    name: 'Wikipedia',
    type: 'web',
    taskAffinity: { chat: 0.3, tools: 0.1, reasoning: 0.6, background: 0.2, domain: 0.5 },
    domainCoverage: { code: 0.1, data: 0.3, factual: 0.9, creative: 0.2, knowledge: 0.95, academic: 0.6 },
    avgLatencyMs: 2000,
    reliability: 0.7,
    chinaAvailable: false,  // 国内不稳定
    needsApiKey: false,
    needsProxy: false,
  },
  {
    id: 'mdn',
    name: 'MDN 文档',
    type: 'web',
    taskAffinity: { chat: 0.0, tools: 0.7, reasoning: 0.3, background: 0.0, domain: 0.6 },
    domainCoverage: { code: 0.8, data: 0.1, factual: 0.4, creative: 0.0, knowledge: 0.3, academic: 0.0 },
    avgLatencyMs: 2000,
    reliability: 0.9,
    chinaAvailable: true,
    needsApiKey: false,
    needsProxy: false,
  },
  {
    id: 'npm',
    name: 'NPM Registry',
    type: 'web',
    taskAffinity: { chat: 0.0, tools: 0.9, reasoning: 0.1, background: 0.0, domain: 0.5 },
    domainCoverage: { code: 0.7, data: 0.0, factual: 0.1, creative: 0.0, knowledge: 0.1, academic: 0.0 },
    avgLatencyMs: 1500,
    reliability: 0.9,
    chinaAvailable: true,
    needsApiKey: false,
    needsProxy: false,
  },
  {
    id: 'pypi',
    name: 'PyPI',
    type: 'web',
    taskAffinity: { chat: 0.0, tools: 0.9, reasoning: 0.1, background: 0.0, domain: 0.5 },
    domainCoverage: { code: 0.7, data: 0.0, factual: 0.1, creative: 0.0, knowledge: 0.1, academic: 0.0 },
    avgLatencyMs: 2000,
    reliability: 0.85,
    chinaAvailable: true,
    needsApiKey: false,
    needsProxy: false,
  },
  {
    id: 'arxiv',
    name: 'ArXiv 论文',
    type: 'web',
    taskAffinity: { chat: 0.0, tools: 0.0, reasoning: 0.5, background: 0.1, domain: 0.8 },
    domainCoverage: { code: 0.2, data: 0.4, factual: 0.5, creative: 0.1, knowledge: 0.6, academic: 0.95 },
    avgLatencyMs: 5000,
    reliability: 0.7,
    chinaAvailable: true,
    needsApiKey: false,
    needsProxy: false,
  },
  {
    id: 'semantic_scholar',
    name: 'Semantic Scholar',
    type: 'web',
    taskAffinity: { chat: 0.0, tools: 0.0, reasoning: 0.4, background: 0.1, domain: 0.7 },
    domainCoverage: { code: 0.1, data: 0.3, factual: 0.4, creative: 0.0, knowledge: 0.5, academic: 0.9 },
    avgLatencyMs: 4000,
    reliability: 0.6,
    chinaAvailable: false,
    needsApiKey: false,
    needsProxy: false,
  },
  {
    id: 'duckduckgo',
    name: 'DuckDuckGo',
    type: 'web',
    taskAffinity: { chat: 0.2, tools: 0.2, reasoning: 0.5, background: 0.2, domain: 0.5 },
    domainCoverage: { code: 0.4, data: 0.5, factual: 0.7, creative: 0.2, knowledge: 0.7, academic: 0.3 },
    avgLatencyMs: 4000,
    reliability: 0.5,
    chinaAvailable: false,  // 国内不通
    needsApiKey: false,
    needsProxy: false,
  },
  {
    id: 'rss_tech_cn',
    name: '中文科技 RSS',
    type: 'rss',
    taskAffinity: { chat: 0.1, tools: 0.0, reasoning: 0.2, background: 0.8, domain: 0.3 },
    domainCoverage: { code: 0.2, data: 0.1, factual: 0.3, creative: 0.1, knowledge: 0.4, academic: 0.0 },
    avgLatencyMs: 2000,
    reliability: 0.8,
    chinaAvailable: true,
    needsApiKey: false,
    needsProxy: false,
  },
  {
    id: 'local_knowledge',
    name: '本地知识库',
    type: 'local',
    taskAffinity: { chat: 0.5, tools: 0.5, reasoning: 0.7, background: 0.3, domain: 0.6 },
    domainCoverage: { code: 0.6, data: 0.5, factual: 0.6, creative: 0.4, knowledge: 0.6, academic: 0.3 },
    avgLatencyMs: 10,
    reliability: 0.9,
    chinaAvailable: true,
    needsApiKey: false,
    needsProxy: false,
  },
  {
    id: 'local_code_index',
    name: '本地代码索引',
    type: 'local',
    taskAffinity: { chat: 0.0, tools: 0.9, reasoning: 0.3, background: 0.0, domain: 0.7 },
    domainCoverage: { code: 0.95, data: 0.1, factual: 0.1, creative: 0.0, knowledge: 0.1, academic: 0.0 },
    avgLatencyMs: 5,
    reliability: 0.95,
    chinaAvailable: true,
    needsApiKey: false,
    needsProxy: false,
  },
];

// ── 注册表 ──

export class SourceCapabilityRegistry {
  private capabilities: Map<string, SourceCapability> = new Map();

  constructor(initial?: SourceCapability[]) {
    for (const cap of initial ?? DEFAULT_CAPABILITIES) {
      this.capabilities.set(cap.id, cap);
    }
  }

  get(id: string): SourceCapability | undefined {
    return this.capabilities.get(id);
  }

  getAll(): SourceCapability[] {
    return [...this.capabilities.values()];
  }

  /** 动态更新源的可靠性（从反馈闭环调用） */
  updateReliability(id: string, reliability: number): void {
    const cap = this.capabilities.get(id);
    if (cap) {
      cap.reliability = Math.max(0, Math.min(1, reliability));
    }
  }

  /** 动态更新源的延迟（从反馈闭环调用） */
  updateLatency(id: string, latencyMs: number): void {
    const cap = this.capabilities.get(id);
    if (cap) {
      // 指数移动平均
      cap.avgLatencyMs = cap.avgLatencyMs * 0.7 + latencyMs * 0.3;
    }
  }
}
```

### 4.2 `src/search/task-aware-router.ts` — 核心路由器

```typescript
/**
 * TaskAwareSourceRouter — 根据任务信号精准选择数据源
 *
 * 三层信息融合:
 *   TaskSignal (意图) + ExecutionPlan (计划) + ResourceState (资源)
 *   → SourceDecision (查哪些源、怎么查)
 *
 * 替代当前"全查"策略，实现精准打击。
 */

import type { TaskSignal, ExecutionPlan, ResourceState } from '../brain/types.js';
import type { SourceCapability } from './source-capability.js';
import { SourceCapabilityRegistry, DEFAULT_CAPABILITIES } from './source-capability.js';

// ── 类型 ──

export interface SourceDecision {
  /** 选中的源 ID（按优先级排序） */
  sources: string[];
  /** 明确跳过的源（日志/调试用） */
  skip: string[];
  /** 查询策略 */
  strategy: QueryStrategy;
  /** 决策理由（可追溯） */
  reason: string;
  /** 预估延迟 ms */
  estimatedLatencyMs: number;
}

export interface QueryStrategy {
  /** 查询模式 */
  mode: 'parallel' | 'sequential';
  /** 最大源数（sequential 模式下提前停止的阈值） */
  maxSources: number;
  /** 质量阈值（达到后停止查询，仅 sequential 模式） */
  qualityThreshold: number;
  /** 是否优先用本地源 */
  preferLocal: boolean;
  /** 单源超时 ms */
  sourceTimeoutMs: number;
}

// ── 配置 ──

export interface RouterConfig {
  /** 简单任务最大源数 */
  maxSourcesSimple: number;
  /** 中等任务最大源数 */
  maxSourcesMedium: number;
  /** 复杂任务最大源数 */
  maxSourcesComplex: number;
  /** 本地覆盖率阈值（超过则不查网络） */
  localCoverageThreshold: number;
  /** 默认单源超时 ms */
  defaultSourceTimeoutMs: number;
}

const DEFAULT_CONFIG: RouterConfig = {
  maxSourcesSimple: 2,
  maxSourcesMedium: 3,
  maxSourcesComplex: 4,
  localCoverageThreshold: 0.7,
  defaultSourceTimeoutMs: 5000,
};

// ── 域→源映射 ──

const DOMAIN_SOURCE_MAP: Record<string, string[]> = {
  code:      ['local_code_index', 'github', 'stackoverflow', 'mdn', 'npm', 'pypi'],
  data:      ['local_knowledge', 'bing'],
  factual:   ['local_knowledge', 'bing', 'wikipedia'],
  creative:  ['local_knowledge', 'rss_tech_cn'],
  knowledge: ['local_knowledge', 'bing', 'wikipedia'],
  academic:  ['arxiv', 'semantic_scholar', 'wikipedia'],
};

// ── taskType→源映射 ──

const TASK_TYPE_SOURCE_MAP: Record<string, string[]> = {
  chat:       [],
  tools:      ['local_code_index', 'github'],
  reasoning:  ['local_knowledge', 'bing'],
  background: ['rss_tech_cn'],
  domain:     [],
};

// ── 路由器 ──

export class TaskAwareSourceRouter {
  private registry: SourceCapabilityRegistry;
  private config: RouterConfig;

  constructor(
    registry?: SourceCapabilityRegistry,
    config?: Partial<RouterConfig>,
  ) {
    this.registry = registry ?? new SourceCapabilityRegistry();
    this.config = { ...DEFAULT_CONFIG, ...config };
  }

  /**
   * 核心决策: 给定任务上下文，返回该查哪些源、怎么查
   */
  decide(
    signal: TaskSignal,
    plan: ExecutionPlan,
    resources: ResourceState,
  ): SourceDecision {

    // ── Step 1: 是否需要外部源 ──
    if (!this.needsExternalSources(signal, plan, resources)) {
      return {
        sources: [],
        skip: [],
        strategy: {
          mode: 'sequential', maxSources: 0,
          qualityThreshold: 1, preferLocal: true,
          sourceTimeoutMs: this.config.defaultSourceTimeoutMs,
        },
        reason: `不需要外部源: coverage=${resources.localCoverageRatio.toFixed(2)}, plan=${plan.mode}`,
        estimatedLatencyMs: 0,
      };
    }

    // ── Step 2: 选候选源 ──
    const candidates = this.selectCandidates(signal, plan);

    // ── Step 3: 过滤不可用源 ──
    const available = this.filterAvailable(candidates);

    // ── Step 4: 按能力排序 ──
    const ranked = this.rankByCapability(available, signal);

    // ── Step 5: 数量控制 ──
    const maxSources = this.computeMaxSources(signal, resources);
    const selected = ranked.slice(0, maxSources);
    const selectedIds = selected.map(s => s.id);
    const allIds = candidates.map(c => c.id);
    const skipped = allIds.filter(id => !selectedIds.includes(id));

    // ── Step 6: 策略 ──
    const strategy = this.buildStrategy(signal, plan, resources, selected);

    return {
      sources: selectedIds,
      skip: skipped,
      strategy,
      reason: this.buildReason(signal, plan, resources, selectedIds),
      estimatedLatencyMs: selected.reduce(
        (sum, s) => sum + s.avgLatencyMs, 0
      ) / Math.max(1, selected.length),
    };
  }

  /**
   * 获取源能力（供外部查询） */
  getRegistry(): SourceCapabilityRegistry {
    return this.registry;
  }

  // ── 内部方法 ──

  /**
   * 检查是否需要外部源
   */
  private needsExternalSources(
    signal: TaskSignal,
    plan: ExecutionPlan,
    resources: ResourceState,
  ): boolean {
    // 预算耗尽
    if (resources.budgetRemaining <= 0) return false;

    // 本地覆盖率充足
    if (resources.localCoverageRatio >= this.config.localCoverageThreshold) return false;

    // 计划明确要求本地
    if (plan.mode === 'local_only') return false;

    // 经验直出（高置信 + 低新颖度 → 不需要外部验证）
    if (plan.routeDecision?.path === 'exp_direct') return false;

    // 闲聊不需要
    if (signal.taskType === 'chat' && signal.complexity === 'simple') return false;

    // 需要世界知识的领域
    const needsWorld = signal.domains.some(d =>
      ['factual', 'knowledge', 'academic'].includes(d)
    );
    if (needsWorld) return true;

    // 代码任务: 本地覆盖率 < 0.4 时查网络
    if (signal.domains.includes('code') && resources.localCoverageRatio < 0.4) return true;

    // 中等以上复杂度
    return signal.complexity !== 'simple';
  }

  /**
   * 从信号中选择候选源
   */
  private selectCandidates(
    signal: TaskSignal,
    plan: ExecutionPlan,
  ): SourceCapability[] {
    const candidateIds = new Set<string>();
    const addSource = (id: string) => candidateIds.add(id);

    // ── 按 domains 选 ──
    for (const domain of signal.domains) {
      (DOMAIN_SOURCE_MAP[domain] ?? []).forEach(addSource);
    }

    // ── 按 taskType 选 ──
    (TASK_TYPE_SOURCE_MAP[signal.taskType] ?? []).forEach(addSource);

    // ── 按 routeDecision 调整 ──
    if (plan.routeDecision?.path === 'exp_verified') {
      // 经验验证路径: 优先查经验相关的领域源
      const skillTags = plan.routeDecision.skill?.tags ?? [];
      for (const tag of skillTags) {
        (DOMAIN_SOURCE_MAP[tag] ?? []).forEach(addSource);
      }
    }

    // ── fineIntent 补充 ──
    if (signal.fineIntent?.domains) {
      for (const domain of signal.fineIntent.domains) {
        (DOMAIN_SOURCE_MAP[domain] ?? []).forEach(addSource);
      }
    }

    // 转为 SourceCapability 对象
    return [...candidateIds]
      .map(id => this.registry.get(id))
      .filter((s): s is SourceCapability => s !== undefined);
  }

  /**
   * 过滤不可用源
   */
  private filterAvailable(candidates: SourceCapability[]): SourceCapability[] {
    return candidates.filter(s => {
      // 国内不可达
      if (!s.chinaAvailable) return false;
      // 需要代理
      if (s.needsProxy) return false;
      // 需要 API Key（后续可检查 key 是否存在）
      if (s.needsApiKey) return false;
      return true;
    });
  }

  /**
   * 按能力排序
   *
   * 综合分数 = taskAffinity * 0.35
   *          + domainCoverage * 0.35
   *          + reliability * 0.2
   *          + (1 - latencyNorm) * 0.1
   */
  private rankByCapability(
    candidates: SourceCapability[],
    signal: TaskSignal,
  ): SourceCapability[] {
    const maxLatency = Math.max(...candidates.map(c => c.avgLatencyMs), 1);

    const scored = candidates.map(c => {
      const taskScore = c.taskAffinity[signal.taskType] ?? 0.3;

      // domain 覆盖度: 取 signal.domains 中最高分
      const domainScore = signal.domains.length > 0
        ? Math.max(...signal.domains.map(d => c.domainCoverage[d] ?? 0.2))
        : 0.3;

      const latencyNorm = c.avgLatencyMs / maxLatency;

      const totalScore =
        taskScore * 0.35 +
        domainScore * 0.35 +
        c.reliability * 0.2 +
        (1 - latencyNorm) * 0.1;

      return { capability: c, score: totalScore };
    });

    scored.sort((a, b) => b.score - a.score);
    return scored.map(s => s.capability);
  }

  /**
   * 计算最大源数
   */
  private computeMaxSources(signal: TaskSignal, resources: ResourceState): number {
    let max: number;

    switch (signal.complexity) {
      case 'simple':
        max = this.config.maxSourcesSimple;
        break;
      case 'medium':
        max = this.config.maxSourcesMedium;
        break;
      case 'complex':
        max = this.config.maxSourcesComplex;
        break;
      default:
        max = this.config.maxSourcesMedium;
    }

    // 预算不足时减少源数
    if (resources.budgetRemaining < 0.3) {
      max = Math.min(max, 2);
    }

    // 高本地覆盖率时减少网络源
    if (resources.localCoverageRatio > 0.5) {
      max = Math.min(max, 2);
    }

    return Math.max(1, max);
  }

  /**
   * 构建查询策略
   */
  private buildStrategy(
    signal: TaskSignal,
    plan: ExecutionPlan,
    resources: ResourceState,
    selected: SourceCapability[],
  ): QueryStrategy {
    // 复杂任务并行查，简单任务顺序查
    const mode = signal.complexity === 'complex' ? 'parallel' : 'sequential';

    // 质量阈值: 简单任务要求高，复杂任务要求低
    const qualityThreshold = signal.complexity === 'simple' ? 0.6
      : signal.complexity === 'medium' ? 0.5
      : 0.4;

    // 本地源延迟低，优先用
    const preferLocal = resources.localCoverageRatio > 0.3;

    // 单源超时: 国内源短，海外源长
    const hasOverseas = selected.some(s => !s.chinaAvailable);
    const sourceTimeoutMs = hasOverseas ? 8000 : this.config.defaultSourceTimeoutMs;

    return { mode, maxSources: selected.length, qualityThreshold, preferLocal, sourceTimeoutMs };
  }

  /**
   * 构建决策理由（可追溯）
   */
  private buildReason(
    signal: TaskSignal,
    plan: ExecutionPlan,
    resources: ResourceState,
    selectedIds: string[],
  ): string {
    const parts: string[] = [];

    parts.push(`taskType=${signal.taskType}`);
    parts.push(`domains=[${signal.domains.join(',')}]`);
    parts.push(`complexity=${signal.complexity}`);

    if (plan.routeDecision?.path) {
      parts.push(`routePath=${plan.routeDecision.path}`);
    }

    parts.push(`coverage=${resources.localCoverageRatio.toFixed(2)}`);
    parts.push(`→ sources=[${selectedIds.join(',')}]`);

    return parts.join(', ');
  }
}
```

### 4.3 `src/search/source-feedback.ts` — 质量反馈闭环

```typescript
/**
 * SourceFeedbackLoop — 源质量反馈闭环
 *
 * 每次查询后记录结果质量，动态更新源的 reliability。
 * 实现"用得越多越准"的自适应效果。
 */

import type { SourceCapabilityRegistry } from './source-capability.js';

// ── 类型 ──

export interface SourceFeedback {
  /** 源 ID */
  sourceId: string;
  /** 查询内容 */
  query: string;
  /** 返回了多少有用结果 */
  hitCount: number;
  /** 平均相关度 0-1 */
  avgRelevance: number;
  /** 实际延迟 ms */
  latencyMs: number;
  /** 用户是否采纳了结果（可选，无用户交互时用 hitCount 推断） */
  userAccepted?: boolean;
  /** 时间戳 */
  timestamp: number;
}

// ── 反馈闭环 ──

export class SourceFeedbackLoop {
  private history: Map<string, SourceFeedback[]> = new Map();
  private registry: SourceCapabilityRegistry;
  private maxHistoryPerSource: number;

  constructor(registry: SourceCapabilityRegistry, maxHistoryPerSource = 100) {
    this.registry = registry;
    this.maxHistoryPerSource = maxHistoryPerSource;
  }

  /**
   * 记录一次查询反馈
   */
  record(feedback: SourceFeedback): void {
    const arr = this.history.get(feedback.sourceId) ?? [];
    arr.push(feedback);

    // 限制历史长度
    if (arr.length > this.maxHistoryPerSource) {
      arr.splice(0, arr.length - this.maxHistoryPerSource);
    }

    this.history.set(feedback.sourceId, arr);

    // 异步更新源的 reliability 和 latency
    this.updateSourceMetrics(feedback.sourceId);
  }

  /**
   * 获取源的历史反馈
   */
  getHistory(sourceId: string): SourceFeedback[] {
    return this.history.get(sourceId) ?? [];
  }

  /**
   * 获取所有源的统计摘要
   */
  getSummary(): Array<{
    sourceId: string;
    queryCount: number;
    avgHitCount: number;
    avgRelevance: number;
    avgLatencyMs: number;
    reliability: number;
  }> {
    const summary: Array<{
      sourceId: string;
      queryCount: number;
      avgHitCount: number;
      avgRelevance: number;
      avgLatencyMs: number;
      reliability: number;
    }> = [];

    for (const [sourceId, feedbacks] of this.history) {
      if (feedbacks.length === 0) continue;

      const cap = this.registry.get(sourceId);
      summary.push({
        sourceId,
        queryCount: feedbacks.length,
        avgHitCount: feedbacks.reduce((s, f) => s + f.hitCount, 0) / feedbacks.length,
        avgRelevance: feedbacks.reduce((s, f) => s + f.avgRelevance, 0) / feedbacks.length,
        avgLatencyMs: feedbacks.reduce((s, f) => s + f.latencyMs, 0) / feedbacks.length,
        reliability: cap?.reliability ?? 0.5,
      });
    }

    return summary.sort((a, b) => b.reliability - a.reliability);
  }

  // ── 内部方法 ──

  /**
   * 更新源的 reliability 和 latency
   *
   * reliability 公式:
   *   weightedScore = Σ(score_i * weight_i) / Σ(weight_i)
   *   其中 score = hitRate * 0.3 + relevance * 0.4 + userAccepted * 0.3
   *   weight = exp(-ageHours / 24)  // 24 小时半衰期
   */
  private updateSourceMetrics(sourceId: string): void {
    const feedbacks = this.history.get(sourceId);
    if (!feedbacks || feedbacks.length === 0) return;

    const now = Date.now();
    let weightedScore = 0;
    let totalWeight = 0;
    let weightedLatency = 0;

    for (const f of feedbacks) {
      const ageHours = (now - f.timestamp) / 3600000;
      const weight = Math.exp(-ageHours / 24); // 24 小时半衰期

      // 单次分数
      const hitScore = f.hitCount > 0 ? Math.min(f.hitCount / 3, 1) : 0;
      const acceptScore = f.userAccepted !== undefined
        ? (f.userAccepted ? 1 : 0)
        : (f.hitCount > 0 ? 0.5 : 0);  // 无用户反馈时用 hitCount 推断

      const score = hitScore * 0.3 + f.avgRelevance * 0.4 + acceptScore * 0.3;

      weightedScore += score * weight;
      totalWeight += weight;
      weightedLatency += f.latencyMs * weight;
    }

    if (totalWeight > 0) {
      const reliability = weightedScore / totalWeight;
      const avgLatency = weightedLatency / totalWeight;

      this.registry.updateReliability(sourceId, reliability);
      this.registry.updateLatency(sourceId, avgLatency);
    }
  }
}
```

### 4.4 `src/intelligence/knowledge-convergence.ts` 改造

```diff
  async converge(
    input: string,
    contextTags: string[] = [],
    toolResults?: Array<{ name: string; output: string; args: Record<string, unknown> }>,
+   sourceDecision?: import('../search/task-aware-router.js').SourceDecision,
  ): Promise<KnowledgeNode[]> {
    const nodes: KnowledgeNode[] = [];

    // 工具结果优先（不变）
    if (toolResults && toolResults.length > 0) { ... }

    // 其他来源并行采集
    const sources: Promise<KnowledgeNode[]>[] = [
      this.fromExperience(input, contextTags),
      this.fromTernary(input),
+     // 改造: 根据 sourceDecision 选择性采集
+     sourceDecision
+       ? this.fromSelectedSources(input, sourceDecision)
+       : this.fromWeb(input),
      this.fromConversation(),
    ];
    // ...
  }

+ /**
+  * 按 SourceDecision 精准查询
+  */
+ private async fromSelectedSources(
+   query: string,
+   decision: import('../search/task-aware-router.js').SourceDecision,
+ ): Promise<KnowledgeNode[]> {
+   if (decision.sources.length === 0) return [];
+
+   const nodes: KnowledgeNode[] = [];
+
+   // sequential 模式: 按优先级逐个查，质量够就停
+   if (decision.strategy.mode === 'sequential') {
+     for (const sourceId of decision.sources) {
+       const results = await this.querySingleSource(sourceId, query);
+       nodes.push(...results);
+
+       // 质量够了，提前停止
+       const quality = this.assessQuality(nodes);
+       if (quality >= decision.strategy.qualityThreshold) break;
+     }
+   }
+   // parallel 模式: 并行查选中的源
+   else {
+     const searches = decision.sources.map(id =>
+       this.querySingleSource(id, query).catch(() => [])
+     );
+     const results = await Promise.allSettled(searches);
+     for (const r of results) {
+       if (r.status === 'fulfilled') nodes.push(...r.value);
+     }
+   }
+
+   return nodes;
+ }
```

### 4.5 `src/brain/brain.ts` 调用链改造

```diff
  // 在 decide() 或 processMessage() 中

  // 现有: 构建 TaskSignal
  const signal = this.buildTaskSignal(input, perception);

  // 现有: Coordinator 决策
  const plan = this.coordinator.analyze(signal, resources, intuition, bodyState);

+ // 新增: 源路由决策
+ const sourceDecision = this.taskAwareRouter.decide(signal, plan, resources);
+ if (this.verbose) {
+   console.log(`[Brain] SourceRouter: ${sourceDecision.reason}`);
+ }

  // 改造: 传入 sourceDecision
  const knowledgeNodes = await this.convergence.converge(
    input,
    contextTags,
    toolResults,
+   sourceDecision,
  );
```

### 4.6 `src/core/subsystems.ts` 初始化

```diff
  // 在 initializeKnowledgeSystems() 或类似位置

+ import { TaskAwareSourceRouter } from '../search/task-aware-router.js';
+ import { SourceCapabilityRegistry, DEFAULT_CAPABILITIES } from '../search/source-capability.js';
+ import { SourceFeedbackLoop } from '../search/source-feedback.js';
+
+ // 初始化源路由
+ const sourceCapRegistry = new SourceCapabilityRegistry();
+ const sourceFeedback = new SourceFeedbackLoop(sourceCapRegistry);
+ const taskAwareRouter = new TaskAwareSourceRouter(sourceCapRegistry);
+
+ // 注入到 Brain
+ this.taskAwareRouter = taskAwareRouter;
+ this.sourceFeedback = sourceFeedback;
```

---

## 5. 测试计划

### 5.1 单元测试

| 测试文件 | 测试用例 | 验证点 |
|---------|---------|--------|
| `task-aware-router.test.ts` | 代码任务路由 | domains=['code'] → 选中 github/stackoverflow |
| | 学术任务路由 | domains=['academic'] → 选中 arxiv/semantic_scholar |
| | 通用知识路由 | domains=['knowledge'] → 选中 bing/wikipedia |
| | 新闻任务路由 | taskType='background' → 选中 rss_tech_cn |
| | 本地覆盖充足 | localCoverageRatio=0.8 → sources=[] |
| | 预算耗尽 | budgetRemaining=0 → sources=[] |
| | 经验直出 | routePath='exp_direct' → sources=[] |
| | 数量控制 | complex → maxSources=4, simple → maxSources=2 |
| | 国内过滤 | chinaAvailable=false → 被过滤 |
| `source-feedback.test.ts` | 记录反馈 | record() 后 history 有数据 |
| | 可靠性计算 | 多次正面反馈 → reliability 上升 |
| | 延迟更新 | 多次查询 → avgLatency 更新 |
| | 半衰期 | 老反馈权重低于新反馈 |

### 5.2 集成测试

| 场景 | 输入 | 期望行为 |
|------|------|---------|
| 代码问题 | "Python asyncio 怎么用" | 只查 local_code_index + github + SO |
| 论文问题 | "transformer 的论文" | 只查 arxiv + semantic_scholar |
| 新闻问题 | "今天的科技新闻" | 只查 rss_tech_cn |
| 本地命中 | 已有经验高置信 | 不查任何网络源 |
| 混合问题 | "Python 的 asyncio 论文" | code + academic 源都选中 |

---

## 6. 执行步骤

### Phase 1: 基础设施 (Day 1)

1. 创建 `src/search/source-capability.ts` — 源能力声明 + 注册表
2. 创建 `src/search/task-aware-router.ts` — 核心路由器
3. 创建 `src/search/source-feedback.ts` — 反馈闭环
4. 创建 `src/search/__tests__/task-aware-router.test.ts` — 单元测试
5. 运行测试确保通过

### Phase 2: 集成对接 (Day 2)

6. 改造 `src/intelligence/knowledge-convergence.ts` — `converge()` 接受 `SourceDecision`
7. 改造 `src/core/subsystems.ts` — 初始化 TaskAwareSourceRouter
8. 改造 `src/brain/brain.ts` — 调用链中插入路由决策
9. 运行现有测试确保不破坏

### Phase 3: 反馈闭环 (Day 3)

10. 在 `KnowledgeConvergence` 查询后自动调用 `sourceFeedback.record()`
11. 在 `SourceRouter` 排序时读取 `reliability`
12. 添加日志: 记录每次路由决策的理由

### Phase 4: 验证 (Day 4)

13. 手动测试: 不同类型的问题，观察路由决策
14. 对比测试: 改造前后的查询次数、延迟、结果质量
15. 编写集成测试

---

## 7. 风险与缓解

| 风险 | 概率 | 影响 | 缓解措施 |
|------|------|------|---------|
| 映射表不准（选错源） | 中 | 结果质量下降 | 反馈闭环自动修正 + 手动调优映射表 |
| sequential 模式提前停止太早 | 低 | 遗漏好结果 | qualityThreshold 可配置 + fallback 到 parallel |
| 国内源不可达 | 低 | 路由失败 | chinaAvailable 标记 + 自动降级 |
| 破坏现有功能 | 低 | 回归 | sourceDecision 为可选参数，不传时走原有逻辑 |
| 反馈数据不足 | 中 | reliability 不准 | 初始值合理设定 + 冷启动用默认分 |

---

## 8. 验收标准

- [ ] `TaskAwareSourceRouter.decide()` 根据 signal 正确选择源
- [ ] 国内不可达源被自动过滤
- [ ] 本地覆盖率高时不查网络源
- [ ] 经验直出时不查网络源
- [ ] sequential 模式下质量够就提前停止
- [ ] `KnowledgeConvergence.converge()` 接受 `SourceDecision` 并精准查询
- [ ] 现有测试全部通过（不破坏兼容性）
- [ ] 新测试覆盖所有路由场景
- [ ] 反馈闭环正确更新 reliability
- [ ] 日志可追溯每次路由决策的理由
