# ByteEncoder 通用语义增强计划

> **目标**：不重训现有权重，通过「成长微调 + 投影头适配」补齐通用语义短板
> **原则**：代码语义零损失，通用语义纯增量

---

## 当前状态

| 指标 | 值 | 目标 |
|------|-----|------|
| 代码语义 pos_sim | 0.994 | ≥0.99（保持） |
| 代码语义 gap | 1.889 | ≥1.8（保持） |
| STS Pearson | 0.444 | ≥0.70 |
| 聚类分离度 | 1.245 | ≥2.5 |
| 无关对 sim | 0.408 | ≤0.15 |
| 跨语言 sim | 0.354 | ≥0.45 |
| 检索 MRR | 0.833 | ≥0.90 |

---

## Phase 1: 在线成长微调（方案 B）

### 1.1 模型扩展

```
当前 GrowthLevel L3:
  numLayers=4, hiddenDim=256, ffnDim=1024, params=145K

扩展到 GrowthLevel L4:
  numLayers=6, hiddenDim=256, ffnDim=1024, params≈220K

扩展策略:
  - expandToNextLevel() 自动执行
  - 旧权重 Corner Embedding 迁移（零损失）
  - 新增 2 层 EncoderBlock + 新参数区域
  - buildNewParamMask(oldParamCount=145K) → 新参数 mask=true
```

**文件**: `src/brain/right/training/online-grow.ts`（新建）

### 1.2 通用语料准备

数据来源（5K 对，混合比例）:

| 类型 | 数量 | 来源 | 示例 |
|------|------|------|------|
| 中文同义句 | 2K | 构造 + 释义改写 | "怎么学编程" ↔ "编程入门指南" |
| 跨领域负样本 | 1K | 随机配对 | "天气" ↔ "数据库"（target=0） |
| 中英平行 | 1K | 术语对照 | "机器学习" ↔ "machine learning" |
| 通用问答对 | 1K | QA 对 | "什么是AI" ↔ "人工智能是..." |

**文件**: `training-data/general-semantic.jsonl`

### 1.3 ByteEncoderBridge 微调流程

```typescript
// 伪代码
const encoder = new ByteEncoder(config);
encoder.expandToNextLevel();           // L3 → L4
const bridge = new ByteEncoderBridge(encoder, {
  learningRate: 0.0001,                // 比主网络低
  temperature: 0.07,                   // BGE 默认温度
  successWeight: 1.0,
  failureWeight: 2.0,                  // 失败样本更重
});

// 设置新参数 mask（只训练新参数）
const oldParamCount = 145000;
bridge.buildNewParamMask(oldParamCount);

// 训练循环
for (const pair of generalPairs) {
  // 正样本：语义相近
  bridge.forward(pair.text_a, true);
  bridge.forward(pair.text_b, true);

  // 负样本：随机配对
  const negPair = randomPair(generalPairs);
  bridge.forward(negPair.text_a, false);

  bridge.backwardAndUpdate();
}

// 验证：代码语义不退化
assert(evalCodePairs(encoder) >= 0.99);  // pos_sim 不降
assert(evalCodeGap(encoder) >= 1.8);     // gap 不降
```

**文件**: `src/brain/right/training/online-grow.ts`

### 1.4 验证检查点

训练后运行 `test-encoder-compare.ts`，确认:

- [ ] 代码 pos_sim ≥ 0.99（不退化）
- [ ] 代码 gap ≥ 1.8（不退化）
- [ ] STS Pearson ≥ 0.55（Phase 1 提升）
- [ ] 聚类分离度 ≥ 1.8（Phase 1 提升）
- [ ] 无关对 sim ≤ 0.25（Phase 1 改善）

---

## Phase 2: 投影头适配（方案 A）

### 2.1 投影头架构

```
ByteEncoder.forward(text) → [256]
        ↓
  ProjectionHead (可选，不训练编码器)
        ↓
  Linear(256 → 128) + GELU + LayerNorm + L2Norm → [128]
```

参数量: 256×128 + 128 + 128 = **32,896**（~33K，极轻量）

**文件**: `src/brain/right/features/projection-head.ts`（新建）

### 2.2 使用方式

```typescript
// 代码语义：走原始路径（保持 pos=0.994）
const codeVec = encoder.forward(codeText);

// 通用语义：走投影头（提升区分度）
const generalVec = projectionHead(encoder.forward(text));
```

双通道输出，按场景切换。

### 2.3 投影头训练（可选）

投影头本身也可以用少量通用数据训练：

```typescript
// 冻结编码器，只训练投影头
for (const pair of generalPairs) {
  const vecA = projectionHead.forward(encoder.forward(pair.a));
  const vecB = projectionHead.forward(encoder.forward(pair.b));
  // InfoNCE loss
  const loss = infoNCE(vecA, vecB, batchNegatives);
  loss.backward();
  projectionHeadOptimizer.step();
}
```

**文件**: `src/brain/right/training/projection-train.ts`（新建）

---

## Phase 3: 集成与切换

### 3.1 自动路由

在 `encodeFeaturesV2` 中根据场景自动选择通道:

```typescript
function encodeFeaturesV2(input, rawText, scene: 'code' | 'general') {
  const baseVec = encoder.forward(rawText);
  if (scene === 'general' && projectionHead) {
    return projectionHead.forward(baseVec);
  }
  return baseVec;  // 代码场景走原始路径
}
```

### 3.2 ByteEncoderBridge 集成

在线微调时，根据任务类型自动路由:

- 代码任务 → 原始路径 + Bridge 训练代码参数
- 通用任务 → 投影头路径 + Bridge 训练投影头参数

---

## 文件清单

| 文件 | 操作 | 说明 |
|------|------|------|
| `training-data/general-semantic.jsonl` | 新建 | 5K 通用语义对 |
| `src/brain/right/training/online-grow.ts` | 新建 | 在线成长微调脚本 |
| `src/brain/right/features/projection-head.ts` | 新建 | 投影头模块 |
| `src/brain/right/training/projection-train.ts` | 新建 | 投影头训练脚本 |
| `src/brain/right/features/encoder.ts` | 修改 | 集成双通道路由 |
| `test-encoder-compare.ts` | 保留 | 验证用 |
| `src/brain/right/features/text-encoder.ts` | 不动 | 核心编码器不变 |

---

## 执行顺序

```
1. 生成 general-semantic.jsonl          (~5min)
2. 编写 online-grow.ts                   (~10min)
3. 运行成长微调 L3→L4                    (~5min)
4. 运行 test-encoder-compare.ts 验证     (~1min)
5. 编写 projection-head.ts               (~10min)
6. 编写 projection-train.ts              (~10min)
7. 训练投影头                             (~3min)
8. 集成双通道路由到 encoder.ts            (~10min)
9. 最终验证 + 推送 GitHub                 (~5min)
```

**总计: ~60min**

---

## 风险控制

| 风险 | 应对 |
|------|------|
| 成长后代码语义退化 | newParamMask 冻结旧参数，代码 pos_sim 作为 checkpoint |
| 通用数据质量差 | 人工构造 + 同义词典，不依赖爬虫 |
| 投影头过拟合 | 只 33K 参数，正则化充足 |
| 扩展失败 | expandToNextLevel() 有完整回退逻辑 |

---

## 成功标准

| 指标 | Phase 1 后 | Phase 2 后 | 最终目标 |
|------|-----------|-----------|---------|
| 代码 pos_sim | ≥0.99 | ≥0.99 | ≥0.99 ✅ |
| 代码 gap | ≥1.8 | ≥1.8 | ≥1.8 ✅ |
| STS Pearson | ≥0.55 | ≥0.65 | ≥0.70 |
| 聚类分离度 | ≥1.8 | ≥2.2 | ≥2.5 |
| 无关对 sim | ≤0.25 | ≤0.15 | ≤0.15 |
| 跨语言 sim | ≥0.40 | ≥0.45 | ≥0.45 |
| 推理速度 | <0.5ms | <0.5ms | <0.5ms ✅ |
