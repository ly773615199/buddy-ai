# 规则引擎增强 + 策略蒸馏优化 执行计划

> 目标：让左脑规则引擎成为确定性操作的主力，策略蒸馏从"二元生死"升级为"完整生命周期管理"。

## 背景

### 现状问题

**规则引擎：**
- 14 条可执行规则，覆盖 109 个工具（~13%）
- 中文 regex 用 `\b` 无效（已在 Phase 1 修复）
- 大量高频操作没有规则覆盖（包管理、构建、测试、Docker 等）

**策略蒸馏（PolicyDistiller）：**
- 只有"新增规则"和"淘汰规则"两种操作
- 没有优先级动态调整
- 没有置信度校准（confidence 写死不变）
- 没有规则合并机制
- 没有条件收窄/放宽
- 滑动窗口统计缺失（总数统计无法反映近期趋势）

### 设计原则

```
确定性操作 → 规则直连，跳过 LLM
不确定操作 → LLM 决策，结果回流蒸馏
规则生命周期：生成 → 试运行 → 校准 → 稳定 → 衰退 → 淘汰
```

---

## Phase 1: 补全种子可执行规则（14 → 40+）

### 1.1 文件写入/编辑类

文件: `src/brain/left/rule-engine.ts`

| ID | 触发词 | 工具 | 参数提取 |
|----|--------|------|----------|
| `seed-executable-file-write` | 写入/创建/保存/write + 文件 | `write_file` | 提取路径和内容 |
| `seed-executable-file-edit` | 修改/编辑/edit/改/替换 + 文件 | `edit_file` | 提取路径、old_text、new_text |
| `seed-executable-file-delete` | 删除/删掉/remove + 文件 | `delete_file` | 提取路径 |
| `seed-executable-file-info` | 文件信息/大小/属性/stat | `file_info` | 提取路径 |
| `seed-executable-file-append` | 追加/append + 文件 | `append_file` | 提取路径和内容 |
| `seed-executable-file-copy` | 复制/copy + 文件 | `copy_file` | 提取源路径和目标路径 |
| `seed-executable-file-move` | 移动/重命名/move/rename | `move_file` | 提取源路径和目标路径 |

### 1.2 Git 操作类

| ID | 触发词 | 工具 | 参数提取 |
|----|--------|------|----------|
| `seed-executable-git-commit` | git commit/提交/提交代码 | `git_commit` | 提取消息 |
| `seed-executable-git-push` | git push/推送/push | `exec` | `git push` |
| `seed-executable-git-merge` | git merge/合并/merge | `exec` | `git merge` |
| `seed-executable-git-stash` | git stash/暂存/stash | `exec` | `git stash` |
| `seed-executable-git-pull` | git pull/拉取/pull | `exec` | `git pull` |

### 1.3 包管理类

| ID | 触发词 | 工具 | 参数提取 |
|----|--------|------|----------|
| `seed-executable-npm-install` | npm install/安装依赖/装包 | `exec` | `npm install` |
| `seed-executable-npm-run` | npm run/运行/启动/start | `exec` | `npm run <script>` |
| `seed-executable-npm-test` | npm test/测试/跑测试 | `exec` | `npm test` |
| `seed-executable-npm-build` | npm build/构建/打包 | `exec` | `npm run build` |
| `seed-executable-pip-install` | pip install/安装python包 | `exec` | `pip install <pkg>` |
| `seed-executable-yarn` | yarn install/yarn add | `exec` | `yarn <cmd>` |

### 1.4 构建/编译类

| ID | 触发词 | 工具 | 参数提取 |
|----|--------|------|----------|
| `seed-executable-tsc` | tsc/typescript编译/类型检查 | `exec` | `npx tsc --noEmit` |
| `seed-executable-make` | make/编译 | `exec` | `make` |
| `seed-executable-cargo` | cargo build/cargo run/rust | `exec` | `cargo <cmd>` |

### 1.5 Docker 类

| ID | 触发词 | 工具 | 参数提取 |
|----|--------|------|----------|
| `seed-executable-docker-ps` | docker ps/容器列表/运行中的容器 | `exec` | `docker ps` |
| `seed-executable-docker-logs` | docker logs/容器日志 | `exec` | `docker logs <id>` |
| `seed-executable-docker-compose` | docker compose/启动服务 | `exec` | `docker compose up` |
| `seed-executable-docker-build` | docker build/构建镜像 | `exec` | `docker build` |

### 1.6 网络/调试类

| ID | 触发词 | 工具 | 参数提取 |
|----|--------|------|----------|
| `seed-executable-curl` | curl/请求/访问接口/fetch API | `exec` | `curl <url>` |
| `seed-executable-ping` | ping/连通性/网络测试 | `exec` | `ping <host>` |
| `seed-executable-wget` | wget/下载 | `exec` | `wget <url>` |

### 1.7 代码分析类

| ID | 触发词 | 工具 | 参数提取 |
|----|--------|------|----------|
| `seed-executable-tsc-check` | 类型检查/tsc/type check | `exec` | `npx tsc --noEmit` |
| `seed-executable-eslint` | eslint/lint/代码规范 | `exec` | `npx eslint .` |
| `seed-executable-wc` | 行数/多少行/wc | `exec` | `wc -l <file>` |
| `seed-executable-grep` | grep/搜索内容/查找文本 | `exec` | `grep -rn <pattern>` |

### 1.8 SSH/远程类

| ID | 触发词 | 工具 | 参数提取 |
|----|--------|------|----------|
| `seed-executable-ssh` | ssh/远程连接 | `exec` | `ssh <host>` |
| `seed-executable-scp` | scp/传输文件 | `exec` | `scp <src> <dst>` |

### 1.9 工具注册表类（利用已注册工具）

| ID | 触发词 | 工具 | 说明 |
|----|--------|------|------|
| `seed-executable-search-web` | 搜索/搜一下/百度/google | `search_web` | 提取关键词 |
| `seed-executable-fetch-url` | 打开链接/访问网页/fetch | `fetch_url` | 提取 URL |
| `seed-executable-analyze-file` | 分析文件/代码分析 | `analyze_file` | 提取路径 |
| `seed-executable-find-refs` | 查找引用/哪里用了/find refs | `find_references` | 提取符号名 |
| `seed-executable-scan-project` | 扫描项目/项目结构 | `scan_project` | 无 |
| `seed-executable-project-deps` | 项目依赖/依赖关系 | `project_deps` | 无 |
| `seed-executable-project-symbols` | 项目符号/函数列表 | `project_symbols` | 无 |

---

## Phase 2: 策略蒸馏生命周期管理

### 2.1 Rule 接口扩展

文件: `src/brain/types.ts`

```ts
export interface Rule {
  id: string;
  name: string;
  priority: number;
  condition: (signal: TaskSignal, resources: ResourceState,
              intuition?: IntuitionSignal, body?: BodyState) => boolean;
  action: (signal: TaskSignal, resources: ResourceState) => ExecutionPlan;
  source: 'builtin' | 'learned' | 'user';
  stats: {
    hits: number;
    successes: number;
    lastUsed: number;
    // === 新增字段 ===
    /** 最近 N 次命中结果（滑动窗口） */
    recentResults: boolean[];
    /** 校准后的置信度（基于实际成功率） */
    calibratedConfidence: number;
    /** 规则生命周期阶段 */
    lifecycle: 'probation' | 'active' | 'declining' | 'deprecated';
    /** 首次命中时间 */
    firstHitAt: number;
    /** 连续失败次数 */
    consecutiveFailures: number;
  };
  createdAt: number;
  // === 新增字段 ===
  /** 条件特征指纹（用于规则合并） */
  fingerprint?: string;
  /** 试运行期结束时间（probation → active） */
  probationUntil?: number;
}
```

### 2.2 DistillReport 扩展

```ts
export interface DistillReport {
  newRules: number;
  prunedRules: number;
  negations: number;
  clusters: number;
  totalRecords: number;
  durationMs: number;
  toolCallRules?: number;
  // === 新增字段 ===
  /** 置信度校准的规则数 */
  calibratedRules: number;
  /** 优先级调整的规则数 */
  priorityAdjusted: number;
  /** 合并的规则数 */
  mergedRules: number;
  /** 生命周期转换统计 */
  lifecycleTransitions: {
    probationToActive: number;
    activeToDeclining: number;
    decliningToDeprecated: number;
  };
}
```

### 2.3 PolicyDistiller 增强

文件: `src/brain/left/policy-distiller.ts`

#### 2.3.1 滑动窗口统计

```ts
const WINDOW_SIZE = 20; // 最近 20 次命中

/** 计算滑动窗口成功率 */
private getWindowedSuccessRate(rule: Rule): number {
  const window = rule.stats.recentResults;
  if (window.length === 0) return rule.stats.hits > 0
    ? rule.stats.successes / rule.stats.hits : 0.5;
  return window.filter(Boolean).length / window.length;
}
```

#### 2.3.2 置信度校准

```ts
/** 校准规则置信度 */
private calibrateConfidence(rule: Rule): void {
  const windowedRate = this.getWindowedSuccessRate(rule);
  const totalRate = rule.stats.hits > 0
    ? rule.stats.successes / rule.stats.hits : 0.5;
  // 加权：窗口 70% + 总体 30%（样本少时偏向总体）
  const windowWeight = Math.min(rule.stats.recentResults.length / WINDOW_SIZE, 1) * 0.7;
  rule.stats.calibratedConfidence = windowedRate * (0.3 + windowWeight)
    + totalRate * (0.7 - windowWeight);
}
```

#### 2.3.3 优先级动态调整

```ts
/** 根据表现动态调整优先级 */
private adjustPriority(rule: Rule): number {
  const conf = rule.stats.calibratedConfidence;
  const basePriority = rule.priority;

  if (conf >= 0.9) return Math.min(basePriority + 5, 100);   // 表现优秀，提权
  if (conf >= 0.7) return basePriority;                        // 表现良好，保持
  if (conf >= 0.5) return Math.max(basePriority - 5, 10);     // 表现一般，降权
  return Math.max(basePriority - 15, 1);                       // 表现差，大幅降权
}
```

#### 2.3.4 生命周期状态机

```
         命中 ≥5 且成功率 ≥0.7
  生成 ──────────────────────────→ 试运行(probation)
                                      │
                    命中 ≥10 且成功率 ≥0.7
                                      │
                                      ▼
                                  稳定(active)
                                      │
                    近期成功率 <0.5 连续 ≥5 次
                                      │
                                      ▼
                                  衰退(declining)
                                      │
                    成功率 <0.3 或 7天未使用
                                      │
                                      ▼
                                  淘汰(deprecated) → 删除
```

```ts
/** 生命周期状态转换 */
private updateLifecycle(rule: Rule): void {
  const { hits, successes, recentResults, consecutiveFailures, lifecycle } = rule.stats;
  const rate = this.getWindowedSuccessRate(rule);

  switch (lifecycle) {
    case 'probation':
      if (hits >= 10 && rate >= 0.7) {
        rule.stats.lifecycle = 'active';
      } else if (hits >= 5 && rate < 0.3) {
        rule.stats.lifecycle = 'deprecated';
      }
      break;

    case 'active':
      if (consecutiveFailures >= 5 && rate < 0.5) {
        rule.stats.lifecycle = 'declining';
      }
      break;

    case 'declining':
      if (rate >= 0.7) {
        rule.stats.lifecycle = 'active'; // 回升
      } else if (rate < 0.3 || this.isStale(rule)) {
        rule.stats.lifecycle = 'deprecated';
      }
      break;
  }
}

private isStale(rule: Rule): boolean {
  const maxIdle = 7 * 24 * 3600_000;
  return Date.now() - rule.stats.lastUsed > maxIdle;
}
```

#### 2.3.5 规则合并

```ts
/** 合并同 fingerprint 的 learned 规则 */
private mergeRules(engine: RuleEngine): number {
  const learned = engine.getRules().filter(r => r.source === 'learned');
  const groups = new Map<string, Rule[]>();

  for (const rule of learned) {
    const fp = rule.fingerprint ?? rule.id;
    if (!groups.has(fp)) groups.set(fp, []);
    groups.get(fp)!.push(rule);
  }

  let merged = 0;
  for (const [fp, rules] of groups) {
    if (rules.length <= 1) continue;

    // 保留表现最好的规则，吸收其他规则的统计
    const best = rules.reduce((a, b) =>
      a.stats.calibratedConfidence > b.stats.calibratedConfidence ? a : b);

    for (const rule of rules) {
      if (rule.id === best.id) continue;
      best.stats.hits += rule.stats.hits;
      best.stats.successes += rule.stats.successes;
      // 合并滑动窗口
      best.stats.recentResults.push(...rule.stats.recentResults);
      if (best.stats.recentResults.length > WINDOW_SIZE * 2) {
        best.stats.recentResults = best.stats.recentResults.slice(-WINDOW_SIZE * 2);
      }
      // 删除被合并的规则
      engine.removeRule(rule.id);
      merged++;
    }

    // 重新校准
    this.calibrateConfidence(best);
    best.stats.priority = this.adjustPriority(best);
  }

  return merged;
}
```

#### 2.3.6 条件收窄（Phase 2 增强）

```ts
/**
 * 对频繁误命中的规则收紧条件
 * 误命中 = 命中但执行失败
 */
private tightenCondition(rule: Rule, engine: RuleEngine): void {
  const failRate = 1 - rule.stats.calibratedConfidence;
  if (failRate < 0.3 || rule.stats.hits < 10) return;

  // 对 learned 规则：提高 confidence 阈值
  if (rule.source === 'learned') {
    const plan = rule.action({} as TaskSignal, {} as ResourceState);
    if (plan.confidence) {
      plan.confidence = Math.min(plan.confidence + 0.1, 0.99);
    }
  }
}
```

### 2.4 RuleEngine 增强

文件: `src/brain/left/rule-engine.ts`

#### 2.4.1 增强 feedback 方法

```ts
/** 规则反馈（增强版） */
feedback(ruleId: string, success: boolean): void {
  const rule = this.rules.find(r => r.id === ruleId);
  if (!rule) return;

  rule.stats.successes += success ? 1 : 0;

  // 滑动窗口更新
  rule.stats.recentResults.push(success);
  if (rule.stats.recentResults.length > WINDOW_SIZE) {
    rule.stats.recentResults.shift();
  }

  // 连续失败计数
  if (success) {
    rule.stats.consecutiveFailures = 0;
  } else {
    rule.stats.consecutiveFailures++;
  }

  // 首次命中记录
  if (!rule.stats.firstHitAt) {
    rule.stats.firstHitAt = Date.now();
  }
}
```

#### 2.4.2 新增 removeRule 方法

```ts
/** 移除指定规则（供合并使用） */
removeRule(ruleId: string): boolean {
  const before = this.rules.length;
  this.rules = this.rules.filter(r => r.id !== ruleId);
  return this.rules.length < before;
}
```

#### 2.4.3 新增 updateRuleStats 方法

```ts
/** 批量更新规则统计（蒸馏时调用） */
updateRuleStats(ruleId: string, updates: Partial<Rule['stats']>): void {
  const rule = this.rules.find(r => r.id === ruleId);
  if (rule) Object.assign(rule.stats, updates);
}
```

---

## Phase 3: 增强蒸馏流程

### 3.1 distill() 方法重构

```ts
async distill(engine: RuleEngine): Promise<DistillReport> {
  const t0 = Date.now();
  const report: DistillReport = {
    newRules: 0, prunedRules: 0, negations: 0,
    clusters: 0, totalRecords: 0, durationMs: 0,
    calibratedRules: 0, priorityAdjusted: 0, mergedRules: 0,
    lifecycleTransitions: { probationToActive: 0, activeToDeclining: 0, decliningToDeprecated: 0 },
  };

  // Step 1: 校准所有 learned 规则的置信度
  for (const rule of engine.getRules().filter(r => r.source === 'learned')) {
    this.calibrateConfidence(rule);
    report.calibratedRules++;
  }

  // Step 2: 调整优先级
  for (const rule of engine.getRules().filter(r => r.source === 'learned')) {
    const newPriority = this.adjustPriority(rule);
    if (newPriority !== rule.priority) {
      rule.priority = newPriority;
      report.priorityAdjusted++;
    }
  }

  // Step 3: 更新生命周期
  for (const rule of engine.getRules().filter(r => r.source === 'learned')) {
    const before = rule.stats.lifecycle;
    this.updateLifecycle(rule);
    if (before !== rule.stats.lifecycle) {
      this.countTransition(before, rule.stats.lifecycle, report);
    }
  }

  // Step 4: 从聚类生成新规则（保留原有逻辑）
  const clusterStats = this.memory.getClusterStats(3);
  report.clusters = clusterStats.length;
  for (const cluster of clusterStats) {
    if (cluster.successRate > 0.8 && cluster.count >= 5) {
      // 生成正规则（带生命周期：probation）
      this.createLearnedRule(engine, cluster);
      report.newRules++;
    }
    if (cluster.successRate < 0.2 && cluster.count >= 3) {
      engine.addNegation(cluster.records[0].signal);
      report.negations++;
    }
  }

  // Step 5: 从 tool call 模式生成规则
  report.toolCallRules = this.generateToolCallRules(engine);
  report.newRules += report.toolCallRules;

  // Step 6: 合并同 fingerprint 规则
  report.mergedRules = this.mergeRules(engine);

  // Step 7: 条件收窄
  for (const rule of engine.getRules().filter(r => r.source === 'learned')) {
    this.tightenCondition(rule, engine);
  }

  // Step 8: 淘汰 deprecated 规则
  report.prunedRules = this.pruneDeprecated(engine);

  report.durationMs = Date.now() - t0;
  report.totalRecords = this.memory.size;

  return report;
}
```

### 3.2 创建规则时初始化生命周期

```ts
private createLearnedRule(engine: RuleEngine, cluster: ClusterStats): void {
  const now = Date.now();
  engine.addLearnedRule({
    id: `learned-${cluster.fingerprint.slice(0, 16)}-${now}`,
    name: `蒸馏规则: ${cluster.fingerprint.slice(0, 30)}`,
    priority: 55,
    condition: (signal) => this.fingerprint(signal) === cluster.fingerprint,
    action: () => ({
      mode: cluster.dominantMode as any,
      reason: `蒸馏: 成功率${(cluster.successRate * 100).toFixed(0)}%`,
      selectedNodes: [{ id: 'primary', type: 'cloud_node' }],
      confidence: cluster.successRate,
      source: 'learned',
    }),
    source: 'learned',
    stats: {
      hits: cluster.count,
      successes: cluster.successCount,
      lastUsed: now,
      recentResults: cluster.records.map(r => r.outcome?.success ?? true).slice(-WINDOW_SIZE),
      calibratedConfidence: cluster.successRate,
      lifecycle: 'probation',
      firstHitAt: now,
      consecutiveFailures: 0,
    },
    createdAt: now,
    fingerprint: cluster.fingerprint,
    probationUntil: now + 24 * 3600_000, // 24小时试运行期
  });
}
```

---

## Phase 4: 测试验证

### 4.1 种子规则覆盖测试

| 输入 | 期望规则 | 期望工具 |
|------|----------|----------|
| `帮我写个文件 test.txt，内容 hello` | seed-executable-file-write | write_file |
| `把 main.ts 里的 console.log 删掉` | seed-executable-file-edit | edit_file |
| `删除 temp.log` | seed-executable-file-delete | delete_file |
| `npm install express` | seed-executable-npm-install | exec |
| `跑一下测试` | seed-executable-npm-test | exec |
| `docker ps` | seed-executable-dps | exec |
| `git commit -m "fix: bug"` | seed-executable-git-commit | git_commit |
| `curl http://localhost:3000` | seed-executable-curl | exec |
| `搜索 TODO` | seed-executable-search-web / file-search | search_web / search_files |

### 4.2 生命周期管理测试

| 场景 | 输入 | 期望行为 |
|------|------|----------|
| 新规则生成 | 聚类成功率 0.9, 样本 10 | lifecycle = 'probation' |
| 试运行通过 | 命中 10 次, 成功率 0.8 | lifecycle → 'active' |
| 规则衰退 | 连续失败 5 次, 窗口成功率 0.4 | lifecycle → 'declining' |
| 规则回升 | 衰退后连续成功, 窗口成功率 0.8 | lifecycle → 'active' |
| 规则淘汰 | 衰退 + 成功率 0.2 | lifecycle → 'deprecated' → 删除 |
| 置信度校准 | 实际成功率 0.6, 初始 0.85 | calibratedConfidence → ~0.6 |
| 优先级调整 | calibratedConfidence 0.9 | priority +5 |
| 规则合并 | 3 条同 fingerprint 规则 | 合并为 1 条最优规则 |

### 4.3 验证方法

1. 单元测试：模拟决策记录，验证蒸馏逻辑
2. 集成测试：dev 环境发送测试消息，检查执行路径
3. 回归测试：确保原有 builtin 规则不受影响

---

## 产出物清单

- [ ] `src/brain/types.ts` — Rule 接口扩展（lifecycle、recentResults、calibratedConfidence）
- [ ] `src/brain/left/rule-engine.ts` — 种子规则补全（14→40+）、feedback 增强、removeRule/updateRuleStats
- [ ] `src/brain/left/policy-distiller.ts` — 生命周期管理、置信度校准、优先级调整、规则合并、条件收窄
- [ ] `src/brain/left/policy-distiller.test.ts` — 蒸馏生命周期测试
- [ ] `src/brain/left/rule-engine.test.ts` — 种子规则覆盖测试

## 预期效果

| 指标 | 改前 | 改后 |
|------|------|------|
| 可执行规则覆盖 | 14/109 (13%) | 40+/109 (37%+) |
| 简单指令延迟 | 30s-∞ | <100ms |
| 规则生命周期 | 生/死二元 | 5 阶段状态机 |
| 置信度校准 | 静态写死 | 滑动窗口动态校准 |
| 优先级调整 | 固定不变 | 基于实测表现浮动 |
| 规则合并 | 无 | 同 fingerprint 自动合并 |
| LLM 调用频率 | ~97% | ~50% |
