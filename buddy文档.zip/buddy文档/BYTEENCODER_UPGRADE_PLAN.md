# ByteEncoder 升级计划 — 自动增长 + 增量训练 + 运行时学习

> 目标：ByteEncoder 不再是"预训练一次就冻结"的静态组件，而是能根据项目积累和主动投喂持续进化的活系统。

---

## 一、现状分析

### 当前架构

```
UTF-8 bytes → ByteEmbedding(256,32) → 熵驱动合并 → Proj(32→128) → EncoderBlock×2 → 128d
                                                                                      ↓
                                                                              IntuitionNet (消费向量)
```

### 当前参数量

| 组件 | 形状 | 参数量 |
|---|---|---|
| ByteEmbedding | [256, 32] | 8,192 |
| Projection W | [32, 128] | 4,096 |
| Projection B | [128] | 128 |
| Attention × 2 | 10 tensors/block × 2 | 132,096 |
| FFN × 2 | 6 tensors/block × 2 | 131,840 |
| **总计** | | **276,352** |

### 三个核心问题

| # | 问题 | 现状 | 影响 |
|---|---|---|---|
| 1 | **预训练是一次性的** | `pretrain-encoder.ts` 每次从零训练 | 新数据无法增量积累 |
| 2 | **运行时不学习** | `OnlineLearner` 只训练 IntuitionNet，不碰 ByteEncoder | ByteEncoder 权重冻结 |
| 3 | **架构不可扩展** | `numLayers=2, hiddenDim=128` 写死 | 数据量增长后容量不足 |

---

## 二、改造方案总览

```
┌─────────────────────────────────────────────────────────┐
│                    ByteEncoder 生命周期                    │
├─────────────────────────────────────────────────────────┤
│                                                         │
│  Phase 1: 增量预训练                                     │
│  ┌──────────┐    ┌──────────┐    ┌──────────┐           │
│  │ 项目代码  │───→│ 提取对   │───→│ 增量训练  │──┐        │
│  └──────────┘    └──────────┘    └──────────┘  │        │
│  ┌──────────┐    ┌──────────┐                  │        │
│  │ JSONL    │───→│ 投喂数据  │──────────────────┤        │
│  └──────────┘    └──────────┘                  │        │
│                                                ▼        │
│                                        checkpoints/     │
│                                        encoder-pretrain/ │
│                                        final.json       │
│                                                         │
│  Phase 2: 自动扩展                                       │
│  ┌──────────┐    ┌──────────┐    ┌──────────┐           │
│  │ 容量评估  │───→│ 扩展决策  │───→│ 权重迁移  │──┐        │
│  └──────────┘    └──────────┘    └──────────┘  │        │
│                                                ▼        │
│                                        扩展后的模型      │
│                                        (旧权重保留)      │
│                                                         │
│  Phase 3: 运行时学习                                     │
│  ┌──────────┐    ┌──────────┐    ┌──────────┐           │
│  │ 每次交互  │───→│ 梯度回传  │───→│ ByteEncoder│         │
│  │ 用户反馈  │    │ 到编码器  │    │ 权重更新   │          │
│  └──────────┘    └──────────┘    └──────────┘           │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

---

## 三、详细任务拆解

### Task 1: 增量预训练支持

**文件**: `src/brain/right/training/pretrain-encoder.ts`

**改动**:
1. 新增 `--resume` 参数：从 `checkpoints/encoder-pretrain/final.json` 加载已有权重继续训练
2. 新增 `--data` 参数：支持 JSONL 格式的自定义训练数据
3. 自动合并：项目代码对 + 自定义投喂对，去重后统一训练
4. 训练日志：记录 loss 曲线、正负样本 gap、每 epoch 评估

**增量训练流程**:
```
加载已有权重 (step=N)
  ↓
5 阶段增量训练 (scripts/dev-train-encoder.sh)
  Stage 0: cedict 词典 117k → lr=0.003, 2 epochs
  Stage 1: 基础 Q&A 19k → lr=0.002, 2 epochs
  Stage 2: 领域对话 23.75k → lr=0.001, 2 epochs
  Stage 3: 技术文本 28.5k → lr=0.0005, 1 epoch
  Stage 4: 泛化代码 23.75k → lr=0.0003, 1 epoch
  ↓
保存 (覆盖 final.json + final.weights.bin)
```

**训练数据**: `training-data/stages/` 下 5 个 JSONL 文件，共 212,060 对

**JSONL 数据格式**:
```jsonl
{"comment": "字词/输入/问题", "code": "释义/输出/回答", "source": "来源标识"}
```

**预计工作量**: 2-3 小时
**风险**: 低 — 纯增量改动，不改现有逻辑

---

### Task 2: ByteEncoder 自动扩展系统

**文件**: `src/brain/right/features/text-encoder.ts`

**新增方法**:

#### `expand(targetConfig)` — 核心扩展方法

**扩展策略**:

| 组件 | 扩展方式 | 权重迁移 |
|---|---|---|
| ByteEmbedding | byteDim 不能变 (UTF-8=256 固定) | N/A |
| Projection | [old_byteDim, old_H] → [new_byteDim, new_H] | 左上角嵌入旧权重，新区域 Xavier |
| Attention (已有块) | [old_H, old_H] → [new_H, new_H] | 左上角嵌入，新区域 Xavier |
| Attention (新块) | 全新 | Xavier 初始化 |
| FFN (已有块) | [old_H, old_ffn] → [new_H, new_ffn] | 左上角嵌入，新区域 Xavier |
| FFN (新块) | 全新 | Xavier 初始化 |

**关键: 左上角嵌入 (Corner Embedding)**:
```
旧权重 [128, 128]        新权重 [256, 256]
┌──────────────┐          ┌──────────────────────────┐
│              │          │  旧权重(128×128)  │ Xavier │
│   旧数据     │    →     │  ──────────────── │ ────── │
│              │          │  Xavier          │ Xavier │
└──────────────┘          └──────────────────────────┘
```

旧数据完全保留，新区域用 Xavier 初始化（小随机值），不破坏已有知识。

#### `assessCapacity()` — 容量评估

根据以下指标判断是否需要扩展:

| 指标 | 阈值 | 含义 |
|---|---|---|
| 预训练数据量 | > 10K 对 | 数据量超过当前容量 |
| 编码后向量方差 | < 0.01 | 向量坍缩，表征能力不足 |
| 下游任务准确率 | < 0.7 | IntuitionNet 准确率下降 |
| 序列长度分布 | P90 > maxSeqLen/2 | 频繁截断 |

#### `autoGrow()` — 一键自动增长

```typescript
async autoGrow(metrics: CapacityMetrics): Promise<boolean> {
  const expansion = this.planExpansion(metrics);
  if (!expansion) return false;  // 不需要扩展

  // 1. 备份当前权重
  await this.backup(`checkpoints/encoder-backup-${Date.now()}.json`);

  // 2. 执行扩展 + 权重迁移
  this.expand(expansion.target);

  // 3. 标记新参数需要训练
  this._newParamMask = this.buildNewParamMask(expansion);

  // 4. 保存扩展后的 checkpoint
  await this.saveCheckpoint();

  return true;
}
```

**扩展阶梯** (预定义的成长路径):

```
Level 0: L=2, H=128, FFN=256   →  276K params  (当前)
Level 1: L=3, H=128, FFN=256   →  408K params  (+48%)
Level 2: L=4, H=128, FFN=384   →  574K params  (+108%)
Level 3: L=4, H=256, FFN=512   →  2.1M params  (+660%)
Level 4: L=6, H=256, FFN=512   →  3.1M params  (+1020%)
Level 5: L=6, H=384, FFN=768   →  6.9M params  (+2400%)
```

每次扩展一步，不跳跃。扩展后运行少量增量预训练让新参数收敛。

**预计工作量**: 4-5 小时
**风险**: 中 — 权重迁移逻辑需要仔细测试，确保旧权重不被破坏

---

### Task 3: OnlineLearner 接入 ByteEncoder

**文件**:
- `src/brain/right/training/online-learner.ts`
- `src/brain/right/training/backward.ts`

**改动**:

当前 `backwardPass()` 只更新 IntuitionNet 的参数。需要:

1. **forward 时缓存 ByteEncoder 的中间结果**

```typescript
// 当前: ByteEncoder.forward() 返回 Float32Array，autograd 链断裂
// 改为: ByteEncoder.forwardTensor() 返回 Tensor，autograd 链完整
const textTensor = byteEncoder.forwardTensor(rawText);  // 已有方法
```

2. **backward 时将梯度传回 ByteEncoder**

```typescript
// 在 backwardPass 末尾追加:
if (textTensor && textTensor.grad) {
  // textTensor 的梯度已经通过 autograd 传到了 encoderBlock 的输入
  // 需要继续传过: encoderBlocks → projection → byteEmbedding
  autogradBackward(textTensor);

  // scatter byteEmbedding 梯度
  scatterByteEmbedGrad(byteEncoder, rawTextBytes, textTensor);
}
```

3. **只更新 ByteEncoder 中有梯度的参数**

```typescript
// 新参数有梯度，旧参数梯度为零 → 自然只训练新参数
const byteParams = byteEncoder.parameters();
optimizer.step_update(byteParams.filter(p => p.grad && hasNonZero(p.grad)));
```

**效果**:
- 用户每次交互的反馈（成功/失败）都会微调 ByteEncoder
- 高频使用的字节组合获得更精确的编码
- 低频/罕见字节组合保持预训练的通用编码

**预计工作量**: 5-6 小时
**风险**: 中高 — autograd 链需要验证，避免梯度爆炸

---

### Task 4: 增量预训练脚本增强

**文件**: `src/brain/right/training/pretrain-encoder.ts`

**新增功能**:

#### 4a. 多数据源加载器 ✅ 已完成

已实现 5 阶段课程数据加载，详见 `scripts/dev-train-encoder.sh`。
数据来源：cedict 词典、alpaca_gpt4_zh、belle_zh、CodeSearchNet (Python/JS/Java)。

#### 4b. 交互日志自动提取

```typescript
// 从 ~/.buddy/memory.db 中提取成功的 用户输入→系统响应 对
async function loadInteractionLog(dbPath: string): Promise<Pair[]> {
  const db = new Database(dbPath);
  const rows = db.prepare(`
    SELECT user_input, system_response
    FROM conversations
    WHERE success = 1 AND length(user_input) > 10
    ORDER BY timestamp DESC
    LIMIT 5000
  `).all();
  return rows.map(r => ({ comment: r.user_input, code: r.system_response }));
}
```

#### 4c. 课程学习 (Curriculum Learning)

```
Epoch 1-2: 简单数据 (短文本、高相似度对)
Epoch 3-4: 中等数据 (中等长度、混合相似度)
Epoch 5+:  全部数据 (包括困难样本)
```

**预计工作量**: 3-4 小时
**风险**: 低

---

### Task 5: 容量监控 + 自动触发

**新增文件**: `src/brain/right/features/capacity-monitor.ts`

**职责**: 持续监控 ByteEncoder 的健康状态，自动触发扩展或增量训练。

```typescript
interface CapacityMetrics {
  // 数据积累
  totalInteractions: number;      // 总交互数
  newPairsSinceLastTrain: number; // 上次训练后的新数据量
  uniqueVocabSeen: number;        // 见过的不同字节组合数

  // 编码质量
  avgVectorNorm: number;          // 平均向量范数 (应接近 1)
  vectorVariance: number;         // 向量方差 (过低=坍缩)
  cosineSimDistribution: {        // 余弦相似度分布
    mean: number;
    std: number;
    p5: number;                   // 5% 分位 (负样本应在此)
    p95: number;                  // 95% 分位 (正样本应在此)
  };

  // 下游表现
  intentAccuracy: number;         // 意图分类准确率
  toolSelectionAccuracy: number;  // 工具选择准确率
}

class CapacityMonitor {
  /** 每次交互后更新指标 */
  observe(interaction: InteractionData): void;

  /** 评估是否需要行动 */
  assess(): {
    needIncrementalTrain: boolean;  // 需要增量训练
    needExpansion: boolean;         // 需要架构扩展
    urgency: 'low' | 'medium' | 'high';
    reason: string;
  };

  /** 自动触发相应动作 */
  async autoAct(): Promise<void> {
    const assessment = this.assess();

    if (assessment.needExpansion) {
      await this.encoder.autoGrow(this.metrics);
      // 扩展后自动跑一轮增量训练
      await this.runIncrementalTrain({ epochs: 3 });
    }

    if (assessment.needIncrementalTrain) {
      await this.runIncrementalTrain({ epochs: 1 });
    }
  }
}
```

**触发条件**:

| 条件 | 动作 | 优先级 |
|---|---|---|
| 新数据 > 500 对 | 增量训练 1 epoch | 低 |
| 新数据 > 2000 对 | 增量训练 3 epochs | 中 |
| 向量方差 < 0.005 | 增量训练 + 检查数据质量 | 高 |
| 交互 > 10000 + 准确率下降 | 架构扩展 Level+1 | 高 |
| 交互 > 50000 | 架构扩展 Level+1 | 中 |

**预计工作量**: 2-3 小时
**风险**: 低

---

## 四、实施顺序

```
Phase A: 基础 (不改运行时行为)
  ├─ Task 1: 增量预训练支持           [2-3h]  ← 立即可用
  └─ Task 4: 预训练脚本增强           [3-4h]  ← 与 Task 1 合并

Phase B: 架构 (扩展 ByteEncoder 本身)
  └─ Task 2: 自动扩展系统             [4-5h]  ← 核心难点

Phase C: 运行时 (改变学习行为)
  ├─ Task 3: OnlineLearner 接入       [5-6h]  ← 需要充分测试
  └─ Task 5: 容量监控 + 自动触发      [2-3h]  ← 收尾

总工作量: 16-21 小时
建议顺序: Task 1 → Task 4 → Task 2 → Task 3 → Task 5
```

---

## 五、风险与缓解

| 风险 | 概率 | 影响 | 缓解措施 |
|---|---|---|---|
| 权重迁移破坏旧知识 | 中 | 高 | 迁移后立即跑回归测试，对比迁移前后编码质量 |
| autograd 链断裂 | 中 | 高 | 数值梯度检查 (numerical gradient check) |
| 增量训练过拟合 | 低 | 中 | 早停 + 验证集 + 学习率衰减 |
| 扩展后推理变慢 | 低 | 低 | CPU 推理基准测试，超时则降级 |
| 向量空间坍缩 | 低 | 高 | 监控向量方差，触发时自动调整 lr |

---

## 六、验收标准

| 阶段 | 验收条件 |
|---|---|
| Task 1 完成 | `pretrain-encoder.ts --resume --data custom.jsonl` 正确增量训练 |
| Task 2 完成 | `encoder.expand({numLayers:4})` 后编码质量不退化 (余弦相似度变化 < 5%) |
| Task 3 完成 | 100 次交互后 ByteEncoder 参数有非零梯度 |
| Task 5 完成 | 运行 1000 次交互后自动触发至少一次增量训练 |
| 全部完成 | ByteEncoder 从 276K 自动增长到 2M+，编码质量持续提升 |

---

## 七、后续可选扩展

1. **多语言优化**: 中文 UTF-8 通常是 3 字节/字，当前 byte-level 对中文效率偏低。可考虑 2-gram 或 3-gram 合并。
2. **知识蒸馏**: 用大模型 (如 GPT-4) 的 embedding 作为 teacher，蒸馏到 ByteEncoder。
3. **LoRA 微调**: 不扩展全量参数，用 LoRA 做轻量适配。
4. **分布式训练**: 多个 Buddy 实例共享训练数据，联邦学习。
