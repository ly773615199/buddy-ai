# 本地执行能力补全计划 — 让规则引擎 + BuddyLM 真正干活

> 版本: v1.0
> 日期: 2026-05-22
> 原则: **竞争出方案，协作做执行，谁合适谁上**
> 状态: 待启动

---

## 一、问题定义

### 1.1 现状：所有执行都经过云端 LLM

```
用户消息 → 三脑决策 → 规则引擎/组装引擎/BuddyLM 生成文本
                                              ↓
                                      localGeneration（文本建议）
                                              ↓
                              confidence < 0.6? → 云端 LLM 执行工具调用 ← 主路径
                              confidence >= 0.6? → 直接返回文本（不执行工具）
```

**核心断裂**：
- 本地方案只能输出"文本建议"，不能输出"可执行的工具调用序列"
- 即使本地方案赢了竞争，plan 还是被映射到云端 LLM 执行
- 没有云端 LLM 时，系统无法执行任何工具操作

### 1.2 目标：学徒超越师傅

```
阶段 1（现在）: 云端 LLM 是主力，本地方案太弱竞争不过
     ↓ 蒸馏学习
阶段 2（过渡）: 本地方案能和云端 LLM 平衡，频繁任务本地搞定
     ↓ 持续进化
阶段 3（成熟）: 常规任务本地更快更好，云端 LLM 只在复杂/新场景介入
```

**竞争关系**（出方案时）：
```
规则引擎方案 ─┐
BuddyLM 方案 ─┼─→ 裁决器 → 选最优方案
组装引擎方案 ─┤
云端 LLM 方案 ─┘
```

**协作关系**（执行时）：
```
选定方案 → 拆解为步骤 → 每步评估最合适执行者 → 协作执行
                         ├─ 规则引擎：调度决策、条件判断
                         ├─ BuddyLM：文本理解、生成、推理
                         ├─ 组装引擎：知识检索、信息整合
                         ├─ 工具层：直接执行（read/write/exec/search）
                         └─ 云端 LLM：复杂推理、知识补充（降级时）
```

---

## 二、架构设计

### 2.1 核心概念：ExecutablePlan

当前 `ExecutionPlan` 只描述"做什么模式"，需要升级为包含"具体怎么做"的可执行计划：

```typescript
// 当前（不可执行）
interface ExecutionPlan {
  mode: 'single' | 'parallel' | 'cascade' | ...;
  reason: string;
  selectedNodes: OrchestrationNode[];  // 最终映射到云端 LLM
  confidence: number;
  source: string;
}

// 目标（可执行）
interface ExecutablePlan {
  mode: 'single' | 'parallel' | 'sequential' | 'conditional';
  reason: string;
  confidence: number;
  source: 'rule' | 'buddyLM' | 'assembly' | 'cloudLLM' | 'experience';

  // 新增：结构化执行步骤
  steps: ExecutableStep[];

  // 新增：预期输出描述
  expectedOutput: string;

  // 新增：是否需要云端 LLM 增强
  needsCloudEnhancement: boolean;
  enhancementReason?: string;
}

interface ExecutableStep {
  id: string;
  type: 'tool_call' | 'reasoning' | 'decision' | 'generate' | 'verify';

  // 工具调用步骤
  tool?: string;
  args?: Record<string, unknown>;

  // 推理步骤（BuddyLM 或云端 LLM）
  prompt?: string;
  expectedFormat?: 'text' | 'json' | 'tool_calls';

  // 决策步骤（规则引擎）
  condition?: string;
  branches?: Array<{ condition: string; nextStepId: string }>;

  // 依赖
  dependsOn: string[];

  // 执行者偏好（按优先级）
  preferredExecutors: Array<'local' | 'buddyLM' | 'cloudLLM'>;

  // 超时
  timeoutMs?: number;
}
```

### 2.2 竞争层升级

让每个本地组件都能产出 `ExecutablePlan`，而不仅仅是文本：

```
┌─────────────────────────────────────────────────────────────┐
│                     竞争层（出方案）                          │
│                                                             │
│  规则引擎 ──→ ExecutablePlan（确定性步骤序列）                │
│    输入: signal + resources + experienceHit                  │
│    输出: 直接映射到已知工具调用模式                            │
│    优势: 零延迟、确定性、可审计                               │
│    劣势: 只能处理已知模式                                     │
│                                                             │
│  BuddyLM ──→ ExecutablePlan（推理生成的步骤序列）             │
│    输入: 用户意图 + 上下文 + 检索结果                         │
│    输出: Decoder 生成结构化 tool call JSON                    │
│    优势: 能处理新场景、有推理能力                              │
│    劣势: 质量依赖训练数据                                     │
│                                                             │
│  组装引擎 ──→ ExecutablePlan（检索+组装的步骤序列）            │
│    输入: 用户问题 + 知识库检索结果                             │
│    输出: 从知识模板组装的执行计划                              │
│    优势: 有知识支撑、可验证                                    │
│    劣势: 限于已有知识覆盖的领域                                │
│                                                             │
│  云端 LLM ──→ ExecutablePlan（LLM 生成的步骤序列）            │
│    输入: 完整上下文 + 工具定义                                 │
│    输出: function calling 生成的 tool calls                   │
│    优势: 最强推理、最广覆盖                                    │
│    劣势: 延迟高、成本高、依赖网络                              │
│                                                             │
│              ↓ 全部转化为 ExecutablePlan ↓                    │
│                                                             │
│  裁决器 ──→ 选择最优 ExecutablePlan                           │
│    评分维度: 质量(0.5) + 可行性(0.25) + 速度(0.15) + 成本(0.1)│
└─────────────────────────────────────────────────────────────┘
```

### 2.3 协作层升级

方案确定后，每一步按"谁最合适"分配执行者：

```
┌─────────────────────────────────────────────────────────────┐
│                     协作层（做执行）                          │
│                                                             │
│  ExecutablePlan.steps[]                                      │
│       ↓ 每一步                                               │
│  执行者选择器:                                                │
│    ├─ 工具调用（read/write/exec/search）→ 本地直接执行        │
│    ├─ 简单推理（分类/匹配/格式化）→ BuddyLM 本地执行          │
│    ├─ 知识检索（问答/总结）→ 组装引擎本地执行                  │
│    ├─ 复杂推理（多步分析/创作）→ 云端 LLM 执行                │
│    └─ 条件判断 → 规则引擎本地执行                              │
│                                                             │
│  执行结果 → 反馈到下一步 → 直到所有步骤完成                    │
└─────────────────────────────────────────────────────────────┘
```

### 2.4 蒸馏闭环

云端 LLM 的成功执行 → 蒸馏为本地能力：

```
云端 LLM 成功执行
  ↓
提取: 输入意图 + 工具调用序列 + 输出结果
  ↓
编译为经验: ExperienceCompiler.compile()
  ↓
存入经验图谱: ExperienceGraph.addNode()
  ↓
训练 BuddyLM: 输入意图 → 期望输出 tool call JSON
  ↓
下次同类任务: 本地方案能赢竞争
```

---

## 三、实施阶段

### Phase 1: 规则引擎产出可执行计划（1-2 周）

**目标**: 规则引擎的 action 输出从 `{mode, reason, selectedNodes}` 升级为包含 `steps[]` 的可执行计划。

**改动文件**:
- `src/brain/left/rule-engine.ts` — 规则 action 返回 ExecutablePlan
- `src/brain/types.ts` — 新增 ExecutablePlan / ExecutableStep 类型
- `src/core/plan-executor.ts` — 新增 executeLocalPlan() 路径
- `src/core/agent.ts` — orchestrateWithThreeBrain() 优先检查本地可执行计划

**具体改动**:

```typescript
// types.ts — 新增类型
export interface ExecutableStep {
  id: string;
  type: 'tool_call' | 'reasoning' | 'decision' | 'generate' | 'verify';
  tool?: string;
  args?: Record<string, unknown>;
  prompt?: string;
  dependsOn: string[];
  preferredExecutors: Array<'local' | 'buddyLM' | 'cloudLLM'>;
  timeoutMs?: number;
}

export interface ExecutablePlan {
  steps: ExecutableStep[];
  expectedOutput: string;
  confidence: number;
  source: string;
  needsCloudEnhancement: boolean;
}
```

```typescript
// rule-engine.ts — 规则 action 升级
// 现有规则可以渐进升级，旧格式自动转换
{
  id: 'seed_git_status',
  condition: (signal) => signal.domains.includes('code') && /git.*status/i.test(signal.content ?? ''),
  action: (signal, resources) => ({
    mode: 'single',
    reason: 'git status 查询',
    confidence: 0.9,
    source: 'rule',
    // 新增：可执行步骤
    executablePlan: {
      steps: [{
        id: 'step_1',
        type: 'tool_call',
        tool: 'exec',
        args: { command: 'git status' },
        dependsOn: [],
        preferredExecutors: ['local'],
      }],
      expectedOutput: 'git 仓库状态',
      confidence: 0.9,
      source: 'rule',
      needsCloudEnhancement: false,
    },
  }),
}
```

```typescript
// plan-executor.ts — 新增本地执行路径
async function executeLocalPlan(ctx: ExecutionContext, plan: ExecutablePlan): Promise<ExecutionResult> {
  const stepResults = new Map<string, string>();

  for (const step of plan.steps) {
    // 检查依赖
    if (!step.dependsOn.every(d => stepResults.has(d))) continue;

    if (step.type === 'tool_call' && step.tool) {
      // 直接调用本地工具，不经过云端 LLM
      const result = await ctx.sys.tools.execute(step.tool, resolveArgs(step.args, stepResults));
      stepResults.set(step.id, result);
    } else if (step.type === 'generate' && step.prompt) {
      // BuddyLM 本地生成
      const result = await ctx.sys.threeBrain?.right.executeBuddyLM(step.prompt);
      stepResults.set(step.id, result?.text ?? '');
    }
    // ... 其他步骤类型
  }

  return { text: stepResults.values().toArray().join('\n'), source: 'local_plan', toolCalls: [] };
}
```

```typescript
// agent.ts — orchestrateWithThreeBrain 升级
// 在检查 localGeneration 之前，先检查 executablePlan
if (decision.executablePlan && decision.executablePlan.confidence >= 0.5) {
  // 本地可执行计划，直接执行，不经过云端 LLM
  return {
    content: '',  // 执行后填充
    mode: 'local_only',
    reason: `本地执行计划: ${decision.executablePlan.source}`,
    executablePlan: decision.executablePlan,
    // ...
  };
}
```

**验证标准**:
- [ ] 规则引擎能输出包含 steps[] 的 ExecutablePlan
- [ ] plan-executor 能执行本地计划（至少支持 exec/read/write 工具）
- [ ] 旧格式规则自动转换为 ExecutablePlan（向后兼容）
- [ ] git status / file read 等简单任务零云端 LLM 执行

---

### Phase 2: BuddyLM 生成结构化 tool calls（2-3 周）

**目标**: BuddyLM 的 Decoder 不只是生成自然语言，还能生成结构化的工具调用 JSON。

**改动文件**:
- `src/brain/right/nn/decoder.ts` — 支持 tool call 格式输出
- `src/brain/right/nn/buddy-lm.ts` — generateWithToolCalls() 方法
- `src/brain/right/training/buddy-lm-trainer.ts` — tool call 格式的训练样本
- `src/brain/shadow/index.ts` — 蒸馏闭环：云端 LLM tool calls → 训练样本

**核心思路**:

```
BuddyLM Decoder 输出格式扩展:
  模式 1: 自然语言（现有）
  模式 2: tool call JSON（新增）
    {"tool": "exec", "args": {"command": "git diff"}}
    {"tool": "read", "args": {"file_path": "src/index.ts"}}

选择逻辑:
  简单任务（经验覆盖）→ 模式 2（直接输出 tool calls）
  复杂任务（需要推理）→ 模式 1（先推理再转 tool calls）
```

**训练数据来源**:
1. 云端 LLM 的成功 tool calls → 直接作为训练样本
2. 经验图谱的 ExperienceUnit.steps → 转换为 tool call 格式
3. 种子经验 → 预训练数据

**验证标准**:
- [ ] BuddyLM 能输出格式正确的 tool call JSON
- [ ] 简单任务（git status、file read）BuddyLM 直接输出 tool calls
- [ ] tool call 格式的训练样本能正常训练
- [ ] 云端 LLM 成功执行后自动蒸馏为 BuddyLM 训练样本

---

### Phase 3: 执行层接入本地计划（1-2 周）

**目标**: plan-executor 新增 `executeLocalPlan` 路径，能直接执行本地组件的可执行计划。

**改动文件**:
- `src/core/plan-executor.ts` — 核心改动
- `src/tools/registry.ts` — 工具注册表暴露 execute() 接口
- `src/core/agent.ts` — 优先走本地执行路径

**执行者选择逻辑**:

```typescript
function selectExecutor(step: ExecutableStep, ctx: ExecutionContext): 'local' | 'buddyLM' | 'cloudLLM' {
  // 1. 工具调用 → 本地直接执行
  if (step.type === 'tool_call' && step.tool) {
    const tool = ctx.sys.tools.get(step.tool);
    if (tool) return 'local';
  }

  // 2. 简单推理 → BuddyLM
  if (step.type === 'generate' && step.expectedFormat === 'text') {
    if (ctx.sys.threeBrain?.right.hasBuddyLM()) return 'buddyLM';
  }

  // 3. 复杂推理 → 云端 LLM
  if (step.type === 'reasoning' || step.expectedFormat === 'json') {
    return 'cloudLLM';
  }

  // 4. 默认 → 云端 LLM
  return 'cloudLLM';
}
```

**渐进迁移策略**:
```
Phase 3.1: executeLocalPlan 只处理 tool_call 类型步骤（纯本地执行）
Phase 3.2: 集成 BuddyLM 处理 generate 类型步骤
Phase 3.3: 只有 reasoning 类型步骤才走云端 LLM
```

**验证标准**:
- [ ] tool_call 步骤能直接调用本地工具（不经过云端 LLM）
- [ ] 混合计划（部分本地 + 部分云端）能正确执行
- [ ] 执行结果能正确传递给依赖步骤
- [ ] 超时和错误处理正确

---

### Phase 4: 蒸馏闭环 — 云端 LLM 教本地（2-3 周）

**目标**: 云端 LLM 的每次成功执行都成为本地组件的学习素材。

**改动文件**:
- `src/brain/dispatch/learner.ts` — 增强蒸馏逻辑
- `src/intelligence/experience-compiler.ts` — 编译 tool call 序列为经验
- `src/brain/right/training/buddy-lm-trainer.ts` — tool call 训练样本收集
- `src/brain/shadow/index.ts` — 自训练闭环接入

**蒸馏管线**:

```
云端 LLM 成功执行
  ↓
提取结构化数据:
  - 用户意图（signal.domains + intent category）
  - 工具调用序列（toolCalls[]）
  - 执行结果（result text）
  - 质量分数（quality assessment）
  ↓
三路蒸馏:
  ├─ 经验图谱: 编译为 ExperienceUnit（可复用的步骤序列）
  ├─ BuddyLM: 输入意图 → 期望输出 tool call JSON（训练样本）
  └─ 规则引擎: 高频模式 → 自动生成规则（PolicyDistiller）
  ↓
下次同类任务: 本地方案能赢竞争
```

**关键实现**:

```typescript
// learner.ts — 增强蒸馏
async distillCloudLLMExecution(
  signal: TaskSignal,
  toolCalls: Array<{ name: string; args: Record<string, unknown>; result: string }>,
  output: string,
  quality: number,
): Promise<void> {
  // 1. 编译为经验
  const conv: ConversationSnapshot = {
    id: `distill_${Date.now()}`,
    userMessage: signal.content ?? '',
    assistantReply: output,
    toolCalls,
    timestamp: Date.now(),
    wasSuccessful: quality > 0.5,
  };
  const unit = this.compiler.compile(conv);
  if (unit) this.graph.addNode(unit);

  // 2. 生成 BuddyLM 训练样本
  if (this.buddyLMTrainer) {
    const toolCallJson = JSON.stringify(toolCalls.map(tc => ({ tool: tc.name, args: tc.args })));
    this.buddyLMTrainer.collectToolCallSample(signal.content ?? '', toolCallJson, quality);
  }

  // 3. 信号汇聚层注入
  this.convergenceLayer?.ingestKnowledge({
    content: output.slice(0, 2000),
    sourceType: 'text',
    source: 'cloud_llm_distill',
    domain: signal.domains[0] ?? 'general',
  });
}
```

**验证标准**:
- [ ] 云端 LLM 成功执行后自动触发蒸馏
- [ ] 经验图谱新增节点来自云端 LLM 蒸馏
- [ ] BuddyLM 收到 tool call 格式的训练样本
- [ ] 同类任务第二次执行时本地方案置信度提升

---

### Phase 5: 竞争裁决升级（1 周）

**目标**: 裁决器能公平比较不同来源的 ExecutablePlan。

**改动文件**:
- `src/brain/dispatch/arbiter.ts` — 支持 ExecutablePlan 比较
- `src/brain/dispatch/collector.ts` — 收集 ExecutablePlan
- `src/brain/dispatch/coordinator.ts` — 策略选择考虑本地执行能力

**评分维度调整**:

```typescript
// 现在（只比较文本质量）
score = quality(0.7) + feasibility(0.25) + costEfficiency(0.05)

// 升级后（比较可执行计划）
score = planQuality(0.4)       // 步骤完整性、逻辑正确性
      + feasibility(0.20)      // 资源是否够用
      + executionSpeed(0.15)   // 预估执行速度
      + costEfficiency(0.10)   // 是否需要云端 LLM
      + reliability(0.15)      // 来源的历史成功率
```

**Thompson Sampling 扩展**:
- 现有：按策略名（quick/buddyLM_chat 等）聚合
- 扩展：按执行者组合聚合（local_only/buddyLM+local/cloudLLM+local/mixed）

**验证标准**:
- [ ] 裁决器能比较不同来源的 ExecutablePlan
- [ ] 本地计划在质量相近时优先选择（速度+成本优势）
- [ ] Thompson Sampling 学习哪种执行者组合效果最好

---

### Phase 6: 自动规则生成（1-2 周）

**目标**: 从云端 LLM 的成功执行中自动提炼规则，补充规则引擎。

**改动文件**:
- `src/brain/left/policy-distiller.ts` — 增强蒸馏逻辑
- `src/brain/left/rule-engine.ts` — 支持自动生成的规则

**自动规则生成流程**:

```
云端 LLM 成功执行同类任务 3 次以上
  ↓
提取共同模式:
  - 触发条件（signal 特征）
  - 工具调用模式（哪些工具、什么顺序）
  - 成功率和平均耗时
  ↓
生成规则:
  condition: (signal) => 信号特征匹配
  action: (signal, resources) => ExecutablePlan（从经验中提取的步骤）
  ↓
注入规则引擎（priority 低于内置规则，高于默认调度）
  ↓
下次同类任务: 规则引擎直接命中，零 LLM
```

**验证标准**:
- [ ] 云端 LLM 成功执行 3 次以上同类任务后自动生成规则
- [ ] 自动生成的规则能命中后续同类任务
- [ ] 规则的 confidence 随成功执行次数提升
- [ ] 失败的规则自动降权或淘汰

---

## 四、增长曲线

### 阶段 1: 云端 LLM 主力（Phase 1-2 完成后）

```
任务分布:
  云端 LLM 执行: 80%  ← 主力
  本地直接执行:  15%  ← 简单任务（git status、file read）
  BuddyLM 执行:  5%  ← 简单问答

学习速度: 快（每次云端 LLM 执行都是学习素材）
```

### 阶段 2: 平衡期（Phase 3-4 完成后）

```
任务分布:
  本地直接执行:  40%  ← 经验覆盖的任务
  BuddyLM 执行:  25%  ← 训练后的简单推理
  云端 LLM 执行: 35%  ← 复杂/新任务

学习速度: 中等（本地执行也在积累经验）
```

### 阶段 3: 本地超越（Phase 5-6 完成后）

```
任务分布:
  本地直接执行:  55%  ← 规则引擎 + 经验覆盖
  BuddyLM 执行:  30%  ← 训练后的推理和生成
  云端 LLM 执行: 15%  ← 复杂/全新任务

学习速度: 持续（规则自动生成 + BuddyLM 持续训练）
```

---

## 五、与现有系统的关系

### 不动的部分
- **三脑架构**: 小脑/左脑/右脑的分工不变
- **经验引擎**: 编译/图谱/路由/进化 不变
- **影子大脑**: 缺口检测/进化/自训练 不变
- **组装引擎**: 检索/重排序/知识图谱 不变

### 升级的部分
- **ExecutionPlan → ExecutablePlan**: 类型扩展，向后兼容
- **plan-executor**: 新增 executeLocalPlan 路径
- **裁决器**: 支持 ExecutablePlan 比较
- **蒸馏管线**: 云端 LLM → 本地组件的学习闭环

### 新增的部分
- **执行者选择器**: 每步评估最合适执行者
- **自动规则生成**: 从成功执行中提炼规则
- **tool call 格式训练**: BuddyLM 学习输出结构化工具调用

---

## 六、风险与缓解

| 风险 | 影响 | 缓解 |
|------|------|------|
| BuddyLM 生成的 tool call 格式错误 | 执行失败 | 格式校验 + 降级到云端 LLM |
| 规则引擎规则爆炸 | 匹配变慢 | 规则数量上限 + 优先级淘汰 |
| 本地方案质量不够 | 用户体验下降 | 保持云端 LLM 作为兜底 |
| 训练数据不足 | BuddyLM 能力上不去 | 种子经验 + 云端 LLM 蒸馏 |
| 执行层工具调用失败 | 任务中断 | 重试 + 降级到云端 LLM |

---

## 七、验收标准

### Phase 1 完成
- [ ] git status / file read / ls 等简单任务零云端 LLM 执行
- [ ] 规则引擎输出包含 steps[] 的 ExecutablePlan
- [ ] 旧格式规则向后兼容

### Phase 2 完成
- [ ] BuddyLM 能输出格式正确的 tool call JSON
- [ ] 简单任务 BuddyLM 直接输出 tool calls

### Phase 3 完成
- [ ] 本地可执行计划直接调用工具（不经过云端 LLM）
- [ ] 混合计划正确执行

### Phase 4 完成
- [ ] 云端 LLM 成功执行后自动蒸馏
- [ ] 同类任务第二次执行时本地方案置信度提升

### Phase 5 完成
- [ ] 裁决器公平比较不同来源的 ExecutablePlan
- [ ] 本地计划在质量相近时优先选择

### Phase 6 完成
- [ ] 高频任务自动生成规则
- [ ] 规则随执行次数自动进化

---

## 八、优先级排序

```
P0: Phase 1（规则引擎 ExecutablePlan）— 打通本地执行的基础
P0: Phase 3（执行层接入）— 让本地计划能真正执行
P1: Phase 4（蒸馏闭环）— 学习增长的核心
P1: Phase 2（BuddyLM tool calls）— 本地推理能力
P2: Phase 5（竞争裁决升级）— 优化选择
P2: Phase 6（自动规则生成）— 自动进化
```

Phase 1 + Phase 3 是最小可用版本：规则引擎出计划 → 本地直接执行 → 零云端 LLM。
Phase 2 + Phase 4 是增长引擎：BuddyLM 学会 tool calls → 云端 LLM 蒸馏 → 能力持续提升。
