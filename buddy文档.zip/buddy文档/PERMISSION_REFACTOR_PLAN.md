# 权限重构计划 — 解耦亲密度与用户权限

## 目标
亲密度只控制 Buddy 的人格行为，不再控制用户的使用权限。
权限基于操作风险等级（只读/写入/隐私），而非用户等级。

## 环境控制
- `BUDDY_PERMISSION_V2=1` 环境变量启用新系统
- 不设置或设为 `0` → 走旧逻辑（亲密度门控）
- 生产环境 `.env` 中设置 `BUDDY_PERMISSION_V2=1`

## 改动清单

### 1. ✅ 新建 `src/core/permission.ts` — 独立权限模块
- RiskLevel: `safe` | `confirm` | `privacy`
- 每个工具映射到风险等级（与亲密度无关）
- `isToolAvailable()` → 始终返回 true
- `getToolRiskLevel()` → 返回风险等级
- `needsConfirmation()` → 基于风险等级判断
- `isPrivacyTool()` → 是否需要单独授权

### 2. ✅ 修改 `src/core/capability-gate.ts`
- `isCapabilityAvailable()` — V2 下所有工具可用
- `needsCapabilityConfirmation()` — V2 下基于风险等级
- `needsConfirmationCompat()` — V2 下委托给 permission.ts
- 引导相关函数不变（`getDiscoverableCapabilities` 等）

### 3. ✅ 修改 `src/core/agent.ts`
- `setupToolInterception()` — V2 下工具始终可用，确认基于风险等级
- 静态导入 permission.ts

### 4. ✅ 修改 `src/core/message-processor.ts`
- V2 下注入所有权限，不再按阶段过滤工具
- 静态导入 permission.ts

### 5. ✅ 测试 `src/core/permission.test.ts`
- 15 个测试全部通过
- 旧 capability-gate 37 个测试全部通过（向后兼容）
- 旧 constants 34 个测试全部通过

## 风险等级映射

| 风险等级 | 工具 | 行为 |
|---------|------|------|
| safe | chat, get_time, read_file, list_files, search_files, git_status, git_diff, git_log, search_web, fetch_url, analyze_file, scan_project, find_references, stmp_retrieve, knowledge_extract | 默认可用，无需确认 |
| confirm | write_file, exec, buddy_learn, dream_consolidate, experience_compile, package_create, package_share | 每次执行需确认 |
| privacy | camera, microphone, location | 需在设置中单独授权 |

## 使用方式

在生产环境 `.env` 中添加：
```
BUDDY_PERMISSION_V2=1
```

不设置则保持旧逻辑（亲密度门控），完全向后兼容。
