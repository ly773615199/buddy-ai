# 社区商业化分离计划

> 目标：软件归软件，社区归社区，商业化归商业化。

## 架构分层

```
┌─────────────────────────────────────────────┐
│              软件（Buddy）                    │
│  纯功能，不涉及任何支付/订阅逻辑              │
│                                              │
│  ├── 装饰/装扮系统                           │
│  ├── 模型管理（安装/卸载/启用）               │
│  ├── 赛季/成就系统                           │
│  ├── 知识学习/记忆                           │
│  ├── 对话引擎                                │
│  └── 传感器/感知                             │
└──────────────────┬──────────────────────────┘
                   │ REST API / WebSocket
┌──────────────────▼──────────────────────────┐
│              社区网站（buddy-community）       │
│  用户系统 + 内容平台 + 商业化                 │
│                                              │
│  ├── 用户注册/登录                           │
│  ├── 模型分享市场（上传/下载/评分）           │
│  ├── 装饰发布平台（UGC）                     │
│  ├── 赛季排行榜/社交                         │
│  ├── 会员订阅（Free/Pro/Team）               │
│  ├── 支付网关（Stripe/支付宝/微信）          │
│  └── 内容审核/安全                           │
└─────────────────────────────────────────────┘
```

## 当前状态

### ✅ 已完成：billing 插件化

- `src/billing/` 已通过 `BillingPlugin` 接口与核心解耦
- `billing-loader.ts` 异步动态加载，可删除/禁用
- 配置 `commercial.enabled = false` 可完全禁用
- 核心软件不依赖 billing 模块

### ✅ 已完成：shop 回归核心

- `ShopCatalog` 是软件功能（装饰/赛季），不是商业化
- `ModelInstaller` / `ModelRepository` 是软件功能（模型管理）
- 这些功能社区网站也会调用，但本身属于软件

## 后续步骤

### Phase 1：清理仓库 ✅ 已完成

- [x] 将 `src/billing/` 从 buddy 仓库移出 → 独立为 `buddy-billing`
- [x] 将 billing 模块独立为 `buddy-billing` 仓库
- [x] `billing-plugin.ts` / `billing-loader.ts` 保留为接口定义 + 空实现
- [x] 软件只定义 `BillingPlugin` 接口，不包含任何实现
- [x] `subsystems.ts` 动态导入改为 `import('buddy-billing')`
- [x] 测试文件迁移到 `buddy-billing/test/`

### Phase 2：社区网站搭建 ✅ 基础完成

- [x] 技术选型 → Next.js 15 (App Router) + Prisma + SQLite + Tailwind CSS
- [x] 用户系统（注册/登录）→ NextAuth.js v5 + Credentials Provider
- [x] 模型市场（上传/下载/版本管理/评分）→ `/api/models` + 前端页面
- [x] 装饰发布平台（UGC 装饰上传/审核/上架）→ `/api/decorations` + 前端页面
- [x] 赛季排行榜（Web 展示 + API 对接）→ `/api/leaderboard` + 前端页面
- [x] 会员订阅 UI → `/pricing` 页面（Free/Pro/Team 三档）
- [ ] 支付网关对接（Stripe/支付宝/微信）→ 接口预留，待接入
- [ ] 内容审核/管理后台 → 待开发

### Phase 3：软件 ↔ 社区对接 ✅ 基础完成

- [x] 软件内增加社区 API 配置（`config.community.apiUrl`）
- [x] `CommunityClient` 客户端 → `src/core/community-client.ts`
- [x] 模型市场：软件通过社区 API 查询/下载模型
- [x] 装饰商城：软件通过社区 API 获取装饰列表
- [x] 赛季数据：软件通过社区 API 获取排行榜
- [x] 订阅状态：社区 API 返回用户订阅等级
- [ ] 订阅状态联动：软件按等级动态启用/禁用功能 → 待集成到 subsystems

### Phase 4：商业化上线（长期）

- [ ] 社区网站接入支付网关（Stripe SDK 已就绪）
- [ ] 会员订阅流程（注册 → 选计划 → 支付 → 激活）
- [ ] 软件通过 API 查询用户订阅状态，动态启用/禁用功能
- [ ] 数据安全合规（GDPR / 个人信息保护法）

## 项目结构

```
buddy/                  ← 核心软件（纯功能）
├── src/core/
│   ├── billing-plugin.ts     ← BillingPlugin 接口 + NullBillingPlugin
│   ├── billing-loader.ts     ← RealBillingPlugin 适配器
│   └── community-client.ts   ← Community API 客户端
└── COMMUNITY_SEPARATION_PLAN.md

buddy-billing/          ← 独立 billing 包
├── src/
│   ├── subscription.ts       ← 订阅管理
│   ├── payment.ts            ← 支付集成
│   └── entitlements.ts       ← 权益检查
└── test/

buddy-community/        ← 社区网站（Next.js）
├── src/app/
│   ├── page.tsx              ← 首页
│   ├── models/               ← 模型市场
│   ├── decorations/          ← 装饰平台
│   ├── leaderboard/          ← 赛季排行
│   ├── pricing/              ← 会员订阅
│   └── api/                  ← REST API
├── prisma/schema.prisma      ← 数据库 Schema
└── middleware.ts             ← 认证中间件
```

## 原则

1. **软件只做功能，不做变现** — 任何涉及钱的逻辑都不进软件仓库
2. **社区是独立产品** — 有自己的仓库、部署、用户体系
3. **对接靠 API** — 软件和社区通过 REST/WS 通信，不共享代码
4. **billing 是社区的事** — 订阅/支付/权益逻辑归属社区仓库
