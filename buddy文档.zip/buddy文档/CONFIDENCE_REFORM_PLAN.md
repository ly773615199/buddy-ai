# Buddy 置信度体系改造 + 闭环修复执行计划

> 版本: v1.0
> 日期: 2026-06-09
> 基于: 全量代码审计 + 学术研究调研 (CritiCal/NeurIPS 2025, Multi-Agent-as-Judge, PRM, Self-Consistency, Outcome-Oriented Evaluation)

---

## 一、问题全景

### 1.1 集成断裂问题（P0 级）

| # | 问题 | 位置 | 影响 |
|---|------|------|------|
| **B-1** | `setEditingPipeline()` 未调用 | `subsystems.ts` 缺失调用 | v5 管线永远降级到 legacy，碰撞引擎+知识汇聚形同虚设 |
| **B-2** | `ThreeBrain.feedback()` 无调用方 | `agent.ts` / `message-processor.ts` 缺失 | 整个反馈闭环断裂：calibrator/BlendBrain/ResourceHub/Thompson Sampling 全部不更新 |
| **B-3** | `ConfidenceCalibrator` 冷启动 | 因 B-2 导致 | MIN_SAMPLES=5 门槛永远达不到，校准器返回原始值，跨模块置信度不可比 |
| **B-4** | `BlendBrain.update()` 不执行 | 因 B-2 导致 | REINFORCE 策略梯度不学习，_explorationSigma=0.3 不衰减，8 维策略退化为均匀随机 |
| **B-5** | `BlendBandit.update()` 不执行 | 因 B-2 导致 | R⁵ 连续 Bandit 不更新，探索/利用权衡失效 |
| **B-6** | `DispatchLearner` 不记录 | 因 B-2 导致 | Thompson Sampling 历史为空，调度器永远走默认策略 |
| **B-7** | `userCorrectionCount` 不更新 | 因 B-2 导致 | 用户连续纠错不被系统感知 |

### 1.2 置信度体系设计缺陷

| # | 问题 | 详情 |
|---|------|------|
| **C-1** | 单一数字公式评判 | `qualityScore` 是一个 0-1 标量，无法区分"格式完美但事实错误"和"格式一般但内容正确" |
| **C-2** | 硬编码阈值不分领域 | `highThreshold=0.8` 对医疗太低、对闲聊太高 |
| **C-3** | 质量评估纯规则正则 | `OutputQualityAssessor` 用 `/i cannot/` 等正则匹配，不理解语义正确性 |
| **C-4** | 无用户反馈信号 | 用户说"不对"但系统仍认为 confidence=0.9 |
| **C-5** | 无一致性检验 | 多次生成不同答案但每次 confidence 都高 |
| **C-6** | 无步骤级评估 | 最后一步错但前面都对 → 整体 confidence 全被拉低 |
| **C-7** | Thompson Sampling Beta 近似误差 | `alpha+beta<10` 时正态近似误差大，且因 B-2 永远不更新 |
| **C-8** | cascade 模式权重不透明 | 高权重组件短路返回，用户不知道输出来自哪个组件 |

### 1.3 现实场景不适配

| 场景 | 当前行为 | 应该的行为 |
|------|----------|------------|
| 紧急求助 | 走完整决策链，可能选到慢路径 | urgency 驱动快速通道 |
| 连续纠错 | 不学习，重复犯错 | 纠错后立即调整策略权重 |
| 多轮上下文 | 每次独立决策 | DAG 状态累积 |
| 代码任务 | 关键词检测 `/代码\|code/` | 实际运行验证 |
| 高风险场景 | 统一 0.8 阈值 | 领域自适应阈值 |

---

## 二、改造目标

### 2.1 核心目标

1. **闭环修复**：让 feedback() 被实际调用，恢复 calibrator → BlendBrain → ResourceHub → Thompson Sampling 的完整闭环
2. **评估升级**：从单一数字公式升级为五层评估体系（Self-Critique + Review Panel + Self-Consistency + Process Evaluator + Outcome Verifier）
3. **场景适配**：引入领域自适应阈值 + 紧急通道 + 纠错学习
4. **可观测性**：每个决策可追溯来源、可解释理由

### 2.2 非目标（本期不做）

- 不重写 NN 内核（BlendBrain 架构保留）
- 不新增外部依赖（纯 TypeScript 实现）
- 不改三脑整体架构（只修集成层 + 增强评估层）
- 不做用户 A/B 测试框架（后续迭代）

---

## 三、执行计划

### Phase 0：闭环修复（P0，预计 2 天）

> 优先级最高。不修复闭环，后续所有改造都建立在"开环运行"的基础上。

#### Task 0.1: 注入 v5 管线依赖

**文件**：`src/core/subsystems.ts`
**改动**：在 ThreeBrain 初始化完成后，调用 `setEditingPipeline()`

```typescript
// subsystems.ts — 在 ThreeBrain 初始化后
if (this.collisionEngine && this.knowledgeConvergence) {
  this.threeBrain.setEditingPipeline(this.collisionEngine, this.knowledgeConvergence);
}
```

**验收标准**：
- `brain.ts` 中 `this.collisionEngine !== null` 且 `this.knowledgeConvergence !== null`
- `processWithV5Pipeline()` 不再走 `legacy_processAssembly` 降级路径
- 测试：v5 管线命中时日志输出 `[ThreeBrain] v5 碰撞编辑` 或 `[ThreeBrain] v5 工具直接格式化`

#### Task 0.2: 接入 feedback() 调用

**文件**：`src/core/agent.ts`
**改动**：在消息处理完成后调用 `threeBrain.feedback()`

```typescript
// agent.ts — 在消息发送后
async afterResponse(signal, resources, plan, outcome, actualOutput) {
  await this.threeBrain.feedback(
    signal, resources, plan, outcome,
    actualIntent, actualTools, failedModels, failedReasons, actualOutput,
  );
}
```

**需要传递的数据**：
- `signal`: 从 `decide()` 透传
- `resources`: 从 `decide()` 透传
- `plan`: 从 `decide()` 返回的 `DecisionResult.plan`
- `outcome.success`: 工具是否执行成功
- `outcome.latencyMs`: 总耗时
- `outcome.costEstimate`: token 消耗估算
- `outcome.toolsUsed`: 使用的工具列表
- `actualOutput`: 最终输出文本

**验收标准**：
- `calibrator.update()` 被调用 → `calibrator.isCalibrated('rule')` 在 5 次交互后返回 true
- `blendBrain.update()` 被调用 → `blendBrain._trainCount` 递增
- `resourceHub.recordOutcome()` 被调用 → 资源画像有更新记录

#### Task 0.3: 保存并透传决策上下文

**文件**：`src/core/agent.ts` 或 `src/core/message-processor.ts`
**改动**：`decide()` 返回的 `DecisionResult` 需要被保存，在 `feedback()` 时使用

```typescript
// 新增类型
interface PendingDecision {
  signal: TaskSignal;
  resources: ResourceState;
  plan: ExecutionPlan;
  timestamp: number;
}

// agent.ts 中
private pendingDecision: PendingDecision | null = null;

async processMessage(input) {
  const decision = await this.threeBrain.decide(input, signal, resources);
  this.pendingDecision = { signal, resources, plan: decision.plan, timestamp: Date.now() };
  // ... 执行、输出 ...
  // 输出完成后
  await this.threeBrain.feedback(
    this.pendingDecision.signal,
    this.pendingDecision.resources,
    this.pendingDecision.plan,
    outcome,
    actualOutput,
  );
  this.pendingDecision = null;
}
```

**验收标准**：
- 每次 `decide()` 后都有对应的 `feedback()` 调用
- `decisionCount` 递增 → 每 100 次决策触发一次 `runDistill()`

#### Task 0.4: 闭环验证测试

**新增文件**：`src/brain/brain.integration.test.ts`

测试用例：
1. 模拟 10 轮交互 → 验证 `calibrator.isCalibrated('rule')` 为 true
2. 模拟成功/失败交替 → 验证 `calibrator.calibrate('rule', 0.8)` 输出值与初始值不同
3. 验证 `blendBrain._trainCount > 0`
4. 验证 `resourceHub` 中有 `recordOutcome` 记录

---

### Phase 1：Self-Critique 自我批判模块（P1，预计 3 天）

> 替代硬编码正则的输出评估，用结构化推理检查输出质量。

#### Task 1.1: 实现 SelfCritic 类

**新增文件**：`src/brain/cerebellum/self-critic.ts`

```typescript
export interface CritiqueResult {
  critique: string;
  confidenceAdjustment: number;  // -0.3 ~ +0.3
  issues: Array<{
    type: 'factual_error' | 'logic_gap' | 'intent_mismatch' | 'incomplete' | 'hallucination';
    evidence: string;
    severity: 'high' | 'medium' | 'low';
  }>;
  shouldRegenerate: boolean;
}

export class SelfCritic {
  critique(input: string, output: string, signal: TaskSignal, toolResults?: string[]): CritiqueResult;
}
```

**5 项检查**：
1. **意图对齐**：输出是否回答了用户的问题（结构化语义比对，非正则）
2. **推理链完整性**：是否有逻辑断裂（因果关系检查）
3. **事实性错误信号**：是否有幻觉特征（交叉验证工具结果）
4. **过度自信检测**：输出是否过于绝对（模态词分析）
5. **输出完整性**：是否遗漏了用户的要求（需求清单比对）

**验收标准**：
- 输入"帮我写个 Python 函数计算斐波那契"，输出只有解释没有代码 → `shouldRegenerate=true`
- 输入"今天天气"，输出有具体温度 → `issues=[]`, `confidenceAdjustment >= 0`
- 所有检查 < 10ms（纯规则+结构化比对，不调 LLM）

#### Task 1.2: 集成到 decide() 流程

**文件**：`src/brain/brain.ts`
**位置**：`localGeneration` 产出后、`DispatchExecutor` 质量迭代前

```typescript
// brain.ts decide() 中
if (localGeneration && localGeneration.text.length > 0) {
  const critique = this.selfCritic.critique(input, localGeneration.text, signal, toolResults);
  localGeneration.confidence += critique.confidenceAdjustment;
  localGeneration.confidence = Math.max(0, Math.min(1, localGeneration.confidence));
  
  if (critique.shouldRegenerate) {
    // 尝试用不同策略重新生成
    const regenerated = await this.tryRegenerate(input, signal, resources, intuition, critique.issues);
    if (regenerated) localGeneration = regenerated;
  }
}
```

**验收标准**：
- Self-Critique 发现高严重度问题时触发重新生成
- 重新生成使用不同策略（如从 assembly 切到 cloudLLM）
- 日志输出批判结果供调试

#### Task 1.3: Self-Critic 测试

**新增文件**：`src/brain/cerebellum/self-critic.test.ts`

测试用例：
- 意图不对齐检测（问代码给解释）
- 推理链断裂检测（结论无论据）
- 事实错误信号检测（工具结果矛盾）
- 过度自信检测（"绝对正确"）
- 完整性检测（遗漏子任务）

---

### Phase 2：Review Panel 多维评审（P1，预计 3 天）

> 替代单一 `OutputQualityAssessor`，用多个专门化评审员各评一个维度。

#### Task 2.1: 实现 ReviewPanel 类

**新增文件**：`src/brain/cerebellum/review-panel.ts`

```typescript
export interface ReviewVerdict {
  dimension: string;
  score: number;
  reasoning: string;
  evidence: string;
  suggestion?: string;
}

export class ReviewPanel {
  async review(input: string, output: string, signal: TaskSignal, context: ReviewContext): Promise<{
    verdicts: ReviewVerdict[];
    overallConfidence: number;
    needsRevision: boolean;
    revisionFocus: string[];
  }>;
}
```

**5 个评审员**：
1. **TaskSuccessJudge**：任务是否完成（意图-输出语义对齐）
2. **ToolQualityJudge**：工具使用是否合理（调用正确性 + 结果利用度）
3. **ReasoningJudge**：推理是否连贯（逻辑链 + 论据支撑）
4. **UserAlignmentJudge**：是否符合用户偏好（情绪/风格/长度适配）
5. **RobustnessJudge**：是否鲁棒（边界条件 + 诚实度）

**综合分计算**：
```typescript
// 短板优先，非加权平均
const minScore = Math.min(...verdicts.map(v => v.score));
const avgScore = verdicts.reduce((s, v) => s + v.score, 0) / verdicts.length;
const overall = minScore < 0.3 ? minScore : minScore < 0.5 ? (minScore * 0.6 + avgScore * 0.4) : avgScore;
```

**验收标准**：
- 5 个评审员独立评分，互不影响
- 任何一个维度 < 0.3 → `needsRevision = true`
- 综合分取短板而非平均

#### Task 2.2: 替代 OutputQualityAssessor

**文件**：`src/brain/brain.ts`, `src/brain/dispatch/executor.ts`

```typescript
// DispatchExecutor 中
// 旧：const qualityScore = this.qualityAssessor.assess(ctx).score;
// 新：
const review = await this.reviewPanel.review(input, output, signal, context);
const qualityScore = review.overallConfidence;

// 如果需要改进，传入 revisionFocus
if (review.needsRevision) {
  // 在下一轮迭代中聚焦改进
}
```

**保留 `OutputQualityAssessor`** 作为 <5ms 快速预筛：
```typescript
// 快速预筛
const quickScore = this.qualityAssessor.assess(ctx).score;
if (quickScore < 0.3) return earlyFail;  // 快速失败

// 深度评估（仅在需要时）
if (quickScore < 0.7 || signal.complexity === 'complex') {
  const review = await this.reviewPanel.review(...);
}
```

**验收标准**：
- 简单任务只走快速预筛（<5ms）
- 复杂任务走 Review Panel（<50ms）
- Review Panel 发现的问题有自然语言理由

#### Task 2.3: Review Panel 测试

**新增文件**：`src/brain/cerebellum/review-panel.test.ts`

---

### Phase 3：Self-Consistency 一致性检验（P1，预计 2 天）

> 多采样验证：如果系统对答案"有信心"，多次生成应语义一致。

#### Task 3.1: 实现 ConsistencyChecker 类

**新增文件**：`src/brain/cerebellum/consistency-checker.ts`

```typescript
export class ConsistencyChecker {
  async checkConsistency(
    input: string,
    signal: TaskSignal,
    resources: ResourceState,
    primaryOutput: string,
    primaryConfidence: number,
  ): Promise<{
    consistencyScore: number;
    adjustedConfidence: number;
    samples: Array<{ output: string; source: string; similarity: number }>;
    isConsensus: boolean;
  }>;
}
```

**逻辑**：
1. 快速路径：`primaryConfidence > 0.85 && complexity === 'simple'` → 跳过
2. 生成 2 个额外样本（低温 + 不同种子）
3. 用 ByteEncoder 向量余弦相似度计算语义一致性
4. 高一致性(>0.8) → 置信度 +0.1；低一致性(<0.4) → 置信度 -0.25

**验收标准**：
- 复杂任务或中等置信度时触发
- 简单任务不触发（节省算力）
- 一致性计算 < 20ms（向量余弦）

#### Task 3.2: 集成到 decide()

**文件**：`src/brain/brain.ts`

```typescript
// 在 Self-Critique 之后
if (localGeneration && signal.complexity !== 'simple') {
  const consistency = await this.consistencyChecker.checkConsistency(
    input, signal, resources, localGeneration.text, localGeneration.confidence,
  );
  localGeneration.confidence = consistency.adjustedConfidence;
}
```

#### Task 3.3: Consistency Checker 测试

**新增文件**：`src/brain/cerebellum/consistency-checker.test.ts`

---

### Phase 4：Process Evaluator 步骤级评估（P2，预计 2 天）

> 不只看最终结果，评估每一步是否正确。

#### Task 4.1: 实现 ProcessEvaluator 类

**新增文件**：`src/brain/cerebellum/process-evaluator.ts`

```typescript
export class ProcessEvaluator {
  evaluateProcess(
    input: string,
    steps: Array<{ description: string; output: string; tool?: string }>,
    signal: TaskSignal,
  ): {
    stepResults: StepEvaluation[];
    processScore: number;
    lastCorrectStep: number;
    failurePoint?: number;
    canResumeFrom?: number;
    overallConfidence: number;
  };
}
```

**集成点**：
- `executeBlendStrategy()` 的 DAG 路径中使用
- 复杂任务拆分为步骤后，每步独立评估
- `canResumeFrom` 指导 `adaptive_replan` 模式的恢复策略

#### Task 4.2: DAG 执行器集成

**文件**：`src/brain/brain.ts` → `executeBlendStrategy()` 的 DAG 路径

```typescript
// 在 buildTaskDAG + executeLocalPlan 之后
const processEval = this.processEvaluator.evaluateProcess(input, dagSteps, signal);
if (processEval.failurePoint !== undefined) {
  // 从失败点恢复，而非从头来过
  const resumed = await this.resumeFromStep(processEval.canResumeFrom, ...);
}
```

#### Task 4.3: Process Evaluator 测试

---

### Phase 5：Outcome Verifier 结果验证器（P2，预计 2 天）

> 用可验证的 ground truth 替代主观打分。

#### Task 5.1: 实现 OutcomeVerifier 类

**新增文件**：`src/brain/cerebellum/outcome-verifier.ts`

```typescript
export class OutcomeVerifier {
  verify(taskType: string, output: string, toolResults?: string[], signal?: TaskSignal): VerificationResult;
}
```

**验证方法**：
| 任务类型 | 验证方式 | 置信度影响 |
|----------|----------|-----------|
| 代码任务 | 语法检查（TypeScript/Python/JS） | 语法正确 +0.15，错误 -0.20 |
| 工具调用 | 检查返回值是否含错误信号 | 成功 +0.10，错误 -0.25 |
| 数学计算 | 重新计算验证 | 正确 +0.20，错误 -0.30 |
| 事实查询 | 交叉验证工具结果 | 一致 +0.10，矛盾 -0.20 |

**验收标准**：
- 代码语法检查 < 5ms
- 工具结果检查 < 1ms
- 发现客观错误时直接短路，不等其他评估层

#### Task 5.2: 集成到评估流程

**文件**：`src/brain/brain.ts`

```typescript
// 在 Review Panel 之前（快速短路）
const verification = this.outcomeVerifier.verify(signal.taskType, localGeneration.text, toolResults);
if (verification.verified === false && verification.confidenceBoost < -0.15) {
  // 客观错误，直接短路
  localGeneration.confidence += verification.confidenceBoost;
  // 触发重新生成
}
```

#### Task 5.3: Outcome Verifier 测试

---

### Phase 6：领域自适应阈值（P2，预计 2 天）

> 替代硬编码的置信度阈值。

#### Task 6.1: 实现领域阈值配置

**新增文件**：`src/brain/config/domain-thresholds.ts`

```typescript
export interface DomainThresholdConfig {
  domain: string;
  highConfidence: number;     // 高置信度阈值
  mediumConfidence: number;   // 中置信度阈值
  noveltyHigh: number;        // 高新颖度阈值
  minSuccessCount: number;    // 最少成功次数
  description: string;
}

export const DOMAIN_THRESHOLDS: Record<string, DomainThresholdConfig> = {
  medical: {
    domain: 'medical',
    highConfidence: 0.95,    // 医疗场景要求极高置信
    mediumConfidence: 0.80,
    noveltyHigh: 0.5,        // 低新颖度就走验证
    minSuccessCount: 10,
    description: '医疗健康 — 高风险，要求高置信度+多验证',
  },
  legal: {
    domain: 'legal',
    highConfidence: 0.93,
    mediumConfidence: 0.75,
    noveltyHigh: 0.5,
    minSuccessCount: 8,
    description: '法律合规 — 高风险，要求准确性和可追溯',
  },
  code: {
    domain: 'code',
    highConfidence: 0.85,    // 代码可通过运行验证
    mediumConfidence: 0.60,
    noveltyHigh: 0.7,
    minSuccessCount: 3,
    description: '代码生成 — 中风险，可验证，允许多次尝试',
  },
  chat: {
    domain: 'chat',
    highConfidence: 0.60,    # 闲聊不需要高置信
    mediumConfidence: 0.35,
    noveltyHigh: 0.9,
    minSuccessCount: 1,
    description: '日常对话 — 低风险，优先流畅度和趣味性',
  },
  knowledge: {
    domain: 'knowledge',
    highConfidence: 0.85,
    mediumConfidence: 0.60,
    noveltyHigh: 0.7,
    minSuccessCount: 3,
    description: '知识查询 — 中风险，要求准确性+来源可追溯',
  },
  creative: {
    domain: 'creative',
    highConfidence: 0.70,
    mediumConfidence: 0.45,
    noveltyHigh: 0.8,
    minSuccessCount: 2,
    description: '创意生成 — 低风险，优先新颖性和表达力',
  },
};

// 默认阈值（兜底）
export const DEFAULT_THRESHOLDS = DOMAIN_THRESHOLDS.chat;
```

#### Task 6.2: 替换硬编码阈值

**文件**：`src/intelligence/experience-router.ts`, `src/brain/left/scheduler.ts`

```typescript
// experience-router.ts
route(input: string, contextTags: string[], qualityEstimate?: number): RouteDecision {
  // 从 signal.domains 推断领域
  const domain = this.inferDomain(contextTags);
  const thresholds = DOMAIN_THRESHOLDS[domain] ?? DEFAULT_THRESHOLDS;
  
  // 用领域阈值替代硬编码
  if (selected.stats.confidence >= thresholds.highConfidence && ...) {
    return { path: 'exp_direct', ... };
  }
}
```

#### Task 6.3: 领域推断

**文件**：`src/brain/left/scheduler.ts` 或新增 `src/brain/cerebellum/domain-infer.ts`

```typescript
function inferDomain(signal: TaskSignal): string {
  // 从 signal.domains + signal.content 推断
  if (signal.domains.includes('medical') || /医|药|病|症/.test(signal.content)) return 'medical';
  if (signal.domains.includes('legal') || /法|律|合同|诉讼/.test(signal.content)) return 'legal';
  if (signal.taskType === 'tools' && /代码|code|函数|function/.test(signal.content)) return 'code';
  // ...
  return 'chat'; // 默认
}
```

---

### Phase 7：紧急通道 + 纠错学习（P2，预计 2 天）

#### Task 7.1: 紧急快速通道

**文件**：`src/brain/brain.ts` → `decide()` 入口

```typescript
async decide(input, signal, resources): Promise<DecisionResult> {
  // ── 紧急快速通道（在所有决策之前）──
  const urgency = this.cerebellum.getBodyState().urgency ?? 0;
  if (urgency > 0.8 || signal.complexity === 'simple' && signal.domains.length === 1) {
    // 直接走最快路径：工具直连 或 经验直连
    const fastResult = await this.tryFastPath(input, signal, resources);
    if (fastResult) {
      return { plan: fastResult.plan, localGeneration: fastResult.output, ... };
    }
  }
  // ... 正常决策流程 ...
}
```

#### Task 7.2: 纠错学习

**文件**：`src/core/agent.ts`

```typescript
// 检测用户纠错
if (this.detectCorrection(userInput)) {
  // 1. 记录到 ResourceHub
  this.resourceHub.recordOutcome(this.lastStrategyName, {
    success: false,
    qualityScore: 0.1,
    scenario: signal.taskType,
  });
  
  // 2. 更新 calibrator
  this.calibrator.update(this.lastPlan.source, this.lastPlan.confidence, false);
  
  // 3. 触发 BlendBrain 立即学习（不等正常 feedback）
  if (this.lastBlendVector) {
    this.blendBrain.update(this.lastFeatureVector, this.lastNeuralOutput, 0.1);
  }
  
  // 4. 标记用户纠正计数
  this.resourceState.userCorrectionCount++;
}
```

#### Task 7.3: 多轮上下文累积

**文件**：`src/brain/brain.ts`

```typescript
// 在 decide() 中
private conversationDAG: TaskDAG | null = null;

async decide(input, signal, resources) {
  // 如果上一轮有未完成的 DAG，继续执行
  if (this.conversationDAG && this.conversationDAG.status === 'in_progress') {
    const continued = await this.continueDAG(input, signal, resources);
    if (continued) return continued;
  }
  // ... 正常决策 ...
}
```

---

### Phase 8：可观测性 + 调试工具（P3，预计 1 天）

#### Task 8.1: 决策追溯日志

**新增文件**：`src/brain/cerebellum/decision-trace.ts`

```typescript
export interface DecisionTrace {
  traceId: string;
  timestamp: number;
  input: string;
  signal: TaskSignal;
  
  // 决策链路
  steps: Array<{
    name: string;        // 'cerebellum' | 'right_brain' | 'rule_engine' | 'blend_brain' | 'arbiter' | 'critique' | 'review_panel'
    duration: number;
    result: string;      // 摘要
    confidence: number;
  }>;
  
  // 最终输出
  output: string;
  finalConfidence: number;
  source: string;        // 最终选择了哪个组件
  
  // 评估结果
  critiqueIssues: string[];
  reviewVerdicts: string[];
  consistencyScore: number;
  verificationResult: string;
}
```

#### Task 8.2: 置信度仪表盘数据导出

**新增文件**：`src/brain/cerebellum/confidence-dashboard.ts`

导出：
- 各模块校准曲线（calibrator.getCalibrationCurve）
- ECE 统计
- Thompson Sampling 历史分布
- BlendBrain 策略向量分布
- 资源画像变化趋势

---

## 四、执行顺序与依赖关系

```
Phase 0 (闭环修复) ─────────────────────────────┐
  │                                               │
  ├── Task 0.1: v5 管线注入                        │
  ├── Task 0.2: feedback() 接入                    │
  ├── Task 0.3: 决策上下文透传                      │
  └── Task 0.4: 闭环验证测试                        │
          │                                       │
          ▼                                       │
Phase 1 (Self-Critique) ◄── 依赖 Phase 0          │
  │                                               │
  ├── Task 1.1: SelfCritic 类                      │
  ├── Task 1.2: 集成到 decide()                    │
  └── Task 1.3: 测试                               │
          │                                       │
          ▼                                       │
Phase 2 (Review Panel) ◄── 依赖 Phase 1           │
  │                                               │
  ├── Task 2.1: ReviewPanel 类                     │
  ├── Task 2.2: 替代 OutputQualityAssessor         │
  └── Task 2.3: 测试                               │
          │                                       │
          ├──► Phase 3 (Self-Consistency) ◄── 依赖 Phase 0
          │     ├── Task 3.1: ConsistencyChecker
          │     ├── Task 3.2: 集成到 decide()
          │     └── Task 3.3: 测试
          │
          ├──► Phase 4 (Process Evaluator) ◄── 依赖 Phase 0
          │     ├── Task 4.1: ProcessEvaluator
          │     ├── Task 4.2: DAG 集成
          │     └── Task 4.3: 测试
          │
          ├──► Phase 5 (Outcome Verifier) ◄── 依赖 Phase 0
          │     ├── Task 5.1: OutcomeVerifier
          │     ├── Task 5.2: 集成
          │     └── Task 5.3: 测试
          │
          ├──► Phase 6 (领域阈值) ◄── 依赖 Phase 0
          │     ├── Task 6.1: 阈值配置
          │     ├── Task 6.2: 替换硬编码
          │     └── Task 6.3: 领域推断
          │
          └──► Phase 7 (紧急+纠错) ◄── 依赖 Phase 0
                ├── Task 7.1: 紧急快速通道
                ├── Task 7.2: 纠错学习
                └── Task 7.3: 多轮上下文
                        │
                        ▼
                Phase 8 (可观测性) ◄── 依赖全部
                  ├── Task 8.1: 决策追溯
                  └── Task 8.2: 仪表盘数据
```

**并行策略**：
- Phase 3/4/5/6/7 可并行开发（都只依赖 Phase 0）
- Phase 1 → Phase 2 串行（Review Panel 替代 Self-Critique 的快速预筛角色）
- Phase 8 最后做（需要所有模块的数据）

---

## 五、时间估算

| Phase | 预估工时 | 可并行 | 关键路径 |
|-------|---------|--------|----------|
| Phase 0 | 2 天 | — | ✅ 关键路径 |
| Phase 1 | 3 天 | — | ✅ 关键路径 |
| Phase 2 | 3 天 | — | ✅ 关键路径 |
| Phase 3 | 2 天 | ✅ 与 4/5/6/7 并行 | |
| Phase 4 | 2 天 | ✅ 与 3/5/6/7 并行 | |
| Phase 5 | 2 天 | ✅ 与 3/4/6/7 并行 | |
| Phase 6 | 2 天 | ✅ 与 3/4/5/7 并行 | |
| Phase 7 | 2 天 | ✅ 与 3/4/5/6 并行 | |
| Phase 8 | 1 天 | — | |

**串行关键路径**：Phase 0 (2d) → Phase 1 (3d) → Phase 2 (3d) = **8 天**
**含并行总工时**：8d + 2d (并行 Ph3-7 取最长) + 1d (Ph8) = **11 天**

---

## 六、风险与缓解

| 风险 | 影响 | 缓解措施 |
|------|------|----------|
| feedback() 接入后性能回退 | 每次交互多 5-10ms | feedback 异步化，不阻塞响应 |
| Self-Critique 误判 | 好的输出被标记为有问题 | 保留快速预筛，Self-Critique 只在中低置信度时触发 |
| 多采样一致性增加延迟 | 每次多 2 次生成 | 仅复杂任务触发，简单任务跳过 |
| 领域推断不准确 | 医疗任务被当闲聊 | 多信号融合（domains + content + signal），兜底用默认阈值 |
| Review Panel 5 个评审员成本 | 每次交互多 5 次评估 | 并行执行 + 超时机制 + 快速预筛过滤 |

---

## 七、验收标准总览

### Phase 0 验收
- [ ] `processWithV5Pipeline()` 不再走降级路径
- [ ] `calibrator.isCalibrated('rule')` 在 5 次交互后返回 true
- [ ] `blendBrain._trainCount` 递增
- [ ] `resourceHub` 有 `recordOutcome` 记录

### Phase 1-5 验收
- [ ] Self-Critique 发现意图不对齐时触发重新生成
- [ ] Review Panel 5 个维度独立评分，短板 < 0.3 时 `needsRevision=true`
- [ ] Self-Consistency 低一致性时置信度下调 ≥ 0.15
- [ ] Process Evaluator 能定位失败步骤并支持恢复
- [ ] Outcome Verifier 代码语法检查 < 5ms，错误时短路

### Phase 6-7 验收
- [ ] 医疗场景 highConfidence=0.95，闲聊场景 highConfidence=0.60
- [ ] 紧急场景 urgency > 0.8 时走快速通道
- [ ] 用户纠错后下一次类似请求策略改变
- [ ] 多轮对话 DAG 状态可累积

### Phase 8 验收
- [ ] 每个决策有完整 trace 日志
- [ ] 可导出校准曲线和 ECE 统计
