# 三脑架构执行监控深度审计与改进计划

> 版本: v1.0
> 日期: 2026-05-27
> 审计范围: ThreeBrain.decide() 全链路 + 执行监控 + 反馈闭环
> 审计方法: 逐行代码走查 + 实际场景追踪 + 调用链验证

---

## 一、审计摘要

| 维度 | 评分 | 核心问题 |
|------|------|----------|
| 决策前（信号采集+策略选择） | ⭐⭐⭐⭐⭐ | 无 |
| 执行中（实时监控+干预） | ⭐⭐ | 决策者对执行过程"失明" |
| 执行后（反馈+学习） | ⭐⭐⭐⭐ | reflect()的plan.source被污染 |
| 资源调配（路由+协作） | ⭐⭐⭐⭐ | 执行中不动态调整 |
| 启停管理 | ⭐⭐⭐⭐ | shutdown丢失最终状态 |
| 生命周期管理 | ⭐⭐⭐ | CLI模式未接入ExecutionSession |

**核心结论：决策者是"决策-遗忘-事后反馈"模式，不是"决策-监控-实时干预"模式。**

---

## 二、发现的问题清单

### 🔴 P0 — 必须修复

#### P0-1: 决策者对执行过程完全失明

**代码位置**: `brain.ts:1175-1715` (executeBlendStrategy)

**问题描述**: `executeBlendStrategy()`遍历5个组件(rule/experience/assembly/buddyLM/cloudLLM)，每个组件try-catch静默失败。决策者(ThreeBrain)在选定策略后，对执行过程没有任何感知：

- 无执行进度回调
- 无超时控制（组件内部各自处理）
- 无取消机制
- 无实时质量检查
- 无中途降级路径

**实际影响**:
1. assembly组件卡在网络请求30秒→决策者不知道
2. buddyLM生成低质量内容→决策者事后才知道
3. 用户无法取消正在执行的任务
4. 前2个组件都失败→静默跳过→用户收到rule引擎的低质量回复

**修复方案**: 参见 [改进计划 3.1](#31-执行链路实时监控)

---

#### P0-2: CerebellumExecutionMonitor只覆盖DAG路径

**代码位置**: `plan-executor.ts:938`

**问题描述**: `CerebellumExecutionMonitor`（连续失败熔断+过载中止+超时跳过）只在`executeDAG()`中实例化。大多数任务走的`executeBlendStrategy()`和`executeLocalPlan()`不经过此监控器。

**实际影响**:
- `executeBlendStrategy`: 5个组件连续失败→无熔断
- `executeLocalPlan`: 步骤连续失败→无熔断
- `executeExperience`: 经验执行失败→无熔断
- 系统load>90时，DAG路径会中止，但其他路径继续执行

**修复方案**: 参见 [改进计划 3.2](#32-cerebellumexecutionmonitor全路径覆盖)

---

#### P0-3: shutdown()丢失最后一次决策数据

**代码位置**: `agent.ts:1729-1737`

**问题描述**: `shutdown()`调用`perceptionBridge.stop()`和`skillOps.savePersisted()`，但未调用`saveBlendState()`和`saveResourceHubState()`。

**实际影响**: 最后10次心跳间隔内的决策数据丢失：
- BlendBrain的REINFORCE梯度
- BlendBandit的Thompson Sampling统计
- ResourceHub的资源画像更新
- DispatchLearner的bandit更新

**修复方案**: 参见 [改进计划 1.1](#11-shutdown最终持久化)

---

#### P0-4: reflect()中feedback使用伪造的ExecutionPlan

**代码位置**: `reflector.ts:116-130`

**问题描述**: `reflect()`构造feedback时，`plan.source`硬编码为`'reflection'`，`confidence`硬编码为`0.5`。

**实际影响**: `threeBrain.feedback()`内部用`plan.source`判断记录到哪个ResourceHub资源画像。硬编码导致：
- 所有反馈记录到`engine:reflection`而非实际引擎
- Thompson Sampling的数据被污染
- 资源画像不准确

**修复方案**: 参见 [改进计划 2.1](#21-reflect的plansource修正)

---

### 🟡 P1 — 应该修复

#### P1-1: BlendBrain探索噪声无下限保护

**代码位置**: `blend-brain.ts:143-160`

**问题描述**: `_explorationSigma`在`update()`中衰减，无下限保护。

**实际影响**: 长期运行后，探索能力可能丧失，陷入局部最优。

**修复方案**: 添加`Math.max(0.05, sigma)`保护。

---

#### P1-2: 小脑PID积分饱和无anti-windup

**代码位置**: `homeostasis.ts:88-93`

**问题描述**: `state.integral += error * dt`无限累积，无积分限幅。

**实际影响**: 长时间运行后，PID输出过大导致过度调节(overshoot)。

**修复方案**: 添加积分限幅`Math.max(-1000, Math.min(1000, state.integral))`。

---

#### P1-3: ShadowBrain的enabled标志不持久化

**代码位置**: `shadow/index.ts:80`

**问题描述**: `private enabled: boolean = true`是内存态。

**实际影响**: 用户禁用ShadowBrain后重启自动恢复为true。

**修复方案**: 持久化到`shadow-state.json`。

---

#### P1-4: CLI模式未接入ExecutionSession

**代码位置**: `agent.ts:477` (handleCLIMessage)

**问题描述**: `ExecutionSession`有完整的生命周期管理(start/pause/resume/fail/complete/checkpoint)，但CLI模式下`handleCLIMessage()`不创建ExecutionSession。

**实际影响**: CLI模式下无检查点确认、无自主等级控制、无执行统计。

**修复方案**: 参见 [改进计划 3.3](#33-cli模式接入executionsession)

---

#### P1-5: decisionTrace无持久化

**代码位置**: `agent.ts:113`

**问题描述**: `decisionTrace`纯内存，最多200条。

**实际影响**: 重启后丢失决策追踪，ShadowBrain的GapDetector需要重新积累。

**修复方案**: 心跳时定期写入`decision-trace.jsonl`。

---

#### P1-6: 蒸馏触发条件过严

**代码位置**: `brain.ts` feedback()中`uniqueModes >= 2`

**问题描述**: 用户长期做同一类任务时蒸馏永远不会触发。

**修复方案**: 添加时间兜底（24h未蒸馏强制触发一次）。

---

### 🟢 P2 — 优化项

#### P2-1: executeBlendStrategy组件静默失败

5个组件任何一个失败都静默跳过，用户不知道发生了什么。建议至少在decisionTrace中记录。

#### P2-2: condenseKnowledge的聚类阈值硬编码

0.65余弦相似度阈值对短文本区分度低，对长文本过于严格。建议自适应阈值。

#### P2-3: HomeostasisAction限频过于保守

`maxActionsPerHour=5`，高频交互场景下可能不够用。建议动态调整。

---

## 三、改进计划

### 3.1 执行链路实时监控

**目标**: 让决策者能看到执行过程，支持超时、进度、质量实时感知。

#### 3.1.1 执行监控接口扩展

```typescript
// brain/dispatch/executor.ts

/** 执行监控回调 — 决策者实时感知执行过程 */
export interface ExecutionMonitorCallback {
  /** 组件开始执行 */
  onComponentStart(component: string, weight: number): void;
  /** 组件执行完成 */
  onComponentComplete(component: string, result: { text: string; confidence: number }): void;
  /** 组件执行失败 */
  onComponentFail(component: string, error: string): void;
  /** 组件执行超时 */
  onComponentTimeout(component: string, timeoutMs: number): void;
  /** 整体质量评估（每完成一个组件后调用） */
  onQualityCheck(overallConfidence: number, components: string[]): 'continue' | 'stop' | 'degrade';
  /** 执行进度 */
  onProgress(completed: number, total: number): void;
}
```

#### 3.1.2 executeBlendStrategy改造

```typescript
// brain.ts — executeBlendStrategy 改造

private async executeBlendStrategy(
  input: string,
  signal: TaskSignal,
  resources: ResourceState,
  intuition: IntuitionSignal | undefined,
  bodyState: BodyState,
  blendVector: BlendVector,
  monitor?: ExecutionMonitorCallback,  // 新增
): Promise<...> {
  const THRESHOLD = 0.05;
  const COMPONENT_TIMEOUT_MS = 15_000;  // 15秒超时
  const QUALITY_FLOOR = 0.3;            // 质量地板
  const weights = blendVector.weights;
  const totalComponents = weights.filter(w => w > THRESHOLD).length;
  let completed = 0;
  const results = [];

  // 按权重排序，高权重优先执行
  const components = [
    { name: 'rule', weight: weights[0], execute: () => this.executeRuleComponent(...) },
    { name: 'experience', weight: weights[1], execute: () => this.executeExperienceComponent(...) },
    { name: 'assembly', weight: weights[2], execute: () => this.executeAssemblyComponent(...) },
    { name: 'buddyLM', weight: weights[3], execute: () => this.executeBuddyLMComponent(...) },
    { name: 'cloudLLM', weight: weights[4], execute: () => this.executeCloudComponent(...) },
  ].filter(c => c.weight > THRESHOLD).sort((a, b) => b.weight - a.weight);

  for (const component of components) {
    monitor?.onComponentStart(component.name, component.weight);

    try {
      // 超时控制
      const result = await Promise.race([
        component.execute(),
        new Promise((_, reject) =>
          setTimeout(() => reject(new Error('timeout')), COMPONENT_TIMEOUT_MS)
        ),
      ];

      monitor?.onComponentComplete(component.name, result);
      results.push(result);
      completed++;
      monitor?.onProgress(completed, totalComponents);

      // 实时质量门控
      const overallConf = this.assessOverallConfidence(results);
      const decision = monitor?.onQualityCheck(overallConf, results.map(r => r.source));
      if (decision === 'stop') break;
      if (decision === 'degrade') {
        // 降级：只用已有结果，不再执行后续组件
        break;
      }

    } catch (err) {
      const isTimeout = (err as Error).message === 'timeout';
      if (isTimeout) {
        monitor?.onComponentTimeout(component.name, COMPONENT_TIMEOUT_MS);
      } else {
        monitor?.onComponentFail(component.name, (err as Error).message);
      }
      completed++;
      monitor?.onProgress(completed, totalComponents);
      // 继续执行下一个组件
    }
  }

  return this.mergeResults(results, blendVector);
}
```

#### 3.1.3 ThreeBrain监控回调实现

```typescript
// brain.ts — ThreeBrain 内部实现

private createExecutionMonitor(): ExecutionMonitorCallback {
  return {
    onComponentStart: (component, weight) => {
      if (this.verbose) console.log(`[Brain] 执行组件: ${component} (weight=${weight.toFixed(3)})`);
    },
    onComponentComplete: (component, result) => {
      if (this.verbose) console.log(`[Brain] 组件完成: ${component} (conf=${result.confidence.toFixed(3)})`);
    },
    onComponentFail: (component, error) => {
      if (this.verbose) console.warn(`[Brain] 组件失败: ${component} — ${error}`);
    },
    onComponentTimeout: (component, timeoutMs) => {
      if (this.verbose) console.warn(`[Brain] 组件超时: ${component} (${timeoutMs}ms)`);
    },
    onQualityCheck: (overallConf, components) => {
      if (overallConf < 0.3 && components.length >= 2) return 'stop';
      if (overallConf < 0.5 && components.length >= 3) return 'degrade';
      return 'continue';
    },
    onProgress: (completed, total) => {
      // 可推送到前端 signalObserver
      this.signalObserver?.({
        phase: 'execution_progress',
        timestamp: Date.now(),
        data: { completed, total },
      });
    },
  };
}
```

#### 3.1.4 实施步骤

| 步骤 | 内容 | 预估工时 |
|------|------|----------|
| 1 | 定义`ExecutionMonitorCallback`接口 | 0.5h |
| 2 | 改造`executeBlendStrategy`加超时+进度 | 2h |
| 3 | 实现ThreeBrain监控回调 | 1h |
| 4 | 接入signalObserver推送到前端 | 0.5h |
| 5 | 测试：超时/质量门控/降级 | 1h |
| **合计** | | **5h** |

---

### 3.2 CerebellumExecutionMonitor全路径覆盖

**目标**: 让所有执行路径都经过小脑监控。

#### 3.2.1 监控器注入改造

```typescript
// brain.ts — decide() 方法中创建监控器

async decide(input, signal, resources): Promise<DecisionResult> {
  // ... 现有逻辑 ...

  // 创建执行监控器（所有执行路径共用）
  const monitor = this.createExecutionMonitor();

  // executeBlendStrategy 传入监控器
  const result = await this.executeBlendStrategy(
    input, signal, resources, intuition, bodyState, blendVector, monitor
  );

  return { plan, intuition, bodyState, ... };
}
```

#### 3.2.2 executeLocalPlan接入监控

```typescript
// plan-executor.ts — executeLocalPlan 改造

export async function executeLocalPlan(
  ctx: ExecutionContext,
  plan: ExecutablePlan,
  monitor?: ExecutionMonitor,  // 新增
): Promise<ExecutionResult | null> {
  for (const step of plan.steps) {
    // 每步开始前检查是否应该中止
    if (monitor) {
      const abortCheck = monitor.shouldAbort();
      if (abortCheck.abort) {
        log.warn(`本地计划中止: ${abortCheck.reason}`);
        return null;
      }
    }

    // ... 执行步骤 ...

    // 步骤完成后报告
    if (monitor) {
      if (stepResult.startsWith('[error')) {
        monitor.onTaskFail(step.id, stepResult);
      } else {
        monitor.onTaskDone(step.id, stepResult);
      }
    }
  }
}
```

#### 3.2.3 实施步骤

| 步骤 | 内容 | 预估工时 |
|------|------|----------|
| 1 | decide()中创建监控器 | 0.5h |
| 2 | executeBlendStrategy传入监控器 | 0.5h |
| 3 | executeLocalPlan传入监控器 | 1h |
| 4 | executeExperience传入监控器 | 0.5h |
| 5 | 测试 | 1h |
| **合计** | | **3.5h** |

---

### 3.3 CLI模式接入ExecutionSession

**目标**: CLI模式下也有完整的生命周期管理。

#### 3.3.1 handleCLIMessage改造

```typescript
// agent.ts — handleCLIMessage 改造

async handleCLIMessage(content: string): Promise<string> {
  // 创建ExecutionSession
  const session = new ExecutionSession({
    id: `cli-${Date.now()}`,
    goal: content.slice(0, 200),
    autonomyLevel: decideAutonomyLevel({
      taskRisk: assessTaskRisk(content),
      userCorrectionCount: this.ws?.getUserCorrectionCount?.() ?? 0,
      sessionLength: this.decisionTrace.length,
      isFirstSession: this.decisionTrace.length === 0,
    }),
    maxRetries: 2,
    maxSteps: 20,
    checkpointInterval: 5,
  });
  session.start();

  try {
    // ... 现有逻辑 ...

    // 每个工具调用记录到session
    for (const tc of result.toolCalls) {
      const step = session.addStep(tc.name, tc.args);
      // 高风险操作检查
      if (session.shouldPauseForConfirmation(tc.name, tc.args)) {
        // CLI模式：通过cliConfirmHandler确认
        if (this.cliConfirmHandler) {
          const allowed = await this.cliConfirmHandler(
            describeToolCall(tc.name, tc.args)
          );
          if (!allowed) {
            session.fail('用户取消');
            return '操作已取消';
          }
        }
      }
      session.completeStep(step.id, tc.result.slice(0, 500), !tc.result.startsWith('['));
    }

    session.complete();
    return presented.text;

  } catch (err) {
    session.fail((err as Error).message);
    throw err;
  }
}
```

#### 3.3.2 实施步骤

| 步骤 | 内容 | 预估工时 |
|------|------|----------|
| 1 | handleCLIMessage创建ExecutionSession | 1h |
| 2 | 工具调用记录到session | 0.5h |
| 3 | 检查点确认接入CLI | 0.5h |
| 4 | 测试 | 1h |
| **合计** | | **3h** |

---

### 2.1 reflect()的plan.source修正

**目标**: 让feedback使用真实的执行计划信息。

#### 2.1.1 方案

```typescript
// reflector.ts — 修正

export async function reflect(
  sys: Subsystems,
  plan: OrchestrationPlan,
  result: { text: string; toolCalls: ... },
  signal: TaskSignal,
  verbose: boolean,
  resources?: ResourceState,
  // 新增：真实执行信息
  executionMeta?: {
    actualSource: string;
    actualConfidence: number;
    blendVector?: import('../brain/types.js').BlendVector;
    strategyName?: string;
  },
): Promise<ReflectResult> {
  // ...

  // ⑤ 三脑反馈 — 使用真实执行信息
  const feedbackPlan = {
    mode: plan.mode,
    reason: plan.reason,
    selectedNodes: plan.selectedNodes,
    confidence: executionMeta?.actualConfidence ?? plan.confidence ?? 0.5,
    source: executionMeta?.actualSource ?? plan.source ?? 'unknown',
  };

  await sys.threeBrain?.feedback?.(
    signal,
    realResources,
    feedbackPlan as any,
    { success: allSuccess, latencyMs: 0, costEstimate: 0, toolsUsed: ... },
    signal.domains.join(','),
    result.toolCalls.map(tc => tc.name),
    undefined,
    undefined,
    result.text,
  );
}
```

#### 2.1.2 agent.ts传递执行信息

```typescript
// agent.ts — reflect 调用处

const reflectResult = await this.reflect(plan, result, signal, this.lastResources ?? undefined, {
  actualSource: decision.plan.source,
  actualConfidence: decision.plan.confidence,
  blendVector: decision.localGeneration ? undefined : undefined,
  strategyName: decision.generationPlan?.strategyName,
});
```

#### 2.1.3 实施步骤

| 步骤 | 内容 | 预估工时 |
|------|------|----------|
| 1 | reflect()签名扩展 | 0.5h |
| 2 | agent.ts传递执行信息 | 0.5h |
| 3 | 测试验证ResourceHub记录正确 | 1h |
| **合计** | | **2h** |

---

### 1.1 shutdown最终持久化

```typescript
// agent.ts — shutdown 改造

async shutdown(): Promise<void> {
  this.perceptionBridge?.stop();

  // 最终持久化
  this.skillOps.savePersisted();
  try {
    (this.sys.threeBrain as any)?.saveBlendState?.();
    (this.sys.threeBrain as any)?.saveResourceHubState?.();
  } catch { /* 静默失败 */ }

  await this.sys.closeAll(
    this.ws.getEventBus(),
    this.ws.getDreamTimer(),
    this.fsWatcher,
    this.config.name,
  );
}
```

**预估工时**: 0.5h

---

## 四、实施优先级与排期

### Phase 1: 紧急修复（1天）

| 任务 | 工时 | 优先级 |
|------|------|--------|
| P0-3: shutdown最终持久化 | 0.5h | 🔴 |
| P0-4: reflect()plan.source修正 | 2h | 🔴 |
| P1-1: BlendBrain探索噪声下限 | 0.5h | 🟡 |
| P1-2: PID积分限幅 | 0.5h | 🟡 |
| P1-3: ShadowBrain enabled持久化 | 0.5h | 🟡 |
| **合计** | **4h** | |

### Phase 2: 执行监控核心（2天）

| 任务 | 工时 | 优先级 |
|------|------|--------|
| P0-1: ExecutionMonitorCallback接口 | 0.5h | 🔴 |
| P0-1: executeBlendStrategy改造 | 2h | 🔴 |
| P0-1: ThreeBrain监控回调 | 1h | 🔴 |
| P0-2: CerebellumExecutionMonitor全路径 | 3.5h | 🔴 |
| 测试 | 2h | |
| **合计** | **9h** | |

### Phase 3: 生命周期完善（1天）

| 任务 | 工时 | 优先级 |
|------|------|--------|
| P1-4: CLI模式ExecutionSession | 3h | 🟡 |
| P1-5: decisionTrace持久化 | 1h | 🟡 |
| P1-6: 蒸馏时间兜底 | 0.5h | 🟡 |
| 测试 | 1h | |
| **合计** | **5.5h** | |

### Phase 4: 优化项（1天）

| 任务 | 工时 | 优先级 |
|------|------|--------|
| P2-1: 组件失败记录 | 1h | 🟢 |
| P2-2: 自适应聚类阈值 | 2h | 🟢 |
| P2-3: HomeostasisAction动态限频 | 1h | 🟢 |
| 测试 | 1h | |
| **合计** | **5h** | |

---

## 五、验证标准

### 5.1 执行监控验证

- [ ] executeBlendStrategy中组件超时15秒自动跳过
- [ ] 组件连续失败2次触发熔断
- [ ] 系统load>90时所有执行路径中止
- [ ] 执行进度通过signalObserver推送到前端
- [ ] 实时质量门控：前2个组件质量<0.3时中断

### 5.2 反馈闭环验证

- [ ] reflect()的feedback中plan.source与实际执行引擎一致
- [ ] ResourceHub记录的引擎级别结果正确
- [ ] Thompson Sampling数据不被reflection污染

### 5.3 生命周期验证

- [ ] shutdown后重启，BlendState完整恢复
- [ ] CLI模式下ExecutionSession正确创建
- [ ] ShadowBrain禁用后重启仍为禁用状态
- [ ] decisionTrace重启后可恢复

### 5.4 稳定性验证

- [ ] BlendBrain探索噪声不低于0.05
- [ ] PID积分项不超过±1000
- [ ] 长时间运行(1000次交互)无内存泄漏

---

## 六、附录：代码变更清单

| 文件 | 变更类型 | 描述 |
|------|----------|------|
| `brain/brain.ts` | 改造 | executeBlendStrategy加监控回调+超时 |
| `brain/brain.ts` | 新增 | createExecutionMonitor()方法 |
| `brain/dispatch/executor.ts` | 新增 | ExecutionMonitorCallback接口 |
| `core/agent.ts` | 改造 | shutdown加持久化 |
| `core/agent.ts` | 改造 | handleCLIMessage加ExecutionSession |
| `core/agent.ts` | 改造 | reflect调用传执行信息 |
| `core/reflector.ts` | 改造 | reflect()签名扩展 |
| `core/plan-executor.ts` | 改造 | executeLocalPlan加监控器 |
| `brain/cerebellum/homeostasis.ts` | 改造 | PID积分限幅 |
| `brain/hub/blend-brain.ts` | 改造 | 探索噪声下限保护 |
| `brain/shadow/index.ts` | 改造 | enabled持久化 |
| `brain/brain.ts` | 改造 | 蒸馏时间兜底 |
