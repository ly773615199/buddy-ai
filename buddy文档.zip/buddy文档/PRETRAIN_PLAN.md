# Buddy 联合预训练方案

> 设计日期：2026-05-21
> 目标：所有预训练模块联合训练 + 三进制专业模型可行性验证

---

## 一、现状分析

### 1.1 需要预训练的模块

| 模块 | 文件 | 参数量 | 当前状态 | 权重格式 |
|------|------|--------|---------|---------|
| BBPE Tokenizer | `src/brain/right/nn/bbpe-tokenizer.ts` | 无权重（vocab/merges） | vocabSize=16384 未训练 | JSON |
| BBPE Embedding | `src/brain/right/nn/bbpe-embedding.ts` | 260×128 ~ 16384×128 | stage-0 进行中(472步) | bin-float32 |
| ByteEncoder | `src/brain/right/features/text-encoder.ts` | ~276K | step=1119, gap不稳定 | bin-float32 |
| BuddyLM Encoder | `src/brain/right/nn/model.ts` (IntuitionNet) | ~1.15M | 未独立预训练 | serialize.ts 格式 |
| BuddyLM Decoder | `src/brain/right/nn/decoder.ts` | ~2.1M (vocab=8192) | step=26952, stage-0 | bin-float32 |
| WorldModel | `src/brain/right/nn/world-model.ts` | ~19K | 未预训练 | bin-float32 |
| 三进制模型 ×N | `src/ternary/` | 10M/100M/300M 预设 | 架构完成,未训练 | .ta 格式 |

### 1.2 当前问题

1. **模块各自为战**：ByteEncoder 独立训练、BuddyLM 独立训练，没有联合优化
2. **数据规模不足**：总 212K 条，ByteEncoder 仅 2600 代码对
3. **BBPE Tokenizer 未训练**：vocab 还是从预设规则生成，未从真实语料学习
4. **三进制模型完全未训练**：架构和训练器就绪，但没有实际训练验证
5. **梯度流断裂**：ByteEncoder → BBPE Embedding 的桥接未在联合训练中验证

---

## 二、联合预训练架构

### 2.1 核心设计思想

**端到端联合训练，分阶段递进**：

```
Stage 0: 基础构建 — Tokenizer 训练 + ByteEncoder 对比学习
Stage 1: 语言建模 — Encoder-Decoder 联合 CE 预训练
Stage 2: 对齐增强 — DPO + 三进制蒸馏
Stage 3: 专业分化 — 三进制专业模型训练
```

### 2.2 统一训练管线

```
                    ┌─────────────────────────────────────┐
                    │        UnifiedPretrainPipeline       │
                    └──────────────┬──────────────────────┘
                                   │
              ┌────────────────────┼────────────────────┐
              ▼                    ▼                    ▼
    ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐
    │  Stage 0        │  │  Stage 1        │  │  Stage 2/3      │
    │  Tokenizer      │  │  LM Pretrain    │  │  Align + Ternary│
    │  + ByteEncoder  │  │  (联合训练)     │  │  Distill        │
    └────────┬────────┘  └────────┬────────┘  └────────┬────────┘
             │                    │                    │
             ▼                    ▼                    ▼
    ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐
    │ checkpoint/     │  │ checkpoint/     │  │ checkpoint/     │
    │ tokenizer.json  │  │ buddylm-pretrain│  │ ternary-*.ta    │
    │ encoder-pretrain│  │ (全量替换)      │  │ (新增)          │
    └─────────────────┘  └─────────────────┘  └─────────────────┘
```

### 2.3 检查点兼容性设计

所有检查点保持现有格式，确保无缝替换：

```
checkpoints/
├── buddylm-pretrain/          ← Stage 1 更新 (替换现有)
│   ├── decoder.weights.bin    ← bin-float32, 兼容现有格式
│   ├── embedding.weights.bin  ← bin-float32, 兼容现有格式
│   ├── meta.json              ← 更新 step/loss/config
│   └── stage-progress.json    ← 更新 stage 进度
├── encoder-pretrain/          ← Stage 0 更新 (替换现有)
│   ├── final.weights.bin      ← bin-float32, 兼容现有格式
│   └── final.json             ← 更新 step/trainPairs
├── tokenizer/                 ← 新增
│   └── bbpe-vocab.json        ← BBPE Tokenizer 训练结果
├── ternary-code/              ← 新增: 代码专业模型
│   └── model.ta
├── ternary-math/              ← 新增: 数学专业模型
│   └── model.ta
├── ternary-qa/                ← 新增: 问答专业模型
│   └── model.ta
├── ternary-creative/          ← 新增: 创意写作专业模型
│   └── model.ta
└── ternary-reasoning/         ← 新增: 推理专业模型
    └── model.ta
```

---

## 三、各 Stage 详细设计

### Stage 0：基础构建（Tokenizer + ByteEncoder）

**目标**：为后续训练打好分词和编码基础

#### 0.1 BBPE Tokenizer 训练

**入口**：新增 `src/brain/right/training/train-tokenizer.ts`

```typescript
// 训练流程
const corpus = await loadCorpus([
  'training-data/stages/stage-0-dictionary.jsonl',   // 117K 条
  'training-data/stages/stage-1-foundation.jsonl',   // 19K 条
  'training-data/stages/stage-2-domain.jsonl',       // 23.7K 条
  'training-data/stages/stage-3-technical.jsonl',    // 28.5K 条
]);

const tokenizer = new BBPETokenizer({ vocabSize: 16384 });
await tokenizer.train(corpus);  // 从语料学习合并规则
tokenizer.save('checkpoints/tokenizer/bbpe-vocab.json');
```

**输出**：`checkpoints/tokenizer/bbpe-vocab.json`（vocab + merges）

**验证**：编码/解码往返测试，OOV 率 < 1%

#### 0.2 ByteEncoder 对比学习（增强版）

**入口**：增强现有 `src/brain/right/training/pretrain-encoder.ts`

**数据源扩展**：
- 代码扫描（现有）：~2600 对
- JSONL 语料：212K 条 → 提取 question↔answer 对
- 字典数据：117K 条中英词典 → 提取 中文↔英文 对
- **新增**：从 `src/` 代码注释提取 comment↔code 对（扩展扫描范围）

**训练参数**：
```typescript
{
  epochs: 5,
  batchSize: 64,
  learningRate: 0.0003,    // cosine schedule
  warmupSteps: 100,
  maxSeqLen: 200,
  negSampleRatio: 1.0,     // 1:1 正负样本
  curriculumStrategy: 'short-to-long',
}
```

**Checkpoint 输出**：
```json
// checkpoints/encoder-pretrain/final.json
{
  "step": "<新 step>",
  "trainPairs": "<新训练对数>",
  "config": { ... },  // 保持现有字段
  "sources": { "code": ..., "jsonl": ..., "dict": ..., "comment": ... }
}
```

**无缝替换**：直接覆盖 `final.weights.bin` 和 `final.json`，现有加载代码兼容。

---

### Stage 1：语言建模联合预训练

**目标**：Encoder + Decoder + Embedding 端到端联合训练

#### 1.1 统一训练器

**入口**：新增 `src/brain/right/training/unified-pretrain.ts`

```typescript
class UnifiedPretrainPipeline {
  // 模块实例
  private tokenizer: BBPETokenizer;
  private encoder: IntuitionNet;         // 或 ByteEncoder
  private embedding: BBPEEmbedding;
  private decoder: BuddyLMDecoder;
  private worldModel: WorldModel;

  // 优化器（统一管理）
  private encoderOptimizer: Adam;        // 冻结或极低 lr
  private embeddingOptimizer: Adam;      // 正常 lr
  private decoderOptimizer: Adam;        // 正常 lr
  private worldModelOptimizer: Adam;     // 正常 lr

  // 训练阶段
  async runStage1(config: Stage1Config): Promise<void> {
    const data = await this.loadData(config.dataPaths);

    for (const epoch of range(config.epochs)) {
      for (const batch of data.batches(config.batchSize)) {
        // 1. Tokenizer 编码
        const tokenIds = this.tokenizer.encode(batch.text);

        // 2. Embedding
        const embeddings = this.embedding.forward(tokenIds);

        // 3. Encoder (默认冻结，可选微调)
        const encoded = config.freezeEncoder
          ? this.encoder.forwardNoGrad(embeddings)
          : this.encoder.forward(embeddings);

        // 4. Decoder (自回归，teacher forcing)
        const logits = this.decoder.forward(encoded, tokenIds);

        // 5. Loss: cross-entropy next-token prediction
        const loss = crossEntropyLoss(logits, batch.targets);

        // 6. 反向传播（跳过冻结的 Encoder）
        loss.backward();

        // 7. 梯度裁剪 + 优化器更新
        clipGradNorm(this.allParams(), 1.0);
        this.embeddingOptimizer.step();
        this.decoderOptimizer.step();
        if (!config.freezeEncoder) this.encoderOptimizer.step();

        // 8. WorldModel 辅助任务（可选）
        if (config.trainWorldModel) {
          const wmLoss = this.trainWorldModelStep(encoded);
          wmLoss.backward();
          this.worldModelOptimizer.step();
        }
      }

      // 每 epoch 结束：保存 checkpoint + 评估
      await this.saveCheckpoint(epoch);
      await this.evaluate(epoch);
    }
  }
}
```

#### 1.2 训练数据

**复用现有数据**，按 stage 递进：

| 顺序 | 数据 | 条数 | 用途 |
|------|------|------|------|
| 1 | stage-0-dictionary.jsonl | 117,060 | 基础词汇 |
| 2 | stage-1-foundation.jsonl | 19,000 | 基础问答 |
| 3 | stage-2-domain.jsonl | 23,750 | 领域知识 |
| 4 | stage-3-technical.jsonl | 28,500 | 技术知识 |
| 5 | stage-4-scale.jsonl | 23,750 | 规模化 |

**数据格式统一为**：
```json
{"text": "问题\t答案", "source": "cedict", "quality": 0.9}
```

#### 1.3 训练配置

```typescript
interface Stage1Config {
  // 数据
  dataPaths: string[];
  batchSize: 32;
  maxSeqLen: 512;

  // 训练
  epochs: 3;
  learningRate: 0.001;          // 主学习率
  encoderLearningRate: 0.00001; // Encoder 极低 lr（不完全冻结，允许微调）
  embeddingLearningRate: 0.001;
  decoderLearningRate: 0.001;
  warmupSteps: 500;
  lrSchedule: 'cosine';         // cosine decay
  gradClip: 1.0;

  // Embedding 增长
  embeddingGrowth: {
    enabled: true;
    stages: [
      { vocabSize: 2048,  minSamples: 0 },      // 快速开始
      { vocabSize: 8192,  minSamples: 50000 },
      { vocabSize: 16384, minSamples: 100000 },
    ];
  };

  // Checkpoint
  checkpointDir: 'checkpoints/buddylm-pretrain';
  saveEverySteps: 1000;
  evalEverySteps: 500;

  // WorldModel
  trainWorldModel: true;
  worldModelWeight: 0.1;  // 辅助 loss 权重
}
```

#### 1.4 Checkpoint 保存（无缝替换）

```typescript
async saveCheckpoint(globalStep: number): Promise<void> {
  // Decoder 权重 — 兼容现有格式
  const decoderBuf = this.decoder.saveWeightsBinary();
  fs.writeFileSync('checkpoints/buddylm-pretrain/decoder.weights.bin', decoderBuf);

  // Embedding 权重 — 兼容现有格式
  const embedBuf = this.embedding.saveWeightsBinary();
  fs.writeFileSync('checkpoints/buddylm-pretrain/embedding.weights.bin', embedBuf);

  // meta.json — 保持现有字段，更新值
  const meta = {
    step: globalStep,
    avgLoss: this.recentAvgLoss,
    totalSamples: this.totalSamples,
    timestamp: new Date().toISOString(),
    decoderParams: this.decoder.paramCount(),
    embeddingParams: this.embedding.paramCount(),
    vocabSize: this.embedding.vocabSize,
    format: 'bin-only',
    config: {
      decoder: this.decoder.config,
      embedding: { vocabSize: this.embedding.vocabSize, embedDim: this.embedding.embedDim },
    },
  };
  fs.writeFileSync('checkpoints/buddylm-pretrain/meta.json', JSON.stringify(meta, null, 2));

  // stage-progress.json — 保持现有字段
  const progress = {
    stage: this.currentStage,
    stageStep: this.stageStep,
    globalStep: globalStep,
  };
  fs.writeFileSync('checkpoints/buddylm-pretrain/stage-progress.json', JSON.stringify(progress));
}
```

**兼容性保证**：
- `decoder.weights.bin`：使用相同的 `saveWeightsBinary()` / `loadWeightsBinary()` 方法
- `embedding.weights.bin`：使用相同的二进制格式
- `meta.json`：保持所有现有字段，只更新值
- 现有 `BuddyLM.tryLoadPretrained()` 无需修改即可加载新权重

---

### Stage 2：对齐增强 + 三进制蒸馏

**目标**：DPO 对齐 + 从 BuddyLM 蒸馏到三进制模型

#### 2.1 Self-Rewarding DPO

复用现有 `BuddyLMTrainer` 的 `self-rewarding` 模式：

```typescript
// 使用 qualityHead 作为裁判
const trainer = new BuddyLMTrainer(config);
await trainer.trainStep('self-rewarding');  // DPO loss
```

#### 2.2 三进制蒸馏

**入口**：新增 `src/brain/right/training/ternary-distill-pipeline.ts`

```typescript
class TernaryDistillPipeline {
  // 教师模型：BuddyLM（Stage 1 训练好的）
  private teacher: BuddyLM;

  // 学生模型：多个三进制专业模型
  private students: Map<string, TernaryTrainer>;

  async run(): Promise<void> {
    // 1. 准备蒸馏数据
    const distillData = await this.prepareDistillData();

    // 2. 对每个专业领域蒸馏
    for (const [domain, trainer] of this.students) {
      const domainData = distillData.filter(d => d.domain === domain);

      // 教师生成 soft labels
      const teacherLogits = await this.teacher.generateLogits(domainData);

      // 学生训练（t-SignSGD）
      const result = await trainer.train(domainData, teacherLogits);

      // 评估 + 保存
      if (result.success) {
        trainer.save(`checkpoints/ternary-${domain}/model.ta`);
      }
    }
  }
}
```

---

### Stage 3：三进制专业模型训练

**目标**：训练至少 5 个三进制专业模型，验证可行性

#### 3.1 专业模型配置

| 模型 | 领域 | 架构预设 | 训练数据来源 | 参数量 |
|------|------|---------|-------------|--------|
| `ternary-code` | 代码 | 100m | stage-2-domain (codesearchnet) + src/ 代码 | 100M |
| `ternary-math` | 数学 | 100m | 合成数学 QA | 100M |
| `ternary-qa` | 通用问答 | 100m | stage-1-foundation + stage-2-domain | 100M |
| `ternary-creative` | 创意写作 | 100m | 合成创意文本 | 100M |
| `ternary-reasoning` | 推理 | 300m | 合成推理链 | 300M |

#### 3.2 训练流程

```typescript
// 每个专业模型的训练流程
for (const domain of ['code', 'math', 'qa', 'creative', 'reasoning']) {
  const arch = TernaryArchitecture.fromPreset(
    domain === 'reasoning' ? '300m' : '100m'
  );

  const model = arch.createModel(domain);
  const trainer = new TernaryTrainer(model, {
    batchSize: 32,
    maxEpochs: 20,
    patience: 5,
    optimizer: { learningRate: 0.01 },
  });

  // 加载该领域的训练数据
  const data = await loadDomainData(domain);

  // 从教师模型蒸馏
  const teacherOutputs = await buddylm.generateLogits(data);

  // 训练
  const result = await trainer.train(data, teacherOutputs);

  // 保存 .ta 文件
  if (result.success) {
    saveTernaryModel(model, `checkpoints/ternary-${domain}/model.ta`);
  }
}
```

#### 3.3 三进制训练数据准备

**数据来源**：

```typescript
// 代码领域
const codeData = [
  ...loadJSONL('training-data/stages/stage-2-domain.jsonl')  // codesearchnet
    .filter(d => d.source === 'codesearchnet'),
  ...scanSourceCode('src/**/*.ts')  // 从项目源码提取
];

// 数学领域（合成）
const mathData = await synthesizeMathQA({
  topics: ['算术', '代数', '几何', '概率', '统计'],
  difficulty: ['基础', '中等', '困难'],
  count: 10000,
});

// 通用问答
const qaData = [
  ...loadJSONL('training-data/stages/stage-1-foundation.jsonl'),
  ...loadJSONL('training-data/stages/stage-2-domain.jsonl'),
];

// 创意写作（合成）
const creativeData = await synthesizeCreativeWriting({
  types: ['故事', '诗歌', '对话', '描述'],
  count: 10000,
});

// 推理链（合成）
const reasoningData = await synthesizeReasoningChain({
  types: ['逻辑推理', '因果分析', '多步推理', '反事实'],
  count: 10000,
});
```

#### 3.4 评估指标

每个三进制模型训练后验证：

```typescript
interface TernaryEvalResult {
  domain: string;
  // 基础指标
  loss: number;              // 训练 loss
  valLoss: number;           // 验证 loss
  perplexity: number;        // 困惑度

  // 三进制特有指标
  ternaryRatio: number;      // 三进制参数占比
  compressionRatio: number;  // 压缩率 (vs fp32)
  inferenceSpeed: number;    // tokens/sec (CPU)

  // 质量指标
  bleu: number;              // BLEU 分数
  humanEval: number;         // 人工评分 (1-5)

  // 可行性判定
  feasible: boolean;         // valLoss < threshold && inferenceSpeed > minSpeed
}
```

---

## 四、统一训练脚本

### 4.1 CLI 入口

**新增文件**：`src/brain/right/training/unified-pretrain.ts`

```bash
# 完整流程（Stage 0 → 3）
npx tsx src/brain/right/training/unified-pretrain.ts --full

# 单独 Stage
npx tsx src/brain/right/training/unified-pretrain.ts --stage 0   # Tokenizer + ByteEncoder
npx tsx src/brain/right/training/unified-pretrain.ts --stage 1   # LM 联合预训练
npx tsx src/brain/right/training/unified-pretrain.ts --stage 2   # DPO 对齐
npx tsx src/brain/right/training/unified-pretrain.ts --stage 3   # 三进制蒸馏

# 配置覆盖
npx tsx src/brain/right/training/unified-pretrain.ts --stage 1 \
  --epochs 5 \
  --batch-size 64 \
  --lr 0.0005 \
  --encoder-lr 0.00001

# 仅训练指定三进制模型
npx tsx src/brain/right/training/unified-pretrain.ts --stage 3 --domains code,math

# 从指定 checkpoint 恢复
npx tsx src/brain/right/training/unified-pretrain.ts --stage 1 --resume checkpoints/buddylm-pretrain
```

### 4.2 配置文件

**新增**：`pretrain-config.json`

```json
{
  "stages": {
    "0": {
      "name": "基础构建",
      "tokenizer": {
        "vocabSize": 16384,
        "corpusPaths": [
          "training-data/stages/stage-0-dictionary.jsonl",
          "training-data/stages/stage-1-foundation.jsonl",
          "training-data/stages/stage-2-domain.jsonl",
          "training-data/stages/stage-3-technical.jsonl"
        ]
      },
      "byteEncoder": {
        "epochs": 5,
        "batchSize": 64,
        "learningRate": 0.0003,
        "maxSeqLen": 200,
        "dataPaths": [
          "training-data/stages/*.jsonl",
          "src/**/*.ts"
        ]
      }
    },
    "1": {
      "name": "语言建模",
      "epochs": 3,
      "batchSize": 32,
      "maxSeqLen": 512,
      "learningRate": 0.001,
      "encoderLearningRate": 0.00001,
      "warmupSteps": 500,
      "lrSchedule": "cosine",
      "gradClip": 1.0,
      "embeddingGrowth": {
        "enabled": true,
        "stages": [
          { "vocabSize": 2048, "minSamples": 0 },
          { "vocabSize": 8192, "minSamples": 50000 },
          { "vocabSize": 16384, "minSamples": 100000 }
        ]
      },
      "dataPaths": [
        "training-data/stages/stage-0-dictionary.jsonl",
        "training-data/stages/stage-1-foundation.jsonl",
        "training-data/stages/stage-2-domain.jsonl",
        "training-data/stages/stage-3-technical.jsonl",
        "training-data/stages/stage-4-scale.jsonl"
      ],
      "checkpointDir": "checkpoints/buddylm-pretrain",
      "saveEverySteps": 1000,
      "evalEverySteps": 500
    },
    "2": {
      "name": "对齐增强",
      "dpo": {
        "enabled": true,
        "referenceSnapshot": true,
        "beta": 0.1,
        "batchSize": 16,
        "epochs": 2
      }
    },
    "3": {
      "name": "三进制蒸馏",
      "models": [
        {
          "domain": "code",
          "architecture": "100m",
          "dataSources": ["stage-2-domain:codesearchnet", "src/**/*.ts"],
          "maxEpochs": 20,
          "batchSize": 32
        },
        {
          "domain": "math",
          "architecture": "100m",
          "dataSources": ["synthetic:math-qa:10000"],
          "maxEpochs": 20,
          "batchSize": 32
        },
        {
          "domain": "qa",
          "architecture": "100m",
          "dataSources": ["stage-1-foundation", "stage-2-domain"],
          "maxEpochs": 20,
          "batchSize": 32
        },
        {
          "domain": "creative",
          "architecture": "100m",
          "dataSources": ["synthetic:creative:10000"],
          "maxEpochs": 20,
          "batchSize": 32
        },
        {
          "domain": "reasoning",
          "architecture": "300m",
          "dataSources": ["synthetic:reasoning:10000"],
          "maxEpochs": 25,
          "batchSize": 16
        }
      ]
    }
  }
}
```

---

## 五、Checkpoint 兼容性矩阵

| 现有文件 | 格式 | 新训练后 | 兼容性 |
|---------|------|---------|--------|
| `buddylm-pretrain/decoder.weights.bin` | bin-float32 | ✅ 直接替换 | 100% — 使用相同 saveWeightsBinary() |
| `buddylm-pretrain/embedding.weights.bin` | bin-float32 | ✅ 直接替换 | 100% — 使用相同 saveWeightsBinary() |
| `buddylm-pretrain/meta.json` | JSON | ✅ 更新值 | 100% — 保持所有现有字段 |
| `buddylm-pretrain/stage-progress.json` | JSON | ✅ 更新值 | 100% — 保持现有字段 |
| `encoder-pretrain/final.weights.bin` | bin-float32 | ✅ 直接替换 | 100% — 使用相同 loadWeightsBinary() |
| `encoder-pretrain/final.json` | JSON | ✅ 更新值 | 100% — 保持所有现有字段 |
| `tokenizer/bbpe-vocab.json` | JSON | 🆕 新增 | 新增 — BBPETokenizer.load() 可加载 |
| `ternary-*/model.ta` | .ta 格式 | 🆕 新增 | 新增 — TernaryEngine 可加载 |

**加载代码无需修改**：
- `BuddyLM.tryLoadPretrained()` → 自动加载 decoder + embedding
- `ByteEncoder` 构造函数 → 自动加载 encoder-pretrain
- `BBPETokenizer.load()` → 加载 vocab JSON
- `TernaryEngine.loadModel()` → 加载 .ta 文件

---

## 六、新增文件清单

```
src/brain/right/training/
├── unified-pretrain.ts           ← 统一训练入口（新增）
├── train-tokenizer.ts            ← Tokenizer 训练（新增）
├── ternary-distill-pipeline.ts   ← 三进制蒸馏管线（新增）
└── data-pipeline.ts              ← 统一数据管线（新增）

pretrain-config.json              ← 训练配置（新增）
PRETRAIN_PLAN.md                  ← 本文档（新增）
```

---

## 七、执行顺序

```
1. 编写 unified-pretrain.ts + train-tokenizer.ts + data-pipeline.ts
2. Stage 0: 训练 Tokenizer → 训练 ByteEncoder（增强数据）
3. 验证 Stage 0 checkpoint 兼容性
4. Stage 1: 联合预训练 Encoder + Decoder + Embedding
5. 验证 Stage 1 checkpoint 可被现有代码加载
6. Stage 2: DPO 对齐
7. Stage 3: 三进制蒸馏（5 个专业模型）
8. 评估报告：三进制模型可行性判定
```

---

## 八、风险与缓解

| 风险 | 影响 | 缓解措施 |
|------|------|---------|
| 联合训练显存不足 | Stage 1 无法运行 | 梯度累积 + 小 batch + Encoder 冻结 |
| Tokenizer 重新训练后 vocab 不兼容 | 旧 checkpoint 失效 | 保留旧 vocab 作为 fallback，新 vocab 用 Corner Embedding |
| 三进制模型 loss 不收敛 | 可行性验证失败 | 先 tiny 验证，成功再扩展 100m/300m |
| 训练时间过长 | 无法在合理时间完成 | 分 Stage 独立运行，每 Stage 可单独恢复 |
| 数据质量不足 | 模型效果差 | 数据清洗 + 去重 + 质量过滤 |
