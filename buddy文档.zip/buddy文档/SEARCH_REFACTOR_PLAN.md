# 搜索重构计划 — 归入组装引擎

> 2026-05-24 | 将搜索从"独立前置模块"改造为"组装引擎管线的一部分"

## 一、现状问题

### 1.1 三条搜索路径并行，职责重叠

| 路径 | 入口 | 决策方式 | 结果格式 | 下游 |
|---|---|---|---|---|
| A: SearchArbiter | agent.ts:437 | 关键词匹配 | 字符串 | 直接注入 prompt |
| B: 组装引擎检索 | brain.ts:543 | 三脑决策 | CandidateFragment[] | Reranker → GraphExpand → ContentSelector |
| C: ProactiveResearcher | proactive-researcher.ts | 关键词匹配 | ResearchResult | 独立缓存，降级调 A |

路径 B 是正确设计，但被 A 和 C 绕过了。

### 1.2 SearchArbiter 的问题
- 关键词匹配判断搜索时机，误判率高
- 提前执行搜索，不知道三脑最终要什么
- 结果以字符串透传，绕过 Reranker/ContentSelector 质量管线
- 内存 Map 缓存，30分钟过期，进程重启丢失
- ~550 行代码，维护成本高

### 1.3 ProactiveResearcher 的问题
- 与 SearchArbiter 关键词列表高度重复
- 独立缓存体系，又一个内存 Map
- 搜索结果不走组装引擎管线

## 二、改造目标

```
用户消息
  │
  ▼
三脑感知（Perceptor）
  │
  ▼
三脑编排（orchestrate）← 搜索决策在这里做（左脑规则 + 右脑分类）
  │
  ▼
组装引擎 retrieve() ← 搜索执行在这里做（9个provider并发）
  │
  ▼
Reranker → GraphExpand → ContentSelector ← 结果质量管线
  │
  ▼
最终输出
```

**唯一路径**：三脑决策 → 组装引擎检索管线 → 质量管线 → 输出

## 三、改动清单

### 3.1 删除 SearchArbiter（~550行）

**文件：** `src/tools/search-arbiter.ts`
- 整个文件删除

**文件：** `src/core/subsystems.ts`
- 删除 `searchArbiter` 属性声明（line ~206）
- 删除 SearchArbiter 初始化逻辑（line ~534-542）

**文件：** `src/core/agent.ts`
- 删除搜索预执行逻辑（line ~437-448）
- 删除 `searchContext` 变量及透传
- 删除 `__web_direct_search__` 快速路径（line ~461-465）
- 删除 `formatSearchResults` 方法
- `orchestrate()` 调用去掉 `searchContext` 参数

**文件：** `src/core/message-processor.ts`
- 删除搜索结果字符串注入（line ~758-762）

**文件：** `src/core/ws-handler.ts`
- 删除 SearchArbiter 预执行逻辑（line ~713-718）
- 删除 `__web_direct_search__` 快速路径（line ~758）

### 3.2 删除 ProactiveResearcher（~250行）

**文件：** `src/core/proactive-researcher.ts`
- 整个文件删除

**文件：** `src/core/subsystems.ts`
- 删除 ProactiveResearcher 相关初始化

**文件：** `src/core/agent.ts`
- 删除 ProactiveResearcher 引用

### 3.3 三脑增加搜索决策能力

**文件：** `src/brain/left/rule-engine.ts`

新增搜索决策规则（复用已有的 `__web_direct_search__` 规则思路，但升级判断逻辑）：

```typescript
// 新增规则：知识缺口 → 触发搜索
{
  name: '知识缺口 → 检索管线',
  condition: (signal, resources) => {
    // 1. 三脑分类为 knowledge/web 且置信度足够
    const dominatedByKnowledge = signal.domains.includes('knowledge') || signal.domains.includes('web');
    // 2. 本地经验/知识无命中
    const noLocalHit = !resources.experienceHit?.skill;
    // 3. 或者右脑明确标记需要搜索
    const rightBrainNeedsWeb = signal.domains.includes('web') && (signal.intentConfidence ?? 0) >= 0.5;
    
    return dominatedByKnowledge && (noLocalHit || rightBrainNeedsWeb);
  },
  action: (signal) => ({
    type: 'skill',
    skillId: '__assembly_search__',  // 触发组装引擎检索管线
    confidence: signal.intentConfidence ?? 0.6,
  }),
}
```

关键区别：
- 不靠关键词匹配，靠三脑信号（右脑分类 + 置信度）
- 不提前执行搜索，只标记"需要搜索"，由组装引擎执行
- 搜索结果走完整质量管线

### 3.4 agent.ts 简化

**文件：** `src/core/agent.ts`

改造后的流程：
```typescript
// 1. 感知
const perception = this.perceptor.perceive(content);

// 2. 编排（三脑决策，包含搜索决策）
plan = await this.orchestrate(content, perception);

// 3. 执行（组装引擎内部处理搜索）
result = await this.executeByPlan(plan);
```

删除所有搜索相关代码后，agent.ts 减少约 50 行。

### 3.5 组装引擎检索管线增强

**文件：** `src/brain/right/features/integration-engine.ts`

`retrieve()` 方法已有分层检索逻辑（本地优先 → 网络升级 → 重试），无需大改。

微调：
- 搜索决策由三脑传入（通过 TaskContext），而非 retrieve 内部判断
- 确保 `__assembly_search__` skill 触发时，组装引擎直接走网络检索

**文件：** `src/brain/brain.ts`

`registerWebProvidersSync()` 已正确注册 9 个 provider 到组装引擎，无需改动。

### 3.6 搜索工具保留

**文件：** `src/tools/web.ts`
- `search_web` 和 `fetch_url` 工具保留
- LLM 仍可通过 tool call 主动触发搜索（用户说"帮我搜xxx"时）
- 去掉 `[DEPRECATED]` 标记，改为正常描述

### 3.7 IntentRouter 保留

**文件：** `src/search/intent-router.ts`
- `classifyQueryIntent()` 和 `routeProviders()` 保留
- 已被 `brain.ts:543` 的 `registerWebProvidersWithModule` 使用
- 组装引擎检索时用它做源路由

### 3.8 清理引用

全局搜索以下引用，逐一清理：
- `SearchArbiter` / `searchArbiter` / `globalSearchArbiter`
- `ProactiveResearcher` / `proactiveResearcher`
- `searchContext`（agent.ts / message-processor.ts / ws-handler.ts）
- `__web_direct_search__`（快速路径，改为走组装引擎）

## 四、不改的部分

| 组件 | 保留原因 |
|---|---|
| 9 个 SearchProvider | 已正确注册到组装引擎，输出 CandidateFragment[] |
| IntentRouter | 源路由逻辑，组装引擎检索时使用 |
| search_web / fetch_url 工具 | LLM tool call 仍需要 |
| InformationIntegrationEngine | 检索管线核心，不改 |
| Reranker / GraphExpand / ContentSelector | 质量管线，不改 |
| score-normalizer.ts | 分数标准化，不改 |

## 五、改动量估算

| 操作 | 文件 | 行数变化 |
|---|---|---|
| 删除 SearchArbiter | search-arbiter.ts | -550 |
| 删除 ProactiveResearcher | proactive-researcher.ts | -250 |
| 清理 agent.ts | agent.ts | -50 |
| 清理 subsystems.ts | subsystems.ts | -30 |
| 清理 ws-handler.ts | ws-handler.ts | -20 |
| 清理 message-processor.ts | message-processor.ts | -10 |
| 新增搜索决策规则 | rule-engine.ts | +30 |
| **合计** | | **-880 行，+30 行** |

净减少 ~850 行代码，消除三条搜索路径的重复。

## 六、验证

1. **单元测试**：搜索相关测试（providers.test.ts / intent-router.test.ts / score-normalizer.test.ts）不改，应全部通过
2. **集成验证**：发送搜索类消息（如"Docker 多阶段构建怎么写"），确认走组装引擎检索管线
3. **工具调用**：发送"帮我搜xxx"，确认 LLM 可通过 tool call 主动触发 search_web
4. **回归**：非搜索类消息（代码生成、闲聊）不受影响
