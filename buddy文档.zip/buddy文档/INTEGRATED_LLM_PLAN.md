# 集成 LLM 架构重构计划

> ⚠️ **已废弃**: 本方案基于旧的耦合架构（组装引擎 + BuddyLM 绑定）。在新的解绑架构下，两者完全独立，通过 Brain 语义编排协作。见 [BUDDYLM_ASSEMBLY_INTEGRATION_PLAN.md](BUDDYLM_ASSEMBLY_INTEGRATION_PLAN.md)。

> 组装引擎 + BuddyLM = 一个整体。组装引擎是发动机，搜索源是燃料，BuddyLM 是语言输出层。
> 断一个都干不了活。

---

## 问题诊断

### 断层 1：ResourceHub 冷启动死锁

**现象**：v3.0 BlendBrain 路径永远被跳过

**根因**：资源注册时 `status='registering'`，`getActive()` 只返回 `'active'|'degraded'`。
资源需要使用记录才能激活（`recordOutcome`），但首次请求无法使用它们。
鸡生蛋问题。

```
brain.ts:1080  if (this.resourceHub.getActive().length > 0) → false
               → 跳过 v3.0 BlendBrain
               → 回退到 coordinator.analyze()
```

**修复**：`scanAndRegister()` 后将本地资源（buddyLM/assembly/experience/rule）直接标记为 `'active'`。
它们是基础设施，不是需要验证的外部依赖。

### 断层 2：Coordinator 把集成系统当可选策略

**现象**：无外部 LLM 时，coordinator 选 `'compete'` 策略（期望有外部 LLM），而非直接走集成系统。

**根因**：`analyze()` 方法按 `localConfidence` 和 `novelty` 选择策略，
当 `localConfidence < 0.5` 时先命中 `'compete'`（line 683），而非 `'buddyLM_chat'`。
`'compete'` 设置 `includeLLM: true`，但外部 LLM 不存在。

```
coordinator.ts:683  localConfidence(0.42) < lowConfidence(0.5)
                    → 返回 'compete' (includeLLM=true)
                    → 期望外部 LLM
                    → 不存在
```

**修复**：无外部 LLM + 有 BuddyLM 时，集成系统是唯一路径。
coordinator 不再把 assembly 和 BuddyLM 当成可独立竞争的组件。

### 断层 3：裁决无回退到集成结果

**现象**：assembly+BuddyLM 在并行执行中产出了结果，但 rule 胜出后结果被丢弃。
rule 失败后走 `executeLocalFallback`，此时 `intuition._hidden`（pooled vector）丢失。

**根因**：
1. 裁决器选了 rule（score=0.990）> assembly（0.555），但 rule 需要外部 LLM
2. rule 失败后没有回退到裁决排名中的次优方案
3. `executeLocalFallback` 用 `generateLocal()`（模板填充），不是 BuddyLM
4. `executeAssemblyWithBuddyLM(content, undefined)` — pooled vector 丢失

```
brain.ts:1312  裁决: rule=0.990 > assembly=0.555
               → rule 胜出，assembly 结果丢弃
agent.ts:496   executeByPlan(plan) → executeLocalFallback()
               → generateLocal() → 模板置信度=0.20 → 失败
               → executeAssemblyWithBuddyLM(content, undefined) → pooled 丢失
```

**修复**：
1. 裁决失败后回退到集成结果（已计算的 assembly+BuddyLM 输出）
2. `executeLocalFallback` 传递 `intuition._hidden` 给组装引擎
3. 无外部 LLM 时，rule 路径不应产生需要 LLM 的计划

### 断层 4：搜索源查询依赖全局状态

**现象**：web 检索源用 `this.lastUserInput`（全局变量）获取查询文本，而非从 `queryVec` 还原。

**根因**：组装引擎的 `retrieve()` 接口只传 `queryVec: Float32Array`，
但 web 源需要文本查询。各源通过闭包捕获 `this.lastUserInput`。

```typescript
// brain.ts:532
const query = this.lastUserInput ?? '';  // 全局状态，可能被覆盖
```

**修复**：`retrieve()` 接口扩展为 `(queryVec, textQuery, topK)`，
将原始文本查询直接传入检索源，不依赖全局状态。

---

## 重构方案

### Phase 1：集成 LLM 统一入口

**目标**：assembly + BuddyLM 作为不可分割的整体，成为无外部 LLM 时的唯一执行路径。

#### 1.1 新增 `IntegratedLLM` 执行器

```typescript
// brain/integrated-llm.ts
export class IntegratedLLM {
  constructor(
    private right: RightBrain,
    private apiGateway: APIGateway | null,
    private stmp: STMPStore | null,
  ) {}

  /**
   * 统一执行入口 — 组装引擎检索 + BuddyLM 生成 + 质量迭代
   *
   * 这是无外部 LLM 时的唯一路径，不是可选策略。
   */
  async execute(
    input: string,
    pooled: Float32Array,       // ByteEncoder 输出，不可丢
    context: { intent?: string; taskType?: string },
    options?: { maxIterations?: number; qualityThreshold?: number },
  ): Promise<IntegratedResult> {
    // 1. API Gateway 预检索（天气/金融/新闻等结构化数据）
    const apiContext = await this.prefetchAPI(input);

    // 2. 组装引擎：多源检索 + 内容选择 + 骨架组装
    //    搜索源作为一等公民，文本查询直接传入
    const assemblyResult = await this.right.processWithAssembly(
      input, pooled, { ...context, apiContext },
    );

    // 3. BuddyLM：CCA 条件化生成（骨架 → 自然语言）
    //    组装引擎的检索结果作为 BuddyLM 的燃料
    const integrated = await this.right.executeAssemblyWithBuddyLM(
      input, pooled, context, options,
    );

    // 4. 质量保底：如果集成结果质量太低，用 API 结果增强
    if (integrated.confidence < 0.3 && apiContext) {
      return this.enrichWithAPI(integrated, apiContext);
    }

    return integrated;
  }

  /**
   * 判断是否应该使用集成 LLM（而非外部 LLM）
   */
  static shouldUse(hasExternalLLM: boolean, hasBuddyLM: boolean): boolean {
    return !hasExternalLLM && hasBuddyLM;
  }
}
```

#### 1.2 Coordinator 改造

```typescript
// coordinator.ts — analyze() 改造

// 无外部 LLM + 有 BuddyLM → 集成系统是唯一路径
if (!hasExternalLLM && hasBuddyLM) {
  return {
    name: 'integrated_llm',
    parallelLocal: true,
    includeLLM: false,    // 不期望外部 LLM
    llmPrimary: false,
    reason: `集成LLM: confidence=${localConfidence.toFixed(2)}, novelty=${novelty.toFixed(2)}`,
    minConfidence: 0.2,
    useWorldModel: true,
    generators: [
      { name: 'assembly', role: 'primary', portion: 'factual' },
      { name: 'buddyLM', role: 'primary', portion: 'conversational' },
    ],
    assembly: 'merge',
  };
}
```

#### 1.3 Brain.decide() 改造

```typescript
// brain.ts — decide() 改造

// ResourceHub 冷启动：本地资源直接激活
// (在 scanAndRegister 后，将 buddyLM/assembly/experience/rule 标记为 active)

// v3.0 BlendBrain 路径（正常走）

// 回退路径改造：无外部 LLM 时，不再走 compete/llm_primary
// coordinator.analyze() 已返回 'integrated_llm'
// → 并行执行方案B（assembly+BuddyLM 作为主路径）
// → 裁决仍然运行（记录 Thompson Sampling），但集成结果优先
```

### Phase 2：搜索源管线打通

**目标**：搜索源作为燃料，必须及时、准确、不依赖全局状态。

#### 2.1 retrieve() 接口扩展

```typescript
// integration-engine.ts

// 旧接口
private async retrieve(queryVec: Float32Array, lightweight?: boolean): Promise<CandidateFragment[]>;

// 新接口：增加 textQuery 参数
private async retrieve(queryVec: Float32Array, textQuery: string, lightweight?: boolean): Promise<CandidateFragment[]>;
```

#### 2.2 检索源接口统一

```typescript
// 统一检索源接口：同时接收向量和文本
type RetrieverFn = (
  queryVec: Float32Array,
  textQuery: string,
  topK: number,
) => CandidateFragment[] | Promise<CandidateFragment[]>;
```

#### 2.3 Web 源改造

```typescript
// brain.ts — registerWebProviders()

// 旧：闭包捕获 lastUserInput
const query = this.lastUserInput ?? '';

// 新：从 textQuery 参数获取
this.right.registerAssemblySource('web_duckduckgo', async (queryVec, textQuery, topK) => {
  if (!textQuery) return [];
  return await provider.search(textQuery, topK);
});
```

#### 2.4 意图路由增强

```typescript
// 当前：每个 web 源独立判断意图 → 可能全部跳过
// 改造：统一意图路由，在 retrieve() 层面决定查询哪些源

private async retrieve(queryVec: Float32Array, textQuery: string): Promise<CandidateFragment[]> {
  const intent = classifyQueryIntent(textQuery);
  const selectedProviders = routeProviders(intent, this.webProviders);

  // 只查询匹配意图的源 + 本地源（始终查询）
  const localEntries = [...this.retrievalSources.entries()].filter(([k]) => !k.startsWith('web_'));
  const webEntries = [...this.retrievalSources.entries()].filter(([k]) =>
    k.startsWith('web_') && selectedProviders.some(p => `web_${p.id}` === k)
  );

  const allEntries = [...localEntries, ...webEntries];
  // ... 并行查询
}
```

### Phase 3：裁决回退机制

**目标**：当选中路径失败时，回退到已计算的集成结果，而非重新执行。

#### 3.1 保存并行执行结果

```typescript
// brain.ts — decide()

// 并行执行后，保存所有结果
const allResults = {
  rule: scoredPlans,
  integrated: integratedProposal,  // assembly+BuddyLM 结果
  intuition: intuitionProposal,
};

// 裁决后，如果选中的路径失败，回退到 integrated
this.lastAllResults = allResults;
```

#### 3.2 Agent 回退链改造

```typescript
// agent.ts — 主执行流程

// 旧：rule 失败 → executeLocalFallback（丢失上下文）
// 新：rule 失败 → 回退到已计算的集成结果

if (plan失败 && this.lastAllResults?.integrated) {
  // 直接使用已计算的集成结果
  result = {
    text: this.lastAllResults.integrated.text,
    source: 'integrated_fallback',
    toolCalls: [],
  };
} else {
  // 兜底：重新执行集成系统
  result = await this.executeIntegratedFallback(content, intuition);
}
```

### Phase 4：质量保底

**目标**：集成系统必须保质保量，即使搜索源返回空结果。

#### 4.1 搜索源空结果处理

```typescript
// integration-engine.ts — processSingle()

const candidates = await this.retrieve(queryVec, textQuery);

if (candidates.length === 0) {
  // 无搜索结果 → 用 BuddyLM 的内部知识生成
  // 不返回空，而是让 BuddyLM 基于训练数据回答
  return this.generateFromInternalKnowledge(input, queryVec);
}
```

#### 4.2 质量阈值调整

```typescript
// assembly-bridge.ts — executeIntegrated()

// 当前：assemblyConfidence <= 0.1 时直接返回骨架
// 改造：assemblyConfidence 低时，让 BuddyLM 更激进地重写

if (assemblyConfidence <= 0.1) {
  // 骨架质量太低 → BuddyLM 全权处理
  maxTokens = 200;  // 更多 token
  temperature = 0.9; // 更高创造性
}
```

#### 4.3 Self-RAG 迭代增强

```typescript
// 当前：质量不达标 → 迭代重检索+重生成
// 改造：迭代时注入检索失败信息，让 BuddyLM 知道哪些信息缺失

if (genQuality < qualityThreshold) {
  // 告诉 BuddyLM 哪些检索源没有返回结果
  const missingSources = this.identifyMissingSources(trace);
  buddyContext.missingInfo = missingSources;
  // BuddyLM 可以基于内部知识补充
}
```

---

## 改动范围

| 文件 | 改动类型 | 描述 |
|------|---------|------|
| `src/brain/hub/resource-hub.ts` | 修改 | `scanAndRegister` 后本地资源标记为 `'active'` |
| `src/brain/dispatch/coordinator.ts` | 修改 | 无外部 LLM 时返回 `'integrated_llm'` 策略 |
| `src/brain/brain.ts` | 修改 | 集成 LLM 统一入口 + retrieve 接口扩展 + 裁决回退 |
| `src/brain/right/features/integration-engine.ts` | 修改 | `retrieve()` 增加 `textQuery` 参数 |
| `src/brain/right/features/assembly-bridge.ts` | 修改 | 传递 `textQuery` 到 retrieve |
| `src/brain/right/index.ts` | 修改 | `processWithAssembly` 传递文本查询 |
| `src/core/agent.ts` | 修改 | 裁决失败回退到集成结果 |
| `src/core/plan-executor.ts` | 修改 | `executeLocalFallback` 使用集成系统 |
| `src/brain/integrated-llm.ts` | 新增 | 集成 LLM 统一执行器 |
| `src/search/providers/*.ts` | 修改 | 接收 `textQuery` 参数而非全局状态 |

---

## 验证方案

1. **冷启动测试**：清除所有持久化数据，发送第一条消息，验证集成路径被触发
2. **搜索源测试**：发送需要外部知识的问题（如"豆腐的制作过程"），验证 web 源返回结果
3. **质量测试**：对比重构前后的回复质量（长度、相关性、流畅度）
4. **回退测试**：模拟搜索源全部失败，验证 BuddyLM 内部知识兜底
5. **性能测试**：测量端到端延迟，确保不超过 15 秒

---

## 执行顺序

1. Phase 1（集成 LLM 统一入口）— 解决核心范式问题
2. Phase 2（搜索源管线打通）— 解决燃料供给问题
3. Phase 3（裁决回退机制）— 解决容错问题
4. Phase 4（质量保底）— 解决质量问题

每个 Phase 完成后推送 GitHub，可独立验证。
