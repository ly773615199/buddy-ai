# 组装引擎 × BuddyLM 解绑架构 v2

> **目标**: 彻底解绑组装引擎和 BuddyLM，通过 Brain 上层编排实现语义级协作，而非微观层硬编码耦合。
>
> **核心原则**: 组装引擎传递的是**语义共享信息增强**（ByteEncoder 128 维空间中的向量信号），不是物理文字。
>
> **创建日期**: 2026-05-21
> **重写日期**: 2026-05-27 — 基于代码审计，彻底解耦
> **关联文档**: ARCHITECTURE_ROADMAP.md

---

## 1. 问题诊断

### 1.1 当前耦合点（代码审计结果）

通过分析以下文件，定位了 3 处硬编码耦合：

| 文件 | 耦合代码 | 问题 |
|------|---------|------|
| `assembly-bridge.ts:421-424` | `this.buddyLm.encodeFragments(fragmentTexts)` | 组装引擎的**物理文字**被灌入 BuddyLM Encoder → CCA K/V |
| `assembly-bridge.ts:440-452` | `this.buddyLm.generateWithContext(pooled, { knowledge: fragmentTexts })` | 物理文字被编码后注入 pooled vector |
| `assembly-bridge.ts:566-591` | `executeBuddyLMDriven` 中同样的 `encodeFragments` + `generateWithContext` | 重复耦合 |
| `brain.ts:1267-1330` | `executeCognitiveLoop` / `executeBuddyLMDriven` / `executeAssemblyWithBuddyLM` | Brain 把两者当绑定单元调用 |
| `right/index.ts:225` | `this.assemblyBridge.setBuddyLM(this.buddyLm)` | 构造时直接注入 BuddyLM 实例 |

**根本问题**: 组装引擎直接持有 BuddyLM 引用，绕过了 Brain 编排层，在微观层把两个模块绑死。

### 1.2 这种耦合为什么是错的

```
当前: 组装引擎 → 拿物理文字 → 调 BuddyLM 内部 API → 注入 CCA
      (组装引擎在操控 BuddyLM 的内部注意力机制)

正确: 组装引擎 → 独立产出内容
      BuddyLM  → 独立产出内容（CCA 是自己的上下文机制）
      Brain    → 语义级编排（传语义信号，不传物理文字）
```

**CCA 是 BuddyLM 自己的上下文注意力机制**，用于 BuddyLM 内部检索自己的知识（对话历史、内部记忆、上下文窗口），不是给组装引擎当管道的。

**MoE 是 BuddyLM 自己的任务路由机制**，8 个专家（code/chat/knowledge/creative/reasoning/tool/summary/general）根据输入自动路由，与组装引擎无关。

---

## 2. 正确架构：完全解绑

### 2.1 三大模块独立

```
┌─────────────────────────────────────────────────────────────────┐
│                         Brain (上层编排)                          │
│                                                                   │
│  语义信号传递:                                                     │
│    intent: string         — 意图分类 (ByteEncoder 空间)           │
│    topicVec: Float32Array — 语义向量 (ByteEncoder 128 维)         │
│    quality: number        — 质量分数 (0-1)                        │
│    taskType: string       — 任务类型                              │
│    assemblyConfidence: number — 组装置信度                        │
│                                                                   │
│  不传递:                                                           │
│    ✗ 物理文字 (fragmentTexts)                                     │
│    ✗ 骨架文本 (skeleton)                                          │
│    ✗ 检索片段 (SelectedFragment[])                                │
└────────────┬──────────────────────────────────┬──────────────────┘
             │ 语义信号                          │ 语义信号
             ▼                                   ▼
┌─────────────────────────┐          ┌─────────────────────────────┐
│    组装引擎 (独立)        │          │    BuddyLM (独立)            │
│                          │          │                              │
│  ByteEncoder 编码查询    │          │  Encoder (冻结, ByteEncoder) │
│  多源向量检索             │          │  Decoder (CCA + MoE + FFN)   │
│  ContentSelector 排序    │          │    CCA: 自己的上下文机制       │
│  FragmentExtractor 提取  │          │    MoE: 自己的任务路由         │
│  骨架组装 + 连接词       │          │    Cross-Attn: Encoder 输出   │
│  输出: 文本 + 置信度     │          │  BBPE Tokenizer              │
│                          │          │  输出: 文本 + 置信度          │
│  不依赖 BuddyLM          │          │  不依赖组装引擎               │
└─────────────────────────┘          └─────────────────────────────┘
```

### 2.2 语义共享空间

组装引擎和 BuddyLM 共享 **ByteEncoder 的 128 维语义空间**，但各自独立使用：

| 模块 | 如何使用 ByteEncoder 空间 |
|------|--------------------------|
| **组装引擎** | `byteEncoder.forward(query)` → 128 维查询向量 → 用于向量检索 |
| **BuddyLM** | `encoder.forward(input)` → 128 维 hidden states → 用于 Decoder 生成 |
| **Brain** | 传递 `pooled: Float32Array` (128 维) 作为语义信号 |

**关键**: 两者用的是**同一个 ByteEncoder**，所以向量在同一空间中可比较，但**不需要互相传递物理内容**。

### 2.3 Brain 编排信号

Brain 在上层决定如何组合两个模块的输出，传递的信号是：

```typescript
interface SemanticSignal {
  /** ByteEncoder 编码的语义向量 (128 维) — 共享空间 */
  pooled: Float32Array;
  /** 意图分类 — 来自 IntuitionNet */
  intent?: string;
  /** 任务类型 — 来自 TaskSignal */
  taskType?: string;
  /** 组装置信度 — 来自 AssemblyBridge */
  assemblyConfidence?: number;
  /** 质量分数 — 来自 quality_head 或评估器 */
  quality?: number;
}
```

**Brain 不传递**: `fragmentTexts`, `skeleton`, `SelectedFragment[]`, `knowledge: string[]`

---

## 3. 模块职责重新划分

### 3.1 组装引擎（纯内容管线）

**职责**: 给定查询，从知识库中检索相关内容并组装成文本。

```
输入: query (string) + pooled (Float32Array, 可选)
  ↓
ByteEncoder 编码查询 → queryVec
  ↓
多源向量检索 (knowledge, prototypes, decision_memory, ...)
  ↓
ContentSelector 排序 + 选择
  ↓
FragmentExtractor 提取 + 骨架组装
  ↓
输出: { text, confidence, trace }
```

**不做的事**:
- 不调用 BuddyLM 的任何 API
- 不 encodeFragments
- 不把自己的输出塞进 BuddyLM 的 CCA
- 不持有 BuddyLM 引用

### 3.2 BuddyLM（纯生成管线）

**职责**: 给定语义信号，自回归生成自然语言文本。

```
输入: pooled (Float32Array) + intent/taskType (可选)
  ↓
Encoder (ByteEncoder) → hidden states
  ↓
Decoder:
  Self-Attention → CCA (自己的上下文) → Cross-Attn (Encoder) → MoE (任务路由)
  ↓
LM Head → token IDs → BBPE 解码 → 文本
  ↓
输出: { text, confidence, tokenIds }
```

**CCA 的正确用途**:
- BuddyLM 自己的上下文窗口（对话历史的 KV cache）
- BuddyLM 自己的内部记忆（如果有 memory 注入机制）
- **不是**组装引擎的检索片段

**MoE 的正确用途**:
- 根据输入自动路由到对应专家
- 8 个专家: code / chat / knowledge / creative / reasoning / tool / summary / general
- taskBias 从 encoder hidden 自动计算，不需要外部注入

**不做的事**:
- 不调用组装引擎的任何 API
- 不 encodeFragments
- 不接受外部物理文字注入 CCA
- 不持有 AssemblyBridge 引用

### 3.3 Brain（语义编排层）

**职责**: 根据场景决定使用哪个模块，如何组合结果。

```
输入: signal + intuition + bodyState
  ↓
Coordinator 分析 → 策略选择
  ↓
┌─ 策略 A: 只用组装引擎 → 直接返回
├─ 策略 B: 只用 BuddyLM → 直接返回
├─ 策略 C: 两者都用 → 并行执行，Arbiter 裁决
├─ 策略 D: 认知循环 → 多轮语义增强
└─ 策略 E: 左脑规则 → 直接返回
```

**传递语义信号**，不传递物理文字。

---

## 4. 代码改动

### 4.1 删除 AssemblyBridge 对 BuddyLM 的直接引用

```diff
// src/brain/right/features/assembly-bridge.ts

export class AssemblyBridge {
  private engine: InformationIntegrationEngine;
  private generator: StructuredGenerator;
- private buddyLm: BuddyLM | null = null;
  // ... 其他字段不变

- setBuddyLM(buddyLm: BuddyLM | null): void {
-   this.buddyLm = buddyLm;
- }

  // executeIntegrated — 删除整个方法
- async executeIntegrated(...) { ... }

  // executeBuddyLMDriven — 删除整个方法
- async executeBuddyLMDriven(...) { ... }

  // 保留: process(), executeRaw(), evaluateAssemblyConfidence()
  // 这些是纯组装引擎逻辑，不依赖 BuddyLM
}
```

### 4.2 删除 RightBrain 的集成方法

```diff
// src/brain/right/index.ts

  constructor(...) {
-   // 删除: this.assemblyBridge.setBuddyLM(this.buddyLm)
  }

- async executeAssemblyWithBuddyLM(...) { ... }
- async executeBuddyLMDriven(...) { ... }
- async executeCognitiveLoop(...) { ... }

  // 保留: processWithAssembly() — 纯组装引擎执行
  // 保留: executeBuddyLM() — 纯 BuddyLM 执行
```

### 4.3 Brain 编排改为并行 + 裁决

```diff
// src/brain/brain.ts — Step 3

- if (strategy.name === 'cognitive' && hasAssembly && hasBuddyLM) {
-   // 认知循环 (删除)
- } else if (hasAssembly && hasBuddyLM && this.shouldBuddyLMDrive(...)) {
-   // BuddyLM 主导 (删除)
- } else if (hasAssembly && hasBuddyLM) {
-   // 一体化 (删除)
- } else if (hasAssembly) {
+ if (hasAssembly) {
    // 组装引擎独立执行
    parallelTasks.push(
      this.processWithAssemblyCompetitive(input, intuition, signal)
        .then(r => ({ ...r, source: 'assembly' as const })),
    );
  }
  if (hasBuddyLM) {
    // BuddyLM 独立执行
    parallelTasks.push(
      this.right.executeBuddyLM(input, intuition?._hidden, {
        userInput: input,
        intent: signal.domains[0],
        taskType: signal.taskType,
        timestamp: Date.now(),
      }).then(r => ({
        text: r.text,
        confidence: r.confidence,
        source: 'buddyLM' as const,
        path: 'buddyLM' as const,
      })),
    );
  }

  // Step 3.5: Arbiter 裁决（已有逻辑，不变）
  const arbitration = this.arbiter.arbitrate(...);
```

### 4.4 认知循环改为 Brain 层语义增强（可选）

如果需要"多轮精化"能力，应在 Brain 层实现，不绑死在 AssemblyBridge 中：

```typescript
// src/brain/brain.ts — 新增语义增强路径

/**
 * 语义增强循环 — Brain 层编排
 *
 * 组装引擎和 BuddyLM 独立执行，Brain 用语义信号增强查询。
 * 不传递物理文字，只传递 pooled vector + intent + quality。
 */
private async executeSemanticEnhancement(
  input: string,
  pooled: Float32Array,
  signal: TaskSignal,
): Promise<{ text: string; confidence: number; path: string }> {
  const maxIterations = 3;
  const qualityThreshold = 0.7;

  let currentPooled = pooled;
  let bestResult = { text: '', confidence: 0, path: '' };

  for (let i = 0; i < maxIterations; i++) {
    // 组装引擎: 用语义向量检索
    const assemblyResult = await this.right.processWithAssembly(
      input, currentPooled, { intent: signal.domains[0] },
    );

    // BuddyLM: 用语义向量生成
    const buddyResult = await this.right.executeBuddyLM(
      input, currentPooled, {
        userInput: input,
        intent: signal.domains[0],
        taskType: signal.taskType,
      },
    );

    // 质量评估 (用语义信号，不用物理文字)
    const assemblyQ = assemblyResult.confidence;
    const buddyQ = buddyResult.confidence;

    // 选更好的
    const winner = assemblyQ >= buddyQ
      ? { text: assemblyResult.text, confidence: assemblyQ, path: 'assembly' }
      : { text: buddyResult.text, confidence: buddyQ, path: 'buddyLM' };

    if (winner.confidence > bestResult.confidence) {
      bestResult = winner;
    }

    // 质量达标 → 退出
    if (winner.confidence >= qualityThreshold) break;

    // 增强下一轮的语义向量 (不传物理文字)
    currentPooled = this.enhancePooled(currentPooled, winner.confidence);
  }

  return bestResult;
}
```

---

## 5. CCA 和 MoE 的正确用途

### 5.1 CCA (Chunked Cross-Attention)

**当前错误用途**: 接收组装引擎的 `encodeFragments()` 输出作为 K/V。

**正确用途**: BuddyLM 自己的内部上下文机制。

```
CCA 的 K/V 来源:
  1. 对话历史 — 前几轮的 Decoder hidden states (KV Cache)
  2. 内部记忆 — 如果有 memory injection, 用 ByteEncoder 编码后注入
  3. 长文本上下文 — 当前对话的完整 context window

CCA 不应该:
  ✗ 接收组装引擎的检索片段
  ✗ 接收外部 encodeFragments() 的输出
  ✗ 作为组装引擎和 BuddyLM 之间的管道
```

**代码改动**: `BuddyLMDecoder.generate()` 和 `prefill()` 中的 `retrievedChunks` 参数标记为内部用途，不从外部传入。

```diff
// src/brain/right/nn/decoder.ts

  prefill(
    encoderHidden: Tensor,
    inputTokenIds: number[],
-   retrievedChunks?: Tensor,
    taskBias?: Float32Array,
  ): Float32Array {
    // CCA 用自己的 KV Cache，不从外部注入
  }

  generate(
    encoderHidden: Tensor,
    startTokenId: number,
    maxTokens = 100,
    temperature = 0.8,
-   retrievedChunks?: Tensor,
    taskBias?: Float32Array,
  ): GenerateResult {
    // 同上
  }
```

### 5.2 MoE (Mixture of Experts)

**当前状态**: 基本正确，taskBias 从 encoder hidden 自动计算。

**保持不变**: MoE Router 根据输入自动路由，8 个专家各司其职。

**删除**: `getExpertPreference(taskType, intent)` 外部 bias 注入 — 让 MoE 自己学。

```diff
// src/brain/right/nn/decoder.ts

  // 保留: computeTaskBias(encoderHidden) — 从 encoder hidden 自动计算
  // 删除: 外部 taskBias 参数传入
```

### 5.3 新增: BuddyLM 内部知识检索（可选，未来）

如果 BuddyLM 需要检索自己的知识（不是组装引擎的知识），可以在 BuddyLM 内部实现：

```typescript
// 未来的 BuddyLM 内部机制 — 不依赖组装引擎
class BuddyLMKnowledgeIndex {
  // BuddyLM 自己的知识库
  // 用 ByteEncoder 编码，向量检索
  // 结果注入 CCA 作为 K/V
  // 完全独立于组装引擎
}
```

---

## 6. 文件改动清单

### 删除（解耦）

| 文件 | 改动 | 原因 |
|------|------|------|
| `assembly-bridge.ts` | 删除 `setBuddyLM()`, `executeIntegrated()`, `executeBuddyLMDriven()` | 组装引擎不应持有 BuddyLM 引用 |
| `right/index.ts` | 删除 `executeAssemblyWithBuddyLM()`, `executeBuddyLMDriven()`, `executeCognitiveLoop()`, 构造函数中的 `setBuddyLM()` | RightBrain 不应做集成编排 |
| `brain.ts` | 删除 `shouldBuddyLMDrive()`, 简化 Step 3 为并行 + 裁决 | Brain 层做编排，不绑死路径 |
| `decoder.ts` | `retrievedChunks` 参数标记 deprecated，内部不再从外部传入 | CCA 是内部机制 |
| `buddy-lm.ts` | `encodeFragments()` 标记 deprecated，`generateWithContext()` 删除 `retrievedChunks` 参数 | 不接受外部物理文字注入 |
| `BUDDYLM_DESIGN.md` | 更新: 删除"AssemblyBridge 集成"章节 | 文档与代码一致 |
| `docs/BUDDYLM_PROGRESS.md` | 更新: 删除"一体化"相关任务 | 文档与代码一致 |

### 保留（不改）

| 文件 | 说明 |
|------|------|
| `decoder.ts` CCA 实现 | 保留，CCA 作为 BuddyLM 内部机制 |
| `decoder.ts` MoE 实现 | 保留，MoE 是 BuddyLM 内部路由 |
| `chunked-cross-attention.ts` | 保留，CCA 层本身没问题 |
| `assembly-bridge.ts` `process()` / `executeRaw()` | 保留，纯组装逻辑 |
| `brain.ts` Step 3.5 Arbiter | 保留，裁决机制不变 |

### 新增（可选）

| 文件 | 说明 | 优先级 |
|------|------|--------|
| `brain.ts` `executeSemanticEnhancement()` | Brain 层语义增强循环（传语义信号，不传文字） | P2 |
| `buddy-lm.ts` `BuddyLMKnowledgeIndex` | BuddyLM 内部知识检索（独立于组装引擎） | P3 |

---

## 7. 理论支撑

### 7.1 为什么要解绑

| 维度 | 绑定架构 | 解绑架构 |
|------|---------|---------|
| 模块独立性 | 组装引擎依赖 BuddyLM，BuddyLM 依赖组装引擎 | 各自独立，可单独测试/部署/替换 |
| 语义空间 | 组装引擎的物理文字硬编码注入 CCA | 共享 ByteEncoder 空间，语义信号传递 |
| CCA 职责 | 混淆：既是内部上下文又是外部检索管道 | 清晰：CCA 是 BuddyLM 自己的机制 |
| MoE 职责 | 外部 taskBias 注入干扰路由 | MoE 自主路由，从 encoder hidden 学习 |
| 可扩展性 | 加新模块需要修改 AssemblyBridge | 加新模块只需在 Brain 层添加策略 |
| 测试复杂度 | 集成测试需要同时启动两个模块 | 单元测试各模块独立 |

### 7.2 学术参考

| 论文 | 启示 |
|------|------|
| **REALM** (Google, 2020) | 检索和生成可以共享语义空间，但不需要物理内容传递 |
| **RETRO** (DeepMind, 2022) | CCA 是模型内部机制，K/V 来自模型自己的编码器 |
| **Self-RAG** (ICLR 2024) | 模型自主决定何时检索，不依赖外部硬编码注入 |
| **MoE** (Shazeer, 2017) | 专家路由是模型内部机制，不应被外部信号覆盖 |

---

## 8. 迁移步骤

### Phase 1: 解耦 AssemblyBridge

1. 从 `AssemblyBridge` 中移除 `buddyLm` 字段和 `setBuddyLM()` 方法
2. 删除 `executeIntegrated()` 和 `executeBuddyLMDriven()` 方法
3. 从 `RightBrain` 构造函数中移除 `setBuddyLM()` 调用
4. 从 `RightBrain` 中移除 `executeAssemblyWithBuddyLM()`, `executeBuddyLMDriven()`, `executeCognitiveLoop()`
5. 测试: `process()` 和 `executeRaw()` 仍然正常工作

### Phase 2: 简化 Brain 编排

1. 删除 `brain.ts` 中的 `shouldBuddyLMDrive()` 方法
2. 简化 Step 3: 组装引擎和 BuddyLM 并行执行，Arbiter 裁决
3. 删除认知循环/一体化/BuddyLM主导的特殊路径
4. 测试: 所有策略路径正常工作

### Phase 3: 清理 BuddyLM 外部接口

1. `decoder.ts`: `retrievedChunks` 参数标记 `@deprecated`
2. `buddy-lm.ts`: `encodeFragments()` 标记 `@deprecated`
3. `buddy-lm.ts`: `generateWithContext()` 移除 `retrievedChunks` 参数
4. 更新 `BUDDYLM_DESIGN.md` 和 `BUDDYLM_PROGRESS.md`

### Phase 4: 可选 — Brain 层语义增强

1. 在 `brain.ts` 中实现 `executeSemanticEnhancement()`
2. 用语义信号（pooled vector + intent）增强查询
3. 不传递物理文字

---

## 9. 验证清单

- [ ] `AssemblyBridge` 不再 import `BuddyLM` 类型
- [ ] `AssemblyBridge.process()` 和 `executeRaw()` 正常工作（纯组装）
- [ ] `RightBrain.executeBuddyLM()` 正常工作（纯生成）
- [ ] `Brain.decide()` 中组装引擎和 BuddyLM 并行执行
- [ ] Arbiter 正常裁决两个独立提案
- [ ] CCA 不从外部接收 `retrievedChunks`
- [ ] MoE 的 `taskBias` 从 encoder hidden 自动计算，不从外部注入
- [ ] 所有现有测试通过
- [ ] 无循环依赖（AssemblyBridge → BuddyLM, BuddyLM → AssemblyBridge）

---

## 10. 参考文献

1. **Kahneman, D.** (2011). *Thinking, Fast and Slow*. — 双系统：独立运作，上层协调
2. **Guu, K. et al.** (2020). *REALM*. ICML 2020. arXiv:2002.08909 — 共享语义空间不需要物理内容传递
3. **Borgeaud, S. et al.** (2022). *RETRO*. arXiv:2112.04426 — CCA 是模型内部机制
4. **Asai, A. et al.** (2024). *Self-RAG*. ICLR 2024. arXiv:2310.11511 — 模型自主检索决策
5. **Shazeer, N. et al.** (2017). *Outrageously Large Neural Networks: The Sparsely-Gated MoE Layer*. arXiv:1701.06538 — MoE 是模型内部路由
