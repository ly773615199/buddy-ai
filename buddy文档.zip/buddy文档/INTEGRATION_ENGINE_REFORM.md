# 信息整合引擎改造方案 — 接入项目已有能力

> 日期: 2026-05-15
> 目标: 把信息整合引擎从"独立模块"变为"三脑协作的一部分"
> 原则: 不新建平行系统，延伸已有模块的思维到组装层

---

## 一、改造总览

```
改造前:
  信息整合引擎 = quickEmbed(hash) + 独立 one-pass 组装
  与主管线断开，自己玩自己的

改造后:
  信息整合引擎 = ByteEncoder(端到端学习) + ReasoningHead(多步推理驱动) 
               + 审议委员会(追问注入) + BodyState(任务上下文)
               + 原型记忆层(风格学习) + 问题分解
  嵌入三脑协作，共享已有能力
```

---

## 二、ByteEncoder 接入（替换 quickEmbed）

### 2.1 现状

```typescript
// integration-engine.ts 当前的编码 —— hash 伪编码
function quickEmbed(text: string, dim = 128): Float32Array {
  const v = new Float32Array(dim);
  let hash = 0x811c_9dc5;
  for (let i = 0; i < text.length; i++) {
    hash ^= text.charCodeAt(i);
    hash = (hash * 16777619) >>> 0;
    v[i % dim] += ((hash & 0xff) / 127.5 - 1);
  }
  return l2Normalize(v);
}
```

### 2.2 改造

```typescript
// 改造后 —— 接入项目的 ByteEncoder 单例
import { getByteEncoder } from './text-encoder.js';

export class InformationIntegrationEngine {
  private byteEncoder: ByteEncoder;

  constructor(config?: Partial<EngineConfig>) {
    this.byteEncoder = getByteEncoder(); // 复用项目全局单例
    // ...
  }

  private encode(text: string): Float32Array {
    return this.byteEncoder.forward(text); // 真正的字节级编码
  }
}
```

### 2.3 影响范围

| 组件 | 当前 | 改后 |
|------|------|------|
| `InformationIntegrationEngine.process()` | `quickEmbed(input)` | `this.byteEncoder.forward(input)` |
| `AssemblyBridge` | 自己也有 `quickEmbed` | 删除，用引擎的编码 |
| 检索源注册 | 传入 `Float32Array` | 不变，接口兼容 |

### 2.4 关键点

- ByteEncoder 已经在 `RightBrain` 中初始化，是全局单例
- 它会随 OnlineLearner 端到端学习，信息整合引擎的编码质量会随交互积累提升
- `getByteEncoder()` 是现成的工厂方法，直接调用
- 不需要额外训练——它已经在主管线里学了

---

## 三、ReasoningHead 驱动组装（替代 one-pass）

### 3.1 现状

```
信息整合引擎: 输入 → 检索 → 选择 → 组装 → 输出 (one-pass)
ReasoningHead: 输入 → 5步推理 → 输出 (独立，不与引擎交互)
```

### 3.2 改造

```
信息整合引擎: 输入 → ByteEncoder → 推理循环 → 组装 → 输出
                              ↑
                    ReasoningHead 每步输出驱动组装
```

核心改变：`InformationIntegrationEngine.process()` 内部改为迭代式：

```typescript
process(input: string): { output: string; trace: PipelineTrace } {
  const queryVec = this.byteEncoder.forward(input);
  
  // Phase 1: 用 ReasoningHead 做多步推理
  const reasoningSteps = this.reason(queryVec);
  
  // Phase 2: 每步推理结果作为组装片段
  const fragments = reasoningSteps.map(step => ({
    content: step.summary,
    role: step.role, // 'problem' | 'cause' | 'solution' | 'detail'
    relevance: step.confidence,
    source: 'reasoning' as const,
  }));
  
  // Phase 3: 补充检索结果
  const retrieved = this.retrieve(queryVec);
  fragments.push(...this.contentSelector.select(input, retrieved));
  
  // Phase 4: 逻辑排序 + 组装
  const ordered = this.discourseChain.order(fragments);
  return this.assemble(input, ordered);
}
```

### 3.3 ReasoningHead 接口适配

ReasoningHead 当前输出 `ReasoningResult`，包含 `steps[]`，每步有 `vector` 和 `confidence`。需要增加一个轻量适配层：

```typescript
interface ReasoningFragment {
  summary: string;    // 从推理向量中提取的摘要
  role: string;       // 推断的逻辑角色
  confidence: number; // 步骤置信度
  stepIndex: number;
}
```

摘要提取方式：
- 如果有 KnowledgeGate 中的知识匹配 → 用匹配的知识条目文本
- 如果有原型记忆匹配 → 用原型标签
- 降级 → 用向量的 top-K 维度作为关键词标签

---

## 四、审议委员会追问注入（替代"需要更多信息"死胡同）

### 4.1 现状

```
信息整合引擎: 检索为空 → "需要更多信息" → 结束
审议委员会: ambiguity > 0.5 → 生成追问 → 返回给用户
```

两个模块各自做模糊度检测，不共享。

### 4.2 改造

```typescript
process(input: string): { output: string; trace: PipelineTrace } {
  // ... 检索阶段 ...
  
  if (candidates.length === 0 || assemblyConfidence < 0.3) {
    // 不再返回"需要更多信息"，而是生成结构化追问
    const clarification = this.generateClarification(input, candidates);
    return { output: clarification, trace: { ... } };
  }
}

private generateClarification(input: string, partialCandidates: CandidateFragment[]): string {
  // 1. 提取输入中的关键词
  const keywords = this.extractKeywords(input);
  
  // 2. 检测缺失维度：what/why/how/where/when
  const missing = this.detectMissingDimensions(input, keywords);
  
  // 3. 用骨架模板生成追问
  const template = this.skeleton.selectSkeleton('clarify', 'simple');
  return this.skeleton.fillMultiSentence(template, {
    topic: keywords.join('、'),
    questions: missing.map(m => this.dimensionToQuestion(m)).join('；'),
  }).sentences.map(s => s.text).join('');
}
```

### 4.3 与审议委员会的关系

不重复建设。信息引擎的追问是**轻量级**的——只在组装层做关键词提取 + 模板追问。审议委员会的追问是**重量级**的——有角色讨论、多轮辩论。

触发路径：
- 简单任务 → 信息引擎自己追问（Clarifier 模式）
- 复杂任务 → 审议委员会接管追问

---

## 五、BodyStateManager 增加任务上下文（WritingContext）

### 5.1 现状

BodyState 维护情绪/欲望/能量/专注度，但不知道"当前在做什么任务"。

### 5.2 改造

在 `BodyState` 类型中增加任务上下文：

```typescript
interface TaskContext {
  /** 当前任务主题（从输入中提取的关键词） */
  currentTopic: string[];
  /** 最近 N 步输出的关键词（滑动窗口） */
  recentKeywords: string[];  // 最多保留 20 个
  /** 输出历史摘要（最近 5 步） */
  outputHistory: string[];   // 每步取前 50 字
  /** 大纲结构（如果有的话） */
  outline: string[];
  /** 大纲当前进度 */
  outlineProgress: number;   // 0-1
}
```

### 5.3 更新时机

```typescript
// ThreeBrain.feedback() 中更新
feedback(outcome, actualOutput) {
  // 已有的反馈逻辑...
  
  // 更新任务上下文
  this.cerebellum.bodyState.updateTaskContext({
    topic: this.extractKeywords(actualOutput),
    outputSummary: actualOutput.slice(0, 50),
  });
}

// ThreeBrain.decide() 中读取
decide(input, signal, resources) {
  // 已有的决策逻辑...
  
  // 信息引擎可以读取任务上下文
  const taskCtx = this.cerebellum.getBodyState().taskContext;
  // 用 recentKeywords 做上下文感知的检索
  // 用 outputHistory 避免重复
}
```

---

## 六、原型记忆层增加风格学习（StyleLearner）

### 6.1 现状

Prototype 有 `toolDist`（工具偏好）和 `toolSuccess`（工具成功率），但没有表达风格。

### 6.2 改造

```typescript
interface Prototype {
  // ... 现有字段 ...
  
  /** 风格画像 */
  styleProfile?: {
    /** 偏好连接词 → 使用次数 */
    preferredConnectors: Map<string, number>;
    /** 平均句长 */
    avgSentenceLength: number;
    /** 正式度 0-1（0=口语，1=书面） */
    formalityScore: number;
    /** 常用句式模式 */
    sentencePatterns: Map<string, number>; // "因为X所以Y" → 3次
  };
}
```

### 6.3 学习时机

```typescript
// feedback() 中，成功回复时学习风格
if (outcome.success && actualOutput) {
  const protoId = this.findMatchedProtoId(signal, resources);
  if (protoId) {
    this.right.prototypeMemory.updateStyle(protoId, {
      connectors: this.extractConnectors(actualOutput),
      sentenceLength: this.avgSentenceLength(actualOutput),
      formality: this.estimateFormality(actualOutput),
    });
  }
}
```

### 6.4 使用时机

信息整合引擎的 `ConnectorInsertor` 选择连接词时，查原型记忆层的风格画像：

```typescript
// ConnectorInsertor.selectConnector() 改造
selectConnector(relation: string, usedConnectors: Set<string>, styleProfile?: StyleProfile): string {
  const candidates = CONNECTORS[relation];
  
  if (styleProfile) {
    // 优先选用户偏好的连接词
    const preferred = candidates.filter(c => 
      styleProfile.preferredConnectors.has(c) && !usedConnectors.has(c)
    );
    if (preferred.length > 0) return preferred[0];
  }
  
  // 降级：选未使用过的
  return candidates.find(c => !usedConnectors.has(c)) ?? candidates[0];
}
```

---

## 七、问题分解（复用 SwarmManager 思路）

### 7.1 不新建模块

SwarmManager 已经有"并行探索多个方向 → 取最优"的能力。问题分解复用这个思路：

```typescript
// InformationIntegrationEngine 内部
private decompose(input: string, intent: IntentResult): string[] {
  // 关键词分割：检测"并"、"和"、"以及"、"同时"
  const conjunctions = ['并', '和', '以及', '同时', '然后', '接着'];
  for (const conj of conjunctions) {
    if (input.includes(conj)) {
      const parts = input.split(new RegExp(conj)).map(s => s.trim()).filter(Boolean);
      if (parts.length >= 2) return parts;
    }
  }
  
  // 意图分割：检测多意图信号
  if (intent.confidence < 0.5) {
    // 模糊输入，尝试拆分
    return this.splitByIntentKeywords(input);
  }
  
  return [input]; // 无法分解，作为单问题处理
}

process(input: string): { output: string; trace: PipelineTrace } {
  const subProblems = this.decompose(input, intent);
  
  if (subProblems.length > 1) {
    // 子问题独立组装，最后合并
    const subResults = subProblems.map(sp => this.processSingle(sp));
    return this.mergeResults(subResults);
  }
  
  return this.processSingle(input);
}
```

---

## 八、接入主管线

### 8.1 当前断点

```typescript
// brain.ts decide() — 当前走 generateLocal()，绕过组装引擎
if (intuition?._hidden && signal.taskType === 'chat') {
  const genResult = this.right.generateLocal(intuition._hidden, { ... });
  // ...
}
```

### 8.2 改后

```typescript
// brain.ts decide() — 组装引擎优先，generateLocal 降级
if (intuition?._hidden) {
  // 优先：组装引擎（有推理驱动 + 检索 + 风格适配）
  const assemblyResult = this.right.processWithAssembly(
    input, intuition._hidden, {
      userInput: input,
      intent: intuition.intent.category,
      taskType: signal.taskType,
      timestamp: Date.now(),
    }
  );
  
  if (assemblyResult.assemblyConfidence >= 0.6) {
    localGeneration = {
      text: assemblyResult.text,
      confidence: assemblyResult.assemblyConfidence,
      templateId: `assembly_${assemblyResult.path}`,
    };
  } else {
    // 降级：StructuredGenerator
    const genResult = this.right.generateLocal(intuition._hidden, { ... });
    if (genResult.local && genResult.confidence >= 0.6) {
      localGeneration = { ... };
    }
  }
}
```

### 8.3 知识源注册

```typescript
// ThreeBrain 构造函数中，注册知识源到组装引擎
constructor(config) {
  // ... 现有初始化 ...
  
  // 注册知识源
  this.right.registerAssemblySource('knowledge', (query, topK) => {
    const gate = this.right.getKnowledgeGate();
    if (!gate) return [];
    return gate.search(query, topK).map(e => ({
      id: e.id,
      content: e.content,
      score: e.score,
      source: 'knowledge',
    }));
  });
  
  this.right.registerAssemblySource('prototypes', (query, topK) => {
    return this.right.prototypeMemory.search(query, topK).map(m => ({
      id: m.prototype.id,
      content: m.prototype.label,
      score: 1 - m.distance,
      source: 'knowledge',
    }));
  });
}
```

---

## 九、改造顺序

| 步骤 | 内容 | 风险 |
|------|------|------|
| 1 | ByteEncoder 接入（替换 quickEmbed） | 低 — 接口兼容 |
| 2 | 审议追问注入（替代"需要更多信息"） | 低 — 只加不改 |
| 3 | BodyState 任务上下文 | 低 — 扩展类型 |
| 4 | 原型风格学习 | 低 — 扩展 Prototype |
| 5 | ReasoningHead 驱动组装 | 中 — 改造 process() 核心逻辑 |
| 6 | 问题分解 | 中 — 需要与步骤 5 配合 |
| 7 | 接入主管线 | 中 — 改 decide() 流程 |

步骤 1-4 可以并行，互不依赖。步骤 5-7 有依赖关系，需要顺序执行。
