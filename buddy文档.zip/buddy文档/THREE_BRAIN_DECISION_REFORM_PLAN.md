# 三脑决策重构计划 — 神经混合版

> 版本: v3.0
> 日期: 2026-05-22
> 原则: **有什么材料做什么饭菜，能力是动态的，决策不是非黑即白**
> 状态: v2.0 已落地 87%，v3.0 神经混合待启动
> 前置: v2.0 ResourceHub / coordinator / arbiter / rule-engine 已实现
> 研究: FrugalGPT / RouteLLM / RLAE / C2MAB-V / Semantic Router / BEST-Route / NeuralBandit

---

## 零、v2.0 实现审计（v3.0 出发点）

### 已完成（87%）

| 模块 | 文件 | 状态 | 备注 |
|------|------|------|------|
| ResourceHub | `src/brain/hub/resource-hub.ts` | ✅ | ~580 行，register/recordOutcome/decay/recommend |
| Resource 类型 | `src/brain/hub/resource.ts` | ✅ | ~210 行，7 种资源类型 + 生命周期 |
| BlendStrategy 类型 | `src/brain/types.ts` | ✅ | BlendStrategy 接口已定义 |
| coordinator 改造 | `src/brain/dispatch/coordinator.ts` | ✅ | selectBlendStrategy 四场景 |
| arbiter 动态权重 | `src/brain/dispatch/arbiter.ts` | ✅ | dynamicWeights 四种场景 |
| 规则引擎优先 | `src/brain/left/rule-engine.ts` | ✅ | evaluateQuick() 阈值 0.8 |
| brain.ts 协调 | `src/brain/brain.ts` | ✅ | 规则→coordinator→arbiter 流程 |
| 反馈闭环 | `src/brain/brain.ts` | ✅ | recordOutcome 三处调用 + heartbeat decay |
| Thompson Sampling | `src/brain/dispatch/learner.ts` | ✅ | recordGeneratorOutcome + recommendStrategy |
| 测试 | `resource-hub.test.ts` / `coordinator.test.ts` / `arbiter.test.ts` | ✅ | 核心场景覆盖 |

### v2.0 遗留缺陷（v3.0 必须修复）

| # | 缺陷 | 严重度 | 根因 |
|---|------|--------|------|
| D1 | `executeBlendStrategy()` 未落地 | **P0** | brain.ts 仍用 if-else 链，blend 权重不驱动执行 |
| D2 | `blendToDispatch()` 信息损失 | **P0** | R⁵ 权重 → 3 个布尔值，精度归零 |
| D3 | 持久化未接入 | **P1** | exportForPersistence/importFromPersistence 从未调用 |
| D4 | TS 覆盖策略名与权重不一致 | **P1** | name 变了但 blend 权重没跟着变 |
| D5 | 动态权重无测试 | **P2** | arbiter.dynamicWeights 零覆盖 |
| D6 | reflector 未接入 recordOutcome | **P2** | 质量自评未反馈资源画像 |

---

## 一、研究综述

### 1.1 LLM 路由与混合 — 直接相关

| 论文 | 年份 | 核心思想 | 对我们的启发 |
|------|------|---------|-------------|
| **FrugalGPT** (Stanford, arXiv:2305.05176) | 2023 | LLM cascade：便宜模型先试，贵的兜底。98% 成本降低。 | 我们的 cascade 执行模式的理论基础 |
| **RouteLLM** (arXiv:2406.18665) | 2024 | 用偏好数据训练轻量路由器，动态选强/弱模型。2x 成本降低。 | 路由器是二分类器（强 vs 弱），我们需推广到多模型加权混合 |
| **Routoo** (arXiv:2401.13979) | 2024 | 性能预测器 + 成本感知选择器分离。匹配 Mixtral 1/3 成本。 | 预测（ResourceHub）与选择（BlendBrain）分离的架构验证 |
| **RLAE** (arXiv:2506.00439) | 2025 | **RL 动态调整 LLM 集成权重**。MDP 建模，PPO 训练。+3.3% 准确率。 | **最直接相关**：我们的 BlendBrain 就是 RLAE 的在线轻量版 |
| **BEST-Route** (ICML'25, arXiv:2506.22716) | 2025 | 小模型多次采样选最优，比单次大模型更划算。60% 成本降低。 | compete 执行模式的理论基础 |
| **C2MAB-V** (arXiv:2405.16587) | 2024 | 上下文组合多臂老虎机选 LLM。 | Thompson Sampling 在离散策略空间的理论基础 |

### 1.2 连续空间 Bandit — 方法论

| 论文 | 年份 | 核心思想 | 对我们的启发 |
|------|------|---------|-------------|
| **Thompson Sampling ∞ Action** (arXiv:2502.02140) | 2025 | 无限动作空间的 TS 理论分析。高斯近似可行。 | R⁵ 连续权重空间的 TS 采样有理论保证 |
| **NeuralBandit** (Springer, updated 2024) | 2014/2024 | 神经网络提取特征 + UCB 探索。无需手工特征。 | BlendBrain 用 NN 替代手工 if-else 的理论基础 |
| **Variance-Aware Neural UCB** (arXiv:2411.05979) | 2024 | 神经网络 + 方差感知 UCB。更稳定的探索。 | 网络输出方差作为不确定性估计 |
| **LLM-Enhanced MAB** (arXiv:2502.01118) | 2025 | TS 框架 + LLM 做 reward 预测。 | 可用 ResourceHub 的评估作为 reward 先验 |
| **Semantic Router** (NeurIPS'25, arXiv:2510.08731) | 2025 | 语义向量路由，10% 精度提升，47% 延迟降低。 | 向量化任务特征 → 路由决策 |

### 1.3 关键洞察

**从研究中提取的三个核心结论：**

1. **离散路由 → 连续混合**（RLAE 2025）：固定权重集成 < 动态 RL 权重。但 RLAE 用 PPO 训练开销大，我们需要更轻量的在线方案。

2. **预测与选择分离**（Routoo 2024）：ResourceHub 做"资源能做什么"的预测，BlendBrain 做"怎么组合"的决策。两层解耦。

3. **Bandit 在连续空间可行**（TS ∞ Action 2025）：高斯近似 Thompson Sampling 在 R⁵ 空间有理论保证。比 Dirichlet 采样高效。

---

## 二、神经混合架构

### 2.1 核心思想

**消灭离散策略名。决策 = R⁵ 权重向量。**

```
v2.0: 15 个离散策略名 → if-else 选择 → blendToDispatch() 丢失精度
v3.0: R⁵ 连续空间 → 神经网络/插值/Bandit → 权重直接驱动执行
```

### 2.2 架构图

```
用户消息
  ↓
小脑 regulate() → BodyState
右脑 predictFull() → IntuitionSignal
规则引擎 evaluateQuick() → 高置信度直接返回（不变）
  ↓ 低置信度
┌─────────────────────────────────────────┐
│         BlendBrain（新增）               │
│                                         │
│  输入: featureVector (128 维)            │
│    ├─ ResourceHub 评估 (N×6 维)          │
│    ├─ 全局信号 (8 维)                     │
│    └─ 历史上下文 (可选)                   │
│                                         │
│  网络: 2 层 MLP (128→64→5, ~8K 参数)     │
│    ├─ Layer 1: ReLU                      │
│    └─ Layer 2: Softmax → R⁵ 权重         │
│                                         │
│  输出: blendWeights[5]                   │
│    [rule, experience, assembly, buddyLM, │
│     cloudLLM]                            │
│                                         │
│  在线学习: REINFORCE + baseline           │
│    └─ reward = execution quality         │
└─────────────────────────────────────────┘
  ↓
executeBlendStrategy()（新增）
  ├─ weights[0] > 0.05 → 规则引擎
  ├─ weights[1] > 0.05 → 经验直连
  ├─ weights[2] > 0.05 → 组装引擎
  ├─ weights[3] > 0.05 → BuddyLM
  └─ weights[4] > 0.05 → 云端 LLM
  ↓
加权融合结果
  ↓
feedback() → BlendBandit.update() + BlendBrain.update()
```

### 2.3 与 v2.0 的兼容策略

```
Phase 6A: BlendBrain 并行运行（影子模式）
  - 同时计算 v2.0 离散策略 和 v3.0 连续权重
  - 用 v2.0 结果执行，v3.0 只记录
  - 积累 200+ 样本后评估 v3.0 质量

Phase 6B: v3.0 接管（质量超过 v2.0 后）
  - v3.0 权重驱动执行
  - v2.0 离散策略作为 fallback

Phase 6C: v2.0 清理
  - 删除 blendToDispatch()
  - 删除 15 个离散策略名
  - coordinator 简化为特征提取器
```

---

## 三、详细执行计划

### Phase 6A: BlendVector 连续化（2 天）

**目标：** 消灭离散策略名，定义连续权重空间。

#### 6A.1 新增类型定义

**文件:** `src/brain/types.ts`

```typescript
/** 连续混合向量 — 替代离散 BlendStrategy */
export interface BlendVector {
  /** R⁵ 权重向量 [rule, experience, assembly, buddyLM, cloudLLM] */
  weights: Float32Array;
  /** 执行模式（离散，4 种） */
  executionMode: 'parallel' | 'sequential' | 'compete' | 'cascade';
  /** 置信度阈值 */
  confidenceThreshold: number;
  /** 选择原因 */
  reason: string;
  /** 来源：'neural' | 'bandit' | 'interpolation' | 'legacy' */
  source: 'neural' | 'bandit' | 'interpolation' | 'legacy';
}
```

#### 6A.2 连续插值函数

**文件:** `src/brain/hub/blend-interpolation.ts`（新增 ~120 行）

```typescript
/**
 * 连续插值 — 替代 15 个离散策略的 if-else 选择
 *
 * 输入: cloudQuality, localStrength, novelty, budget
 * 输出: R⁵ 权重向量
 *
 * 特点:
 * - 相邻区域平滑过渡（无跳变）
 * - 边界条件自然退化（预算=0 → cloudLLM=0）
 * - 可解释（每个维度有明确含义）
 */
export function computeBlendWeights(
  cloudQuality: number,   // 0-1, ResourceHub 评估
  localStrength: number,  // 0-1, 本地资源综合
  novelty: number,        // 0-1, 任务新颖度
  budgetPressure: number, // 0-1, 0=充裕, 1=耗尽
): Float32Array {
  const w = new Float32Array(5);

  // cloudLLM 权重：S 型曲线，受 cloudQuality 和 novelty 调制
  // cloudQuality=0 → 0, cloudQuality=1 → 0.7
  w[4] = sigmoid(cloudQuality, 0.5, 8) * (0.3 + 0.4 * novelty) * (1 - budgetPressure);

  // 本地预算
  const localBudget = 1 - w[4];
  const lr = localStrength;

  // rule: 基础保障，随本地减弱而增加
  w[0] = localBudget * (0.15 + 0.10 * (1 - lr));

  // experience: 随本地强度线性增长
  w[1] = localBudget * 0.40 * lr;

  // assembly: 本地弱时多用（补偿）
  w[2] = localBudget * (0.25 + 0.15 * (1 - lr));

  // buddyLM: 需要最低本地能力才启用
  w[3] = lr > 0.3 ? localBudget * 0.20 : 0;

  // 归一化
  return normalize(w);
}

function sigmoid(x: number, center: number, steepness: number): number {
  return 1 / (1 + Math.exp(-steepness * (x - center)));
}

function normalize(w: Float32Array): Float32Array {
  const sum = w.reduce((s, v) => s + v, 0);
  if (sum > 0) for (let i = 0; i < w.length; i++) w[i] /= sum;
  return w;
}
```

#### 6A.3 BlendStrategy → BlendVector 桥接

**文件:** `src/brain/hub/blend-interpolation.ts`（追加）

```typescript
/**
 * 从 v2.0 BlendStrategy 提取等价 BlendVector
 * 用于过渡期兼容
 */
export function strategyToVector(strategy: BlendStrategy): BlendVector {
  const weights = new Float32Array(5);
  weights[0] = strategy.blend.ruleEngine;
  weights[1] = strategy.blend.experience;
  weights[2] = strategy.blend.assembly;
  weights[3] = strategy.blend.buddyLM;
  weights[4] = strategy.blend.cloudLLM;
  return {
    weights: normalize(weights),
    executionMode: strategy.executionMode,
    confidenceThreshold: strategy.confidenceThreshold,
    reason: strategy.reason,
    source: 'legacy',
  };
}
```

**验收标准:**
- [ ] BlendVector 类型定义完成
- [ ] computeBlendWeights() 输出 5 维归一化权重
- [ ] 相邻输入平滑过渡（微分连续）
- [ ] 边界条件正确（budget=0 → cloudLLM=0, cloudQuality=0 → cloudLLM=0）
- [ ] strategyToVector() 桥接旧策略

---

### Phase 6B: Bandit in R⁵（3 天）

**目标：** Thompson Sampling 直接在权重空间采样，替代策略名选择。

#### 6B.1 高斯 Thompson Sampling

**文件:** `src/brain/hub/blend-bandit.ts`（新增 ~150 行）

```typescript
/**
 * BlendBandit — R⁵ 连续空间的 Thompson Sampling
 *
 * 理论基础: Thompson Sampling ∞ Action Spaces (arXiv:2502.02140)
 *
 * 与 v2.0 DispatchLearner 的区别:
 * - v2.0: 15 个离散策略名，每个维护 Beta(alpha, beta)
 * - v3.0: R⁵ 连续空间，每个维度维护高斯 N(μ, σ²)
 *
 * 采样: 从高斯分布采样 5 维向量 → softmax 归一化
 * 更新: 观察到 reward 后，用 Robbins-Monro 在线更新 μ 和 σ²
 */
export class BlendBandit {
  private mean: Float32Array;      // 当前最优权重估计
  private variance: Float32Array;  // 每个维度的不确定性
  private count = 0;
  private runningBaseline = 0.5;

  constructor() {
    // 初始化：均匀先验
    this.mean = new Float32Array([0.2, 0.2, 0.2, 0.2, 0.2]);
    this.variance = new Float32Array([0.1, 0.1, 0.1, 0.1, 0.1]);
  }

  /**
   * 采样一个权重向量
   *
   * 不确定性大（variance 高）→ 探索多
   * 不确定性小（variance 低）→ 利用多
   */
  sample(): Float32Array {
    const sampled = new Float32Array(5);
    for (let i = 0; i < 5; i++) {
      sampled[i] = this.mean[i] + this.randn() * Math.sqrt(this.variance[i]);
    }
    return softmax(sampled);
  }

  /**
   * 更新 — 观察到 reward 后调整分布
   *
   * 用在线高斯更新（Robbins-Monro 变体）
   * 学习率随样本数衰减：lr = 1/(10 + count)
   */
  update(weights: Float32Array, reward: number): void {
    this.count++;
    const lr = 1 / (10 + this.count);
    const advantage = reward - this.runningBaseline;
    this.runningBaseline = 0.99 * this.runningBaseline + 0.01 * reward;

    for (let i = 0; i < 5; i++) {
      // 均值更新：朝 reward 方向微调
      this.mean[i] += lr * advantage * (weights[i] - this.mean[i]);
      // 方差更新：观察越多越确定
      const delta = weights[i] - this.mean[i];
      this.variance[i] = (1 - lr) * this.variance[i] + lr * delta * delta;
      this.variance[i] = Math.max(0.005, this.variance[i]); // 最小方差保底探索
    }
  }

  /**
   * 从 v2.0 DispatchLearner 的 bandit 数据迁移
   *
   * 用历史策略的平均权重初始化 mean
   */
  migrateFromLearner(learnerBandits: Map<string, { alpha: number; beta: number }>): void {
    // 从离散 bandit 估计连续空间的初始均值
    // 简单方案：用历史最优策略的权重作为初始均值
  }

  getState(): { mean: Float32Array; variance: Float32Array; count: number } {
    return { mean: new Float32Array(this.mean), variance: new Float32Array(this.variance), count: this.count };
  }

  private randn(): number {
    const u1 = Math.random(), u2 = Math.random();
    return Math.sqrt(-2 * Math.log(u1)) * Math.cos(2 * Math.PI * u2);
  }
}
```

#### 6B.2 集成到 coordinator

**文件:** `src/brain/dispatch/coordinator.ts`（修改 ~50 行）

```typescript
// 新增方法
selectBlendVector(
  signal: TaskSignal,
  resources: ResourceState,
  intuition?: IntuitionSignal,
  bodyState?: BodyState,
): BlendVector {
  // 1. 资源评估
  const recommendations = this.resourceHub?.recommend({...}) ?? [];
  const cloud = this.assessCloudLLM(recommendations);
  const local = this.assessLocalResources(recommendations);

  // 2. 连续插值作为 prior
  const interpolationWeights = computeBlendWeights(
    cloud.quality,
    (local.assemblyCoverage + local.experienceHitRate) / 2,
    this.estimateNovelty(signal, intuition),
    resources.budgetRemaining <= 0 ? 1 : 0,
  );

  // 3. Bandit 采样（有足够数据后覆盖 prior）
  if (this.blendBandit && this.blendBandit.getState().count >= 20) {
    const banditWeights = this.blendBandit.sample();
    // 混合：70% bandit + 30% prior（防止 bandit 跑偏）
    const blended = new Float32Array(5);
    for (let i = 0; i < 5; i++) {
      blended[i] = 0.7 * banditWeights[i] + 0.3 * interpolationWeights[i];
    }
    return { weights: normalize(blended), executionMode: this.selectExecutionMode(blended), ... };
  }

  // 4. 不够数据时用插值
  return { weights: interpolationWeights, executionMode: ..., source: 'interpolation' };
}
```

**验收标准:**
- [ ] BlendBandit 采样输出归一化 R⁵ 向量
- [ ] 在线更新收敛（100 次交互后 mean 方差下降）
- [ ] v2.0 bandit 数据可迁移
- [ ] coordinator.selectBlendVector() 替代 selectBlendStrategy()

---

### Phase 6C: BlendBrain 神经网络（1 周）

**目标：** 用小网络替代手工插值函数，输入资源评估 → 输出 blend 权重。

#### 6C.1 特征提取器

**文件:** `src/brain/hub/feature-extractor.ts`（新增 ~100 行）

```typescript
/**
 * 特征提取器 — 将 ResourceHub 评估 + 全局信号编码为固定维度向量
 *
 * 输入: ResourceHub + TaskSignal + ResourceState + BodyState
 * 输出: Float32Array(128)
 *
 * 设计:
 * - 每个活跃资源 6 维: [capability, reliability, speed, costEfficiency, confidence, scenarioMatch]
 * - 最多 18 个资源 × 6 = 108 维
 * - 全局信号 8 维: [novelty, complexity, budget, load, energy, hour, localCoverage, intentConf]
 * - 剩余 12 维: 历史统计（最近 N 次决策的平均质量、策略分布等）
 */
export function buildFeatureVector(
  hub: ResourceHub,
  signal: TaskSignal,
  resources: ResourceState,
  bodyState: BodyState,
): Float32Array {
  const vec = new Float32Array(128);
  let offset = 0;

  // 资源评估（最多 18 个资源 × 6 维 = 108）
  const active = hub.getActive();
  for (const r of active.slice(0, 18)) {
    const a = r.assessment;
    vec[offset++] = a.capability;
    vec[offset++] = a.reliability;
    vec[offset++] = a.speed;
    vec[offset++] = a.costEfficiency;
    vec[offset++] = a.confidence;
    vec[offset++] = hub.getScenarioReliability(r.id, signal.taskType);
  }

  // 全局信号（8 维）
  vec[offset++] = signal.novelty ?? 0.5;
  vec[offset++] = signal.complexity === 'complex' ? 1 : signal.complexity === 'medium' ? 0.5 : 0;
  vec[offset++] = Math.min(1, resources.budgetRemaining / 100);
  vec[offset++] = bodyState.load / 100;
  vec[offset++] = bodyState.energy / 100;
  vec[offset++] = bodyState.hour / 23;
  vec[offset++] = resources.localCoverageRatio;
  vec[offset++] = signal.intentConfidence;

  return vec;
}
```

#### 6C.2 BlendBrain 网络

**文件:** `src/brain/hub/blend-brain.ts`（新增 ~200 行）

```typescript
/**
 * BlendBrain — 决策神经网络
 *
 * 研究基础:
 * - NeuralBandit (Springer 2014/2024): NN 特征提取 + bandit 探索
 * - RLAE (arXiv:2506.00439): RL 动态调整 LLM 集成权重
 * - Variance-Aware Neural UCB (arXiv:2411.05979): 方差感知探索
 *
 * 架构: 2 层 MLP (128→64→5), ~8K 参数, 纯 JS 实现
 * 学习: REINFORCE 策略梯度 + baseline
 *
 * 与 BlendBandit 的关系:
 * - BlendBandit: 无上下文，在 R⁵ 空间全局探索
 * - BlendBrain: 有上下文，根据资源状态条件化输出权重
 * - 两者互补：BlendBrain 做主决策，BlendBandit 做全局校准
 */
export class BlendBrain {
  private W1: Float32Array;  // 128×64
  private b1: Float32Array;  // 64
  private W2: Float32Array;  // 64×5
  private b2: Float32Array;  // 5
  private runningBaseline = 0.5;
  private trainCount = 0;

  constructor() {
    this.W1 = this.xavierInit(128 * 64, 128, 64);
    this.b1 = new Float32Array(64);
    this.W2 = this.xavierInit(64 * 5, 64, 5);
    this.b2 = new Float32Array(5);
  }

  /**
   * 前向传播
   *
   * input: 128 维特征向量
   * output: 5 维 softmax 权重
   */
  forward(input: Float32Array): Float32Array {
    // Layer 1: ReLU
    const hidden = new Float32Array(64);
    for (let j = 0; j < 64; j++) {
      let sum = this.b1[j];
      for (let i = 0; i < 128; i++) {
        sum += input[i] * this.W1[i * 64 + j];
      }
      hidden[j] = Math.max(0, sum);
    }

    // Layer 2: → logits
    const logits = new Float32Array(5);
    for (let j = 0; j < 5; j++) {
      let sum = this.b2[j];
      for (let i = 0; i < 64; i++) {
        sum += hidden[i] * this.W2[i * 5 + j];
      }
      logits[j] = sum;
    }

    return softmax(logits);
  }

  /**
   * 在线学习 — REINFORCE 策略梯度
   *
   * loss = -reward * log π(a|s)
   * 梯度估计: ∇loss ≈ (reward - baseline) * ∇log π(a|s)
   *
   * 为稳定性:
   * - 只更新输出层 W2（W1 保持稳定，避免灾难性遗忘）
   * - 梯度裁剪（|grad| < 0.01）
   * - 小学习率（0.001）
   */
  update(input: Float32Array, output: Float32Array, reward: number): void {
    this.trainCount++;
    const advantage = reward - this.runningBaseline;
    this.runningBaseline = 0.99 * this.runningBaseline + 0.01 * reward;

    // 简化梯度：用输出偏差方向作为梯度估计
    const lr = Math.min(0.001, 0.01 / Math.sqrt(this.trainCount));
    for (let i = 0; i < 64; i++) {
      for (let j = 0; j < 5; j++) {
        const grad = advantage * output[j] * 0.01;
        this.W2[i * 5 + j] += lr * Math.max(-0.01, Math.min(0.01, grad));
      }
    }
  }

  /**
   * 从 v2.0 插值函数蒸馏
   *
   * 冷启动方案：用 computeBlendWeights 生成伪标签训练网络
   * 让网络学习插值函数的映射关系
   */
  distillFromInterpolation(hub: ResourceHub, samples: number = 500): void {
    for (let i = 0; i < samples; i++) {
      // 随机生成资源状态
      const cloudQ = Math.random();
      const localS = Math.random();
      const novelty = Math.random();
      const budget = Math.random() > 0.1 ? 0 : 1;

      // 插值函数生成伪标签
      const target = computeBlendWeights(cloudQ, localS, novelty, budget);

      // 构造对应特征向量（简化版）
      const input = new Float32Array(128);
      input[108] = novelty;
      input[109] = 0.5; // complexity
      input[110] = 1 - budget;
      input[111] = 0.5; // load
      input[112] = 0.8; // energy
      input[113] = 14 / 23; // hour
      input[114] = localS;
      input[115] = 0.7; // intentConf

      // 训练
      const output = this.forward(input);
      for (let j = 0; j < 5; j++) {
        // MSE 梯度
        const grad = target[j] - output[j];
        for (let k = 0; k < 64; k++) {
          this.W2[k * 5 + j] += 0.001 * grad;
        }
      }
    }
  }

  private xavierInit(size: number, fanIn: number, fanOut: number): Float32Array {
    const w = new Float32Array(size);
    const scale = Math.sqrt(2 / (fanIn + fanOut));
    for (let i = 0; i < size; i++) w[i] = (Math.random() * 2 - 1) * scale;
    return w;
  }
}
```

#### 6C.3 四层预训练（冷启动）

**目标：** 启动时 < 1 秒完成预训练，上线即"懂这个系统"。

**Step 1: 插值函数蒸馏（500 样本）**

用 `computeBlendWeights()` 作为教师，按场景分布采样（非均匀随机）：

```typescript
const scenarios = [
  { cloudQ: 0,                  localS: rand(0.3, 0.9), novelty: rand(0, 0.6) },  // 无 LLM
  { cloudQ: rand(0.2, 0.5),    localS: rand(0.3, 0.8), novelty: rand(0, 1)   },  // 弱 LLM
  { cloudQ: rand(0.7, 1.0),    localS: rand(0.2, 0.7), novelty: rand(0, 1)   },  // 强 LLM
  { cloudQ: rand(0.5, 0.7),    localS: rand(0.4, 0.8), novelty: rand(0, 1)   },  // 均衡
  { cloudQ: 0, localS: 0, novelty: 1 },  // 啥都没有
  { cloudQ: 1, localS: 1, novelty: 0 },  // 啥都有
];
```

MSE 收敛到 < 0.005，< 1 秒。

**Step 2: v2.0 历史决策迁移**

从 `left.memory.getRecords()` 提取成功的 `DecisionRecord`，将 `plan.source` 转换为等价 blend weights：

```typescript
function planToWeights(plan: ExecutionPlan): Float32Array {
  const w = new Float32Array(5);
  if (plan.source === 'rule')     w[0] = 0.8;
  if (plan.source === 'assembly') w[2] = 0.7;
  if (plan.source === 'learned')  w[1] = 0.6;
  // ... 归一化
  return normalize(w);
}
```

**Step 3: ResourceHub 实战数据回放**

从 `resourceHub.getActive()` 中每个资源的 `assessment` + `scenarioStats` 反推理想权重。资源越强，对应维度权重越高。

**Step 4: Bandit 先验迁移**

从 `dispatchLearner.getGeneratorBandits()` 的离散 bandit 统计，按策略名查表转为等价 blend weights，用成功率加权平均得到 BlendBandit 的初始 `mean`：

```typescript
mean[i] += strategyWeights[i] * (alpha / (alpha + beta));
```

**预训练总耗时 < 1 秒，全部在启动时同步完成。**

#### 6C.4 持久化

**文件:** `src/brain/hub/blend-brain.ts`（追加）

```typescript
exportBlendBrain(): Record<string, unknown> {
  return {
    W1: Array.from(this.W1),
    b1: Array.from(this.b1),
    W2: Array.from(this.W2),
    b2: Array.from(this.b2),
    runningBaseline: this.runningBaseline,
    trainCount: this.trainCount,
  };
}

importBlendBrain(data: Record<string, unknown>): void {
  this.W1 = new Float32Array(data.W1 as number[]);
  this.b1 = new Float32Array(data.b1 as number[]);
  this.W2 = new Float32Array(data.W2 as number[]);
  this.b2 = new Float32Array(data.b2 as number[]);
  this.runningBaseline = data.runningBaseline as number;
  this.trainCount = data.trainCount as number;
}
```

**验收标准:**
- [ ] BlendBrain 前向传播正确（softmax 归一化）
- [ ] 从插值函数蒸馏后，网络输出与插值函数近似（MSE < 0.01）
- [ ] 在线学习不发散（梯度裁剪 + 小学习率）
- [ ] 持久化后恢复正确
- [ ] 推理延迟 < 1ms（纯 JS，无外部依赖）

---

### Phase 6D: executeBlendStrategy 落地（2 天）

**目标：** 权重直接驱动执行器选择，替代 if-else 链。

#### 6D.1 执行器封装

**文件:** `src/brain/brain.ts`（修改 ~200 行）

```typescript
/**
 * 执行混合策略 — 权重驱动
 *
 * 替代现有的 if-else 链。
 * 每个组件按权重决定是否参与、参与程度。
 */
private async executeBlendStrategy(
  input: string,
  signal: TaskSignal,
  resources: ResourceState,
  intuition: IntuitionSignal | undefined,
  bodyState: BodyState,
  blend: BlendVector,
): Promise<{ text: string; confidence: number; source: string; components: string[] }> {
  const results: Array<{
    name: string;
    text: string;
    confidence: number;
    weight: number;
  }> = [];

  // 按权重阈值决定是否执行各组件
  const THRESHOLD = 0.05;

  // 规则引擎（权重 > 阈值时参与）
  if (blend.weights[0] > THRESHOLD) {
    const rulePlan = this.left.evaluate(signal, resources, intuition, bodyState);
    if (rulePlan) {
      results.push({
        name: 'rule',
        text: rulePlan.reason,
        confidence: rulePlan.confidence,
        weight: blend.weights[0],
      });
    }
  }

  // 经验直连
  if (blend.weights[1] > THRESHOLD) {
    const exp = await this.tryExperience(input, signal);
    if (exp) {
      results.push({ name: 'experience', ...exp, weight: blend.weights[1] });
    }
  }

  // 组装引擎
  if (blend.weights[2] > THRESHOLD && intuition?._hidden) {
    const asm = await this.processWithAssemblyCompetitive(input, intuition, signal);
    results.push({
      name: 'assembly',
      text: asm.text,
      confidence: asm.assemblyConfidence,
      weight: blend.weights[2],
    });
  }

  // BuddyLM
  if (blend.weights[3] > THRESHOLD && this.right.hasBuddyLM()) {
    const buddy = await this.tryBuddyLM(input, intuition);
    if (buddy) {
      results.push({ name: 'buddyLM', ...buddy, weight: blend.weights[3] });
    }
  }

  // 云端 LLM
  if (blend.weights[4] > THRESHOLD && this.hasExternalLLM) {
    const cloud = await this.tryCloudLLM(input, signal);
    if (cloud) {
      results.push({ name: 'cloudLLM', ...cloud, weight: blend.weights[4] });
    }
  }

  // 加权融合
  return this.blendResults(results, blend);
}

/**
 * 加权融合 — 按执行模式组合各组件输出
 */
private blendResults(
  results: Array<{ name: string; text: string; confidence: number; weight: number }>,
  blend: BlendVector,
): { text: string; confidence: number; source: string; components: string[] } {
  if (results.length === 0) {
    return { text: '', confidence: 0, source: 'none', components: [] };
  }

  // cascade 模式: 按权重排序，第一个够好就用
  if (blend.executionMode === 'cascade') {
    results.sort((a, b) => b.weight - a.weight);
    for (const r of results) {
      if (r.confidence >= blend.confidenceThreshold) {
        return { text: r.text, confidence: r.confidence, source: r.name, components: [r.name] };
      }
    }
    return { text: results[0].text, confidence: results[0].confidence, source: results[0].name, components: [results[0].name] };
  }

  // compete 模式: 质量最高的赢
  if (blend.executionMode === 'compete') {
    results.sort((a, b) => b.confidence - a.confidence);
    return { text: results[0].text, confidence: results[0].confidence, source: results[0].name, components: [results[0].name] };
  }

  // parallel/sequential 模式: 加权融合
  const totalWeight = results.reduce((s, r) => s + r.weight * r.confidence, 0);
  const primary = results.sort((a, b) => (b.weight * b.confidence) - (a.weight * a.confidence))[0];

  return {
    text: primary.text,
    confidence: totalWeight > 0 ? results.reduce((s, r) => s + r.weight * r.confidence, 0) / results.length : primary.confidence,
    source: results.map(r => r.name).join('+'),
    components: results.map(r => r.name),
  };
}
```

#### 6D.2 辅助执行器（try* 方法）

**文件:** `src/brain/brain.ts`（新增 ~80 行）

```typescript
private async tryExperience(input: string, signal: TaskSignal): Promise<{ text: string; confidence: number } | null> {
  // 从经验图谱中查找匹配
  // 暂返回 null（需要接入 ExperienceGraph）
  return null;
}

private async tryBuddyLM(input: string, intuition?: IntuitionSignal): Promise<{ text: string; confidence: number } | null> {
  if (!this.right.hasBuddyLM()) return null;
  try {
    const result = await this.right.executeBuddyLM(input, intuition?._hidden, {
      userInput: input, intent: 'general', taskType: 'chat', timestamp: Date.now(),
    });
    return { text: result.text, confidence: result.confidence };
  } catch { return null; }
}

private async tryCloudLLM(input: string, signal: TaskSignal): Promise<{ text: string; confidence: number } | null> {
  // 需要接入 LLMAdapter
  // 暂返回 null
  return null;
}
```

**验收标准:**
- [ ] executeBlendStrategy() 替代 if-else 链
- [ ] 权重 > 0.05 的组件被执行
- [ ] cascade/compete/parallel 模式正确
- [ ] 空结果时返回 confidence=0（不崩溃）
- [ ] 反馈闭环：执行后 recordOutcome 到 ResourceHub

---

### Phase 6E: 反馈闭环 + 持久化（2 天）

**目标：** 执行结果反馈到 BlendBandit + BlendBrain + ResourceHub。重启后恢复状态。

#### 6E.1 feedback() 改造

**文件:** `src/brain/brain.ts`（修改 ~40 行）

```typescript
// 在 feedback() 中新增
// 记录 blend 权重的执行效果
if (this.lastBlendVector) {
  // 更新 BlendBandit
  this.blendBandit.update(this.lastBlendVector.weights, qualityScore);

  // 更新 BlendBrain（有特征向量时）
  if (this.lastFeatureVector) {
    this.blendBrain.update(this.lastFeatureVector, this.lastBlendVector.weights, qualityScore);
  }

  // 记录到 ResourceHub
  this.resourceHub.recordOutcome('blend_vector', {
    success: outcome.success,
    qualityScore,
    latencyMs: outcome.latencyMs,
    scenario: signal.taskType,
  });
}
```

#### 6E.2 持久化接入

**文件:** `src/brain/brain.ts`（修改 ~30 行）

```typescript
// 在心跳或关闭时
saveState(): void {
  const state = {
    resourceHub: this.resourceHub.exportForPersistence(),
    blendBrain: this.blendBrain.exportBlendBrain(),
    blendBandit: this.blendBandit.getState(),
  };
  // 写入文件
  fs.writeFileSync(this.statePath, JSON.stringify(state));
}

// 在启动时
loadState(): void {
  try {
    const data = JSON.parse(fs.readFileSync(this.statePath, 'utf-8'));
    this.resourceHub.importFromPersistence(data.resourceHub);
    this.blendBrain.importBlendBrain(data.blendBrain);
    // blendBandit 恢复...
  } catch { /* 冷启动 */ }
}
```

**验收标准:**
- [ ] feedback() 正确调用 blendBandit.update() 和 blendBrain.update()
- [ ] 持久化后重启状态恢复
- [ ] ResourceHub + BlendBrain + BlendBandit 三者状态一致

---

### Phase 6F: 影子模式 + 渐进切换（3 天）

**目标：** v3.0 并行运行但不接管，积累数据后自动切换。

#### 6F.1 影子模式

**文件:** `src/brain/brain.ts`（修改 ~50 行）

```typescript
async decide(input, signal, resources): Promise<DecisionResult> {
  // ... 现有流程 ...

  // v2.0 路径（执行）
  const v2Strategy = this.coordinator.selectBlendStrategy(signal, resources, intuition, bodyState);
  const v2Result = await this.executeLegacy(v2Strategy, ...);

  // v3.0 路径（影子）
  if (this.blendBrainReady) {
    const features = buildFeatureVector(this.resourceHub, signal, resources, bodyState);
    const v3Weights = this.blendBrain.forward(features);
    // 记录但不执行
    this.shadowRecorder.record({ features, v2Strategy, v3Weights, timestamp: Date.now() });
  }

  return v2Result;
}
```

#### 6F.2 质量评估 + 切换

```typescript
// 每 100 次决策评估一次
if (this.decisionCount % 100 === 0 && this.shadowRecorder.count >= 100) {
  const comparison = this.shadowRecorder.evaluate();
  if (v3Quality > v2Quality + 0.02) {
    this.blendBrainActive = true;
    console.log('[ThreeBrain] v3.0 BlendBrain 接管: 质量优势 +${(v3Quality - v2Quality).toFixed(3)}');
  }
}
```

**验收标准:**
- [ ] 影子模式不影响现有决策质量
- [ ] 积累 200+ 样本后自动评估
- [ ] v3.0 质量超过 v2.0 2% 时自动切换
- [ ] 切换后可回滚（v2.0 fallback 保留）

---

### Phase 6G: v2.0 清理（1 天）

**前提:** v3.0 稳定运行 500+ 次决策后。

#### 清理清单

| 删除 | 文件 | 替代 |
|------|------|------|
| `blendToDispatch()` | brain.ts | 不再需要，BlendVector 直接驱动 |
| `DispatchStrategyName` 15 个值 | coordinator.ts | BlendVector.weights |
| `selectBlendStrategy()` | coordinator.ts | selectBlendVector() |
| `applyBlendThompsonSampling()` | coordinator.ts | BlendBandit.update() |
| `strategyNoLLM/WeakLLM/StrongLLM/Balanced()` | coordinator.ts | computeBlendWeights() |

---

## 四、文件改动汇总

| 文件 | 操作 | 行数 | Phase |
|------|------|------|-------|
| `src/brain/types.ts` | 修改 | +30 | 6A |
| `src/brain/hub/blend-interpolation.ts` | **新增** | ~120 | 6A |
| `src/brain/hub/blend-bandit.ts` | **新增** | ~150 | 6B |
| `src/brain/hub/feature-extractor.ts` | **新增** | ~100 | 6C |
| `src/brain/hub/blend-brain.ts` | **新增** | ~200 | 6C |
| `src/brain/dispatch/coordinator.ts` | 修改 | +50/-200 | 6B/6G |
| `src/brain/brain.ts` | 修改 | +200/-100 | 6D/6E/6F |
| `src/brain/hub/blend-interpolation.test.ts` | **新增** | ~80 | 6A |
| `src/brain/hub/blend-bandit.test.ts` | **新增** | ~60 | 6B |
| `src/brain/hub/blend-brain.test.ts` | **新增** | ~80 | 6C |

**总计:** ~820 行新增/修改，~220 行删除，净增 ~600 行

---

## 五、风险与缓解

| 风险 | 影响 | 缓解 |
|------|------|------|
| 网络初期乱决策 | 输出质量下降 | 影子模式 + 插值 prior + 质量门控切换 |
| 在线学习不稳定 | 权重发散 | 梯度裁剪 + 小学习率 + baseline |
| 冷启动无数据 | BlendBrain 输出随机 | 从插值函数蒸馏（distillFromInterpolation） |
| 维度灾难 | 128 维输入太多 | 实际有效维度 ~30，其余为 0 |
| REINFORCE 方差大 | 学习慢 | baseline + advantage normalization |
| v2.0→v3.0 切换风险 | 用户感知质量下降 | 渐进切换 + 自动回滚 |
| 持久化状态不一致 | 重启后行为异常 | 三者（Hub/Brain/Bandit）原子写入 |

---

## 六、验收标准总览

### Phase 6A 完成
- [ ] BlendVector 类型定义
- [ ] computeBlendWeights() 连续插值
- [ ] strategyToVector() 桥接
- [ ] 单元测试覆盖

### Phase 6B 完成
- [ ] BlendBandit 高斯 TS 采样 + 更新
- [ ] 在线收敛验证
- [ ] coordinator.selectBlendVector()

### Phase 6C 完成
- [ ] BlendBrain 前向传播 + 在线学习
- [ ] 从插值蒸馏
- [ ] 持久化
- [ ] 推理延迟 < 1ms

### Phase 6D 完成
- [ ] executeBlendStrategy() 替代 if-else
- [ ] 权重驱动执行
- [ ] 加权融合正确

### Phase 6E 完成
- [ ] feedback() 三路更新（Hub/Brain/Bandit）
- [ ] 持久化接入

### Phase 6F 完成
- [ ] 影子模式运行
- [ ] 质量评估 + 自动切换

### Phase 6G 完成
- [ ] v2.0 离散策略清理
- [ ] 代码行数净减少

---

## 七、时间线

```
Week 1:  Phase 6A (2d) + Phase 6B (3d)
         → 连续化 + Bandit in R⁵
         → 产出: BlendVector + BlendBandit + 测试

Week 2:  Phase 6C (5d)
         → BlendBrain 神经网络
         → 产出: 特征提取器 + 网络 + 蒸馏 + 测试

Week 3:  Phase 6D (2d) + Phase 6E (2d) + Phase 6F (3d)
         → 执行落地 + 反馈闭环 + 影子模式
         → 产出: 完整 v3.0 可运行（影子模式）

Week 4:  影子模式运行 + 评估 + 切换
         → 产出: v3.0 接管决策

Week 5:  Phase 6G + 收尾
         → 产出: v2.0 清理 + 文档更新
```

---

## 附录 A: 与 v2.0 研究支撑的对应关系

| v2.0 研究 | v3.0 扩展 | 新研究 |
|-----------|----------|--------|
| FrugalGPT cascade | cascade 执行模式保留 | RouteLLM 路由器训练 |
| C2MAB-V TS 选策略 | TS 在 R⁵ 空间采样 | TS ∞ Action 理论保证 |
| Semantic Router 按任务选资源 | 特征向量化任务特征 | NeuralBandit NN 特征提取 |
| BEST-Route 多方案竞争 | compete 模式保留 | RLAE RL 动态集成权重 |
| MAPE-K 统一知识库 | ResourceHub 不变 | Routoo 预测/选择分离 |

## 附录 B: BlendBrain vs 其他方案对比

| 方案 | 参数量 | 上下文感知 | 在线学习 | 冷启动 | 复杂度 |
|------|--------|-----------|---------|--------|--------|
| if-else 离散策略 | 0 | ❌ | ❌ | ✅ | O(1) |
| 连续插值 | 0 | 部分 | ❌ | ✅ | O(1) |
| BlendBandit (R⁵ TS) | 10 | ❌ | ✅ | 需迁移 | O(5) |
| **BlendBrain (MLP)** | **~8K** | **✅** | **✅** | **蒸馏** | **O(8K)** |
| RLAE (PPO) | ~100K | ✅ | ✅ | 需训练 | O(100K) |
| RouteLLM (分类器) | ~1M | ✅ | ❌ | 需标注 | O(1M) |

BlendBrain 在参数量、在线学习能力、冷启动方案上取得最佳平衡。
