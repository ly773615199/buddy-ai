# 能力发现与动态路由 — 解决方案 v2

> 基于：三脑决策架构深度审计 + Semantic Router 研究 + ByteEncoder/ArgExtractor/ResourceHub/LawClassifier 现有组件分析 + 组装引擎/碰撞引擎全能力审计
> 生成时间：2026-06-01
>
> **v2 更新**：新增第五章「组装引擎 + 碰撞引擎全能力释放」— 15 个无 LLM 可解场景 + 完整能力矩阵 + 架构升级方案

---

## 一、问题精确定义

### 1.1 现有决策管线

```
用户输入
  │
  ▼
Step 1: 小脑感知融合 → BodyState (情绪/能量/负载/困惑度)
  │
  ▼
Step 2: 右脑直觉预测 → IntuitionSignal (意图/原型匹配/建议工具/质量预判)
  │
  ▼
Step 2.4: 左脑 evaluateExecutableRule()
  │        53条种子规则 × 正则 condition()
  │        ↓ 命中 → ExecutablePlan → executeExecutablePlan() → composeToolResult() → 输出
  │        ↓ 未命中 ↓
  ▼
Step 2.5: 审议委员会 deliberate()
  │        ↓ proceed ↓
  ▼
Step 3: 调度协调 → BlendBrain(180维特征) → R⁵路由权重 → 执行策略
  │
  ▼
Step 3.5: 裁决 → ProposalCollector + FeasibilityChecker + Arbiter → 选最优方案
  │
  ▼
输出
```

### 1.2 断裂点

正则规则覆盖了 **确定性操作**（git/file/system/weather），但存在明确的语义缝隙：

```
输入: "最新经济新闻"
  Step 2.4: 53条正则 → 无命中（无"git""天气""文件"关键词）
  Step 2.5: 审议 → proceed
  Step 3: BlendBrain → 可能路由到 LLM（浪费资源，其实 search_web 就够）
  → 或者走追问："你想查什么？"（信息已经很明确，不该追问）
```

**核心矛盾**：信息明确 → 应该执行 → 但无正则命中 → 被动检索/LLM → 本不该发生的资源消耗。

### 1.3 现有可复用组件

| 组件 | 能力 | 在方案中的角色 |
|------|------|---------------|
| `ByteEncoder` | 256维向量, ~3ms, 纯CPU | 语义编码引擎 |
| `ToolRegistry.onRegister/onUnregister` | 工具注册回调 | 工具变更同步 |
| `ArgExtractorRegistry` | 从文本提取工具参数 | 参数提取层 |
| `ResourceHub` | 资源画像 + Thompson Sampling | 路由结果反馈学习 |
| `ToolRetriever` | 关键词/TF-IDF 工具检索 | 语义匹配的降级兜底 |
| `LawClassifier` | 六条法则互斥分类 | 法则1扩展 |
| `AssemblyEngine.retrieve()` | 多源检索管线 | 工具检索源注册 |
| `BlendBrain` | 180维特征 → R⁵路由 | 特征区扩展 |
| `ExperienceExecutor` | 经验图谱检索 | 工具匹配结果缓存 |

---

## 二、方案设计

### 2.1 核心思想

**不重写，只桥接。** 利用 ByteEncoder 的向量空间做语义匹配，利用现有管线做执行和学习。

```
正则命中 → 快速通道（保留，不改）
正则未命中 → CapabilityRouter 语义匹配 → 命中则执行 / 未命中则继续原流程
```

### 2.2 架构定位

```
                    ┌─────────────────────────────────────┐
                    │           ThreeBrain                 │
                    │                                      │
                    │  Step 2.4: evaluateExecutableRule()  │
                    │    53条正则 → 命中? → 执行            │
                    │         ↓ 未命中                      │
                    │  Step 2.45: CapabilityRouter ← 新增   │
                    │    ByteEncoder 语义匹配               │
                    │    ArgExtractor 参数提取              │
                    │    ResourceHub 反馈记录               │
                    │    命中? → 执行 / 未命中 → 继续       │
                    │         ↓                            │
                    │  Step 2.5: 审议委员会                 │
                    │         ↓                            │
                    │  Step 3: BlendBrain 调度              │
                    └─────────────────────────────────────┘
```

### 2.3 与现有架构的对齐

| 现有概念 | CapabilityRouter 的对应 |
|---------|----------------------|
| `Rule.condition()` | 语义相似度 > 阈值 |
| `Rule.action()` | ArgExtractor 提取参数 → ExecutablePlan |
| `ExecutablePlan` | 复用现有结构，source 标记为 'capability_router' |
| `LawClassifier` 法则1 | 扩展：法则1 = 正则确定性 OR 语义确定性 |
| `BlendBrain` 特征向量 | [172, 180) 预留区编码路由匹配信号 |
| `ResourceHub` 工具画像 | 注册为 tool 类型资源，记录匹配成功率 |
| `ToolRetriever` | 降级兜底：语义匹配失败时用 TF-IDF 重试 |

---

## 三、详细设计

### 3.1 CapabilityRouter 核心

```typescript
// src/tools/capability-router.ts

import { ByteEncoder } from '../brain/right/features/text-encoder.js';
import { l2Normalize } from '../brain/right/features/vector-index.js';
import type { ToolDef, ToolRegistry } from './registry.js';
import { logger } from '../audit/structured-logger.js';

// ==================== 类型 ====================

export interface RouteMatch {
  tool: ToolDef;
  score: number;
  extractedArgs: Record<string, unknown> | null;
  source: 'semantic' | 'fallback';
}

export interface CapabilityRouterConfig {
  /** 匹配阈值 — 低于此值视为未匹配 */
  matchThreshold: number;
  /** 最大候选数 */
  topK: number;
  /** 每个工具最多注册几条 utterance */
  maxUtterancesPerTool: number;
  /** 是否启用 ToolRetriever 降级 */
  enableFallback: boolean;
  /** 动态阈值：是否基于历史匹配分布自适应 */
  adaptiveThreshold: boolean;
}

const DEFAULT_CONFIG: CapabilityRouterConfig = {
  matchThreshold: 0.40,    // 初始保守阈值，积累数据后自适应
  topK: 3,
  maxUtterancesPerTool: 8,
  enableFallback: true,
  adaptiveThreshold: true,
};

// ==================== 工具路由条目 ====================

interface RouteEntry {
  toolName: string;
  utterances: string[];
  /** 预编码的 utterance 向量（注册时一次性计算） */
  embeddings: Float32Array[];
  /** 最近匹配分数（滑动窗口，用于动态阈值） */
  recentScores: number[];
  /** 匹配成功次数 */
  hitCount: number;
  /** 匹配总次数 */
  totalCount: number;
}

// ==================== 路由器 ====================

export class CapabilityRouter {
  private encoder: ByteEncoder;
  private entries: Map<string, RouteEntry> = new Map();
  private config: CapabilityRouterConfig;
  private log = logger.child('CapabilityRouter');

  // 动态阈值：基于历史匹配分布
  private scoreHistory: number[] = [];
  private readonly HISTORY_WINDOW = 200;

  constructor(encoder: ByteEncoder, config?: Partial<CapabilityRouterConfig>) {
    this.encoder = encoder;
    this.config = { ...DEFAULT_CONFIG, ...config };
  }

  // ── 工具注册 ──

  /**
   * 注册工具的语义路由条目
   * 在 ToolRegistry.register() 时自动调用
   */
  register(tool: ToolDef): void {
    const utterances = this.generateUtterances(tool);
    if (utterances.length === 0) return;

    const embeddings = utterances.map(u => {
      const raw = this.encoder.forward(u);
      return l2Normalize(raw);
    });

    this.entries.set(tool.name, {
      toolName: tool.name,
      utterances,
      embeddings,
      recentScores: [],
      hitCount: 0,
      totalCount: 0,
    });
  }

  /** 注销工具 */
  unregister(name: string): void {
    this.entries.delete(name);
  }

  // ── 语义路由 ──

  /**
   * 核心路由方法 — 语义匹配用户输入到工具
   *
   * @returns 匹配结果或 null（未命中）
   */
  route(input: string): RouteMatch | null {
    const t0 = performance.now();

    // 1. 编码用户输入
    const queryVec = l2Normalize(this.encoder.forward(input));

    // 2. 与所有工具 utterance 做余弦相似度
    const candidates: Array<{ toolName: string; score: number; entry: RouteEntry }> = [];

    for (const entry of this.entries.values()) {
      let bestScore = 0;
      for (const emb of entry.embeddings) {
        const score = cosineSimilarity(queryVec, emb);
        if (score > bestScore) bestScore = score;
      }
      if (bestScore > 0) {
        candidates.push({ toolName: entry.toolName, score: bestScore, entry });
      }
    }

    // 3. 排序取 topK
    candidates.sort((a, b) => b.score - a.score);
    const top = candidates.slice(0, this.config.topK);

    if (top.length === 0) {
      this.log.debug('route: no candidates', { input: input.slice(0, 50) });
      return null;
    }

    // 4. 动态阈值判定
    const threshold = this.getEffectiveThreshold();
    const best = top[0];

    if (best.score < threshold) {
      this.log.debug('route: below threshold', {
        input: input.slice(0, 50),
        bestScore: best.score.toFixed(3),
        threshold: threshold.toFixed(3),
      });
      this.recordScore(best.score);
      return null;
    }

    // 5. 命中 — 提取参数
    const toolDef = this.getToolDef(best.toolName);
    if (!toolDef) return null;

    const extractedArgs = this.extractArgs(input, best.toolName);
    const latencyMs = performance.now() - t0;

    // 6. 记录统计
    best.entry.hitCount++;
    best.entry.totalCount++;
    best.entry.recentScores.push(best.score);
    if (best.entry.recentScores.length > 50) best.entry.recentScores.shift();
    this.recordScore(best.score);

    this.log.info('route: matched', {
      input: input.slice(0, 50),
      tool: best.toolName,
      score: best.score.toFixed(3),
      threshold: threshold.toFixed(3),
      latencyMs: latencyMs.toFixed(1),
      hasArgs: extractedArgs !== null,
    });

    return {
      tool: toolDef,
      score: best.score,
      extractedArgs,
      source: 'semantic',
    };
  }

  // ── 动态阈值 ──

  private getEffectiveThreshold(): number {
    if (!this.config.adaptiveThreshold) return this.config.matchThreshold;

    // 基于历史分布：用 P25 作为阈值（更保守）
    if (this.scoreHistory.length < 50) return this.config.matchThreshold;

    const sorted = [...this.scoreHistory].sort((a, b) => a - b);
    const p25 = sorted[Math.floor(sorted.length * 0.25)];
    // 阈值不低于初始值的 80%，不高于 0.6
    return Math.max(this.config.matchThreshold * 0.8, Math.min(0.6, p25));
  }

  private recordScore(score: number): void {
    this.scoreHistory.push(score);
    if (this.scoreHistory.length > this.HISTORY_WINDOW) this.scoreHistory.shift();
  }

  // ── 参数提取 ──

  private extractArgs(input: string, toolName: string): Record<string, unknown> | null {
    // 优先使用 ArgExtractorRegistry（如果已注入）
    if (this.argExtractors) {
      const extractors = this.argExtractors.getByTool(toolName);
      for (const ext of extractors) {
        const args = ext.extract(input);
        if (args) return args;
      }
    }

    // 降级：通用参数提取
    return this.genericExtract(input, toolName);
  }

  /** 通用参数提取 — 无专用提取器时的兜底 */
  private genericExtract(input: string, toolName: string): Record<string, unknown> | null {
    // search_web / fetch_url: 整个输入作为 query
    if (toolName === 'search_web' || toolName === 'fetch_url') {
      return { query: input.trim() };
    }
    // read_file: 提取文件路径
    if (toolName === 'read_file' || toolName === 'read') {
      const fileMatch = input.match(/([\w/.\-~]+\.\w{1,5})\b/);
      if (fileMatch) return { file_path: fileMatch[1] };
    }
    // exec: 提取命令
    if (toolName === 'exec') {
      const cmdMatch = input.match(/(?:执行|运行|run|exec)\s+(.+)/i);
      if (cmdMatch) return { command: cmdMatch[1].trim() };
    }
    // 默认：整段输入作为 query
    return { query: input.trim() };
  }

  // ── Utterance 生成 ──

  /**
   * 从工具定义自动生成语义 utterance
   *
   * 策略：
   * 1. 工具描述（最核心）
   * 2. 工具名的自然语言变体
   * 3. 常见用户表达模式
   */
  private generateUtterances(tool: ToolDef): string[] {
    const utterances: string[] = [];
    const desc = tool.description ?? '';
    const name = tool.name;

    // 1. 描述直接用
    if (desc.length > 5) utterances.push(desc);

    // 2. 工具名 → 自然语言
    const nameVariants = this.nameToUtterances(name);
    utterances.push(...nameVariants);

    // 3. 基于工具类别的常见表达
    const categoryUtterances = this.getCategoryUtterances(name, desc);
    utterances.push(...categoryUtterances);

    // 去重 + 限制数量
    const unique = [...new Set(utterances)].filter(u => u.length > 3);
    return unique.slice(0, this.config.maxUtterancesPerTool);
  }

  /** 工具名 → 自然语言表达 */
  private nameToUtterances(name: string): string[] {
    const results: string[] = [];
    // search_web → "搜索网页" "网上搜索" "查一下"
    // fetch_url → "获取网页" "抓取链接" "打开网址"
    // git_status → "查看git状态" "git仓库情况"

    // snake_case → 中文动词+名词
    const parts = name.split('_');
    if (parts.length >= 2) {
      const verb = parts[0];
      const noun = parts.slice(1).join(' ');
      // 英文变体
      results.push(`${verb} ${noun}`);
      // 中文映射
      const zhVerb = this.verbToChinese(verb);
      const zhNoun = this.nounToChinese(noun);
      if (zhVerb && zhNoun) {
        results.push(`${zhVerb}${zhNoun}`);
        results.push(`帮我${zhVerb}${zhNoun}`);
        results.push(`${zhVerb}一下${zhNoun}`);
      }
    }

    return results;
  }

  /** 基于工具类别的常见用户表达 */
  private getCategoryUtterances(name: string, desc: string): string[] {
    const results: string[] = [];
    const lower = (name + ' ' + desc).toLowerCase();

    // 搜索类
    if (lower.includes('search') || lower.includes('搜索') || lower.includes('web')) {
      results.push('帮我查一下', '搜一下', '网上找找', '帮我搜');
    }
    // 文件类
    if (lower.includes('file') || lower.includes('文件') || lower.includes('read')) {
      results.push('看看这个文件', '读取文件', '打开文件');
    }
    // Git 类
    if (lower.includes('git')) {
      results.push('查看git', 'git操作', '版本控制');
    }
    // 信息查询类
    if (lower.includes('fetch') || lower.includes('获取') || lower.includes('url')) {
      results.push('打开这个链接', '看看这个网页', '获取网页内容');
    }
    // 天气类
    if (lower.includes('weather') || lower.includes('天气')) {
      results.push('今天天气怎么样', '查天气', '天气预报');
    }
    // 进程/系统类
    if (lower.includes('process') || lower.includes('进程') || lower.includes('system')) {
      results.push('系统状态', '查看进程', '运行状态');
    }

    return results;
  }

  // ── 辅助 ──

  private verbToChinese(verb: string): string {
    const map: Record<string, string> = {
      search: '搜索', fetch: '获取', read: '读取', write: '写入',
      get: '获取', check: '检查', list: '列出', create: '创建',
      delete: '删除', run: '运行', exec: '执行', find: '查找',
      analyze: '分析', scan: '扫描', open: '打开', send: '发送',
    };
    return map[verb.toLowerCase()] ?? verb;
  }

  private nounToChinese(noun: string): string {
    const map: Record<string, string> = {
      web: '网页', url: '链接', file: '文件', 'git': 'git',
      status: '状态', log: '日志', diff: '差异', branch: '分支',
      process: '进程', disk: '磁盘', port: '端口', weather: '天气',
      project: '项目', search: '搜索', info: '信息',
    };
    return map[noun.toLowerCase()] ?? noun;
  }

  private getToolDef(name: string): ToolDef | undefined {
    // 通过 ToolRegistry 引用获取
    return this.toolRegistry?.get(name);
  }

  // ── 依赖注入 ──

  private toolRegistry: ToolRegistry | null = null;
  private argExtractors: import('./arg-extractor.js').ArgExtractorRegistry | null = null;

  setToolRegistry(registry: ToolRegistry): void {
    this.toolRegistry = registry;
  }

  setArgExtractors(extractors: import('./arg-extractor.js').ArgExtractorRegistry): void {
    this.argExtractors = extractors;
  }

  // ── 统计 ──

  getStats(): {
    registeredTools: number;
    totalUtterances: number;
    hitRate: number;
    avgScore: number;
    currentThreshold: number;
  } {
    let totalUtterances = 0;
    let totalHits = 0;
    let totalRequests = 0;
    let scoreSum = 0;

    for (const entry of this.entries.values()) {
      totalUtterances += entry.embeddings.length;
      totalHits += entry.hitCount;
      totalRequests += entry.totalCount;
    }

    for (const s of this.scoreHistory) scoreSum += s;

    return {
      registeredTools: this.entries.size,
      totalUtterances,
      hitRate: totalRequests > 0 ? totalHits / totalRequests : 0,
      avgScore: this.scoreHistory.length > 0 ? scoreSum / this.scoreHistory.length : 0,
      currentThreshold: this.getEffectiveThreshold(),
    };
  }
}

// ==================== 工具函数 ====================

/** 余弦相似度（假设输入已 L2 归一化） */
function cosineSimilarity(a: Float32Array, b: Float32Array): number {
  let dot = 0;
  const len = Math.min(a.length, b.length);
  for (let i = 0; i < len; i++) dot += a[i] * b[i];
  return dot; // 已归一化，dot = cosine
}
```

### 3.2 CapabilityFallback — 正则未命中时的降级入口

```typescript
// src/brain/left/capability-fallback.ts

import type { TaskSignal, ResourceState, ExecutionPlan, IntuitionSignal, BodyState } from '../types.js';
import type { CapabilityRouter, RouteMatch } from '../../tools/capability-router.js';
import type { ArgExtractorRegistry } from './arg-extractor.js';
import { logger } from '../../audit/structured-logger.js';

export interface FallbackConfig {
  /** 是否启用 */
  enabled: boolean;
  /** 匹配结果缓存大小 */
  cacheSize: number;
}

interface FallbackRecord {
  input: string;
  matched: boolean;
  toolName?: string;
  score?: number;
  timestamp: number;
}

export class CapabilityFallback {
  private router: CapabilityRouter;
  private argExtractors: ArgExtractorRegistry;
  private config: FallbackConfig;
  private log = logger.child('CapabilityFallback');

  /** 匹配历史（用于调试和学习） */
  private history: FallbackRecord[] = [];

  constructor(
    router: CapabilityRouter,
    argExtractors: ArgExtractorRegistry,
    config?: Partial<FallbackConfig>,
  ) {
    this.router = router;
    this.argExtractors = argExtractors;
    this.config = { enabled: true, cacheSize: 100, ...config };
  }

  /**
   * 尝试语义路由 — 在 evaluateExecutableRule() 未命中后调用
   *
   * @returns ExecutionPlan 或 null（继续走原流程）
   */
  tryRoute(
    signal: TaskSignal,
    resources: ResourceState,
    intuition?: IntuitionSignal,
    body?: BodyState,
  ): { plan: ExecutionPlan; match: RouteMatch } | null {
    if (!this.config.enabled) return null;

    const content = signal.content ?? '';
    if (content.length < 3) return null;

    // 1. 语义匹配
    const match = this.router.route(content);
    if (!match) {
      this.history.push({ input: content.slice(0, 100), matched: false, timestamp: Date.now() });
      if (this.history.length > this.config.cacheSize) this.history.shift();
      return null;
    }

    // 2. 构建 ExecutablePlan
    const step = {
      id: 'capability_step_1',
      type: 'tool_call' as const,
      tool: match.tool.name,
      args: match.extractedArgs ?? { query: content.trim() },
      dependsOn: [],
      preferredExecutors: ['local' as const],
    };

    const plan: ExecutionPlan = {
      mode: 'local_only',
      reason: `能力路由: ${match.tool.name} (score=${match.score.toFixed(3)}, source=${match.source})`,
      selectedNodes: [{ id: 'auto', type: 'experience' as const }],
      confidence: match.score,
      source: 'capability_router',
      executablePlan: {
        steps: [step],
        expectedOutput: `${match.tool.name} 执行结果`,
        confidence: match.score,
        source: 'experience' as const,
        needsCloudEnhancement: false,
      },
    };

    // 3. 记录历史
    this.history.push({
      input: content.slice(0, 100),
      matched: true,
      toolName: match.tool.name,
      score: match.score,
      timestamp: Date.now(),
    });
    if (this.history.length > this.config.cacheSize) this.history.shift();

    // 4. 注册到 ResourceHub（如果可用）
    // 由 ThreeBrain 在调用后根据执行结果记录

    return { plan, match };
  }

  /** 获取匹配历史（调试用） */
  getHistory(): FallbackRecord[] {
    return [...this.history];
  }

  /** 获取命中率 */
  getHitRate(): { matched: number; total: number; rate: number } {
    const matched = this.history.filter(r => r.matched).length;
    const total = this.history.length;
    return { matched, total, rate: total > 0 ? matched / total : 0 };
  }
}
```

### 3.3 集成点 — ThreeBrain (brain.ts)

```typescript
// === brain.ts 改动（Step 2.4 之后插入） ===

// Step 2.4: 可执行规则快速通道（现有代码不变）
const executableRule = this.left.evaluateExecutableRule(signal, resources, intuition, bodyState);
if (executableRule) {
  // ... 现有逻辑不变 ...
}

// ─── Step 2.45: 能力路由（新增）───
if (this.capabilityFallback) {
  const capResult = this.capabilityFallback.tryRoute(signal, resources, intuition, bodyState);
  if (capResult) {
    if (this.verbose) {
      console.log(`[ThreeBrain] 能力路由命中: ${capResult.match.tool.name} (score=${capResult.match.score.toFixed(3)})`);
    }
    const ep = capResult.plan.executablePlan;
    if (ep) {
      const toolResult = await this.executeExecutablePlan(ep);
      if (toolResult) {
        const composed = await this.composeToolResult(input, toolResult, signal, intuition);
        // 记录到 ResourceHub（成功匹配 + 执行）
        this.recordCapabilityMatch(capResult.match, true);
        return {
          plan: capResult.plan,
          localGeneration: {
            text: composed.text,
            confidence: composed.confidence,
            templateId: 'capability_composed',
          },
          intuition, bodyState, homeostasisActions,
          latencyMs: performance.now() - t0,
        };
      }
      // 执行失败
      this.recordCapabilityMatch(capResult.match, false);
    }
  }
}

// Step 2.5: 审议委员会（现有代码不变）
```

### 3.4 集成点 — ToolRegistry (registry.ts)

```typescript
// === registry.ts 改动 ===

// 新增字段
private capabilityRouter: import('./capability-router.js').CapabilityRouter | null = null;

/** 注入 CapabilityRouter */
setCapabilityRouter(router: import('./capability-router.js').CapabilityRouter): void {
  this.capabilityRouter = router;
  // 同步已注册的工具
  for (const tool of this.tools.values()) {
    router.register(tool);
  }
}

// 修改 register() 方法
register(tool: ToolDef): void {
  const isNew = !this.tools.has(tool.name);
  this.tools.set(tool.name, tool);
  if (!this.usageCount.has(tool.name)) {
    this.usageCount.set(tool.name, 0);
  }
  // 现有: 通知监听器
  if (isNew) {
    for (const cb of this.registerCallbacks) {
      try { cb(tool); } catch { /* 不影响主流程 */ }
    }
    // 新增: 同步到 CapabilityRouter
    this.capabilityRouter?.register(tool);
  }
}

// 修改 unregister() 方法
unregister(name: string): boolean {
  const existed = this.tools.delete(name);
  if (existed) {
    this.usageCount.delete(name);
    for (const cb of this.unregisterCallbacks) {
      try { cb(name); } catch { /* 不影响主流程 */ }
    }
    // 新增: 从 CapabilityRouter 移除
    this.capabilityRouter?.unregister(name);
  }
  return existed;
}
```

### 3.5 集成点 — ResourceHub

```typescript
// === brain.ts 中记录路由结果到 ResourceHub ===

private recordCapabilityMatch(match: RouteMatch, success: boolean): void {
  const resourceId = `capability:${match.tool.name}`;

  // 如果 ResourceHub 中没有此工具的画像，注册一个
  if (!this.resourceHub.get(resourceId)) {
    this.resourceHub.register({
      id: resourceId,
      type: 'tool',
      name: `Capability:${match.tool.name}`,
      status: 'active',
      capabilities: {
        type: 'tool',
        toolName: match.tool.name,
        category: 'capability_routed',
        hasSideEffects: false,
        requiresConfirmation: false,
        avgLatencyMs: 0,
        parameters: [],
      },
      assessment: {
        capability: match.score,
        reliability: 0.5,
        speed: 0.9,  // 语义路由很快
        costEfficiency: 0.95, // 无 LLM 成本
        confidence: 0.3,  // 初始低置信
        suitableFor: [],
        notSuitableFor: [],
        updatedAt: Date.now(),
      },
    });
  }

  // 记录结果（ResourceHub.recordOutcome 内部做贝叶斯更新）
  this.resourceHub.recordOutcome(resourceId, {
    success,
    latencyMs: 0, // 由 executeExecutablePlan 记录
    timestamp: Date.now(),
  });
}
```

### 3.6 集成点 — BlendBrain 特征扩展

```typescript
// === feature-extractor.ts 改动 ===

// [172, 180) 预留区 → 能力路由信号

// 172: 能力路由最近一次是否命中 (0/1)
vec[172] = ctx.capabilityMatch?.hit ? 1 : 0;
// 173: 能力路由最近一次匹配分数
vec[173] = ctx.capabilityMatch?.score ?? 0;
// 174: 能力路由历史命中率
vec[174] = ctx.capabilityMatch?.hitRate ?? 0;
// 175-179: 预留
```

这需要在 `FeatureContext` 接口中新增：

```typescript
export interface FeatureContext {
  // ... 现有字段 ...
  /** 能力路由信号（新增） */
  capabilityMatch?: {
    hit: boolean;
    score: number;
    hitRate: number;
  };
}
```

### 3.7 集成点 — AssemblyEngine 检索源

```typescript
// === brain.ts registerAssemblySources() 中新增 ===

// ── 检索源 8: 能力路由（工具语义匹配） ──
this.right.registerAssemblySource('capability_tools', (query, topK) => {
  if (!this.capabilityRouter) return [];
  // 用 capabilityRouter 做工具匹配
  const match = this.capabilityRouter.route(query);
  if (!match) return [];
  return [{
    id: `capability:${match.tool.name}`,
    content: `[工具调用] ${match.tool.name}: ${match.tool.description ?? ''}\n参数: ${JSON.stringify(match.extractedArgs ?? {})}`,
    score: match.score,
    source: 'knowledge' as const,
  }];
});
```

---

## 四、与 LawClassifier 的关系

### 4.1 法则1 扩展

当前法则1（确定性执行）只检查正则 `ArgExtractor`：

```typescript
// law-classifier.ts 现有逻辑
private tryDeterministic(content: string, signal: TaskSignal): LawClassification | null {
  const extractors = this.argExtractors.getAll();
  for (const ext of extractors) {
    const args = ext.extract(content);
    if (args) {
      return {
        lawId: 'deterministic',
        confidence: 0.95,
        reason: `正则确定性: ${ext.toolName}`,
        matchedRule: ext.id,
        extractedArgs: args,
      };
    }
  }
  return null;
}
```

**扩展方案**：法则1 增加语义路径

```typescript
private tryDeterministic(content: string, signal: TaskSignal): LawClassification | null {
  // 1. 正则路径（现有，不变）
  const extractors = this.argExtractors.getAll();
  for (const ext of extractors) {
    const args = ext.extract(content);
    if (args) {
      return {
        lawId: 'deterministic',
        confidence: 0.95,
        reason: `正则确定性: ${ext.toolName}`,
        matchedRule: ext.id,
        extractedArgs: args,
      };
    }
  }

  // 2. 语义路径（新增）
  if (this.capabilityRouter) {
    const match = this.capabilityRouter.route(content);
    if (match && match.score > 0.5) { // 法则1 用更高阈值
      return {
        lawId: 'deterministic',
        confidence: match.score,
        reason: `语义确定性: ${match.tool.name} (score=${match.score.toFixed(3)})`,
        extractedArgs: match.extractedArgs ?? undefined,
      };
    }
  }

  return null;
}
```

---

## 五、无 LLM 场景 — 组装引擎 + 碰撞引擎全能力释放

> **核心认知转变**：组装引擎不是"格式化器"，它是**信息整合引擎**（四层管线：字典→语义→组装→篇法）。
> 碰撞引擎不是"排列组合"，它是**候选方案工厂**（四种策略：穷举/随机/语义引导/变异）。
> 把它们从"工具输出的后处理器"提升为"信息处理的主引擎"，可以从根本上解决一大类不需要 LLM 的任务。

### 5.0 组装引擎完整能力图谱

当前 `AssemblyBridge` (v4) 把组装引擎降级为"纯格式化器"，但 `InformationIntegrationEngine` 实际有完整的四层管线：

```
Layer 1: 字典层
  ├── ByteEncoder 编码 (256维, ~3ms)
  ├── 问题分解 (tryDecompose: 并列连接词/句号分割)
  └── 意图分类 (classifyIntent: 5类关键词匹配)

Layer 2: 语义层
  ├── 7+ 检索源并发 (knowledge/prototypes/decision_memory/file_index/tool_output/code_templates/web)
  ├── GraphExpand 知识图谱多跳扩展 (maxHops=2, hopDecay=0.6)
  ├── Reranker 四维重排序 (相关度×新鲜度×权威度×推理链)
  └── 分层控制: 本地优先 → 质量评估 → 网络升级 → 换词重试

Layer 3: 组装层
  ├── ContentSelector 去重(阈值0.9) + 角色标注(6种) + 来源多样性
  ├── FragmentExtractor 关键句提取 + 工具输出解析(8种模式) + 代码签名摘要
  ├── CombinatorialGenerator 候选工厂 (穷举/随机/语义引导/变异)
  ├── RelevanceEvaluator 三维评分 (语义0.6 + 关键词0.25 + 意图0.15)
  ├── MultiSentenceSkeleton 多句骨架 (按意图×复杂度选择模板)
  └── ConnectorInsertor 连接词插入 (风格适配)

Layer 4: 篇法层
  ├── ParagraphPlanner 段落规划
  ├── DiscourseChain 逻辑排序 (问题→背景→方案→细节)
  ├── ReferringExpr 指代消解
  └── DocumentTypeDetector 5种文档框架 (paper/article/code_doc/report/general)
```

**已有但未充分利用的组件**：

| 组件 | 能力 | 当前使用 | 可扩展到 |
|------|------|---------|---------|
| `FragmentExtractor.extractFromToolOutput()` | 解析错误/路径/数值/状态码/URL/版本/退出码/PID | 仅格式化 | 工具输出深度解读 |
| `tryDecompose()` | 按连接词/句号分解子问题 | 仅 process() 内部 | 问题分解+子任务编排 |
| `DocumentTypeDetector` | 5种文档框架 (paper/article/code_doc/report/general) | 仅长文路径 | 所有结构化输出 |
| `GraphExpand` | 知识图谱多跳扩展 | 仅 retrieve() 内部 | 知识发现+因果推理 |
| `ExtractivePreprocessor` | 关键段落筛选 (5维评分) | 仅长文路径 | 所有信息聚合 |
| `MapReduceProcessor` | 长文分块并行处理 | 仅长文路径 | 大规模数据处理 |
| `postAssemblyHook` | 组装完成后知识持久化 | 已有 | 自我增强循环 |
| `CombinatorialGenerator.guided` | ByteEncoder 语义引导每个槽位 | 已有 | 候选工具调用方案生成 |

### 5.1 场景一：多源信息聚合（"采编发"工作流）

**当前问题**：`search_web` 返回 10 条结果，直接丢给 LLM 总结。

**组装引擎能做的**：

```
输入: "最近 AI 领域有什么大新闻"

CapabilityRouter → search_web + fetch_url (多工具)
  ↓
search_web("AI 大新闻") → 10 条结果
fetch_url(前3条 URL) → 详细内容
  ↓
组装引擎 retrieve():
  ├── 本地源: KnowledgeGate (已有知识) + DecisionMemoryR (历史对话)
  ├── 网络源: search_web 结果 + fetch_url 内容 + RSS 订阅
  └── 分层控制: 本地质量足够(≥0.6) → 直接用; 不够 → 网络升级
  ↓
ContentSelector: 去重(阈值0.9) + 角色标注(context/detail) + 来源多样性(≥3源)
FragmentExtractor: 提取关键句(每段取 top-2 相关句)
GraphExpand: "AI" → "大模型" → "GPT-5" → "OpenAI" 多跳扩展
Reranker: 相关度×新鲜度×权威度×推理链 四维重排序
  ↓
DiscourseChain: 按 问题→背景→要点→影响 排序
MultiSentenceSkeleton: "news_medium" 模板
ConnectorInsertor: "此外"、"值得注意的是"、"与此同时"
  ↓
输出: 结构化新闻简报 (无 LLM，纯组装)
```

**关键差异**：不是"搜索→返回结果"，而是"多源采集→去重→提取→排序→结构化输出"。**这是新闻编辑部的工作流，不是搜索引擎的工作流。**

### 5.2 场景二：工具输出深度解读（提取→解释→关联）

**当前问题**：`git diff` 返回 200 行输出，直接贴给用户。

**FragmentExtractor 已有的 8 种解析模式**：

| 模式 | 正则 | 示例 |
|------|------|------|
| 错误信息 | `error\|Error\|ERROR\|错误` | `Error: ENOENT: no such file` |
| 文件路径 | `(?:\/[\w.-]+)+\.\w+` | `/src/main.ts` |
| 数值指标 | `(\d+(?:\.\d+)?)\s*(ms\|s\|KB\|MB\|GB\|bytes\|%)` | `123ms`, `45MB` |
| HTTP 状态码 | `\b([1-5]\d{2})\b` | `200`, `404`, `500` |
| URL | `https?://[^\s"']+` | `https://api.github.com` |
| 版本号 | `v?\d+\.\d+(?:\.\d+)?` | `v1.2.3` |
| 退出码 | `exit(?:ed)?\s*(?:code\s*)?(\d+)` | `exit code 1` |
| 进程 ID | `pid[：:\s]*(\d+)` | `pid: 12345` |

**完整流程**：

```
输入: "看看最近改了什么"

CapabilityRouter → git diff + git log
  ↓
FragmentExtractor.extractFromToolOutput():
  提取: 文件路径、变更行数、新增/删除标记、commit message、author
  ↓
ContentSelector: 按文件分组，每组取关键变更
GraphExpand: 变更文件 → 关联测试文件 → 关联文档
  ↓
MultiSentenceSkeleton: "code_medium" 模板
  problem: "本次变更涉及 N 个文件"
  detail: "主要修改: xxx.ts (核心逻辑), yyy.ts (接口)"
  solution: "建议检查: zzz.test.ts (关联测试)"
  ↓
输出: 结构化变更报告 (无 LLM)
```

### 5.3 场景三：问题分解 + 子问题独立组装（"分治"策略）

**组装引擎已有的 `tryDecompose()`**：

```typescript
const SPLIT_CONJUNCTIONS = ['并', '并且', '和', '以及', '同时', '然后', '接着'];
const sentences = input.split(/[。；;]/); // 按句号/分号分割
```

**完整流程**：

```
输入: "看看这个项目的代码质量，然后查下最近的 commit，再看看有没有 TODO 没处理"

tryDecompose() 分解:
  子问题1: "看看这个项目的代码质量" → CapabilityRouter → skill_lint_check
  子问题2: "查下最近的 commit" → CapabilityRouter → git log
  子问题3: "看看有没有 TODO 没处理" → CapabilityRouter → search_files("TODO")

每个子问题独立走:
  CapabilityRouter → 工具执行 → FragmentExtractor → ContentSelector
  ↓
processDecomposed() 合并:
  ConnectorInsertor: "首先"、"其次"、"另外"
  DiscourseChain: 按逻辑排序
  ReferringExpr: 指代消解 ("该项目" → 项目名)
  ↓
输出: 三段结构化报告 (无 LLM)
```

**这已经是一个完整的 DAG 编排——不需要 LLM 规划，组装引擎的 `processDecomposed()` 已经实现了这个流程。**

### 5.4 场景四：结构化报告生成（5 种文档框架）

**`DocumentTypeDetector` 已有的框架**：

| 类型 | 框架结构 | 连接词 | 适用场景 |
|------|---------|--------|---------|
| `paper` | 目的→方法→结果→结论→意义 | "为此"/"结果发现"/"因此" | 学术论文解读 |
| `article` | 核心观点→论点→论据→结论 | "具体来说"/"举例"/"总之" | 博客/文章总结 |
| `code_doc` | 接口→用法→示例→注意事项 | "使用方法"/"例如"/"注意" | 代码文档生成 |
| `report` | 背景→数据→分析→建议 | "数据显示"/"分析表明"/"建议" | 数据分析报告 |
| `general` | 通用 | — | 默认 |

**完整流程**：

```
输入: "帮我分析下这个项目的依赖安全问题"

CapabilityRouter → scan_project + dependency_audit
  ↓
DocumentTypeDetector → "report" 框架
  ↓
ExtractivePreprocessor: 从依赖列表中筛选关键依赖 (5维评分)
MapReduce: 大型依赖列表分块处理
  ↓
框架组装:
  【背景】项目依赖 N 个包，其中 M 个有已知漏洞
  【数据】高危: xxx@1.2.3 (CVE-...), 中危: yyy@2.0.0
  【分析】主要风险集中在 xxx 生态，yyy 的问题已在新版修复
  【建议】优先升级 xxx 到 3.x，yyy 到 2.1+
  ↓
输出: 结构化安全报告 (无 LLM)
```

### 5.5 场景五：碰撞引擎 — 候选方案工厂

`CombinatorialGenerator` 的四种生成策略不只是"排列组合"，它是**候选答案工厂**：

| 策略 | 机制 | 适用场景 | 关键能力 |
|------|------|---------|---------|
| `exhaustive` | 穷举所有组合 (early pruning) | 小规模原子集 (<200 组合) | 保证不遗漏 |
| `random` | 随机采样 | 大规模原子集 | 快速探索 |
| `guided` | ByteEncoder 在每个槽位选最相关的原子 | **语义引导生成** | 理解意图 |
| `mutate` | 从成功候选微调 | 迭代优化 | 持续改进 |

**`guided` 策略的关键应用**——生成候选工具调用方案：

```
AtomDictionary:
  动作原子: [查询, 搜索, 获取, 检查, 分析, ...]
  实体原子: [文件, 代码, 依赖, 进程, 端口, ...]
  修饰原子: [最新, 所有, 详细, 简要, ...]

SlotTemplate: "{动作}{实体}的{修饰}信息"

输入: "查一下所有依赖的详细信息"

guided 策略:
  槽位1(动作): ByteEncoder 匹配 → "查询" (score=0.82)
  槽位2(实体): ByteEncoder 匹配 → "依赖" (score=0.91)
  槽位3(修饰): ByteEncoder 匹配 → "详细" (score=0.78)

生成: "查询依赖的详细信息"
  → 匹配工具: dependency_audit
  → 参数: { detail: true }
```

**碰撞引擎不只是生成候选句子，它可以生成候选工具调用方案。**

### 5.6 场景六：知识图谱多跳推理（GraphExpand 因果链）

**当前问题**：用户问"函数慢"，只匹配到直接相关的文档。

**GraphExpand 已有的能力**：

```
初检: "函数慢" → 命中 "性能问题" (score=0.7)
  ↓ GraphExpand (maxHops=2, hopDecay=0.6)
1跳: 性能问题 --causes--> 嵌套循环 (score=0.7×0.6=0.42)
1跳: 性能问题 --causes--> 内存泄漏 (score=0.7×0.6=0.42)
2跳: 嵌套循环 --solved_by--> 哈希表 (score=0.42×0.6=0.25)
2跳: 内存泄漏 --solved_by--> 对象池 (score=0.42×0.6=0.25)
  ↓
最终组装:
  "函数性能问题，可能原因是嵌套循环或内存泄漏。
   建议：用哈希表替代嵌套循环，或使用对象池减少内存分配。"
```

**关键**：这不需要 LLM 做推理，图谱结构本身就编码了因果/解决方案关系。

**可扩展场景**：

| 初检命中 | 1跳扩展 | 2跳扩展 | 最终输出 |
|---------|---------|---------|---------|
| "编译报错" | → 类型不匹配 --causes--> | → 接口变更 --solved_by--> 更新调用 | "接口变更导致类型不匹配，需更新调用方式" |
| "测试失败" | → 断言错误 --causes--> | → 数据格式变化 --solved_by--> 更新 mock | "数据格式变化导致断言失败，需更新 mock 数据" |
| "部署失败" | → 端口占用 --causes--> | → 旧进程未退出 --solved_by--> kill 进程 | "端口被旧进程占用，需先 kill 再部署" |

### 5.7 场景七：跨语言信息检索（TranslateConnector + 组装）

**API Gateway 已有 `TranslateConnector`** (DeepL 免费 50 万字符/月)：

```
输入: "最新的 transformer 架构论文有什么突破"

CapabilityRouter → search_web("transformer architecture 2025")
  ↓ search_web 返回英文结果
TranslateConnector.fetch({ type: 'translate', target: '...' })
  ↓ 翻译关键片段
ContentSelector: 去重 + 角色标注
FragmentExtractor: 提取关键结论
  ↓
DocumentTypeDetector → "paper" 框架
  ↓
组装: "2025年 Transformer 架构的主要突破包括：
  【目的】解决 xxx 问题
  【方法】提出 yyy 架构
  【结果】效率提升 40%
  【结论】该方向值得关注"
```

### 5.8 场景八：追问的智能化（不只是"你想查什么"）

**组装引擎已有的追问机制**：

```typescript
const DIMENSION_PATTERNS = {
  what: ['什么', '哪些', '哪个'],
  why:  ['为什么', '原因'],
  how:  ['怎么', '如何', '怎样'],
  where: ['哪里', '在哪'],
  when:  ['什么时候', '何时'],
  who:   ['谁'],
};
```

**智能追问流程**：

```
输入: "帮我查一下"

当前: 无正则命中 → 追问 "你想查什么？" (太泛)
  ↓
CapabilityRouter: 语义分数 0.25 (低于阈值)
  ↓
组装引擎追问增强:
  1. 检测缺失维度: what, how 都缺失
  2. 检查 TaskContext: 用户最近在看代码 → 推断 "代码相关"
  3. 检查 BodyState: 用户情绪 frustrated → 简化追问
  ↓
输出: "你是想查代码问题，还是查其他信息？" (更精准)
```

### 5.9 场景九：对比分析（双实体并行检索 + 框架组装）

```
输入: "React 和 Vue 哪个更适合我们的项目"

tryDecompose() 分解:
  子问题1: "React 适合什么场景"
  子问题2: "Vue 适合什么场景"
  ↓
子问题1: search_web("React 优势 场景") + KnowledgeGate → 片段集1
子问题2: search_web("Vue 优势 场景") + KnowledgeGate → 片段集2
  ↓
ContentSelector: 选择对比维度 (性能/生态/学习曲线/团队经验)
RelevanceEvaluator: 三维评分 (语义0.6 + 关键词0.25 + 意图0.15)
  ↓
DocumentTypeDetector → "report" 框架
  ↓
框架组装:
  【背景】项目需求: ...
  【数据】React: ... / Vue: ...
  【分析】基于团队经验，...
  【建议】建议选择 ...
```

### 5.10 场景十：增量知识积累（postAssemblyHook 自我增强循环）

**组装引擎已有 `postAssemblyHook`**：

```typescript
// 组装完成后回调 — 将网络数据灌入持久化存储
this.postAssemblyHook(input, candidates);
```

**自我增强循环**：

```
第 1 次: search_web("AI 新闻") → 10 条结果 → 组装输出 → hook 持久化到 KnowledgeGate
第 2 次: search_web("AI 新闻") → 10 条新结果 + KnowledgeGate 已有知识 → 更丰富的组装
第 3 次: 知识积累足够 → 本地源质量≥0.6 → 跳过网络搜索 → 更快的响应
```

**每次使用都在增强知识库**：
- 网络搜索结果 → KnowledgeGate (下次检索更快)
- 工具执行结果 → ToolOutputCache (避免重复调用)
- 成功的组装模式 → DecisionMemoryR (学习怎么组装)
- 成功的工具调用 → ExperienceGraph (学习怎么调用工具)

### 5.11 场景十一：大规模文档处理（MapReduce + 提取式预处理）

**已有但未充分利用的管线**：

```
输入: 一个 50 页的技术文档

ExtractivePreprocessor (5维评分):
  ├── 结构标记: 标题/摘要/结论 → 必选
  ├── 关键词密度: 与查询相关度高的段落 → 优先
  ├── 位置权重: 开头/结尾段 → 加权
  ├── 信息密度: 数据/引用/代码密集 → 加权
  └── 噪声过滤: 纯列表/参考文献/页眉页脚 → 跳过
  ↓
筛选后: 50页 → 15个关键段落
  ↓
MapReduceProcessor: 分块 → 每块独立走 retrieve + assemble → 合并
  ↓
DocumentTypeDetector → "report" 框架
  ↓
输出: 结构化文档摘要 (无 LLM)
```

### 5.12 场景十二：代码理解（签名提取 + 模板组装）

**`FragmentExtractor` 已有的代码解析**：

```typescript
extractCodeSignatures(code: string): CodeSummary {
  // 提取: 函数名、参数列表、返回类型
  // 支持: TypeScript/JavaScript/Python
}
```

**`CodeTemplateStore` 已有的模板匹配**：

```
输入: "这个函数是干什么的"

CapabilityRouter → read_file + analyze_file
  ↓
FragmentExtractor.extractCodeSignatures():
  name: "processOrder"
  params: ["order: Order", "user: User"]
  returns: "Promise<Result>"
  ↓
CodeTemplateStore.search(): 匹配到 "数据处理" 模板
  ↓
MultiSentenceSkeleton: "code_doc" 框架
  【接口】processOrder(order: Order, user: User) → Promise<Result>
  【用法】处理用户订单，验证权限后执行
  【示例】const result = await processOrder(order, user)
  【注意】需要 user 有 order:write 权限
```

### 5.13 无 LLM 场景完整能力矩阵

| 场景 | CapabilityRouter | 组装引擎 | 碰撞引擎 | GraphExpand | DocumentType | MapReduce | 复杂度 |
|------|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
| 简单工具调用 | ✅ | — | — | — | — | — | 低 |
| 工具输出解读 | ✅ | ✅ | — | — | — | — | 低 |
| 多源信息聚合 | ✅ | ✅ | — | — | — | — | 中 |
| 问题分解+子任务 | ✅ | ✅ | — | — | — | — | 中 |
| 结构化报告 | ✅ | ✅ | — | — | ✅ | — | 中 |
| 知识图谱推理 | — | ✅ | — | ✅ | — | — | 中 |
| 候选方案生成 | — | — | ✅ | — | — | — | 中 |
| 对比分析 | ✅ | ✅ | — | — | ✅ | — | 中 |
| 跨语言检索 | ✅ | ✅ | — | — | — | — | 中 |
| 大规模文档 | — | ✅ | — | — | ✅ | ✅ | 高 |
| 代码理解 | ✅ | ✅ | — | — | ✅ | — | 中 |
| 智能追问 | — | ✅ | — | — | — | — | 低 |
| 多工具 DAG | ✅ | ✅ | ✅ | — | — | — | 高 |
| 知识积累循环 | ✅ | ✅ | — | — | — | — | 持续 |

### 5.14 CapabilityRouter 多工具匹配

支持 `routeAll()` 返回多个匹配工具，交给组装引擎做多工具编排：

```typescript
routeAll(input: string, maxTools: number = 3): RouteMatch[] {
  const queryVec = l2Normalize(this.encoder.forward(input));
  const candidates: Array<{ toolName: string; score: number }> = [];

  for (const entry of this.entries.values()) {
    let bestScore = 0;
    for (const emb of entry.embeddings) {
      const score = cosineSimilarity(queryVec, emb);
      if (score > bestScore) bestScore = score;
    }
    if (bestScore > this.getEffectiveThreshold()) {
      candidates.push({ toolName: entry.toolName, score: bestScore });
    }
  }

  candidates.sort((a, b) => b.score - a.score);
  return candidates.slice(0, maxTools).map(c => ({
    tool: this.getToolDef(c.toolName)!,
    score: c.score,
    extractedArgs: this.extractArgs(input, c.toolName),
    source: 'semantic' as const,
  })).filter(m => m.tool);
}
```

### 5.15 总体架构：从"格式化器"到"信息处理主引擎"

```
┌──────────────────────────────────────────────────────────────┐
│                    当前使用方式 (AssemblyBridge v4)            │
│                                                              │
│  工具输出 → 组装引擎格式化 → 输出                              │
│  (只用了 Layer 3 的一小部分)                                   │
├──────────────────────────────────────────────────────────────┤
│                    应该使用方式 (全管线释放)                     │
│                                                              │
│  用户输入                                                     │
│    ↓                                                          │
│  CapabilityRouter (语义匹配工具)                               │
│    ↓                                                          │
│  工具执行 → 多源结果                                           │
│    ↓                                                          │
│  组装引擎全管线:                                               │
│    Layer 1: ByteEncoder 编码 + 问题分解 + 意图分类              │
│    Layer 2: 7源并发检索 + GraphExpand + Reranker               │
│    Layer 3: ContentSelector + FragmentExtractor + 骨架填充     │
│    Layer 4: ParagraphPlanner + DiscourseChain + 指代消解       │
│    ↓                                                          │
│  碰撞引擎: 候选工厂 (guided/mutate 策略)                       │
│    ↓                                                          │
│  DocumentTypeDetector → 框架化输出                             │
│    ↓                                                          │
│  postAssemblyHook → 知识持久化 (自我增强循环)                   │
│    ↓                                                          │
│  结构化输出 (无 LLM)                                           │
└──────────────────────────────────────────────────────────────┘
```

---

## 六、反馈学习闭环

### 6.1 四层反馈

```
执行结果
  │
  ├─→ ResourceHub.recordOutcome()     — 资源画像贝叶斯更新
  ├─→ CapabilityRouter.recordScore()  — 动态阈值自适应
  ├─→ BlendBrain.feedback()           — REINFORCE 策略梯度
  └─→ DecisionMemory.record()         — 经验图谱积累
```

### 6.2 动态阈值演化

```
初始: threshold = 0.40 (保守)
  ↓ 积累 50+ 匹配记录
自适应: threshold = max(0.32, P25(scores))
  ↓ 匹配分布稳定后
收敛: threshold ≈ 0.38 (典型值)
```

### 6.3 工具画像演化

```
注册时: capability=0.5, reliability=0.5, confidence=0.1
  ↓ 首次成功匹配
capability=0.6, reliability=0.6, confidence=0.3
  ↓ 连续 10 次成功
capability=0.8, reliability=0.85, confidence=0.7
  ↓ 3 次失败
capability=0.65, reliability=0.7, confidence=0.6 (贝叶斯衰减)
```

---

## 七、性能预算

| 操作 | 耗时 | 触发条件 |
|------|------|---------|
| ByteEncoder.forward() | ~3ms | 每次路由 |
| cosineSimilarity × N 工具 | ~0.1ms × N | 每次路由 |
| ArgExtractor.extract() | <0.1ms | 命中时 |
| L2 normalize | <0.1ms | 每次路由 |
| **路由总延迟** | **~5ms** | **仅正则未命中时** |
| register() 预编码 | ~3ms × M 条 utterance | 工具注册时（一次性） |

**对比**：
- LLM 调用：500ms-3000ms
- 审议委员会：50-200ms
- BlendBrain 调度：10-50ms

能力路由增加的 5ms 延迟 **仅在正则未命中时发生**，相比 LLM 调用节省 99% 时间。

---

## 八、执行计划

### Phase 0: 基础设施（1-2天）

| 任务 | 文件 | 工作量 |
|------|------|--------|
| 创建 `CapabilityRouter` 类 | `src/tools/capability-router.ts` | 核心 |
| 创建 `CapabilityFallback` 类 | `src/brain/left/capability-fallback.ts` | 核心 |
| 单元测试 | `src/tools/capability-router.test.ts` | 验证 |
| 单元测试 | `src/brain/left/capability-fallback.test.ts` | 验证 |

### Phase 1: 集成（1天）

| 任务 | 文件 | 改动量 |
|------|------|--------|
| ToolRegistry 接入 | `src/tools/registry.ts` | ~15行 |
| ThreeBrain Step 2.45 | `src/brain/brain.ts` | ~30行 |
| CapabilityRouter 初始化 | `src/brain/brain.ts` 构造函数 | ~10行 |
| ArgExtractor 注入 | `src/brain/brain.ts` | ~5行 |

### Phase 2: 反馈闭环（1天）

| 任务 | 文件 | 改动量 |
|------|------|--------|
| ResourceHub 记录 | `src/brain/brain.ts` | ~20行 |
| BlendBrain 特征扩展 | `src/brain/hub/feature-extractor.ts` | ~10行 |
| FeatureContext 扩展 | `src/brain/hub/feature-extractor.ts` | ~5行 |

### Phase 3: 增强（1-2天）

| 任务 | 文件 | 改动量 |
|------|------|--------|
| LawClassifier 法则1 语义扩展 | `src/brain/left/law-classifier.ts` | ~15行 |
| AssemblyEngine 检索源注册 | `src/brain/brain.ts` | ~10行 |
| 多工具匹配 routeAll() | `src/tools/capability-router.ts` | ~30行 |
| DAG 编排集成 | `src/brain/brain.ts` | ~20行 |

### Phase 4: 测试与调优（1天）

| 任务 | 工作量 |
|------|--------|
| 集成测试：正则命中 → 行为不变 | 验证 |
| 集成测试：语义命中 → 正确执行 | 验证 |
| 集成测试：低分 → 走原流程 | 验证 |
| 阈值调优：收集 100+ 样本 → 分析分布 | 调优 |
| 性能测试：确认 <10ms 额外延迟 | 验证 |

### 总计：4-6 天

---

## 九、风险与缓解

| 风险 | 概率 | 影响 | 缓解 |
|------|------|------|------|
| ByteEncoder 区分度不足 | 中 | 误触发 | 初始高阈值 + 动态自适应 |
| 误触发执行危险工具 | 低 | 高 | 工具权限检查 + 高危操作确认（复用现有机制） |
| 与现有规则冲突 | 低 | 中 | Step 2.45 在规则引擎之后，不会抢先 |
| 性能回退 | 极低 | 低 | 仅正则未命中时触发，~5ms |
| 参数提取不准 | 中 | 中 | ArgExtractor 已有 30+ 提取器 + 通用降级 |

---

## 十、未来扩展

### 10.1 自动 Utterance 学习

从成功执行的对话中自动提取 utterance 模式：

```
用户: "帮我查查最近的科技新闻" → search_web 成功
→ 自动新增 utterance: "查查最近的科技新闻" 到 search_web 条目
```

### 10.2 跨工具协作学习

当 CapabilityRouter 匹配到工具 A 但执行失败，最终由工具 B 成功时：

```
→ 降低工具 A 的画像分数
→ 提升工具 B 的画像分数
→ 记录 "A→B" 的降级路径
```

### 10.3 用户个性化

不同用户的表达习惯不同，CapabilityRouter 可以基于用户历史微调阈值：

```
用户 A 经常说 "查一下" → search_web
用户 B 经常说 "帮我搜" → search_web
→ 各自维护个性化 utterance 列表
```

### 10.4 与 ShadowBrain 的协同

影子大脑的 gap-detector 检测到 "工具匹配失败" 时：

```
→ 触发 CapabilityRouter 的 utterance 扩展
→ 或触发新规则推导（RuleDerivationEngine）
```
