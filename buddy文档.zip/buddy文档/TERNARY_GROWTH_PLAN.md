# 三进制模型自然生长机制 — 执行计划

> 创建日期：2026-05-31
> 状态：Phase 1-5 已完成 ✅
> 关联文档：ARCHITECTURE_ROADMAP.md, ARCHITECTURE.md, src/ternary/
> 核心原理：矩阵定义天花板，知识填充地板。三进制 {-1,0,1} 天然支持稀疏生长与叠加合并。

---

## 一、设计原理

### 1.1 三进制的天然生长性

三进制权重 {-1, 0, 1} 中，**0 是"未学习"的标记**。模型创建时所有权重为零，训练驱动 latent 全精度权重偏离零值，越过阈值后激活为 ±1。

```
创建:  [0, 0, 0, 0, 0, 0, 0, 0]  ← 空壳，容量已分配，知识为零
训练:  [0, 0, 1, 0,-1, 0, 0, 1]  ← 部分权重被激活
继续:  [1,-1, 1, 0,-1, 1,-1, 1]  ← 有效容量接近满载
```

**模型大小只跟学到的知识有关，无底洞，潜力无限。**

### 1.2 叠加合并机制

.ta 文件不能原地 resize，但三进制支持**逐元素叠加**：

```
base:    [-1, 0, 1, 0, 0, 1,-1, 0]
overlay: [ 0, 1, 0, 0,-1, 0, 0, 1]
merged:  [-1, 1, 1, 0,-1, 1,-1, 1]  ← 仍是 {-1,0,1}
```

叠加规则：非零覆盖零，同值保持，冲突时取新值。

### 1.3 生长生命周期

```
seed → sprout → growing → trainable → mature
  ↓        ↓         ↓          ↓         ↓
零权重   少量激活   活跃填充   深度学习   稳定/冻结

容量不够时:
mature → 创建更大 .ta → 迁移旧知识 → 继续生长
```

---

## 二、现状分析

### 2.1 已实现

| 组件 | 文件 | 状态 |
|------|------|------|
| 三进制格式 (.ta) | format.ts, codec.ts | ✅ 完整 |
| 推理引擎 | engine.ts | ✅ 可用 |
| 增量训练器 (t-SignSGD) | t-signsgd.ts, trainer.ts | ✅ 可用 |
| 成长阶段管理 | growth.ts | ✅ 可用 |
| 蒸馏管线 | distill.ts, distill-prep.ts | ✅ 可用 |
| 训练调度器 | scheduler.ts | ✅ 可用 |
| 容器热插拔 | container.ts | ✅ 可用 |
| 专家经验训练 | exp-head.ts, exp-bridge.ts | ✅ 可用 |

### 2.2 缺失（本计划要实现的）

| 缺失 | 影响 | 优先级 |
|------|------|--------|
| OutputProj 未训练 | hidden→vocab 映射随机，生成永远为空 | P0 |
| 无容量监控 | 不知道何时需要创建更大的 .ta | P1 |
| 无叠加合并机制 | 新知识无法叠加到 base 模型 | P1 |
| 无自动层扩展 | 容量满载时无法自动升级 | P2 |
| 模型创建默认太小 | 初始天花板太低 | P2 |

---

## 三、执行计划

### Phase 1: OutputProj 联合训练 (P0) ✅

**目标**：让 outputProj 参与训练，使 hidden state 能映射到词表，实现真正的 token 生成。

**改动文件**：`src/ternary/trainer.ts`

**已完成**：
- computeOutputGradient 新增 outputProj 梯度计算（数值稳定化）
- trainBatch 新加 outputProj SGD 更新（isFinite 守卫）
- 247 测试全通过

**核心逻辑**：

```
当前 trainBatch():
  embedding → projIn → LoRA layers → projOut → hidden
  loss = crossEntropy(hidden, targetId)  ← 只算 LoRA 梯度

改后 trainBatch():
  embedding → projIn → LoRA layers → projOut → hidden
  logits = outputProj @ hidden
  loss = crossEntropy(logits, targetId)
  ∂L/∂outputProj → 更新 outputProj  ← 新增
  ∂L/∂hidden → 反向传播到 LoRA layers ← 已有
```

**具体步骤**：

1. 在 `TernaryTrainer` 中添加 `outputProj` 的梯度计算
2. `computeCrossEntropy` 改为返回 `dOutputProj` 梯度
3. `trainBatch` 末尾用 SGD 更新 outputProj 的相关行
4. 采样负例策略保持不变（15 个负样本近似 softmax）

**验收标准**：
- 训练后 outputProj 不再是初始值
- `generate()` 输出非空文本
- loss 持续下降

**预估工时**：1 天

---

### Phase 2: 容量监控器 (P1) ✅

**目标**：检测当前模型权重激活率，判断是否需要创建更大的 .ta。

**新增文件**：`src/ternary/capacity-monitor.ts`

**已完成**：
- 激活率检测（非零权重/总权重）
- loss 趋势分析（滑动窗口对比）
- 扩容建议（rank > layers > features 优先级）

**核心指标**：

```typescript
interface CapacityMetrics {
  /** 权重激活率: 非零权重 / 总权重 */
  activationRate: number;       // 0~1
  /** 各层激活率 */
  layerActivationRates: number[];
  /** latent 权重分布: 距离阈值的平均距离 */
  latentMeanAbs: number;
  /** 训练 loss 趋势: 最近 N 步的 loss 变化率 */
  lossTrend: number;            // 正=上升, 负=下降, 0=平稳
  /** 建议: 是否需要扩容 */
  needsExpansion: boolean;
  /** 建议: 扩容目标架构 */
  suggestedArchitecture?: string;
}
```

**判断逻辑**：

```
IF activationRate > 0.8 AND lossTrend >= 0:
  → 权重快满了，loss 不再下降
  → 建议创建更大架构

IF activationRate < 0.3:
  → 还有大量空间
  → 建议继续训练

IF lossTrend < -0.01:
  → loss 还在下降
  → 不要打断训练
```

**具体步骤**：

1. 新建 `capacity-monitor.ts`
2. 实现 `analyze(model: TernaryModel): CapacityMetrics`
3. 在 `TernaryScheduler.checkAndTrain()` 中调用分析
4. 暴露 `onCapacityFull` 回调

**验收标准**：
- 能准确计算激活率
- 能检测 loss 趋势
- 给出合理的扩容建议

**预估工时**：0.5 天

---

### Phase 3: 叠加合并机制 (P1) ✅

**目标**：实现 base + overlay → merged 的三进制叠加合并。

**新增文件**：`src/ternary/overlay.ts`

**已完成**：
- 创建全零 overlay 模型
- 运行时叠加推理（不修改原文件）
- 持久化合并（含统计：base贡献/overlay贡献/冲突数）
- 三进制叠加规则：非零覆盖零，冲突按策略

**核心接口**：

```typescript
/** 叠加合并配置 */
interface OverlayConfig {
  /** 冲突策略: base优先 / overlay优先 / 取绝对值大的 */
  conflictStrategy: 'base' | 'overlay' | 'stronger';
  /** 合并后是否自动保存 */
  autoSave: boolean;
}

/** 叠加合并器 */
class TernaryOverlay {
  /** 创建 overlay 模型（与 base 同维度，全零） */
  createOverlay(base: TernaryModel): TernaryModel;

  /** 运行时叠加推理: base + overlay → 临时合并权重 */
  mergeForInference(base: TernaryLayer, overlay: TernaryLayer): {
    A: Int8Array; B: Int8Array;
  };

  /** 持久化合并: base + overlay → 新的 merged .ta */
  mergePersistent(base: TernaryModel, overlay: TernaryModel): TernaryModel;

  /** 检查两个模型是否可合并（维度匹配） */
  canMerge(a: TernaryModel, b: TernaryModel): boolean;
}
```

**叠加规则**：

```
base[i]  overlay[i]  merged[i]
  0        ±1          ±1       ← overlay 填充空位
  ±1        0          ±1       ← base 保持
  ±1       ±1(同)      ±1       ← 同值保持
  ±1       ±1(异)      ±1       ← overlay 优先 (或 stronger 策略取绝对值大的)
```

**具体步骤**：

1. 新建 `overlay.ts`
2. 实现 `mergeForInference`（运行时叠加，不修改文件）
3. 实现 `mergePersistent`（合并为新 .ta）
4. 在 `TernaryEngine.loadFromModel` 中支持 base + overlay 双模型加载
5. 在 `TernaryContainer.loadDomain` 中支持 overlay 文件自动检测

**验收标准**：
- 两个同维度 .ta 可以叠加合并
- 合并后推理结果正确
- 合并后的 .ta 体积合理

**预估工时**：1 天

---

### Phase 4: 自动层扩展 (P2) ✅

**目标**：容量满载时自动创建更大的 .ta，迁移旧知识。

**新增文件**：`src/ternary/expansion.ts`

**已完成**：
- rank 扩展（4→8→16→32→64）
- 层扩展（+4 层，零初始化）
- 维度扩展（384→768→1536→4096）
- 旧权重复制，新权重零填充

**核心流程**：

```
容量监控器检测到 activationRate > 0.8
  ↓
expansion.ts 决定扩展策略:
  - rank 扩展: rank 8 → 16 (增加 LoRA 秩)
  - 层扩展:   6 层 → 12 层 (增加 Transformer 层)
  - 维度扩展: 384 → 768 (增加 hidden size)
  ↓
创建新 .ta (更大维度，零初始化)
  ↓
迁移旧权重:
  - 同维度部分: 直接复制
  - 新增部分: 零初始化 (等待训练填充)
  ↓
新模型接管，旧模型归档
```

**扩展策略选择**：

```typescript
function selectExpansionStrategy(metrics: CapacityMetrics, current: TernaryModelMeta) {
  // 优先扩 rank (成本最低，效果最直接)
  if (current.rank < 32) {
    return { type: 'rank', newRank: current.rank * 2 };
  }
  // 其次加层
  if (current.numLayers < 24) {
    return { type: 'layers', newLayers: current.numLayers + 2 };
  }
  // 最后扩维度
  return { type: 'features', newFeatures: Math.min(current.inFeatures * 2, 2048) };
}
```

**具体步骤**：

1. 新建 `expansion.ts`
2. 实现 `expandModel(model, strategy): TernaryModel`
3. 实现权重迁移（同维度复制，新维度零填充）
4. 更新 `manager.ts` 的 `create()` 支持更大预设
5. 集成到 `scheduler.ts` 的训练循环中

**验收标准**：
- 扩展后旧知识保留
- 新维度为零，等待训练填充
- 扩展后的 .ta 可正常加载推理

**预估工时**：1.5 天

---

### Phase 5: 集成与端到端验证 (P2) ✅

**目标**：将所有组件串联，验证完整的生长闭环。

**已完成**：
- scheduler.ts 集成容量监控 + 自动扩展
- container.ts 支持 overlay 自动检测与合并
- growth-e2e.test.ts 5 个端到端测试全通过
- 247 测试全通过

**集成点**：

```
用户对话
  ↓
ExperienceCompiler → 训练样本
  ↓
TernaryScheduler.checkAndTrain()
  ├── CapacityMonitor.analyze() → 检查激活率
  ├── IF needsExpansion → Expansion.expandModel()
  ├── TernaryTrainer.train() → 含 outputProj 联合训练
  └── IF overlay模式 → Overlay.mergePersistent()
  ↓
模型生长，能力提升
```

**端到端测试场景**：

1. **基础生成**：灌装 QA 数据 → 训练 → 验证 generate() 输出有意义文本
2. **叠加学习**：base 模型 + 新知识 overlay → 推理验证
3. **容量扩展**：小模型训练至满载 → 自动扩展 → 继续训练
4. **成长阶段**：seed → sprout → growing → trainable → mature 完整流转

**验收标准**：
- 完整闭环可跑通
- 模型能力随训练提升
- 扩展过程无知识丢失

**预估工时**：1 天

---

## 四、文件清单

### 新增文件

| 文件 | 用途 | Phase |
|------|------|-------|
| `src/ternary/capacity-monitor.ts` | 容量监控器 | 2 |
| `src/ternary/overlay.ts` | 叠加合并器 | 3 |
| `src/ternary/expansion.ts` | 自动层扩展 | 4 |
| `src/ternary/growth-e2e.test.ts` | 端到端生长测试 | 5 |

### 修改文件

| 文件 | 改动 | Phase |
|------|------|-------|
| `src/ternary/trainer.ts` | outputProj 联合训练 | 1 |
| `src/ternary/scheduler.ts` | 集成容量监控 + 自动扩展 | 2, 4 |
| `src/ternary/container.ts` | 支持 overlay 加载 | 3 |
| `src/ternary/engine.ts` | 支持 base+overlay 双模型推理 | 3 |
| `src/ternary/manager.ts` | 支持更大预设 + overlay 管理 | 4 |

---

## 五、时间线

```
Day 1:  Phase 1 — OutputProj 联合训练
Day 2:  Phase 2 — 容量监控器 + Phase 3 — 叠加合并（并行）
Day 3:  Phase 3 完成 + Phase 4 — 自动层扩展
Day 4:  Phase 5 — 集成验证 + 修复
Day 5:  文档更新 + 代码审查
```

总计：5 个工作日

---

## 六、风险与缓解

| 风险 | 影响 | 缓解 |
|------|------|------|
| outputProj 训练梯度不稳定 | NaN/爆炸 | 梯度裁剪 + 学习率调度 |
| 叠加合并产生冲突权重 | 推理质量下降 | conflictStrategy 可配置 |
| 扩展后旧知识退化 | 回归 | A/B 对比 + 回滚机制 |
| 大模型推理速度慢 | 用户体验 | 三进制天然快速，2-bit 打包 |

---

## 七、附录：关键设计决策

### Q1: 为什么不用原地 resize？
.ta 是二进制格式 + SHA-256 校验，无法原地修改。叠加合并是更好的方案：
- 不破坏已有文件
- 支持多层 overlay（知识分层）
- 合并时可以做冲突检测

### Q2: 为什么不直接训练大模型？
可以。但三进制的优势是**大矩阵零初始化成本极低**：
- 2-bit 打包，1B 参数只占 250MB
- 零权重不参与计算，推理跳过
- 训练只激活需要的部分

### Q3: overlay 合并时冲突怎么办？
默认策略是 overlay 优先（新知识覆盖旧知识）。
可选策略：
- `base`: 旧知识优先，新知识只填空位
- `stronger`: 取绝对值大的（训练步数多的更可靠）
- `overlay`: 新知识总是覆盖

### Q4: 容量监控的阈值怎么定？
初始阈值 80% 激活率。后续可通过 ShadowBrain 自学习调整：
- 某些领域可能 50% 就够用
- 某些领域可能需要 95% 才饱和
- 元认知系统自动优化阈值
