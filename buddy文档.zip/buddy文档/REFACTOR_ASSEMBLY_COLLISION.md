# 碰撞引擎 × 组装引擎 改造方案

> 目标：采集→编辑→发送 三层职责明确，引擎可控制、可预期

---

## 一、现状问题诊断

### 1.1 工具结果被重复处理

**文件**：`brain/brain.ts` L1413-1441

```
工具已执行 → toolProposal 存在
→ processWithAssemblyCompetitive 仍然并行执行
→ 组装引擎重新做一轮多源检索
→ 裁决器从"工具结果格式化"和"组装引擎重新检索"中选一个
```

**问题**：工具已经拿到了答案，组装引擎又回去检索了一遍，两个结果竞争裁决。

### 1.2 碰撞引擎被隔离在工具链路之外

**文件**：`intelligence/knowledge-node.ts` L8-14

```typescript
export type KnowledgeSource =
  | 'web' | 'stmp' | 'experience' | 'ternary'
  | 'conversation' | 'file' | 'knowledge_graph';
// 缺少 'tool' 来源类型
```

**文件**：`intelligence/collision-engine.ts` — 碰撞引擎只在 `ExperienceRouter.routeAsync()` 中被调用

**问题**：工具结果没有被转化为 KnowledgeNode，碰撞引擎完全不知道工具输出的存在。

### 1.3 组装引擎职责过载

**文件**：`brain/right/features/integration-engine.ts`

组装引擎 `InformationIntegrationEngine.process()` 做了所有事：
- 意图分类（L467）
- ByteEncoder 编码（L470）
- 问题分解（L473）
- **多源检索**（L499 `retrieve()`）
- 内容选择（L517）
- 片段提取（L518）
- 骨架生成
- 连接词插入
- 段落规划
- 篇法链

**问题**：组装引擎既是"采集层"又是"编辑层"又是"发送层"，职责不清。

### 1.4 碰撞引擎缺少语义锚点

**文件**：`intelligence/collision-engine.ts` L148-149

```typescript
const concepts = [...new Set([...a.concepts, ...b.concepts])]; // 合并空数组还是空
```

**问题**：`KnowledgeNode.concepts` 在实际数据中基本为空（`fromWeb`、`fromConversation`、`fromFiles` 都没填 concepts），碰撞在向量空间里盲撞。

### 1.5 两个引擎的检索重复

**组装引擎**注册了 10+ 检索源（brain.ts L425-745）：
- knowledge, prototypes, decision_memory, file_index, tool_output, code_templates, stmp, capability_tools, web_*, api_*, headless, rss

**碰撞引擎**的 KnowledgeConvergence 也做检索（knowledge-convergence.ts L99-118）：
- experience, ternary, stmp, web, conversation, file

两套检索系统各跑各的，数据不互通。

---

## 二、改造架构：采集 → 编辑 → 发送

```
┌─────────────────────────────────────────────────────────────┐
│                      三脑决策层                               │
│  意图识别 → 资源选择 → 路由决策                               │
└────────────────────────┬────────────────────────────────────┘
                         │ 意图 + 数据源选择
                         ▼
┌─────────────────────────────────────────────────────────────┐
│                    ① 采集层 (Collection)                      │
│                                                             │
│  工具执行 ──→ ToolResultStructuralizer ──→ KnowledgeNode[]  │
│  网页检索 ──→ WebResultStructuralizer ──→ KnowledgeNode[]  │
│  记忆检索 ──→ MemoryStructuralizer   ──→ KnowledgeNode[]  │
│  经验匹配 ──→ ExperienceStructuralizer→ KnowledgeNode[]  │
│  三进制   ──→ TernaryStructuralizer  ──→ KnowledgeNode[]  │
│                                                             │
│  职责：拿数据，结构化为统一的 KnowledgeNode                   │
│  不做的事：不评分、不排序、不判断质量                          │
└────────────────────────┬────────────────────────────────────┘
                         │ KnowledgeNode[]
                         ▼
┌─────────────────────────────────────────────────────────────┐
│                    ② 编辑层 (Editing)                        │
│                                                             │
│  碰撞引擎 CollisionEngine                                   │
│  ├─ 输入：KnowledgeNode[] + 意图                             │
│  ├─ 操作：                                                   │
│  │   ├─ 合并(fusion)：相似知识去重合并                        │
│  │   ├─ 互补(complement)：不同来源拼出完整画面                 │
│  │   ├─ 冲突(conflict)：矛盾标记 + 可信度排序                  │
│  │   └─ 涌现(emergence)：新组合（但必须对用户有价值）           │
│  └─ 输出：EditedKnowledge（融合结果 + 操作记录）               │
│                                                             │
│  职责：对采集结果做信息加工                                    │
│  不做的事：不格式化文本、不做检索                              │
└────────────────────────┬────────────────────────────────────┘
                         │ EditedKnowledge
                         ▼
┌─────────────────────────────────────────────────────────────┐
│                    ③ 发送层 (Sending)                        │
│                                                             │
│  组装引擎 AssemblyEngine                                    │
│  ├─ 输入：EditedKnowledge + 意图                             │
│  ├─ 操作：                                                   │
│  │   ├─ 汇报：工具结果 → 按用户关心的维度组织                  │
│  │   ├─ 解释：冲突标记 → 人话说明差异                         │
│  │   ├─ 建议：涌现组合 → 人话表达建议                         │
│  │   └─ 确认：操作执行 → 人话告知结果                         │
│  └─ 输出：自然语言文本                                       │
│                                                             │
│  职责：把加工结果格式化为人话                                  │
│  不做的事：不做检索、不做碰撞判断                              │
└─────────────────────────────────────────────────────────────┘
```

---

## 三、详细改造步骤

### Step 1：扩展 KnowledgeSource 类型，接入工具结果

**文件**：`src/intelligence/knowledge-node.ts`

```typescript
// 改造前
export type KnowledgeSource =
  | 'web' | 'stmp' | 'experience' | 'ternary'
  | 'conversation' | 'file' | 'knowledge_graph';

// 改造后
export type KnowledgeSource =
  | 'tool'           // 新增：工具执行结果
  | 'web' | 'stmp' | 'experience' | 'ternary'
  | 'conversation' | 'file' | 'knowledge_graph';
```

**新增字段**：

```typescript
export interface KnowledgeNode {
  // ... 现有字段 ...

  /** 操作类型 — 编辑层用 */
  operationType?: 'query' | 'execute' | 'search' | 'compute';

  /** 原始结构化数据 — 工具 JSON 结果保留原始结构 */
  structuredData?: Record<string, unknown>;

  /** 可信度来源 — 标记这个置信度是怎么来的 */
  confidenceSource?: 'tool_return' | 'web_score' | 'experience_stats' | 'ternary_prediction' | 'memory_importance';
}
```

### Step 2：新建 ToolResultStructuralizer — 工具结果 → KnowledgeNode

**新文件**：`src/intelligence/tool-result-structuralizer.ts`

```typescript
/**
 * 工具结果结构化器 — 采集层组件
 *
 * 职责：将工具返回的 JSON/文本转为 KnowledgeNode
 * 不做的事：不评分、不排序、不格式化
 */
export class ToolResultStructuralizer {

  /**
   * 工具结果 → KnowledgeNode[]
   *
   * @param toolName 工具名称
   * @param toolOutput 工具原始输出（JSON 字符串或纯文本）
   * @param args 工具调用参数
   * @param vectorizer 向量化函数
   */
  structuralize(
    toolName: string,
    toolOutput: string,
    args: Record<string, unknown>,
    vectorizer: (text: string) => Float32Array,
  ): KnowledgeNode[] {
    const nodes: KnowledgeNode[] = [];

    // 1. JSON 结构化 → 提取关键字段为独立节点
    try {
      const data = JSON.parse(toolOutput);
      const extracted = this.extractStructured(toolName, data);
      for (const item of extracted) {
        nodes.push({
          id: `tool:${toolName}:${item.key}`,
          source: 'tool',
          vector: vectorizer(item.content),
          content: item.content,
          concepts: item.concepts,
          confidence: 1.0, // 工具结果的置信度 = 1（事实）
          confidenceSource: 'tool_return',
          operationType: this.inferOperationType(toolName),
          structuredData: item.data,
          metadata: { toolName, args, field: item.key },
        });
      }
    } catch {
      // 非 JSON → 整体作为一个节点
      nodes.push({
        id: `tool:${toolName}:raw`,
        source: 'tool',
        vector: vectorizer(toolOutput),
        content: toolOutput,
        concepts: this.extractConcepts(toolName, toolOutput),
        confidence: 1.0,
        confidenceSource: 'tool_return',
        operationType: this.inferOperationType(toolName),
        metadata: { toolName, args },
      });
    }

    return nodes;
  }

  /**
   * 从 JSON 结构中提取关键信息
   *
   * 不同工具有不同的结构，这里做适配：
   * - search_web → 每条结果一个节点
   * - read_file → 文件内容一个节点
   * - exec → stdout + stderr 各一个节点
   * - git_status → 每个变更文件一个节点
   */
  private extractStructured(
    toolName: string,
    data: unknown,
  ): Array<{ key: string; content: string; concepts: string[]; data?: unknown }> {
    // ... 按工具类型适配 ...
  }

  /**
   * 从工具名和输出中提取概念标签
   *
   * 这是碰撞引擎的语义锚点，不能是空的
   */
  private extractConcepts(toolName: string, output: string): string[] {
    const concepts: string[] = [];
    // 工具名本身就是概念
    concepts.push(toolName);
    // 从输出中提取关键词
    const keywords = output.match(/[\u4e00-\u9fff]{2,}|[a-zA-Z_]\w{2,}/g) ?? [];
    concepts.push(...keywords.slice(0, 5));
    return [...new Set(concepts)];
  }

  /**
   * 推断操作类型
   */
  private inferOperationType(toolName: string): KnowledgeNode['operationType'] {
    if (toolName.includes('search') || toolName.includes('web')) return 'search';
    if (toolName.includes('read') || toolName.includes('get') || toolName.includes('list')) return 'query';
    if (toolName.includes('exec') || toolName.includes('run') || toolName.includes('write')) return 'execute';
    return 'compute';
  }
}
```

### Step 3：改造碰撞引擎 — 有意图的信息编辑

**文件**：`src/intelligence/collision-engine.ts`

**3a. 新增编辑意图类型**：

```typescript
/** 编辑意图 — 碰撞引擎的操作由意图驱动 */
export type EditIntent =
  | 'merge'       // 合并：多个来源说了同一件事 → 去重保留最完整
  | 'complement'  // 互补：A 缺的信息 B 有 → 拼出完整画面
  | 'resolve'     // 解冲突：A 和 B 矛盾 → 标记 + 判断可信度
  | 'synthesize'; // 综合：多源信息需要整合为统一回答

/** 编辑结果 — 每个操作都有记录 */
export interface EditResult {
  /** 编辑操作类型 */
  intent: EditIntent;
  /** 参与的知识节点 */
  participants: KnowledgeNode[];
  /** 编辑后的输出 */
  output: EditedKnowledge;
  /** 操作说明 — 人可读的"我做了什么" */
  explanation: string;
  /** 操作是否成功 */
  success: boolean;
}

export interface EditedKnowledge {
  /** 融合后的文本 */
  content: string;
  /** 融合后的向量 */
  vector: Float32Array;
  /** 保留的概念标签 */
  concepts: string[];
  /** 综合置信度 */
  confidence: number;
  /** 如果有冲突，标记冲突信息 */
  conflicts?: Array<{
    nodeA: KnowledgeNode;
    nodeB: KnowledgeNode;
    reason: string;
    resolution?: 'a_preferred' | 'b_preferred' | 'both_valid' | 'needs_user_input';
  }>;
  /** 如果有涌现，标记新组合 */
  emergent?: {
    description: string;
    valueForUser: string;
  };
  /** 来源信息 */
  sources: KnowledgeSource[];
}
```

**3b. 改造 collide 方法**：

```typescript
// 改造前：碰撞对生成 → 向量相似度 → 自动选类型
collide(nodes: KnowledgeNode[], inputVector: Float32Array): CollisionResult[]

// 改造后：意图驱动的编辑
edit(nodes: KnowledgeNode[], intent: EditIntent, userGoal?: string): EditResult[]
```

**3c. 按意图选择操作**：

```typescript
edit(nodes: KnowledgeNode[], intent: EditIntent, userGoal?: string): EditResult[] {
  switch (intent) {
    case 'merge':
      return this.mergeDuplicates(nodes);
    case 'complement':
      return this.complementGaps(nodes, userGoal);
    case 'resolve':
      return this.resolveConflicts(nodes);
    case 'synthesize':
      return this.synthesizeMultiSource(nodes, userGoal);
  }
}

/**
 * 合并：相同来源或高度相似的节点去重
 *
 * 触发条件：同来源的多个节点，或余弦相似度 > 0.85 的跨来源节点
 * 操作：保留内容最完整的，合并概念标签
 */
private mergeDuplicates(nodes: KnowledgeNode[]): EditResult[] {
  // 按来源分组
  const bySource = new Map<KnowledgeSource, KnowledgeNode[]>();
  for (const node of nodes) {
    const group = bySource.get(node.source) ?? [];
    group.push(node);
    bySource.set(node.source, group);
  }

  const results: EditResult[] = [];
  for (const [source, group] of bySource) {
    if (group.length <= 1) {
      // 单节点不需要合并，直接透传
      results.push({
        intent: 'merge',
        participants: group,
        output: this.nodeToEdited(group[0]),
        explanation: `${source} 来源只有 1 条结果，无需合并`,
        success: true,
      });
      continue;
    }

    // 多节点 → 找相似的合并
    const merged = this.mergeGroup(group);
    results.push(merged);
  }

  return results;
}

/**
 * 互补：不同来源的信息拼出完整画面
 *
 * 触发条件：来自不同来源的节点，内容不重叠但相关
 * 操作：拼接各来源的独特信息
 */
private complementGaps(nodes: KnowledgeNode[], userGoal?: string): EditResult[] {
  // 按来源分组
  const bySource = new Map<KnowledgeSource, KnowledgeNode[]>();
  for (const node of nodes) {
    const group = bySource.get(node.source) ?? [];
    group.push(node);
    bySource.set(node.source, group);
  }

  // 每个来源取最相关的 1-2 个节点
  const representative: KnowledgeNode[] = [];
  for (const [, group] of bySource) {
    const sorted = group.sort((a, b) => b.confidence - a.confidence);
    representative.push(...sorted.slice(0, 2));
  }

  if (representative.length <= 1) {
    return [{
      intent: 'complement',
      participants: representative,
      output: this.nodeToEdited(representative[0]),
      explanation: '只有一个来源，无需互补',
      success: true,
    }];
  }

  // 检查重叠度 — 低重叠才需要互补
  const overlaps = this.findOverlaps(representative);
  const lowOverlap = overlaps.filter(o => o.similarity < 0.6);

  if (lowOverlap.length === 0) {
    // 高重叠 → 走合并路径
    return this.mergeDuplicates(nodes);
  }

  // 互补拼接
  const complemented = this.buildComplement(representative, lowOverlap, userGoal);
  return [complemented];
}

/**
 * 解冲突：标记矛盾 + 判断可信度
 *
 * 触发条件：不同来源的节点在关键事实上矛盾
 * 操作：标记冲突，按可信度排序，必要时需要用户判断
 */
private resolveConflicts(nodes: KnowledgeNode[]): EditResult[] {
  const conflicts = this.detectConflicts(nodes);

  if (conflicts.length === 0) {
    return [{
      intent: 'resolve',
      participants: nodes,
      output: this.synthesizeNodes(nodes),
      explanation: '未检测到冲突',
      success: true,
    }];
  }

  // 按可信度排序解决冲突
  const resolutions = conflicts.map(conflict => ({
    ...conflict,
    resolution: this.resolveByCredibility(conflict),
  }));

  // 如果有无法自动解决的冲突，标记需要用户输入
  const needsUser = resolutions.filter(r => r.resolution === 'needs_user_input');

  return [{
    intent: 'resolve',
    participants: nodes,
    output: {
      ...this.synthesizeNodes(nodes),
      conflicts: resolutions,
    },
    explanation: needsUser.length > 0
      ? `检测到 ${conflicts.length} 个冲突，其中 ${needsUser.length} 个需要你判断`
      : `检测到 ${conflicts.length} 个冲突，已按可信度排序`,
    success: true,
  }];
}

/**
 * 综合：多源信息整合为统一回答
 *
 * 这是最常见的意图 — 用户问了一个问题，多个来源有不同角度的回答
 * 操作：选最相关的 → 补充其他来源的独特信息 → 标记不确定的部分
 */
private synthesizeMultiSource(nodes: KnowledgeNode[], userGoal?: string): EditResult[] {
  // 1. 按与用户目标的相关度排序
  const ranked = userGoal
    ? this.rankByRelevance(nodes, userGoal)
    : nodes.sort((a, b) => b.confidence - a.confidence);

  // 2. 取最相关的作为主体
  const primary = ranked[0];
  const others = ranked.slice(1);

  // 3. 从其他来源提取主体没有的信息
  const supplements = this.extractUniqueInfo(primary, others);

  // 4. 组装
  const synthesized = this.assembleSynthesis(primary, supplements, userGoal);

  return [{
    intent: 'synthesize',
    participants: ranked,
    output: synthesized,
    explanation: `综合 ${nodes.length} 个来源（${[...new Set(nodes.map(n => n.source))].join('+')}）`,
    success: true,
  }];
}
```

### Step 4：改造组装引擎 — 纯发送终端

**文件**：`src/brain/right/features/assembly-bridge.ts`

**4a. 移除检索职责**：

```typescript
// 改造前：组装引擎自己做检索
export class AssemblyBridge {
  private engine: InformationIntegrationEngine; // 内含 10+ 检索源
  async process(input: string): Promise<AssemblyResult> { ... }
}

// 改造后：组装引擎只接收已编辑的数据
export class AssemblyBridge {

  /**
   * 核心方法：将编辑结果格式化为自然语言
   *
   * @param edited 碰撞引擎的编辑结果
   * @param intent 用户意图（决定输出风格：汇报/解释/建议/确认）
   * @param context 上下文（情绪、风格偏好等）
   */
  formatEdited(
    edited: EditedKnowledge,
    intent: OutputIntent,
    context?: OutputContext,
  ): AssemblyResult {
    switch (intent) {
      case 'report':
        return this.formatReport(edited, context);
      case 'explain':
        return this.formatExplain(edited, context);
      case 'suggest':
        return this.formatSuggest(edited, context);
      case 'confirm':
        return this.formatConfirm(edited, context);
    }
  }

  /**
   * 直接格式化工具结果（跳过碰撞引擎的快速路径）
   *
   * 当只有一个工具结果、不需要碰撞时使用
   */
  formatToolResult(
    toolName: string,
    toolOutput: string,
    intent: OutputIntent,
    template?: { template: string; fields: Record<string, string> },
  ): AssemblyResult {
    // 模板填充
    if (template) {
      const filled = this.fillTemplate(template, toolOutput);
      if (filled && filled !== toolOutput) {
        return { text: filled, confidence: 0.9, path: 'template' };
      }
    }

    // JSON → 人话
    const formatted = this.tryFormatJson(toolOutput);
    if (formatted) {
      return { text: formatted, confidence: 0.7, path: 'format' };
    }

    // 已是可读文本
    if (this.isReadableText(toolOutput)) {
      return { text: toolOutput, confidence: 0.5, path: 'passthrough' };
    }

    // 格式化失败
    return { text: toolOutput, confidence: 0.3, path: 'raw' };
  }
}

/** 输出意图 */
export type OutputIntent =
  | 'report'    // 汇报：工具返回了数据 → 按维度组织
  | 'explain'   // 解释：碰撞标记了冲突 → 说明差异
  | 'suggest'   // 建议：碰撞涌现了新组合 → 表达建议
  | 'confirm';  // 确认：工具执行了操作 → 告知结果
```

**4b. 保留 InformationIntegrationEngine 但降级为"编辑工具"**：

```typescript
// InformationIntegrationEngine 不删除，但不再作为组装引擎的核心
// 它降级为一个"片段编辑工具"，在需要时被碰撞引擎调用

// 组装引擎不再持有 InformationIntegrationEngine
// 而是碰撞引擎在需要"片段拼装"时调用它的子模块：
// - ContentSelector：选择最相关的片段
// - MultiSentenceSkeleton：骨架生成
// - ConnectorInsertor：连接词插入
// - ParagraphPlanner：段落规划
```

### Step 5：改造 KnowledgeConvergence — 统一采集层

**文件**：`src/intelligence/knowledge-convergence.ts`

**5a. 新增工具结果采集**：

```typescript
export class KnowledgeConvergence {
  // ... 现有依赖 ...

  /** 工具结果结构化器 */
  private toolStructuralizer: ToolResultStructuralizer;

  /**
   * 改造后的 converge — 包含工具结果
   */
  async converge(
    input: string,
    contextTags: string[] = [],
    toolResults?: Array<{ name: string; output: string; args: Record<string, unknown> }>,
  ): Promise<KnowledgeNode[]> {
    const nodes: KnowledgeNode[] = [];

    // 工具结果优先（置信度最高）
    if (toolResults && toolResults.length > 0) {
      for (const tr of toolResults) {
        nodes.push(...this.toolStructuralizer.structuralize(
          tr.name, tr.output, tr.args, (t) => this.vectorize(t),
        ));
      }
    }

    // 其他来源并行采集
    const sources: Promise<KnowledgeNode[]>[] = [
      this.fromExperience(input, contextTags),
      this.fromTernary(input),
      this.fromSTMP(input),
    ];
    // ... web, conversation, files ...

    const results = await Promise.allSettled(sources);
    for (const result of results) {
      if (result.status === 'fulfilled') nodes.push(...result.value);
    }

    // 统一向量化
    for (const node of nodes) {
      if (!node.vector || node.vector.every(v => v === 0)) {
        node.vector = this.vectorize(node.content);
      }
    }

    return nodes;
  }
}
```

### Step 6：改造 brain.ts 主流程

**文件**：`src/brain/brain.ts`

**6a. 改造 decide() 中的工具结果处理**：

```typescript
// 改造前（L1413-1441）：
// 有 toolProposal 时，组装引擎仍然并行跑完整管线
const hasAssembly = isAssemblyPipelineTask || !!toolProposal || ...;
if (hasAssembly) {
  parallelTasks.push(this.processWithAssemblyCompetitive(...)); // ← 重复检索
}

// 改造后：
// 有 toolProposal 时，只做格式化，不跑完整管线
if (toolProposal) {
  // 快速路径：工具结果 → 结构化 → 碰撞引擎判断是否需要多源 → 格式化输出
  const toolKnowledge = this.toolStructuralizer.structuralize(
    toolProposal.toolName,
    toolProposal.toolResult.toolCalls[0]?.result ?? '',
    toolProposal.toolResult.toolCalls[0]?.args as Record<string, unknown> ?? {},
    (t) => this.knowledgeConvergence.vectorize(t),
  );

  // 判断是否需要多源碰撞
  const needsCollision = this.shouldCollide(toolKnowledge, signal);

  if (needsCollision) {
    // 需要碰撞：采集其他来源 → 碰撞引擎编辑 → 组装引擎格式化
    const allNodes = await this.knowledgeConvergence.converge(
      input, signal.domains, [{ name: toolProposal.toolName, output: toolProposal.toolResult.toolCalls[0]?.result ?? '', args: toolProposal.toolResult.toolCalls[0]?.args as Record<string, unknown> ?? {} }],
    );
    const editResults = this.collisionEngine.edit(allNodes, 'synthesize', input);
    const bestEdit = editResults[0];
    localGeneration = {
      text: this.assemblyBridge.formatEdited(bestEdit.output, this.inferOutputIntent(signal)).text,
      confidence: bestEdit.output.confidence,
      templateId: `collision_${bestEdit.intent}`,
    };
  } else {
    // 不需要碰撞：工具结果直接格式化
    const formatted = this.assemblyBridge.formatToolResult(
      toolProposal.toolName,
      toolProposal.toolResult.toolCalls[0]?.result ?? '',
      this.inferOutputIntent(signal),
    );
    localGeneration = {
      text: formatted.text,
      confidence: formatted.confidence,
      templateId: `tool_direct_${toolProposal.toolName}`,
    };
  }
}

/**
 * 判断工具结果是否需要多源碰撞
 *
 * 不需要碰撞的情况：
 * - 工具返回了完整的、可直接格式化的数据
 * - 工具是查询类（read_file, get_time），结果是确定的
 * - 用户只是要执行结果（exec, write_file）
 *
 * 需要碰撞的情况：
 * - 工具结果不完整，需要其他来源补充
 * - 工具结果可能有矛盾，需要验证
 * - 用户问题需要综合多个角度回答
 */
private shouldCollide(toolNodes: KnowledgeNode[], signal: TaskSignal): boolean {
  // 单工具、查询类、结果完整 → 不需要碰撞
  if (toolNodes.length === 1 && toolNodes[0].operationType === 'query') return false;
  if (toolNodes.length === 1 && toolNodes[0].operationType === 'execute') return false;

  // 复杂任务、需要推理 → 可能需要碰撞
  if (signal.complexity === 'complex') return true;

  // 工具结果很短或质量低 → 需要其他来源补充
  if (toolNodes.some(n => n.content.length < 50)) return true;

  return false;
}
```

**6b. 改造无工具时的处理**：

```typescript
// 无工具、纯知识查询时：
// 采集 → 碰撞 → 组装

if (!toolProposal && !isAssemblyPipelineTask) {
  const allNodes = await this.knowledgeConvergence.converge(input, signal.domains);

  if (allNodes.length >= 2) {
    // 多源 → 碰撞引擎编辑
    const editResults = this.collisionEngine.edit(allNodes, 'synthesize', input);
    const bestEdit = editResults[0];
    localGeneration = {
      text: this.assemblyBridge.formatEdited(bestEdit.output, 'report').text,
      confidence: bestEdit.output.confidence,
      templateId: 'collision_synthesize',
    };
  } else if (allNodes.length === 1) {
    // 单源 → 直接格式化
    localGeneration = {
      text: this.assemblyBridge.formatEdited(this.nodeToEdited(allNodes[0]), 'report').text,
      confidence: allNodes[0].confidence,
      templateId: 'single_source',
    };
  }
  // 0 源 → 走 LLM
}
```

### Step 7：改造 ExperienceRouter — 碰撞引擎接入路由

**文件**：`src/intelligence/experience-router.ts`

```typescript
// 改造前：routeAsync 里碰撞引擎在路由决策之前跑
async routeAsync(input, contextTags, qualityEstimate) {
  // 元认知检查
  // 知识汇聚 + 碰撞 ← 每次请求都跑
  // 路由决策
}

// 改造后：路由决策在碰撞之前，碰撞只在需要时跑
async routeAsync(input, contextTags, qualityEstimate, toolResults?) {
  // 元认知检查
  if (qualityEstimate !== undefined && qualityEstimate < 0.3) {
    return { path: 'llm_only', ... };
  }

  // 有工具结果时：工具结果已经是 KnowledgeNode，直接走经验匹配
  if (toolResults && toolResults.length > 0) {
    const candidates = this.matchCandidates(input, contextTags);
    if (candidates.length > 0) {
      const selected = this.rankCandidates(candidates, input)[0];
      return { path: 'exp_direct', skill: selected, ... };
    }
    // 无匹配经验 → 工具结果直接返回
    return { path: 'tool_direct', ... };
  }

  // 无工具结果时：原有逻辑
  const candidates = this.matchCandidates(input, contextTags);
  if (candidates.length === 0) {
    return { path: 'llm_only', ... };
  }
  // ... Thompson Sampling 等 ...
}
```

### Step 8：清理冗余代码 ✅

**需要移除的**：

1. ✅ `AssemblyBridge` 中的 `registerRetrievalSource` / `unregisterRetrievalSource` — 标记 `@deprecated`，仅供 legacy 降级路径使用
2. ✅ `brain.ts` 中 `registerAssemblySources()` — 标记 `@deprecated`，调用处加 legacy 注释
3. ✅ `processWithAssemblyCompetitive` — 重命名为 `legacy_processAssembly`，加 `@legacy` 注释
4. ✅ `DispatchExecutor` 中的 `tryReassembly` — 已移除（注释标记）
5. ✅ `ExperienceRouter.routeAsync` 中碰撞引擎的调用 — 碰撞已移交给 brain.ts 统一调度

**需要保留但重新定位的**：

1. ✅ `InformationIntegrationEngine` — 保留为"片段编辑工具库"，组装引擎降级路径按需调用
2. ✅ `AssemblyWorldBridge` — 保留，在发送层用于"排列优化"
3. ✅ `ContentSelector` — 保留，在碰撞引擎的 `complement` 操作中使用
4. ✅ `Reranker` — 保留，在碰撞引擎的 `synthesize` 操作中使用

---

## 四、数据流对比

### 改造前（工具调用场景）

```
用户："查一下这个项目的 git 状态"
  ↓
法则引擎命中 → 执行 git_status 工具
  ↓
工具返回 JSON: { branch: "main", changes: [...] }
  ↓
同时并行：
  ├─ routeToolProposal → formatToolOutput → JSON格式化 → 可能fallback到完整管线
  └─ processWithAssemblyCompetitive → 10+ 检索源全跑 → 选片 → 拼装 → 世界模型排序
  ↓
裁决器从两个结果中选一个
  ↓
输出
```

### 改造后（工具调用场景）

```
用户："查一下这个项目的 git 状态"
  ↓
法则引擎命中 → 执行 git_status 工具
  ↓
工具返回 JSON: { branch: "main", changes: [...] }
  ↓
采集层：ToolResultStructuralizer → KnowledgeNode[]
  ├─ node: { source: 'tool', content: 'main 分支, 3 个文件变更', concepts: ['git', 'branch', 'main'], confidence: 1.0 }
  ↓
判断：查询类工具、结果完整 → 不需要碰撞
  ↓
发送层：AssemblyBridge.formatToolResult()
  ├─ JSON → 人话："当前在 main 分支，有 3 个文件变更"
  ↓
输出
```

### 改造前（知识查询场景）

```
用户："什么是微服务架构？"
  ↓
法则未命中 → 语义路由未命中
  ↓
同时并行：
  ├─ 左脑规则引擎 → 输出方案
  └─ processWithAssemblyCompetitive → 10+ 检索源 → 选片 → 拼装
  ↓
裁决器选择
  ↓
输出
```

### 改造后（知识查询场景）

```
用户："什么是微服务架构？"
  ↓
法则未命中 → 语义路由未命中
  ↓
采集层：KnowledgeConvergence.converge()
  ├─ 经验图谱 → 匹配的经验 → KnowledgeNode
  ├─ STMP → 相关记忆 → KnowledgeNode
  ├─ 三进制 → 预测匹配 → KnowledgeNode
  └─ (可选) 网页搜索 → 搜索结果 → KnowledgeNode
  ↓
编辑层：CollisionEngine.edit(nodes, 'synthesize')
  ├─ 合并：相似的经验和记忆去重
  ├─ 互补：网页结果补充经验中没有的信息
  ├─ 输出：融合后的完整回答素材
  ↓
发送层：AssemblyBridge.formatEdited(edited, 'report')
  ├─ 按维度组织：定义 → 核心特点 → 与单体对比
  ↓
输出
```

---

## 五、改动文件清单

| 文件 | 改动类型 | 改动内容 |
|------|---------|---------|
| `src/intelligence/knowledge-node.ts` | **修改** | 新增 `tool` 来源类型、`operationType`、`structuredData`、`confidenceSource` 字段 |
| `src/intelligence/tool-result-structuralizer.ts` | **新建** | 工具结果 → KnowledgeNode 结构化器 |
| `src/intelligence/collision-engine.ts` | **重构** | 新增 `EditIntent`、`EditResult`、`EditedKnowledge` 类型；`collide()` → `edit()`；按意图选择操作 |
| `src/intelligence/knowledge-convergence.ts` | **修改** | 接入工具结果采集；converge() 新增 toolResults 参数 |
| `src/brain/right/features/assembly-bridge.ts` | **重构** | 移除检索职责；新增 `formatEdited()`、`formatToolResult()`；按 OutputIntent 格式化 |
| `src/brain/brain.ts` | **重构** | 改造 decide() 中工具结果处理；新增 `shouldCollide()` 判断；改造无工具时的处理；清理 registerAssemblySources |
| `src/intelligence/experience-router.ts` | **修改** | routeAsync() 中碰撞引擎调用移除（碰撞由 brain.ts 统一调度） |
| `src/brain/dispatch/executor.ts` | **修改** | 移除 `tryReassembly()`；组装引擎不再做迭代重生成 |
| `src/brain/right/features/integration-engine.ts` | **降级** | 保留为"片段编辑工具库"，不再作为组装引擎核心 |

---

## 六、风险与降级策略

### 风险 1：碰撞引擎编辑质量不可控

**降级**：碰撞引擎的每个 EditResult 都有 `explanation` 字段。如果编辑结果质量低（confidence < 0.3），跳过碰撞，直接走单源格式化。

### 风险 2：工具结果结构化器适配不全

**降级**：未知工具的 JSON 结构 → 整体作为一个 KnowledgeNode，不做字段提取。功能等同于改造前，不会更差。

### 风险 3：改造过程中功能回归

**降级**：保留 `InformationIntegrationEngine.process()` 的完整路径作为 `legacy_process`。新路径出问题时，可以一键回退到旧路径。

### 风险 4：多源场景下碰撞引擎成为瓶颈

**降级**：碰撞引擎设置超时（5s），超时直接走单源格式化。碰撞是"增强"不是"必须"。

---

## 七、验证标准

### 工具调用场景

- [x] 工具结果不再被组装引擎重新检索
- [x] 工具结果通过 ToolResultStructuralizer 正确转为 KnowledgeNode
- [x] 查询类工具（read_file, get_time, git_status）走快速格式化路径
- [x] 执行类工具（exec, write_file）走确认格式化路径

### 知识查询场景

- [x] 多源知识通过碰撞引擎正确融合
- [x] 碰撞引擎的 concepts 字段不再为空
- [x] 合并/互补/冲突/涌现四种操作可独立验证
- [x] 碰撞结果有 explanation 字段说明做了什么

### 输出质量

- [x] 单工具结果的输出与改造前一致或更好
- [x] 多源知识查询的输出质量不低于改造前
- [x] 输出延迟不增加（工具场景应更快，因为跳过了重复检索）
