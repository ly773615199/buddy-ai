# 法则系统设计 — 从规则进化到法则（落地执行计划）

> 基于现有代码架构的详细实施方案。
> 上次更新：2026-05-27

## 现状分析

### 已实现的基础设施

| 模块 | 文件 | 行数 | 能力 |
|------|------|------|------|
| RuleEngine | `src/brain/left/rule-engine.ts` | 2205 | 53 条种子规则 + 12 条内置规则，evaluate/evaluateQuick/evaluateExecutableRule 三级匹配 |
| PolicyDistiller | `src/brain/left/policy-distiller.ts` | 387 | 生命周期管理、置信度校准、优先级调整、规则合并、条件收窄 |
| DecisionMemory | `src/brain/left/decision-memory.ts` | 558 | JSONL 持久化、kNN 相似查询、向量聚类、反事实样本生成、知识凝结 |
| UnifiedScheduler | `src/brain/left/scheduler.ts` | 542 | 四层新颖度路由、Thompson Sampling、元认知控制、小脑稳态注入 |
| LeftBrain | `src/brain/left/index.ts` | 317 | 统一入口：decide → evaluateQuick → evaluateExecutableRule → scheduler |
| ToolRegistry | `src/tools/registry.ts` | 192 | 工具注册/注销、使用频率追踪、执行日志、回调监听 |
| DispatchLearner | `src/brain/dispatch/learner.ts` | 672 | LLM 胜出时蒸馏到本地模块、tool call 模式收集 |
| DispatchCoordinator | `src/brain/dispatch/coordinator.ts` | 864 | BlendStrategy 选择、资源评估、混合权重计算 |
| types.ts | `src/brain/types.ts` | 634 | Rule/TaskSignal/ResourceState/ExecutionPlan/DistillReport 等完整类型 |
| brain.ts | `src/brain/brain.ts` | 3101 | 三脑协作：小脑→右脑→左脑→执行→反馈闭环 |

### 信号流（现有）

```
用户输入
  → brain.ts: decide()
    → 小脑: 感知融合 → BodyState
    → 右脑: 直觉推理 → IntuitionSignal
    → 左脑:
      → evaluateExecutableRule()  ← 带 ExecutablePlan 的确定性规则（快速通道）
      → evaluateQuick()           ← 带 ExecutablePlan 的规则（跳过审议）
      → left.decide()
        → ruleEngine.evaluate()   ← 按优先级匹配第一条
        → scheduler.schedule()    ← 四层路由兜底
    → DispatchCoordinator: BlendStrategy 选择
    → DispatchExecutor: 执行
  → 反馈: left.recordDecision() + left.recordOutcome()
  → 蒸馏: left.distill() (定期)
```

### 法则系统要解决的问题

1. **规则是人工堆砌的**：53 条种子规则手动编写，新工具需手动添加规则
2. **分类器缺失**：evaluate() 按优先级线性扫描，无法互斥分类
3. **无推导机制**：规则不能从法则 + 注册表自动生成
4. **无模式发现**：LLM 调用中的可确定化模式未被自动提取
5. **无变异/交叉**：规则衰退时直接淘汰，而非自我优化

---

## 实施方案

### 总体策略

**渐进替换，不破坏现有功能。** 法则系统作为新的分类层插入 `evaluate()` 之前，原有规则作为法则 1 的实例继续工作。

```
现有:  evaluate() → 线性扫描 65 条规则
目标:  classify() → 法则互斥分类 → 推导规则 → 执行
过渡:  evaluate() → classify() 优先 → fallback 线性扫描
```

---

### Phase 1: 法则分类器（LawClassifier）

**目标**：实现输入分类，判定输入属于哪条法则。

**文件**：`src/brain/left/law-classifier.ts`

#### 1.1 类型定义

```ts
// 添加到 src/brain/types.ts

/** 法则 ID */
export type LawId =
  | 'deterministic'     // 法则 1: 确定性执行
  | 'retrieval'         // 法则 2: 信息检索
  | 'generative'        // 法则 3: 生成创造
  | 'clarification'     // 法则 4: 交互澄清
  | 'orchestration'     // 法则 5: 组合编排
  | 'degradation';      // 法则 6: 降级兜底

/** 法则分类结果 */
export interface LawClassification {
  lawId: LawId;
  confidence: number;
  reason: string;
  /** 匹配到的推导规则（法则 1 时有值） */
  matchedRule?: Rule;
  /** 提取到的参数（法则 1 时有值） */
  extractedArgs?: Record<string, unknown>;
  /** 歧义信息（法则 4 时有值） */
  ambiguity?: { missing: string[]; candidates: string[] };
}
```

#### 1.2 核心实现

```ts
// src/brain/left/law-classifier.ts

export class LawClassifier {
  private toolRegistry: ToolRegistry;
  private argExtractors: ArgExtractorRegistry;

  constructor(toolRegistry: ToolRegistry) {
    this.toolRegistry = toolRegistry;
    this.argExtractors = new ArgExtractorRegistry();
    this.loadDefaultExtractors();
  }

  /**
   * 分类入口 — 优先级从高到低判定
   *
   * 与现有 evaluate() 的关系：
   * - classify() 先执行，如果命中法则 1 且有 executablePlan → 快速通道
   * - 未命中 → fallback 到原有 evaluate() 线性扫描
   */
  classify(signal: TaskSignal, resources: ResourceState): LawClassification {
    const content = signal.content ?? '';

    // 法则 1: 确定性执行 — 输入可直接映射到工具
    const det = this.tryDeterministic(content);
    if (det) return det;

    // 法则 4: 交互澄清 — 输入歧义或信息不足
    const clar = this.tryClarification(content, signal);
    if (clar) return clar;

    // 法则 2: 信息检索 — 需要外部信息
    const ret = this.tryRetrieval(content, signal);
    if (ret) return ret;

    // 法则 5: 组合编排 — 可分解为子任务
    const orc = this.tryOrchestration(content, signal);
    if (orc) return orc;

    // 法则 3: 生成创造 — 需要产出新内容
    const gen = this.tryGenerative(content, signal);
    if (gen) return gen;

    // 法则 6: 降级兜底
    return {
      lawId: 'degradation',
      confidence: 0.5,
      reason: '无法匹配任何法则，降级兜底',
    };
  }

  // ==================== 法则 1: 确定性执行 ====================

  private tryDeterministic(content: string): LawClassification | null {
    // 遍历参数提取器（每个提取器绑定一个工具）
    for (const extractor of this.argExtractors.getAll()) {
      const args = extractor.extract(content);
      if (args !== null) {
        return {
          lawId: 'deterministic',
          confidence: args._confidence ?? 0.9,
          reason: `法则1: ${extractor.toolName} 确定性执行`,
          extractedArgs: args,
        };
      }
    }
    return null;
  }

  // ==================== 法则 4: 交互澄清 ====================

  private tryClarification(content: string, signal: TaskSignal): LawClassification | null {
    // 信息不足
    if (content.length < 5 && signal.domains.length === 0) {
      return {
        lawId: 'clarification',
        confidence: 0.8,
        reason: '法则4: 输入过短，信息不足',
        ambiguity: { missing: ['intent'], candidates: [] },
      };
    }

    // 指代不明
    if (/(?:它|这个|那个|那个东西|帮我改一下)\s*$/.test(content)) {
      return {
        lawId: 'clarification',
        confidence: 0.7,
        reason: '法则4: 指代不明',
        ambiguity: { missing: ['target', 'action'], candidates: [] },
      };
    }

    return null;
  }

  // ==================== 法则 2: 信息检索 ====================

  private tryRetrieval(content: string, signal: TaskSignal): LawClassification | null {
    // 事实性问题 + 非本地知识
    const factualPatterns = /(?:什么是|怎么|如何|为什么|多少|哪个|谁|天气|新闻|价格|汇率)/;
    if (factualPatterns.test(content) && !this.canMapToTool(content)) {
      return {
        lawId: 'retrieval',
        confidence: 0.7,
        reason: '法则2: 需要外部信息',
      };
    }
    return null;
  }

  // ==================== 法则 5: 组合编排 ====================

  private tryOrchestration(content: string, signal: TaskSignal): LawClassification | null {
    // 多步骤任务
    const multiStep = /(?:然后|接着|之后|先.*再|首先.*最后|第一步.*第二步)/;
    if (multiStep.test(content) || signal.shouldUseDAG) {
      return {
        lawId: 'orchestration',
        confidence: 0.7,
        reason: '法则5: 多步骤组合任务',
      };
    }
    return null;
  }

  // ==================== 法则 3: 生成创造 ====================

  private tryGenerative(content: string, signal: TaskSignal): LawClassification | null {
    // 生成性动词
    const generative = /(?:写|生成|创建|编写|设计|实现|开发|写一个|帮我写)/;
    if (generative.test(content)) {
      return {
        lawId: 'generative',
        confidence: 0.7,
        reason: '法则3: 需要生成新内容',
      };
    }
    return null;
  }

  /** 工具映射检查（法则 1 辅助） */
  private canMapToTool(content: string): boolean {
    return this.argExtractors.getAll().some(e => e.extract(content) !== null);
  }
}
```

#### 1.3 参数提取器注册表

```ts
// src/brain/left/arg-extractor.ts

export interface ArgExtractor {
  id: string;
  toolName: string;
  /** 匹配模式 */
  patterns: Array<{ regex: RegExp; extract: (match: RegExpMatchArray) => Record<string, unknown> | null }>;
  /** 匹配内容，返回提取的参数或 null */
  extract(content: string): Record<string, unknown> | null;
}

export class ArgExtractorRegistry {
  private extractors: ArgExtractor[] = [];

  register(extractor: ArgExtractor): void {
    this.extractors.push(extractor);
  }

  getAll(): ArgExtractor[] {
    return this.extractors;
  }

  getByTool(toolName: string): ArgExtractor[] {
    return this.extractors.filter(e => e.toolName === toolName);
  }
}
```

#### 1.4 默认提取器加载

从现有 53 条种子规则中提取模式，注册为 ArgExtractor：

```ts
// src/brain/left/law-classifier.ts 中的 loadDefaultExtractors()

private loadDefaultExtractors(): void {
  // Git 操作
  this.argExtractors.register({
    id: 'ext-git-status', toolName: 'exec',
    patterns: [{ regex: /git\s+(status|状态)/, extract: () => ({ command: 'git status' }) }],
    extract(c) { const m = c.match(/git\s+(?:status|状态)/i); return m ? { command: 'git status', _confidence: 0.92 } : null; },
  });

  this.argExtractors.register({
    id: 'ext-git-log', toolName: 'exec',
    patterns: [{ regex: /git\s+(log|日志|历史)/, extract: () => ({ command: 'git log --oneline -20' }) }],
    extract(c) { const m = c.match(/git\s+(?:log|日志|历史|提交记录)/i); return m ? { command: 'git log --oneline -20', _confidence: 0.92 } : null; },
  });

  // 文件操作
  this.argExtractors.register({
    id: 'ext-file-read', toolName: 'read_file',
    patterns: [{ regex: /(?:读取|打开|查看|cat)\s+(.+)/, extract: (m) => ({ path: m[1] }) }],
    extract(c) { const m = c.match(/(?:读取|打开|查看|cat)\s+(.+)/); return m ? { path: m[1].trim(), _confidence: 0.85 } : null; },
  });

  // ... 从现有种子规则批量生成更多提取器
}
```

#### 1.5 集成点

修改 `src/brain/left/rule-engine.ts` 的 `evaluate()` 方法：

```ts
// 在 evaluate() 中插入法则分类器
evaluate(signal, resources, intuition, body): ExecutionPlan | null {
  // Phase 1: 法则分类器优先
  const classification = this.lawClassifier?.classify(signal, resources);
  if (classification?.lawId === 'deterministic' && classification.matchedRule) {
    // 法则 1 命中：直接执行
    const rule = classification.matchedRule;
    rule.stats.hits++;
    rule.stats.lastUsed = Date.now();
    return rule.action(signal, resources);
  }

  // Fallback: 原有线性扫描
  const sorted = [...this.rules].sort((a, b) => b.priority - a.priority);
  // ... 现有逻辑
}
```

#### 1.6 产出物

| 文件 | 操作 | 说明 |
|------|------|------|
| `src/brain/types.ts` | 修改 | 新增 LawId、LawClassification 类型 |
| `src/brain/left/law-classifier.ts` | 新建 | 法则分类器核心 |
| `src/brain/left/arg-extractor.ts` | 新建 | 参数提取器注册表 |
| `src/brain/left/rule-engine.ts` | 修改 | evaluate() 中插入 classify() 调用 |

---

### Phase 2: 规则推导引擎（RuleDerivationEngine）

**目标**：规则从法则 + 工具注册表自动推导，不再人工堆砌。

**文件**：`src/brain/left/law-derivation.ts`

#### 2.1 核心设计

```ts
// src/brain/left/law-derivation.ts

export interface DerivationContext {
  toolRegistry: ToolRegistry;
  argExtractors: ArgExtractorRegistry;
  knowledgeSources: KnowledgeSource[];
}

export interface KnowledgeSource {
  id: string;
  name: string;
  covers: (content: string) => boolean;
  retrieve: (query: string) => Promise<string>;
}

export class RuleDerivationEngine {
  private context: DerivationContext;

  constructor(context: DerivationContext) {
    this.context = context;
  }

  /**
   * 法则 1 推导：从工具注册表 + 参数提取器自动生成规则
   *
   * 每个 (tool, extractor) 对 → 一条确定性执行规则
   * 与现有种子规则的区别：种子规则是人工写的 regex，推导规则从注册表自动生成
   */
  deriveDeterministicRules(): Rule[] {
    const rules: Rule[] = [];
    const now = Date.now();

    for (const extractor of this.context.argExtractors.getAll()) {
      rules.push({
        id: `law1-${extractor.id}-${now}`,
        name: `法则1推导: ${extractor.toolName}`,
        priority: 90,
        condition: (signal) => {
          const content = signal.content ?? '';
          return extractor.extract(content) !== null;
        },
        action: (signal) => {
          const content = signal.content ?? '';
          const args = extractor.extract(content)!;
          const { _confidence, ...cleanArgs } = args as any;
          return {
            mode: 'local_only',
            reason: `法则1推导: ${extractor.toolName}`,
            selectedNodes: [{ id: 'auto', type: 'experience' }],
            confidence: _confidence ?? 0.9,
            source: 'rule',
            executablePlan: {
              steps: [{
                id: 'step_1', type: 'tool_call',
                tool: extractor.toolName, args: cleanArgs,
                dependsOn: [], preferredExecutors: ['local'],
              }],
              expectedOutput: `${extractor.toolName} 执行结果`,
              confidence: _confidence ?? 0.9,
              source: 'rule',
              needsCloudEnhancement: false,
            },
          };
        },
        source: 'learned',
        stats: { hits: 0, successes: 0, lastUsed: 0, recentResults: [], calibratedConfidence: 0.5, lifecycle: 'active', firstHitAt: 0, consecutiveFailures: 0 },
        createdAt: now,
      });
    }

    return rules;
  }

  /**
   * 法则 2 推导：从知识源注册表自动生成规则
   */
  deriveRetrievalRules(): Rule[] {
    const rules: Rule[] = [];
    const now = Date.now();

    for (const source of this.context.knowledgeSources) {
      rules.push({
        id: `law2-${source.id}-${now}`,
        name: `法则2推导: ${source.name}`,
        priority: 60,
        condition: (signal) => {
          const content = signal.content ?? '';
          return source.covers(content);
        },
        action: (signal) => ({
          mode: 'single',
          reason: `法则2推导: ${source.name} 信息检索`,
          selectedNodes: [{ id: source.id, type: 'experience' }],
          confidence: 0.7,
          source: 'rule',
        }),
        source: 'learned',
        stats: { hits: 0, successes: 0, lastUsed: 0, recentResults: [], calibratedConfidence: 0.5, lifecycle: 'active', firstHitAt: 0, consecutiveFailures: 0 },
        createdAt: now,
      });
    }

    return rules;
  }

  /**
   * 全量推导：生成所有法则的规则
   */
  deriveAll(): Rule[] {
    return [
      ...this.deriveDeterministicRules(),
      ...this.deriveRetrievalRules(),
      // 法则 3-6 不生成规则，由分类器直接处理
    ];
  }
}
```

#### 2.2 与现有种子规则的关系

现有 53 条种子规则 → 迁移为 ArgExtractor → 由推导引擎自动生成。

**迁移步骤**：
1. 从 `rule-engine.ts` 的种子规则中提取 regex + 参数映射
2. 转换为 ArgExtractor 注册到 `arg-extractor.ts`
3. 推导引擎从 ArgExtractor 自动生成规则
4. 移除 `rule-engine.ts` 中的硬编码种子规则（保留内置规则）

#### 2.3 产出物

| 文件 | 操作 | 说明 |
|------|------|------|
| `src/brain/left/law-derivation.ts` | 新建 | 规则推导引擎 |
| `src/brain/left/law-classifier.ts` | 修改 | 注入 DerivationContext |
| `src/brain/left/rule-engine.ts` | 修改 | 启动时调用推导引擎生成规则 |
| `src/brain/left/index.ts` | 修改 | LeftBrain 初始化时创建推导引擎 |

---

### Phase 3: 学习层 — 模式发现（PatternDiscovery）

**目标**：从运行时数据中发现新模式，自动扩展推导源。

**文件**：`src/brain/left/pattern-discovery.ts`

#### 3.1 核心设计

```ts
// src/brain/left/pattern-discovery.ts

export class PatternDiscovery {
  private decisionMemory: DecisionMemory;
  private dispatchLearner: DispatchLearner;

  constructor(memory: DecisionMemory, learner: DispatchLearner) {
    this.decisionMemory = memory;
    this.dispatchLearner = learner;
  }

  /**
   * 从 LLM 调用中发现可确定化的模式
   *
   * 原理：如果同一类输入反复走 LLM，且输出可以被工具直接生成，
   *       则发现了一个可确定化的新模式。
   */
  discoverDeterminizable(): DeterminizablePattern[] {
    const patterns: DeterminizablePattern[] = [];

    // 1. 从 DecisionMemory 聚类中找高频 LLM 调用
    const clusters = this.decisionMemory.getClusterStats(5);

    for (const cluster of clusters) {
      // 只看走 LLM 的决策
      const llmRecords = cluster.records.filter(r =>
        r.plan.source === 'scheduler' || r.plan.source === 'cloudLLM',
      );
      if (llmRecords.length < 3) continue;

      // 2. 检查输出是否可以被工具直接生成
      const toolMatch = this.findMatchingTool(llmRecords);
      if (toolMatch) {
        patterns.push({
          trigger: cluster.fingerprint,
          tool: toolMatch.tool,
          argsExtractor: toolMatch.extractor,
          confidence: cluster.successRate,
          sampleCount: llmRecords.length,
        });
      }
    }

    return patterns;
  }

  /**
   * 从未覆盖输入中发现模式
   *
   * 原理：输入既不命中法则 1（确定性），也不命中其他法则，
   *       但反复出现且有成功记录 → 可能需要新规则。
   */
  discoverUncovered(): UncoveredPattern[] {
    const patterns: UncoveredPattern[] = [];
    const clusters = this.decisionMemory.getClusterStats(3);

    for (const cluster of clusters) {
      // 找走 degradation 的记录
      const degraded = cluster.records.filter(r =>
        r.plan.source === 'degradation' || r.plan.confidence < 0.5,
      );
      if (degraded.length < 3) continue;

      // 分析共同特征
      const commonDomains = this.findCommonDomains(degraded);
      const commonTool = this.findMostUsedTool(degraded);

      if (commonTool) {
        patterns.push({
          fingerprint: cluster.fingerprint,
          suggestedTool: commonTool,
          domains: commonDomains,
          successRate: cluster.successRate,
          sampleCount: degraded.length,
        });
      }
    }

    return patterns;
  }

  /**
   * 发现可确定化模式后，自动生成 ArgExtractor
   */
  generateExtractor(pattern: DeterminizablePattern): ArgExtractor {
    return {
      id: `discovered-${pattern.trigger.slice(0, 16)}`,
      toolName: pattern.tool,
      patterns: [],
      extract: (content: string) => {
        // 基于 fingerprint 的模糊匹配
        const fp = this.fingerprint(content);
        if (this.fingerprintSimilarity(fp, pattern.trigger) > 0.7) {
          return { _confidence: pattern.confidence };
        }
        return null;
      },
    };
  }

  // ... 辅助方法
}
```

#### 3.2 集成点

在 `brain.ts` 的蒸馏流程中调用：

```ts
// src/brain/brain.ts 中的 distill() 方法
async distill(): Promise<DistillReport> {
  // ... 现有蒸馏逻辑

  // 新增: 模式发现
  const discoveries = this.patternDiscovery.discoverDeterminizable();
  for (const pattern of discoveries) {
    const extractor = this.patternDiscovery.generateExtractor(pattern);
    this.left.getLawClassifier().getArgExtractors().register(extractor);
    report.discoveredPatterns++;
  }

  return report;
}
```

#### 3.3 产出物

| 文件 | 操作 | 说明 |
|------|------|------|
| `src/brain/left/pattern-discovery.ts` | 新建 | 模式发现引擎 |
| `src/brain/left/index.ts` | 修改 | LeftBrain 持有 PatternDiscovery |
| `src/brain/brain.ts` | 修改 | distill() 中调用模式发现 |

---

### Phase 4: 学习层 — 变异与交叉（RuleMutation）

**目标**：规则能自我优化，而不是直接淘汰。

**文件**：`src/brain/left/rule-mutation.ts`

#### 4.1 核心设计

```ts
// src/brain/left/rule-mutation.ts

export class RuleMutator {
  /**
   * 收紧条件：减少误命中
   *
   * 当规则频繁命中但失败时，收紧条件排除误命中场景。
   */
  tighten(rule: Rule, falsePositives: DecisionRecord[]): Rule {
    // 从误命中中提取共同特征
    const excludePatterns = this.extractExcludePatterns(falsePositives);

    const newCondition = (signal: TaskSignal, resources: ResourceState, intuition?: IntuitionSignal, body?: BodyState) => {
      // 原始条件
      if (!rule.condition(signal, resources, intuition, body)) return false;
      // 排除误命中
      const content = signal.content ?? '';
      for (const pattern of excludePatterns) {
        if (pattern.test(content)) return false;
      }
      return true;
    };

    return { ...rule, condition: newCondition, name: `${rule.name} [收紧]` };
  }

  /**
   * 放宽条件：减少漏命中
   *
   * 当规则未命中但同类输入成功时，放宽条件覆盖更多场景。
   */
  loosen(rule: Rule, falseNegatives: DecisionRecord[]): Rule {
    const includePatterns = this.extractIncludePatterns(falseNegatives);

    const newCondition = (signal: TaskSignal, resources: ResourceState, intuition?: IntuitionSignal, body?: BodyState) => {
      // 原始条件
      if (rule.condition(signal, resources, intuition, body)) return true;
      // 放宽：匹配漏命中模式
      const content = signal.content ?? '';
      for (const pattern of includePatterns) {
        if (pattern.test(content)) return true;
      }
      return false;
    };

    return { ...rule, condition: newCondition, name: `${rule.name} [放宽]` };
  }

  /**
   * 规则交叉：合并两条规则的优势
   */
  crossover(ruleA: Rule, ruleB: Rule): Rule | null {
    // 找共同结构
    const sharedFp = this.findSharedFingerprint(ruleA, ruleB);
    if (!sharedFp) return null;

    const bestAction = ruleA.stats.calibratedConfidence > ruleB.stats.calibratedConfidence
      ? ruleA.action : ruleB.action;

    return {
      id: `cross-${ruleA.id}-${ruleB.id}`,
      name: `交叉: ${ruleA.name} ∪ ${ruleB.name}`,
      priority: Math.max(ruleA.priority, ruleB.priority),
      condition: (signal, resources, intuition, body) =>
        ruleA.condition(signal, resources, intuition, body) ||
        ruleB.condition(signal, resources, intuition, body),
      action: bestAction,
      source: 'learned',
      stats: { hits: 0, successes: 0, lastUsed: 0, recentResults: [], calibratedConfidence: 0.5, lifecycle: 'probation', firstHitAt: 0, consecutiveFailures: 0 },
      createdAt: Date.now(),
    };
  }

  /**
   * 从 declining 规则中尝试变异
   *
   * 不是直接淘汰，而是尝试收紧/放宽后重新放入 probation。
   */
  mutateDecliningRules(engine: RuleEngine, memory: DecisionMemory): number {
    const declining = engine.getRules().filter(r => r.stats.lifecycle === 'declining');
    let mutated = 0;

    for (const rule of declining) {
      const fp = rule.fingerprint ?? rule.id;
      const records = memory.getAll().filter(r => {
        const rFp = `${r.signal.domains.sort().join(',')}|${r.signal.complexity}|${r.signal.taskType}`;
        return rFp === fp;
      });

      if (records.length < 5) continue;

      const successes = records.filter(r => r.outcome?.success);
      const failures = records.filter(r => r.outcome && !r.outcome.success);

      // 尝试收紧
      if (failures.length >= 3) {
        const tightened = this.tighten(rule, failures);
        tightened.stats = { ...rule.stats, lifecycle: 'probation', consecutiveFailures: 0 };
        engine.addLearnedRule(tightened);
        mutated++;
      }

      // 尝试放宽
      if (successes.length >= 3) {
        const loosened = this.loosen(rule, successes);
        loosened.stats = { ...rule.stats, lifecycle: 'probation', consecutiveFailures: 0 };
        engine.addLearnedRule(loosened);
        mutated++;
      }
    }

    return mutated;
  }
}
```

#### 4.2 集成点

在 PolicyDistiller 的 `distill()` 中插入变异步骤：

```ts
// src/brain/left/policy-distiller.ts 的 distill() 方法

// Step 8.5: 变异 declining 规则（替代直接淘汰）
const mutated = this.mutator.mutateDecliningRules(engine, this.memory);
report.mutatedRules = mutated;

// Step 9: 淘汰 deprecated 规则（变异失败的才淘汰）
report.prunedRules = this.pruneDeprecated(engine);
```

#### 4.3 产出物

| 文件 | 操作 | 说明 |
|------|------|------|
| `src/brain/left/rule-mutation.ts` | 新建 | 变异/交叉引擎 |
| `src/brain/left/policy-distiller.ts` | 修改 | distill() 中调用变异 |
| `src/brain/types.ts` | 修改 | DistillReport 新增 mutatedRules |

---

### Phase 5: 法则验证框架（LawValidator）

**目标**：自动验证法则系统的五大标准。

**文件**：`src/brain/left/law-validator.ts`

#### 5.1 核心设计

```ts
// src/brain/left/law-validator.ts

export interface ValidationResult {
  complete: boolean;
  consistent: boolean;
  minimal: boolean;
  deterministic: boolean;
  interpretable: boolean;
  violations: string[];
  coverage: { total: number; covered: number; rate: number };
}

export class LawValidator {
  private classifier: LawClassifier;
  private derivation: RuleDerivationEngine;

  /**
   * 完备性验证：枚举测试输入，验证全覆盖
   */
  validateCompleteness(testInputs: string[]): ValidationResult {
    const violations: string[] = [];
    let covered = 0;

    for (const input of testInputs) {
      const signal = this.inputToSignal(input);
      const classification = this.classifier.classify(signal, this.defaultResources());
      if (classification.lawId === 'degradation') {
        violations.push(`未覆盖: "${input}" → degradation`);
      } else {
        covered++;
      }
    }

    return {
      complete: violations.length === 0,
      consistent: true, // 一致性由互斥分类保证
      minimal: true,    // 最小性由推导保证
      deterministic: true,
      interpretable: true,
      violations,
      coverage: { total: testInputs.length, covered, rate: covered / testInputs.length },
    };
  }

  /**
   * 一致性验证：检测规则冲突
   */
  validateConsistency(rules: Rule[]): string[] {
    const violations: string[] = [];
    // 检查同优先级规则是否有重叠条件
    // ...
    return violations;
  }

  /**
   * 最小性验证：检测冗余规则
   */
  validateMinimality(rules: Rule[]): string[] {
    const violations: string[] = [];
    // 检查是否有规则被其他规则完全覆盖
    // ...
    return violations;
  }
}
```

#### 5.2 产出物

| 文件 | 操作 | 说明 |
|------|------|------|
| `src/brain/left/law-validator.ts` | 新建 | 法则验证框架 |
| `src/brain/left/law-validator.test.ts` | 新建 | 验证测试 |

---

## 实施顺序与依赖关系

```
Phase 1: LawClassifier + ArgExtractor
  ├── 不依赖其他 Phase
  ├── 可独立测试（分类准确率）
  └── 产出: law-classifier.ts, arg-extractor.ts

Phase 2: RuleDerivationEngine
  ├── 依赖 Phase 1（ArgExtractorRegistry）
  ├── 可独立测试（推导规则正确性）
  └── 产出: law-derivation.ts

Phase 3: PatternDiscovery
  ├── 依赖 Phase 1（ArgExtractorRegistry）
  ├── 依赖现有 DecisionMemory + DispatchLearner
  └── 产出: pattern-discovery.ts

Phase 4: RuleMutation
  ├── 依赖现有 PolicyDistiller + DecisionMemory
  ├── 可独立测试（变异效果）
  └── 产出: rule-mutation.ts

Phase 5: LawValidator
  ├── 依赖 Phase 1 + Phase 2
  └── 产出: law-validator.ts
```

---

## 预期效果

| 指标 | 改前（规则） | 改后（法则） |
|------|-------------|-------------|
| 决策来源 | 65 条人工规则 | 6 条法则 + 自动推导 |
| 新工具覆盖 | 手动写规则 | 注册工具 → 自动推导规则 |
| 规则冲突 | 可能（优先级裁决） | 不可能（法则互斥） |
| 确定性 | 受运行时状态影响 | 法则层纯函数 |
| 可解释性 | learned 规则是黑箱 | 每条规则可追溯到法则 |
| 进化方式 | 蒸馏 + 淘汰 | 变异 + 交叉 + 模式发现 |
| 完备性 | 13% 工具覆盖 | 法则级完备（6 条覆盖全空间） |
| LLM 调用频率 | ~97% | ~50%（模式发现逐步降低） |
