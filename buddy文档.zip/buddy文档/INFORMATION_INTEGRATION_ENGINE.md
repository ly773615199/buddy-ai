# 信息整合引擎 — 详细实施计划

> 版本: v1.1
> 日期: 2026-05-15
> 目标: 零 LLM 调用，纯检索 + 规则，覆盖 85%+ 日常交互
> 新增: 创造性机制（变异 + 评估 + 进化闭环 + 用户框架注入）

---

## 一、设计原则

不"生成"，只"组装"。所有回复由四层管线拼装而成：

1. **字典层**：存储所有可检索的信息单元（知识、历史回复、工具输出、文件索引）
2. **语义层**：把查询编码为向量，从字典中检索相关信息
3. **组装层**：从检索结果中提取片段，填入骨架模板，加连接词
4. **篇法层**：组句成篇，控制逻辑链和篇幅

全程不用神经网络做文本生成，只用 ByteEncoder 编码 + 向量检索 + 规则组装。

---

## 二、架构总览

```
┌─────────────────────────────────────────────────────────────────┐
│                    信息整合引擎                                    │
│                                                                 │
│  Layer 1: 字典层（多粒度存储）                                    │
│  ├─ KnowledgeStore:   结构化知识条目                               │
│  ├─ DecisionMemory:   历史成功回复片段                             │
│  ├─ ToolOutputCache:  工具执行结果缓存                             │
│  ├─ FileIndex:        本地文件多粒度索引                           │
│  └─ CodeTemplates:    代码模板库                                  │
│                                                                 │
│  Layer 2: 语义层（检索 + 重排序）                                 │
│  ├─ ByteEncoder:      任意文本 → 128d 向量                        │
│  ├─ VectorIndex:      余弦相似度 top-K 检索                       │
│  ├─ Reranker:         相关度 × 新鲜度 × 权威度 × 推理链完整性      │
│  └─ GraphExpand:      知识图谱边关系多跳扩展                       │
│                                                                 │
│  Layer 3: 组装层（选 + 提取 + 填 + 连）                           │
│  ├─ ContentSelector:  从 top-K 中选出关键片段                     │
│  ├─ FragmentExtractor:从检索结果中提取关键信息                     │
│  ├─ SkeletonSelector: intent/taskType → 选骨架模板                │
│  ├─ SlotFiller:       片段填入骨架槽位                             │
│  └─ ConnectorInsertor:语义关系 → 连接词选择                       │
│                                                                 │
│  Layer 4: 篇法层（组句成篇）                                      │
│  ├─ ParagraphPlanner: 开头→正文→结尾 结构                         │
│  ├─ DiscourseChain:   因果/并列/递进/转折 逻辑链                   │
│  ├─ ReferringExpr:    指代消解（"它"/"这个函数"）                   │
│  └─ LengthController:  根据任务复杂度调整篇幅                       │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## 三、Layer 1: 字典层

### 3.1 KnowledgeStore（已有，需升级）

**现状**：`KnowledgeGate` 已实现向量化存储和检索。

**升级**：
- 加入图结构边关系（LightRAG 思路）：实体之间有 `causes`/`solves`/`requires`/`improves` 等关系边
- 支持多跳检索：A --causes--> B --solved_by--> C，查 A 时自动扩展到 C

**新增文件**：`src/brain/right/nn/knowledge-graph.ts`

```typescript
interface KnowledgeEdge {
  from: string;       // 源实体 ID
  to: string;         // 目标实体 ID
  relation: 'causes' | 'solves' | 'requires' | 'improves' | 'related';
  weight: number;     // 边权重
}

class KnowledgeGraph {
  private edges: KnowledgeEdge[] = [];
  private entityIndex: Map<string, KnowledgeEdge[]> = new Map();

  // 添加边
  addEdge(from: string, to: string, relation: string, weight: number): void;

  // 多跳扩展：从起始实体出发，沿边关系扩展 N 跳
  expand(entityIds: string[], maxHops: number): Array<{ id: string; score: number; path: string[] }>;
}
```

**参数量**：0（纯数据结构，不增加 NN 参数）

### 3.2 DecisionMemory（新增）

**作用**：存储历史成功回复的片段，供组装时提取复用。

**数据结构**：

```typescript
interface DecisionFragment {
  id: string;
  text: string;              // 回复片段原文
  embedding: Float32Array;   // 128d 向量
  intent: string;            // 关联的意图类别
  taskType: string;          // 关联的任务类型
  successRate: number;       // 历史成功率
  usageCount: number;        // 使用次数
  createdAt: number;         // 创建时间
  source: 'llm_reply' | 'local_gen' | 'user_feedback';  // 来源
}

class DecisionMemory {
  private fragments: DecisionFragment[] = [];
  private vectorIndex: VectorIndex;

  // 存储成功回复片段
  store(fragment: DecisionFragment): void;

  // 语义检索
  retrieve(query: Float32Array, topK: number, filters?: { intent?: string; taskType?: string }): DecisionFragment[];

  // 按使用频率排序（高频片段更可靠）
  getPopular(intent: string, topK: number): DecisionFragment[];
}
```

**触发时机**：每次 LLM 回复成功后，自动切分为片段存入。由 `OnlineLearner.feedback()` 触发。

**新增文件**：`src/brain/right/features/decision-memory.ts`

### 3.3 ToolOutputCache（新增）

**作用**：缓存工具执行结果，供后续组装时引用。

```typescript
interface CachedOutput {
  tool: string;          // 工具名
  input: string;         // 输入（文件路径/命令等）
  output: string;        // 输出摘要（截取前 500 字符）
  embedding: Float32Array;
  timestamp: number;
  ttl: number;           // 过期时间
}

class ToolOutputCache {
  private cache: Map<string, CachedOutput> = new Map();
  private vectorIndex: VectorIndex;

  // 缓存工具输出
  put(tool: string, input: string, output: string): void;

  // 语义检索
  retrieve(query: Float32Array, topK: number): CachedOutput[];

  // 按工具名精确查找
  getByInput(tool: string, input: string): CachedOutput | null;
}
```

**新增文件**：`src/brain/right/features/tool-output-cache.ts`

### 3.4 FileIndex（新增）

**作用**：本地文件多粒度索引，支持按段落/函数/类检索。

```typescript
interface FileChunk {
  filePath: string;
  chunkType: 'paragraph' | 'function' | 'class' | 'section' | 'import';
  name: string;            // 函数名/类名/段落标题
  content: string;         // 原文
  embedding: Float32Array; // 128d 向量
  startLine: number;
  endLine: number;
}

class FileIndex {
  private chunks: FileChunk[] = [];
  private vectorIndex: VectorIndex;
  private fileHashes: Map<string, string> = new Map(); // 文件路径 → 内容哈希

  // 索引文件（按类型自动切分）
  indexFile(filePath: string, content: string): void;

  // 索引目录（递归扫描）
  indexDirectory(dirPath: string, patterns?: string[]): void;

  // 语义检索
  search(query: Float32Array, topK: number, filters?: { filePath?: string; chunkType?: string }): FileChunk[];

  // 增量更新（只重新索引变化的文件）
  updateFile(filePath: string, content: string): void;
}
```

**切分策略**：
- `.ts`/`.js` → 按函数/类切分（AST 解析或正则匹配）
- `.md` → 按标题切分
- `.json` → 按顶层 key 切分
- 其他 → 按段落（空行分隔）切分

**新增文件**：`src/brain/right/features/file-index.ts`

### 3.5 CodeTemplates（新增）

**作用**：代码模板库，支持模式化代码组装。

```typescript
interface CodeTemplate {
  id: string;
  language: string;        // 'typescript' | 'python' | 'bash' | ...
  pattern: string;         // 模式描述（"错误处理"、"日志添加"、"参数校验"）
  skeleton: string;        // 代码骨架，用 {slotName} 标记槽位
  slots: Array<{ name: string; type: 'variable' | 'expression' | 'block' | 'type' }>;
  embedding: Float32Array; // 模式描述的向量
  successRate: number;
}

class CodeTemplateStore {
  private templates: CodeTemplate[] = [];
  private vectorIndex: VectorIndex;

  // 添加模板
  add(template: CodeTemplate): void;

  // 语义检索
  retrieve(query: Float32Array, language?: string, topK?: number): CodeTemplate[];

  // 从成功代码中自动学习模板
  learnFromPair(userRequest: string, generatedCode: string, language: string): void;
}
```

**新增文件**：`src/brain/right/features/code-templates.ts`

---

## 四、Layer 2: 语义层

### 4.1 ByteEncoder（已有）

**现状**：已实现，maxSeqLen=4096 字节，DynamicMerge 熵驱动压缩。

**改进**：
- 分段编码：长文本按段落切分，每段独立编码，不截断
- 缓存：相同文本不重复编码

### 4.2 VectorIndex（已有，需升级）

**现状**：`KnowledgeGate` 内置简单的线性扫描。

**升级**：统一为独立的 `VectorIndex` 组件，所有字典层共用。

```typescript
class VectorIndex {
  private vectors: Float32Array[] = [];
  private ids: string[] = [];

  // 构建索引
  add(id: string, vector: Float32Array): void;
  addBatch(ids: string[], vectors: Float32Array[]): void;

  // 余弦相似度 top-K
  search(query: Float32Array, topK: number): Array<{ id: string; score: number }>;

  // 删除
  remove(id: string): void;

  // 序列化/反序列化（持久化）
  serialize(): ArrayBuffer;
  deserialize(data: ArrayBuffer): void;
}
```

**新增文件**：`src/brain/right/features/vector-index.ts`

### 4.3 Reranker（新增）

**作用**：对 top-K 结果重排序，综合多个维度。

```typescript
interface RerankScore {
  relevance: number;    // 语义相关度（余弦相似度）
  freshness: number;    // 新鲜度（越新越高）
  authority: number;    // 权威度（成功率/使用频率）
  chainFit: number;     // 推理链完整性（是否形成因果链）
}

class Reranker {
  // 重排序
  rerank(
    query: Float32Array,
    candidates: Array<{ id: string; score: number; metadata: any }>,
    weights?: Partial<RerankScore>,
  ): Array<{ id: string; score: number; breakdown: RerankScore }>;
}
```

**评分公式**：
```
finalScore = w1 * relevance + w2 * freshness + w3 * authority + w4 * chainFit
默认权重: w1=0.5, w2=0.15, w3=0.15, w4=0.2
```

**推理链完整性**（LIR³AG 启发）：
- 检查候选片段之间是否有因果/递进关系
- 有关系的片段获得 chainFit 加分
- 优先保留形成完整推理链的片段组合

**新增文件**：`src/brain/right/features/reranker.ts`

### 4.4 GraphExpand（新增）

**作用**：沿知识图谱边关系扩展检索结果。

```typescript
class GraphExpand {
  constructor(private graph: KnowledgeGraph) {}

  // 从初始检索结果出发，沿边扩展
  expand(
    initialResults: Array<{ id: string; score: number }>,
    maxHops: number,      // 最大跳数（默认 2）
    maxExpand: number,    // 最多扩展几个（默认 5）
  ): Array<{ id: string; score: number; hopCount: number; path: string[] }>;
}
```

**新增文件**：`src/brain/right/features/graph-expand.ts`

---

## 五、Layer 3: 组装层

### 5.1 ContentSelector（新增）

**作用**：从 top-K 检索结果中选出需要的信息片段。

```typescript
interface SelectedFragment {
  source: 'knowledge' | 'decision_memory' | 'tool_output' | 'file_index' | 'code_template';
  content: string;       // 原文片段
  role: 'problem' | 'cause' | 'solution' | 'example' | 'context';
  relevance: number;
}

class ContentSelector {
  // 从检索结果中选择关键片段
  select(
    query: string,
    candidates: Array<{ id: string; content: string; score: number; source: string }>,
    maxFragments: number,  // 最多选几个（默认 5）
  ): SelectedFragment[];
}
```

**选择策略**：
- 去重：语义相似度 > 0.9 的只保留最高的
- 角色标注：根据内容推断角色（问题/原因/方案/示例/上下文）
- 多样性：不同来源各保留至少 1 个

**新增文件**：`src/brain/right/features/content-selector.ts`

### 5.2 FragmentExtractor（新增）

**作用**：从检索结果中提取关键信息片段（不是全文，是摘出来的关键句）。

```typescript
class FragmentExtractor {
  // 从文本中提取关键信息
  extractKeyInfo(text: string, query: string): string[];

  // 从工具输出中提取关键值
  extractFromToolOutput(tool: string, output: string): Map<string, string>;

  // 从代码中提取签名/摘要
  extractCodeSummary(code: string): { name: string; params: string[]; returns: string };
}
```

**提取策略**：
- 工具输出：正则匹配关键模式（错误信息、文件路径、数值、状态码）
- 代码：提取函数签名、类名、关键注释
- 文本：取与查询最相关的 1-2 句（用 ByteEncoder 逐句编码，选相似度最高的）

**新增文件**：`src/brain/right/features/fragment-extractor.ts`

### 5.3 SkeletonSelector（已有，需升级）

**现状**：`StructuredGenerator` 已有基础的骨架选择。

**升级**：扩展骨架库，支持多句骨架。

```typescript
// 骨架从单句扩展为多句模板
interface MultiSentenceSkeleton {
  id: string;
  intent: string;
  taskType: string;
  sentences: Array<{
    role: 'opening' | 'problem' | 'cause' | 'solution' | 'detail' | 'closing';
    template: string;    // 含 {slotName} 的模板
    slots: SlotDef[];
    optional: boolean;   // 是否可省略
  }>;
  connectors: Array<{
    from: string; role;  // 前一句的角色
    to: string; role;    // 后一句的角色
    words: string[];     // 可选连接词
  }>;
}
```

**新增文件**：扩展现有 `src/brain/right/nn/generator.ts`

### 5.4 ConnectorInsertor（新增）

**作用**：根据语义关系在片段之间插入连接词。

```typescript
// 连接词库
const CONNECTORS: Record<string, string[]> = {
  cause:    ['因为', '由于', '这是因为', '原因是'],
  effect:   ['所以', '因此', '导致', '这使得'],
  contrast: ['但是', '然而', '不过', '虽然...但是'],
  additive: ['另外', '此外', '同时', '而且'],
  solution: ['建议', '可以', '推荐', '解决方案是'],
  example:  ['例如', '比如', '具体来说', '举个例子'],
  summary:  ['总之', '综上', '总的来说', '简而言之'],
};

class ConnectorInsertor {
  // 判断两个片段之间的语义关系
  inferRelation(prev: SelectedFragment, next: SelectedFragment): string;

  // 选择连接词（避免重复使用同一个）
  selectConnector(relation: string, usedConnectors: Set<string>): string;

  // 在文本中插入连接词
  insert(fragments: SelectedFragment[]): string;
}
```

**关系推断规则**：
- problem → cause: `cause`
- cause → solution: `solution`
- solution → detail: `additive`
- any → example: `example`
- opening → closing: `summary`

**新增文件**：`src/brain/right/features/connector-insertor.ts`

---

## 六、Layer 4: 篇法层

### 6.1 ParagraphPlanner（新增）

**作用**：规划段落结构。

```typescript
interface ParagraphPlan {
  paragraphs: Array<{
    role: 'opening' | 'body' | 'closing';
    sentences: string[];
  }>;
  totalLength: 'short' | 'medium' | 'long';
}

class ParagraphPlanner {
  plan(
    fragments: SelectedFragment[],
    complexity: 'simple' | 'medium' | 'complex',
  ): ParagraphPlan;
}
```

**长度控制**：
- simple（一句话能答）→ 1 段，2-3 句
- medium（需要解释）→ 2 段，4-6 句
- complex（需要分析）→ 3 段，6-10 句

**新增文件**：`src/brain/right/features/paragraph-planner.ts`

### 6.2 DiscourseChain（新增）

**作用**：组织逻辑链——因果、并列、递进、转折。

```typescript
class DiscourseChain {
  // 对片段排序，形成逻辑链
  order(fragments: SelectedFragment[]): SelectedFragment[];

  // 检查逻辑链完整性
  validateChain(ordered: SelectedFragment[]): { valid: boolean; gaps: string[] };
}
```

**排序规则**：
1. 问题描述（必须在最前）
2. 原因分析（紧跟问题）
3. 解决方案（在原因之后）
4. 具体细节（在方案之后）
5. 示例（可选，在最后）

**新增文件**：`src/brain/right/features/discourse-chain.ts`

### 6.3 ReferringExpr（新增）

**作用**：指代消解，避免重复名词。

```typescript
class ReferringExpr {
  // 检测需要指代的实体
  detectEntities(text: string): Array<{ entity: string; positions: number[] }>;

  // 替换后续出现为指代词
  replace(text: string, entities: Array<{ entity: string; positions: number[] }>): string;
}
```

**规则**：
- 第一次出现：全称（"这个函数"、"Python 的 requests 库"）
- 后续出现：指代（"它"、"该库"）
- 中文：它/该/这个 + 名词
- 英文：it/this/that + noun

**新增文件**：`src/brain/right/features/referring-expr.ts`

---

## 七、完整管线调用流程

```
用户输入: "帮我看看这个函数为什么慢"
         ↓
┌─ Layer 2: 语义层 ─────────────────────────────────────┐
│ ByteEncoder.encode("帮我看看这个函数为什么慢") → 128d    │
│ VectorIndex.search(query, topK=10) → 候选片段            │
│ Reranker.rerank(candidates) → 重排序结果                  │
│ GraphExpand.expand(results, hops=2) → 扩展结果            │
└──────────────────────────────────────────────────────────┘
         ↓
┌─ Layer 3: 组装层 ─────────────────────────────────────┐
│ ContentSelector.select(candidates, max=5) → 关键片段     │
│ FragmentExtractor.extract(fragments) → 提取关键信息       │
│ SkeletonSelector.select(intent="code_ops") → 选骨架      │
│ SlotFiller.fill(skeleton, fragments) → 填充槽位           │
│ ConnectorInsertor.insert(filled) → 加连接词                │
└──────────────────────────────────────────────────────────┘
         ↓
┌─ Layer 4: 篇法层 ─────────────────────────────────────┐
│ ParagraphPlanner.plan(fragments, complexity) → 段落规划   │
│ DiscourseChain.order(fragments) → 逻辑排序                │
│ ReferringExpr.replace(text) → 指代消解                    │
│ LengthController.adjust(plan, target) → 篇幅控制           │
└──────────────────────────────────────────────────────────┘
         ↓
输出: "这个函数有 3 层嵌套循环，时间复杂度是 O(n³)，
      这是它慢的主要原因。建议用哈希表替代内层循环，
      可以降到 O(n²)。"
```

---

## 八、实施节奏

### Phase A: 基础设施（Week 1-2）
- [ ] `VectorIndex` 统一向量索引组件
- [ ] `DecisionMemory` 历史回复片段存储
- [ ] `ToolOutputCache` 工具输出缓存
- [ ] ByteEncoder maxSeqLen 调优（已完成：4096）

### Phase B: 检索增强（Week 3-4）
- [ ] `Reranker` 多维重排序
- [ ] `KnowledgeGraph` 图结构 + `GraphExpand` 多跳扩展
- [ ] `FileIndex` 文件多粒度索引

### Phase C: 组装引擎（Week 5-6）
- [ ] `ContentSelector` 片段选择
- [ ] `FragmentExtractor` 关键信息提取
- [ ] `ConnectorInsertor` 连接词插入
- [ ] 扩展 `StructuredGenerator` 为多句骨架

### Phase D: 篇法层（Week 7-8）
- [ ] `ParagraphPlanner` 段落规划
- [ ] `DiscourseChain` 逻辑链排序
- [ ] `ReferringExpr` 指代消解
- [ ] `CodeTemplates` 代码模板库

### Phase E: 集成测试（Week 9）
- [ ] 完整管线端到端测试
- [ ] 效果评估：本地完成率从 60% → 目标 85%
- [ ] 性能基准：组装延迟 < 50ms

---

## 九、参数影响

| 组件 | 新增参数 | 累计参数 |
|------|---------|---------|
| 现有系统 | — | 925K |
| VectorIndex | 0（纯算法） | 925K |
| DecisionMemory | 0（数据存储） | 925K |
| ToolOutputCache | 0（数据存储） | 925K |
| FileIndex | 0（数据存储） | 925K |
| KnowledgeGraph | 0（数据结构） | 925K |
| Reranker | 0（规则） | 925K |
| ContentSelector | 0（规则） | 925K |
| FragmentExtractor | 0（规则） | 925K |
| ConnectorInsertor | 0（规则） | 925K |
| ParagraphPlanner | 0（规则） | 925K |
| DiscourseChain | 0（规则） | 925K |
| ReferringExpr | 0（规则） | 925K |
| CodeTemplates | 0（数据存储） | 925K |
| **总计** | **+0K** | **925K** |

信息整合引擎全部是**规则 + 数据结构**，不增加任何 NN 参数。所有"智能"来自 ByteEncoder 编码 + 向量检索 + 规则组装。

---

## 十、与现有模块的关系

| 现有模块 | 关系 |
|---------|------|
| `KnowledgeGate` | Layer 1 的一个数据源，升级为图结构 |
| `StructuredGenerator` | Layer 3 的骨架选择器，扩展为多句骨架 |
| `DecisionMemory`（新） | Layer 1 的历史回复存储 |
| `PrototypeMemory` | 复用向量空间，但用途不同（原型匹配 vs 片段检索） |
| `OnlineLearner` | 触发 DecisionMemory 的存储 |
| `KnowledgeCondenser` | 在 Layer 1 中做知识凝结 |
| `ByteEncoder` | Layer 2 的编码器，已有 |
| `IntuitionNet` | 提供 intent/taskType 分类，驱动骨架选择 |

---

## 十一、关键指标

| 指标 | 当前 | 目标 |
|------|------|------|
| 本地完成率 | ~60% | ~85% |
| 平均响应延迟 | <25ms（NN） | <50ms（NN + 组装） |
| 代码模板覆盖率 | 0% | ~60% |
| 长文本理解 | ~500 字 | 无限制（FileIndex 分段） |
| 知识检索精度 | ~55% | ~75%（Reranker + GraphExpand） |
| 回复自然度 | 模板化 | 接近 LLM（多源组装 + 连接词） |

---

## 十二、未覆盖的 15%：创造性的边界

### 12.1 哪些场景组装引擎搞不定

| 场景 | 为什么组装不行 | 举例 |
|------|---------------|------|
| 开放式创作 | 没有可检索的"正确答案"，需要从无到有 | "写一首关于量子纠缠的诗" |
| 复杂推理/规划 | 需要多步逻辑推导，不是简单拼接 | "分析竞态条件并给出 3 种修复方案" |
| 跨域综合判断 | 知识库没有现成答案，需要融会贯通 | "这个架构适不适合我们团队？" |
| 长篇连贯文本 | 组装在长篇幅下容易逻辑断裂 | "写一份 2000 字技术方案" |
| 新颖/冷门问题 | 检索结果为空或质量差 | 从未遇到的全新领域问题 |
| 风格/语气适配 | 规则难以捕捉微妙语气变化 | "用轻松幽默的方式解释" |
| 多轮上下文推理 | 需要理解对话历史中的隐含信息 | "上次的方案结合今天的新需求改一下" |

**本质：组装擅长"已有信息的重组"，不擅长"从零创造"和"复杂推理"。**

### 12.2 创造的本质：尘埃的碰撞

万物由尘埃组成——LLM 的 token 是尘埃，注意力权重是组合规则。**粒度够小 + 组合规则够丰富，就能逼近创造。**

当前方案的差距不在"能不能组合"，而在三个机制的缺失：

```
当前方案：  原子（✅） + 组合规则（✅） + 变异（❌） + 评估（❌） + 进化（❌）
           → 能重组，不能创造

加三机制后：原子（✅） + 组合规则（✅） + 变异（✅） + 评估（✅） + 进化（✅）
           → 能创造（有限创造）
```

---

## 十三、创造性机制

### 13.1 变异算子（Mutation）— 尘埃的碰撞方式

当前组装是确定性的：相同输入 → 相同输出。创造需要非确定性重组。

**向量空间变异**：利用 ByteEncoder 的 128d 向量空间做语义探索。

```typescript
class SemanticMutator {
  constructor(private encoder: ByteEncoder, private vectorIndex: VectorIndex) {}

  // 语义插值：两个概念之间的"中间地带"
  interpolate(vecA: Float32Array, vecB: Float32Array, t: number): Float32Array {
    // t=0 → A, t=1 → B, t=0.5 → 从未存在但语义合理的概念
    return vecA.map((v, i) => v * (1 - t) + vecB[i] * t);
  }

  // 语义扰动：在某个方向上随机偏移
  perturb(vec: Float32Array, noiseScale: number): Float32Array {
    return vec.map(v => v + (Math.random() - 0.5) * noiseScale);
  }

  // 跨域嫁接：从两个不相关领域各取片段组合
  crossDomainSplice(domainA: string, domainB: string): {
    fragmentA: string;
    fragmentB: string;
    bridge: string;  // 连接两者的隐喻/类比
  };

  // 探索向量空间中的空白地带（最近邻距离 > 阈值的区域）
  explore空白(maxSamples: number): Float32Array[];
}
```

**核心思想**：ByteEncoder 的 128d 空间是连续的语义空间。在知识库未覆盖的点做采样，用最近邻找到相关片段，组装出"从未存在但语义合理"的组合。

**这就是创造的数学本质：在已知概念之间的空白地带探索。**

### 13.2 创造性评估（Evaluation）— 谁来判断"好"

创造不只是"产生新东西"，而是"产生好的新东西"。

```typescript
interface CreativeScore {
  novelty: number;     // 与已有输出的向量距离（越远越新）
  quality: number;     // 与高质量模板的相似度（越像越好）
  coherence: number;   // 内部逻辑一致性
  surprise: number;    // 出乎意料但合理（违反预期但可理解）
}

class CreativeEvaluator {
  // 评估创造性得分
  evaluate(
    output: string,
    context: { query: string; existingOutputs: string[]; qualityTemplates: string[] },
  ): CreativeScore;

  // 综合评分
  // finalScore = novelty × quality × coherence
  // 任何一项接近 0 → 总分接近 0（避免"新颖但垃圾"或"平庸但正确"）
}
```

**创造 = 新颖 × 有价值 × 可理解。缺任何一项都是随机噪声。**

### 13.3 进化闭环（Feedback Loop）— 尘埃的进化

当前方案是开环的：组装 → 输出 → 结束。创造需要闭环。

```typescript
class EvolutionaryLoop {
  // 记录输出 + 用户反馈
  record(output: string, feedback: 'positive' | 'negative' | 'neutral', embedding: Float32Array): void;

  // 根据反馈更新知识库条目权重
  updateWeights(): void;

  // 识别"创造性成功"模式：用户惊讶 + 满意的组合
  identifySuccessPatterns(): Array<{ combination: string; score: number }>;

  // 淘汰低分组合，保留高分组合（自然选择）
  evolve(generations: number): void;
}
```

**闭环流程**：
```
组装 → 输出 → 用户反馈 → 更新权重 → 下次检索和组装结果不同
  ↑_____________________________________________↓
```

用户的"哇"反应 → 标记为创造性成功 → 提升类似组合的权重。
用户的"不对"反应 → 标记为失败 → 降低该组合路径。

**同样的原子，经过反馈筛选，组合方式越来越"好"——这就是尘埃的进化。**

---

## 十四、用户框架注入 — 概念框架由用户提供

### 14.1 核心认知

系统不需要自己发明概念框架。**框架由用户提供，系统在框架内做创造性探索。**

这是人类创造的实际运作方式：
- 毕加索没有发明"颜色"和"形状"，他重组了它们
- 爱因斯坦没有发明"数学"，他在数学框架内重新组合了概念
- 程序员没有发明"编程语言"，在语言规则内组合

**框架从来不是创造者发明的，创造者是在框架内做碰撞。**

### 14.2 用户提供什么

用户不需要写代码，只需提供三样东西：

#### 1) 概念词表（Vocabulary）

```
"我的领域是教育科技，核心概念有：
学习路径、认知负荷、间隔重复、知识图谱、最近发展区、心流状态..."
```

→ 这些词是向量空间里的锚点。系统围绕它们做插值和扰动。

#### 2) 关系规则（Constraints）

```
"认知负荷和学习路径是反比关系：
路径越短，负荷越低，但学习深度也越低。
这是一个需要平衡的张力。"
```

→ 告诉系统哪些组合合理，哪些荒谬。约束过滤掉噪声。

#### 3) 审美标准（What's "good"）

```
"好的教育方案应该：让学生感到惊讶但不失控，
新颖但可理解，有挑战但不焦虑。"
```

→ 创造评估函数的权重。用户定义"好"，系统在定义域内搜索。

### 14.3 注入机制

```typescript
interface UserFramework {
  vocabulary: Array<{
    concept: string;         // 概念名称
    definition: string;      // 定义/描述
    embedding?: Float32Array; // 可选：预计算向量
  }>;

  relations: Array<{
    from: string;            // 概念 A
    to: string;              // 概念 B
    type: 'causes' | 'contradicts' | 'requires' | 'enables' | 'balances' | 'metaphor';
    description: string;     // 关系描述
  }>;

  aesthetics: {
    noveltyWeight: number;   // 0-1，用户对新颖性的偏好
    coherenceWeight: number; // 0-1，用户对逻辑性的偏好
    surpriseWeight: number;  // 0-1，用户对意外性的偏好
    style: string;           // 风格描述（"严谨"、"轻松"、"诗意"...）
  };
}

class FrameworkInjector {
  // 将用户框架注入系统
  inject(framework: UserFramework): void;

  // 概念词表 → 注入 KnowledgeStore + 向量空间锚点
  // 关系规则 → 注入 KnowledgeGraph 边
  // 审美标准 → 配置 CreativeEvaluator 权重
}
```

### 14.4 与四层管线的集成

```
用户注入框架（词表 + 关系 + 审美）
         ↓
Layer 1 字典层 ← 概念词表 + 关系规则注入 KnowledgeStore / KnowledgeGraph
         ↓
Layer 2 语义层 ← ByteEncoder 把概念编码为向量，建立语义空间
         ↓
Layer 3 组装层 ← SemanticMutator 在向量空间内做变异 + 约束过滤 + 组装
         ↓
Layer 4 篇法层 ← CreativeEvaluator 按审美标准评估输出
         ↓
创造性输出（在用户定义的框架内）
```

**系统的"创造力上限"不由系统自己决定，而由用户提供的框架丰富度决定。**

框架越丰富 → 向量空间越稠密 → 可探索的组合越多 → 创造性越高。

### 14.5 这解决了 15% 的差距

那 15% 不是"系统做不到"，而是没有框架可探索的空白区。一旦用户给了框架，空白区就被定义出来了。

> **15% 的差距不是能力差距，是信息差距。用户填上信息，差距就消失。**

这也是"个人 AI 助手"比"通用 AI"更适合这条路线的原因——不需要覆盖所有领域，只需要覆盖这一个用户关心的领域。用户的框架就是护城河。

---

## 十五、有限创造 vs 无限创造

### 15.1 什么是"有限创造"

加了上述三机制 + 用户框架后，系统能做到：

- ✅ 在已知概念空间的空白地带探索
- ✅ 产生新颖且有价值的组合
- ✅ 跨域嫁接不同领域的概念
- ✅ 随用户反馈进化

但做不到：

- ❌ 跳出"概念空间的边界"
- ❌ 发明全新的概念框架
- ❌ 超越用户提供的认知范围

### 15.2 这够不够？

**够用。** 因为人类的大部分创造也是有限创造：

- 毕加索重组了已有的视觉元素
- 爱因斯坦重新组合了已有的物理概念
- 乔布斯把书法美学嫁接到计算机设计

**真正的"无限创造"（无中生有）可能根本不存在。** 所有创造都是重组，只是重组的跨度和新颖度不同。

系统的上限 = 用户框架的丰富度 × 向量空间的探索能力。只要用户持续注入新知识、新关系、新标准，系统就能持续产出"有限但有价值"的创造性输出。

---

## 十六、更新后的实施节奏

### Phase A: 基础设施（Week 1-2）— 不变
- [ ] `VectorIndex` 统一向量索引组件
- [ ] `DecisionMemory` 历史回复片段存储
- [ ] `ToolOutputCache` 工具输出缓存
- [ ] ByteEncoder maxSeqLen 调优（已完成：4096）

### Phase B: 检索增强（Week 3-4）— 不变
- [ ] `Reranker` 多维重排序
- [ ] `KnowledgeGraph` 图结构 + `GraphExpand` 多跳扩展
- [ ] `FileIndex` 文件多粒度索引

### Phase C: 组装引擎（Week 5-6）— 不变
- [ ] `ContentSelector` 片段选择
- [ ] `FragmentExtractor` 关键信息提取
- [ ] `ConnectorInsertor` 连接词插入
- [ ] 扩展 `StructuredGenerator` 为多句骨架

### Phase D: 篇法层（Week 7-8）— 不变
- [ ] `ParagraphPlanner` 段落规划
- [ ] `DiscourseChain` 逻辑链排序
- [ ] `ReferringExpr` 指代消解
- [ ] `CodeTemplates` 代码模板库

### Phase E: 集成测试（Week 9）— 不变

### Phase F: 创造性机制（Week 10-11）— **新增**
- [ ] `SemanticMutator` 向量空间变异算子
- [ ] `CreativeEvaluator` 创造性评估（新颖 × 质量 × 连贯）
- [ ] `EvolutionaryLoop` 反馈进化闭环
- [ ] `FrameworkInjector` 用户框架注入机制

### Phase G: 创造性集成测试（Week 12）— **新增**
- [ ] 向量空间插值 → 检索 → 组装端到端测试
- [ ] 用户框架注入 → 创造性输出验证
- [ ] 反馈闭环 → 进化效果评估
- [ ] 创造性指标：新颖度、质量、用户满意度

---

## 十七、更新后的参数影响

| 组件 | 新增参数 | 累计参数 |
|------|---------|---------|
| 原有系统（Phase A-E） | +0K | 925K |
| SemanticMutator | 0（纯算法） | 925K |
| CreativeEvaluator | 0（规则） | 925K |
| EvolutionaryLoop | 0（数据存储） | 925K |
| FrameworkInjector | 0（数据注入） | 925K |
| **总计** | **+0K** | **925K** |

创造性机制同样是**规则 + 数据结构 + 向量空间操作**，不增加 NN 参数。
所有"创造"来自向量空间的数学操作（插值/扰动/探索）+ 用户框架的语义约束。

---

## 十八、更新后的关键指标

| 指标 | 当前 | Phase A-E 目标 | Phase F-G 目标 |
|------|------|---------------|---------------|
| 本地完成率 | ~60% | ~85% | ~90%+ |
| 平均响应延迟 | <25ms（NN） | <50ms（NN + 组装） | <80ms（NN + 组装 + 变异） |
| 代码模板覆盖率 | 0% | ~60% | ~60% |
| 长文本理解 | ~500 字 | 无限制（FileIndex 分段） | 无限制 |
| 知识检索精度 | ~55% | ~75% | ~80%（含变异探索） |
| 回复自然度 | 模板化 | 接近 LLM | 接近 LLM + 创造性 |
| **创造性输出** | **无** | **无** | **支持**（用户框架内） |
| **跨域组合能力** | **无** | **无** | **支持**（向量空间嫁接） |
| **进化能力** | **无** | **无** | **支持**（反馈闭环） |
