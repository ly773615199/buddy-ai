# 三脑缺口修复总计划

> 版本: v1.0
> 日期: 2026-05-15
> 目标: 修复三个核心缺口，让三脑架构从"有壳无核"变为"可用"

---

## 一、全局视图

### 三个缺口 + 一个支撑

```
┌─────────────────────────────────────────────────────────┐
│                    三脑架构                               │
│                                                         │
│  缺口一：语言理解     缺口二：语言生成     缺口三：多模态   │
│  (ByteEncoder)       (Generator)        (Vision/Audio)  │
│       ❌                 ❌                 ❌            │
│  权重随机             8个模板             像素统计         │
│                                                         │
│  ─────────────────────────────────────────────────────  │
│                                                         │
│  支撑层：知识体系                                         │
│  (KnowledgeTier)                                       │
│       ⚠️                                               │
│  15条种子，覆盖率20%                                     │
│                                                         │
│  所有缺口共同依赖：ByteEncoder 训练                       │
│  ByteEncoder 训练依赖：预训练教师模型蒸馏                  │
└─────────────────────────────────────────────────────────┘
```

### 依赖关系

```
预训练教师模型蒸馏
    │
    ▼
ByteEncoder 训练完成 ──────────────────────┐
    │                                      │
    ├──→ 缺口一修复（语义向量有意义）        │
    │       │                              │
    │       ▼                              │
    │    KnowledgeGate 向量检索有效          │
    │       │                              │
    │       ▼                              │
    │    知识分层 Tier 1-3 生效              │
    │                                      │
    ├──→ 缺口二修复（模板学习有意义）        │
    │                                      │
    └──→ 缺口三修复（多模态向量对齐）        │
```

**核心结论：ByteEncoder 训练是一切的地基。**

---

## 二、Phase 0：修 Bug（1天）

在开始缺口修复前，先修掉集成遗留的 4 个 P0-P1 问题。

### Bug 1：KnowledgeGate 注入空数据 [P0]

**问题**：`predictFull()` 调用 `forwardWithKnowledge(tokenIds, textEmbedding, undefined)`
**修复**：在 `predictFull()` 前从 STMP 检索相关记忆，注入 KnowledgeGate

```
文件：src/brain/right/index.ts
改动：predictFull() 中增加 STMP 检索 → KnowledgeGate 注入
```

### Bug 2：ReasoningHead 重复推理 [P1]

**问题**：`predictFull()` 先跑 `forwardWithKnowledge()`，再单独跑 `reasoningHead.forward()`
**修复**：改用 `forwardWithReasoning()` 一步完成

```
文件：src/brain/right/index.ts
改动：predictFull() 改用 forwardWithReasoning()，内部已包含 CrossHead
```

### Bug 3：模板学习输入为空 [P1]

**问题**：`brain.ts` feedback() 中 `learnTemplate('', actualOutput, ...)`
**修复**：传入实际的用户输入

```
文件：src/brain/brain.ts
改动：feedback() 签名增加 userInput 参数，传入 learnTemplate()
```

### Bug 4：agent.ts 不消费 localGeneration [P1]

**问题**：`decide()` 返回 `localGeneration` 但 `agent.ts` 不使用
**修复**：在 agent.ts 中检查 localGeneration，置信度足够时跳过 LLM

```
文件：src/core/agent.ts
改动：orchestrate() 后检查 decision.localGeneration，直接返回
```

### 验收标准

- KnowledgeGate 收到真实知识条目
- ReasoningHead 只运行一次
- 模板学习能记录用户输入
- localGeneration 置信度 ≥ 0.6 时不调用 LLM

---

## 三、Phase 1：ByteEncoder 训练（3天）

### 1.1 教师模型选择

| 选项 | 模型 | 大小 | 维度 | 语言 | 推荐场景 |
|------|------|------|------|------|---------|
| **A** | BAAI/bge-small-zh-v1.5 | 24MB | 512 | 中文为主 | ✅ 默认推荐 |
| B | Xenova/all-MiniLM-L6-v2 | 22MB | 384 | 英文为主 | 英文场景 |
| C | nomic-ai/nomic-embed-text-v1.5 | 137MB | 768 | 多语言 | 性能最优 |

**默认选择 A**：bge-small-zh-v1.5。中文向量质量最好，24MB 轻量，Apache 2.0 许可。

### 1.2 训练数据准备

#### 数据源

| 来源 | 采样方式 | 预期数量 |
|------|---------|---------|
| STMP 记忆 | 同房间配对 → 正样本 | 200-1000 对 |
| 经验图谱 | 同 intent 关键词配对 | 50-100 对 |
| 种子经验 | 描述文本配对 | 30-50 对 |
| 代码注释 | 同文件的注释+代码 | 100-200 对（可选） |

#### 数据格式

```jsonl
{"text": "读一下 package.json", "room": "project", "concepts": ["file", "read"]}
{"text": "查看 package.json 内容", "room": "project", "concepts": ["file", "read"]}
{"text": "git 提交代码", "room": "git", "concepts": ["git", "commit"]}
```

#### 数据生成脚本

```
文件：scripts/generate-training-data.ts
功能：
  1. 从 STMP 导出所有记忆 → 按房间分组 → 生成正样本对
  2. 从 ExperienceGraph 导出经验 → 按 intent 分组 → 生成正样本对
  3. 从种子经验生成描述文本配对
  4. 合并去重 → 输出 training-corpus.jsonl
  5. 调用教师模型预计算向量 → 输出 teacher-embeddings.json
```

### 1.3 蒸馏训练

#### 架构

```
教师模型 (bge-small-zh, 512d, 冻结)
    │
    │ teacher embedding (512d, 已归一化)
    │
    ▼
投影层 (128d → 512d, 可训练, 训练后丢弃)
    │
    │ projected (512d)
    │
    ▼
MSE Loss ← → 教师向量
    │
    ▼
反向传播 → 更新 ByteEncoder 145K 参数 + 投影层
```

#### Loss 函数

```typescript
// MSE Loss（向量回归）
L = Σ (projected[i] - teacher[i])² / dim

// 可选增强：对比 Loss（更好）
L_contrastive = InfoNCE(anchor, positive, negatives, τ=0.07)

// 组合 Loss
L = α * L_mse + (1-α) * L_contrastive   // α=0.5
```

#### 训练超参

| 参数 | 值 | 说明 |
|------|-----|------|
| 学习率 | 0.001 | SGD + momentum 0.9 |
| Batch size | 16 | |
| Epochs | 30 | CPU 约 10-30 分钟 |
| 温度 τ | 0.07 | InfoNCE 温度 |
| 投影维度 | 128→512 | 对齐教师维度 |
| 梯度裁剪 | 1.0 | maxGradNorm |

#### 实现文件

```
文件：src/brain/right/training/byte-encoder-trainer.ts (~250行)
类：ByteEncoderTrainer
方法：
  - constructor(byteEncoder, teacherCache, optimizer)
  - samplePairs(): 从语料中采样正/负样本对
  - trainStep(): 单步训练
  - train(epochs): 完整训练循环
  - evaluate(): 验证（余弦相似度对比）
  - save(path): 保存训练后权重
```

#### 训练入口

```
文件：scripts/train-byte-encoder.ts (~80行)
功能：
  1. 加载教师向量缓存 (teacher-embeddings.json)
  2. 加载训练语料 (training-corpus.jsonl)
  3. 初始化 ByteEncoder + 投影层 + 优化器
  4. 训练 30 epoch
  5. 验证：10 组相似文本对，余弦相似度 > 0.8
  6. 保存权重 → models/byte-encoder-trained.bin
```

### 1.4 权重加载与热替换

```
文件：src/brain/right/features/text-encoder.ts
改动：
  - 新增 loadTrained(path): 加载训练后权重
  - 新增 isTrained(): 检查是否已训练
文件：src/brain/right/index.ts
改动：
  - constructor 中尝试加载 models/byte-encoder-trained.bin
  - 加载失败时使用随机权重（向后兼容）
```

### 1.5 验收标准

| 指标 | 训练前 | 训练后目标 |
|------|--------|-----------|
| 相似文本余弦相似度 | ~0.05 (随机) | > 0.80 |
| 不同文本余弦相似度 | ~0.05 (随机) | < 0.30 |
| KnowledgeGate 检索命中率 | 随机 | > 60% |
| Intent 分类准确率 (中文) | ~40% (关键词) | ~60% |
| 训练时间 (CPU) | - | < 30 分钟 |

---

## 四、Phase 2：知识分层（1周）

> 详见 KNOWLEDGE_TIER_PLAN.md，此处为概要。

### 2.1 Tier 1：扩展种子（2天）

- 新增 ~85 条能力种子（代码生成/调试/系统/文档/问答/文件）
- 导入 ExperienceGraph
- 冷启动覆盖率从 20% → 65%

### 2.2 Tier 2：按需搜索兜底（2天）

- 新建 `OnDemandSearcher` 类
- 经验未命中 → search_web → LLM 总结 → 自动编译为经验
- 防滥用：冷却 30 分钟 + 每日 50 次上限

### 2.3 Tier 3：自积累增强（3天）

- KnowledgeBridge：STMP/经验图谱 → KnowledgeGate 向量注入
- Dream Engine ↔ KnowledgeGate 联动
- QA 知识提取器（从纯问答中提取知识条目）

### 验收标准

| 指标 | 目标 |
|------|------|
| 冷启动覆盖率 | ≥ 65% |
| 搜索兜底延迟 | < 10s |
| 搜索沉淀率 | ≥ 30% |
| 30 天后经验数 | ≥ 200 |

---

## 五、Phase 3：语言生成增强（4天）

### 3.1 模板库扩充（2天）

从 8 个内置模板扩展到 ~50 个：

| 类别 | 当前 | 目标 | 示例 |
|------|------|------|------|
| 工具确认 | 3 | 8 | 读取/写入/执行/搜索/提交/部署/安装/配置 |
| 结果展示 | 2 | 10 | 成功/失败/部分成功/超时/无结果/权限不足 |
| 代码相关 | 1 | 10 | 解释/审查/重构/测试/调试/优化/生成/转换 |
| 问答 | 1 | 8 | 定义/对比/步骤/原理/推荐/排查/评估/总结 |
| 系统操作 | 0 | 5 | 进程/端口/服务/日志/备份 |
| 闲聊 | 1 | 4 | 问候/感谢/告别/确认 |
| 错误处理 | 0 | 5 | 网络/权限/依赖/超时/未知 |

### 3.2 agent.ts 消费 localGeneration（1天）

```
文件：src/core/agent.ts
改动：
  - orchestrate() 后检查 decision.localGeneration
  - confidence ≥ 0.6 → 直接返回本地生成
  - confidence ≥ 0.4 → 本地骨架 + LLM 补完
  - confidence < 0.4 → 走 LLM（现有路径）
```

### 3.3 模板自动学习修复（1天）

```
文件：src/brain/brain.ts
改动：
  - feedback() 中传入实际 userInput（非空字符串）
  - learnTemplate() 增加去重逻辑（避免重复模板）
文件：src/brain/right/nn/generator.ts
改动：
  - autoLearn() 增加最小槽位数过滤（≥ 1）
  - 模板淘汰：成功率 < 0.3 的自动模板被清除
```

### 验收标准

| 指标 | 目标 |
|------|------|
| 内置模板数 | ≥ 50 |
| 本地生成率（chat 任务） | ≥ 30% |
| 模板学习成功率 | ≥ 10% 的成功交互产生新模板 |
| LLM 调用减少 | chat 任务 LLM 调用减少 20% |

---

## 六、Phase 4：多模态管道（1周，优先级最低）

### 4.1 ImageEncoder 升级（3天）

**当前**：像素统计（平均颜色、方差、边缘强度）
**目标**：学习式 patch 投影 → Transformer → 语义向量

```
文件：src/brain/right/features/image-encoder.ts
改动：
  - 替换 encodeImage() 实现
  - 像素 → 8x8 patch → 线性投影 → 128d
  - 2 层 Transformer（复用 EncoderBlock）
  - alignProj：视觉 128d → 文本 128d 空间对齐
参数量：~180K
```

### 4.2 感知管道接入（2天）

```
文件：src/brain/brain.ts
改动：
  - injectScreenshot() / injectImage() 已有
  - 需要对接实际的截图/摄像头/图片上传源
  - 图片 → RawImage → ImageEncoder → 128d → 融合到 predictFull()
```

### 4.3 AudioEncoder 管道（2天）

```
文件：src/brain/right/features/audio-encoder.ts
改动：
  - 接入音频采集（麦克风 / 音频文件）
  - 音频 → RawAudio → AudioEncoder → 128d → 融合
需要：音频采集库（如 node-microphone 或 Web Audio API）
```

### 验收标准

| 指标 | 目标 |
|------|------|
| 图片理解 | 能识别物体/场景/文字（不是色块） |
| 图文融合 | "这个截图里有错误" → 分析截图 |
| 音频理解 | 语音输入 → 文本转录 + 语义理解 |
| 多模态推理延迟 | < 30ms（图片）/ < 50ms（音频） |

---

## 七、P0-P1 Bug 修复清单

在 Phase 0 中完成，与其他 Phase 并行。

| Bug | 文件 | 修复 | 状态 |
|-----|------|------|------|
| KnowledgeGate 注入空数据 | right/index.ts | STMP 检索注入 | 📋 |
| ReasoningHead 重复推理 | right/index.ts | 改用 forwardWithReasoning | 📋 |
| 模板学习输入为空 | brain.ts | 传入 userInput | 📋 |
| agent.ts 不消费 localGeneration | agent.ts | 检查并使用 | 📋 |
| LayerwiseLPR 注册了但没用 | online-learner.ts | 逐层 λ 替代全局 λ | 📋 |

---

## 八、实施时间线

```
Week 0 (当前):
  Day 1: Phase 0 - 修 Bug (4个P0-P1)
  Day 2-3: Phase 1.1-1.2 - 训练数据准备 + 教师向量预计算

Week 1:
  Day 1-2: Phase 1.3-1.4 - ByteEncoder 蒸馏训练 + 权重加载
  Day 3: Phase 1.5 - 验证语义向量质量
  Day 4-5: Phase 2.1 - Tier 1 种子扩展 (85条)

Week 2:
  Day 1-2: Phase 2.2 - Tier 2 按需搜索
  Day 3-5: Phase 2.3 - Tier 3 自积累增强

Week 3:
  Day 1-2: Phase 3.1 - 模板库扩充
  Day 3: Phase 3.2 - agent.ts 消费 localGeneration
  Day 4: Phase 3.3 - 模板自动学习修复
  Day 5: 集成测试 + 文档

Week 4 (可选):
  Phase 4: 多模态管道（优先级最低，按需执行）
```

### 里程碑

| 里程碑 | 时间 | 验收 |
|--------|------|------|
| M0: Bug 修复 | Week 0 末 | 4 个 P0-P1 修复完成 |
| M1: ByteEncoder 训练 | Week 1 中 | 相似文本 sim > 0.8 |
| M2: 知识分层 | Week 2 末 | 冷启动覆盖 65% |
| M3: 语言生成 | Week 3 末 | 本地生成率 30% |
| M4: 多模态 (可选) | Week 4 末 | 图片理解可用 |

---

## 九、产出文件清单

### 新建文件

| 文件 | 用途 | 行数估算 |
|------|------|---------|
| `src/brain/right/training/byte-encoder-trainer.ts` | ByteEncoder 蒸馏训练 | ~250 |
| `src/intelligence/on-demand-search.ts` | 按需搜索兜底 | ~200 |
| `src/brain/right/nn/knowledge-bridge.ts` | STMP→KnowledgeGate 桥接 | ~150 |
| `src/intelligence/qa-extractor.ts` | QA 知识提取 | ~100 |
| `scripts/train-byte-encoder.ts` | 离线训练入口 | ~80 |
| `scripts/generate-training-data.ts` | 训练数据生成 | ~120 |
| `scripts/seed-capabilities.ts` | Tier 1 种子导入 | ~300 |
| `data/training-corpus.jsonl` | 训练语料 | - |
| `models/byte-encoder-trained.bin` | 训练后权重 | ~570KB |

### 修改文件

| 文件 | 改动 |
|------|------|
| `src/brain/right/index.ts` | predictFull 修复、ByteEncoder 热加载 |
| `src/brain/brain.ts` | feedback 修复、condenseKnowledge 增强 |
| `src/core/agent.ts` | localGeneration 消费 |
| `src/brain/right/training/online-learner.ts` | LayerwiseLPR 实际使用 |
| `src/brain/right/features/text-encoder.ts` | loadTrained() 方法 |
| `src/brain/right/nn/generator.ts` | 模板扩充 + 学习修复 |

---

## 十、风险与缓解

| 风险 | 影响 | 缓解 |
|------|------|------|
| 教师模型蒸馏效果差 | ByteEncoder 向量无意义 | 对比多种教师模型、调整 loss 权重 |
| 训练数据不足 | 过拟合 | 数据增强（同义词替换、回译） |
| STMP 记忆太少 | 训练对不足 | 用种子经验 + 经验图谱补充 |
| 搜索 API 限流 | Tier 2 失效 | 缓存 + 每日上限 + 降级到纯 LLM |
| 模板质量参差 | 本地生成质量差 | 成功率阈值 + 人工审核种子模板 |

---

## 十一、验收总表

| Phase | 指标 | 基线 | 目标 | 测量方法 |
|-------|------|------|------|---------|
| 0 | Bug 修复数 | 0/4 | 4/4 | 代码审查 |
| 1 | 相似文本 sim | 0.05 | >0.80 | 10 组测试对 |
| 1 | 不同文本 sim | 0.05 | <0.30 | 10 组测试对 |
| 1 | Intent 准确率 | 40% | 60% | 50 条测试集 |
| 2 | 冷启动覆盖率 | 20% | 65% | 100 条标准问题 |
| 2 | 搜索沉淀率 | 0% | 30% | 搜索后自动编译 |
| 3 | 本地生成率 | 0% | 30% | chat 任务统计 |
| 3 | LLM 调用减少 | 0% | 20% | 对比实验 |
| 4 | 图片理解 | 色块 | 识别物体 | 10 张测试图 |
