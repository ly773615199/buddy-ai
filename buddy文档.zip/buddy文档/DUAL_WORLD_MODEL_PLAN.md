# 双世界模型平行宇宙 — 详细实现计划

> 代号: Quantum Entangled World Models (QEWM)
> 目标: WorldModel(MLP) 主推理 + SceneWorldModel(GNN) 主模拟，相互独立又相互纠缠

---

## 1. 架构总览

```
                         用户输入
                            │
                            ▼
                   ┌────────────────┐
                   │  三脑决策中心    │
                   └───────┬────────┘
                           │
               ┌───────────┴───────────┐
               ▼                       ▼
       ┌──────────────┐       ┌──────────────┐
       │  宇宙A: 推理  │       │  宇宙B: 模拟  │
       │  WorldModel   │       │  SceneWorld   │
       │  (MLP 快速)   │       │  (GNN 精确)   │
       │              │       │              │
       │  多步推理链    │       │  多步场景推演   │
       │  反事实推理    │       │  实体级变更预测  │
       │  类比迁移     │       │  风险传播分析   │
       └──────┬───────┘       └──────┬───────┘
              │                      │
              │    ┌──────────┐      │
              └───►│  纠缠层   │◄────┘
                   │ Entangle │
                   └────┬─────┘
                        │
                        ▼
                   综合决策输出
```

---

## 2. 现有代码盘点

### 2.1 已实现的组件

| 组件 | 文件 | 状态 | 需要改造 |
|------|------|------|---------|
| WorldModel (MLP) | `src/brain/right/nn/world-model.ts` | ✅ 完整 | 升级推理能力 |
| SceneWorldModel (GNN) | `src/brain/right/scene/scene-world-model.ts` | ✅ 完整 | 专注模拟 |
| ReasoningHead | `src/brain/right/nn/reasoning-head.ts` | ✅ 完整 | 与宇宙A融合 |
| EntityRegistry | `src/brain/right/scene/entity-registry.ts` | ✅ 完整 | 无 |
| GNNLayer | `src/brain/right/scene/gnn-layer.ts` | ✅ 完整 | 无 |
| RightBrain (集成层) | `src/brain/right/index.ts` | ✅ 完整 | 接入纠缠层 |
| A/B 测试框架 | `src/brain/right/scene/ab-scene-vs-legacy.test.ts` | ✅ 完整 | 扩展测试 |

### 2.2 需要新建的组件

| 组件 | 文件 | 作用 |
|------|------|------|
| ReasoningUniverse (宇宙A) | `src/brain/right/universe/reasoning-universe.ts` | 推理宇宙封装 |
| SimulationUniverse (宇宙B) | `src/brain/right/universe/simulation-universe.ts` | 模拟宇宙封装 |
| EntangleLayer (纠缠层) | `src/brain/right/universe/entangle-layer.ts` | 双宇宙信息交换 |
| ParallelUniverseOrchestrator | `src/brain/right/universe/orchestrator.ts` | 并行编排器 |
| 反事实推理引擎 | `src/brain/right/universe/counterfactual.ts` | "如果当时..." |
| 类比迁移引擎 | `src/brain/right/universe/analogy.ts` | 从相似场景迁移 |
| 风险传播分析 | `src/brain/right/universe/risk-propagation.ts` | 风险在图中传播 |

---

## 3. 分步实现计划

### Phase 1: 宇宙封装层 (Day 1-2)

**目标:** 将现有 WorldModel 和 SceneWorldModel 封装为独立"宇宙"，统一接口。

#### 3.1 定义宇宙接口

```typescript
// src/brain/right/universe/types.ts

/** 宇宙状态 — 叠加态 */
export interface UniverseState {
  /** 状态向量（推理宇宙用 latent，模拟宇宙用 scene graph） */
  vector: Float32Array;
  /** 场景图（模拟宇宙专用，推理宇宙为 null） */
  scene: SceneGraph | null;
  /** 时间步 */
  timestep: number;
}

/** 宇宙预测结果 */
export interface UniversePrediction {
  /** 下一状态 */
  nextState: UniverseState;
  /** 置信度 0-1 */
  confidence: number;
  /** 风险评分 0-1 */
  riskScore: number;
  /** 完成概率 0-1 */
  completionProb: number;
  /** 延迟 ms */
  latencyMs: number;
  /** 来源宇宙 */
  source: 'reasoning' | 'simulation';
}

/** 候选动作 */
export interface CandidateAction {
  id: string;
  type: string;
  params: Float32Array;
  label: string;
  /** 初始评分（来自调度器/规则/直觉） */
  initialScore: number;
}

/** 推理路径（宇宙A专用） */
export interface ReasoningPath {
  steps: Array<{
    action: CandidateAction;
    predictedState: UniverseState;
    confidence: number;
    counterfactual?: string;  // 反事实分析
  }>;
  totalConfidence: number;
  analogies: AnalogyResult[];
}

/** 模拟结果（宇宙B专用） */
export interface SimulationResult {
  scenarios: Array<{
    action: CandidateAction;
    entityChanges: EntityChange[];
    edgeChanges: EdgeChange[];
    riskPropagation: RiskNode[];
    completionProb: number;
  }>;
  criticalPath: string[];
  totalRisk: number;
}

/** 纠缠结果 — 两个宇宙坍缩后的最终决策 */
export interface EntangledDecision {
  /** 选中的动作 */
  selectedAction: CandidateAction;
  /** 共振置信度（A×B 加权） */
  resonatedConfidence: number;
  /** 推理路径摘要 */
  reasoningSummary: string;
  /** 模拟结果摘要 */
  simulationSummary: string;
  /** 风险评估 */
  riskAssessment: number;
  /** 是否需要用户确认 */
  needsUserConfirmation: boolean;
  /** 替代方案（置信度接近时提供） */
  alternatives: Array<{
    action: CandidateAction;
    confidence: number;
    riskScore: number;
  }>;
}
```

#### 3.2 推理宇宙封装

```typescript
// src/brain/right/universe/reasoning-universe.ts

export class ReasoningUniverse {
  private worldModel: WorldModel;
  private reasoningHead: ReasoningHead;
  private byteEncoder: ByteEncoder;

  /**
   * 快速推理：对多个候选动作并行评估
   * 目标: 20 候选 < 1ms
   */
  reason(
    currentState: UniverseState,
    candidates: CandidateAction[],
    maxSteps: number = 5,
  ): ReasoningPath {
    // 1. 编码当前状态为 latent
    const latent = this.encodeState(currentState);

    // 2. 对每个候选动作快速预测
    const evaluated = candidates.map(c => {
      const action = this.encodeAction(c);
      const prediction = this.worldModel.predict(latent, action);
      return {
        action: c,
        predictedState: this.decodeState(prediction.nextLatent),
        confidence: prediction.confidence,
        riskScore: 1 - prediction.confidence,
      };
    });

    // 3. 排序
    evaluated.sort((a, b) => b.confidence - a.confidence);

    // 4. ReasoningHead 多步推理（复杂任务）
    const reasoningResult = this.reasoningHead.forward(
      this.byteEncoder.forward(JSON.stringify(evaluated.slice(0, 5)))
    );

    return {
      steps: evaluated,
      totalConfidence: reasoningResult.finalConfidence,
      analogies: [], // Phase 3 实现
    };
  }

  /**
   * 反事实推理："如果当时不这样做呢？"
   */
  reasonCounterfactual(
    state: UniverseState,
    actualAction: CandidateAction,
    alternativeActions: CandidateAction[],
  ): CounterfactualResult { ... }

  /**
   * 多步想象：连续执行多个动作的预测
   */
  imagine(state: UniverseState, actions: CandidateAction[]): UniversePrediction[] {
    const latent = this.encodeState(state);
    const encodedActions = actions.map(a => this.encodeAction(a));
    const results = this.worldModel.imagine(latent, encodedActions);
    return results.map((r, i) => ({
      nextState: this.decodeState(r.nextLatent),
      confidence: r.confidence,
      riskScore: 1 - r.confidence,
      completionProb: r.topologyChangeProb,
      latencyMs: r.latencyMs,
      source: 'reasoning' as const,
    }));
  }
}
```

#### 3.3 模拟宇宙封装

```typescript
// src/brain/right/universe/simulation-universe.ts

export class SimulationUniverse {
  private sceneWorldModel: SceneWorldModel;
  private entityRegistry: EntityRegistry;

  /**
   * 精确模拟：对指定候选动作做场景级推演
   * 目标: 3-5 候选 < 3ms
   */
  simulate(
    scene: SceneGraph,
    candidates: CandidateAction[],
  ): SimulationResult {
    const scenarios = candidates.map(c => {
      const action: SceneAction = {
        type: c.type,
        target_entity: c.params.length > 0 ? String(c.params[0]) : undefined,
        params: c.params,
      };
      const result = this.sceneWorldModel.predict(scene, action);
      return {
        action: c,
        entityChanges: result.entityChanges,
        edgeChanges: result.edgeChanges,
        riskPropagation: this.analyzeRiskPropagation(result),
        completionProb: result.completionProb,
      };
    });

    return {
      scenarios,
      criticalPath: this.findCriticalPath(scenarios),
      totalRisk: scenarios.reduce((s, sc) => s + sc.riskPropagation.length, 0) / scenarios.length,
    };
  }

  /**
   * 风险传播分析：风险如何在图中扩散
   */
  private analyzeRiskPropagation(result: ScenePredictionResult): RiskNode[] { ... }

  /**
   * 关键路径分析：完成任务的最短路径
   */
  private findCriticalPath(scenarios: SimulationResult['scenarios']): string[] { ... }
}
```

---

### Phase 2: 纠缠层 (Day 3-4)

**目标:** 实现双宇宙的信息交换——叠加、纠缠、坍缩。

#### 3.4 纠缠层核心

```typescript
// src/brain/right/universe/entangle-layer.ts

export interface EntangleConfig {
  /** 宇宙A筛选传给B的候选数（快筛） */
  topKForSimulation: number;
  /** 风险阈值：超过此值打回重推理 */
  riskRejectThreshold: number;
  /** 共振权重：推理宇宙权重 */
  reasoningWeight: number;
  /** 共振权重：模拟宇宙权重 */
  simulationWeight: number;
  /** 最大纠缠轮数（防止无限循环） */
  maxEntangleRounds: number;
  /** 需要用户确认的风险阈值 */
  userConfirmRiskThreshold: number;
}

const DEFAULT_CONFIG: EntangleConfig = {
  topKForSimulation: 3,
  riskRejectThreshold: 0.7,
  reasoningWeight: 0.4,
  simulationWeight: 0.6,
  maxEntangleRounds: 3,
  userConfirmRiskThreshold: 0.8,
};

export class EntangleLayer {
  private config: EntangleConfig;

  /**
   * 纠缠主流程：A 和 B 交互直到坍缩
   *
   * 量子力学类比:
   * - 叠加态: 多个候选同时存在
   * - 纠缠: A 和 B 的结果相互影响
   * - 坍缩: 最终确定一个决策
   */
  entangle(
    reasoningUniverse: ReasoningUniverse,
    simulationUniverse: SimulationUniverse,
    currentState: UniverseState,
    candidates: CandidateAction[],
  ): EntangledDecision {
    let currentCandidates = [...candidates];
    let round = 0;

    while (round < this.config.maxEntangleRounds) {
      // ── 叠加态: 宇宙A 快速推理 ──
      const reasoningPath = reasoningUniverse.reason(currentState, currentCandidates);

      // ── 纠缠: 取 Top K 传给宇宙B ──
      const topK = reasoningPath.steps.slice(0, this.config.topKForSimulation);
      const toSimulate = topK.map(s => s.action);

      // ── 宇宙B 精确模拟 ──
      const scene = currentState.scene ?? this.buildSceneFromState(currentState);
      const simulationResult = simulationUniverse.simulate(scene, toSimulate);

      // ── 风险反馈: 高风险方案打回 ──
      const rejected = simulationResult.scenarios.filter(
        s => s.riskPropagation.some(r => r.risk > this.config.riskRejectThreshold)
      );

      if (rejected.length === 0 || round === this.config.maxEntangleRounds - 1) {
        // ── 坍缩: 共振决策 ──
        return this.collapse(reasoningPath, simulationResult, candidates);
      }

      // 移除高风险方案，补充新候选
      currentCandidates = currentCandidates.filter(
        c => !rejected.some(r => r.action.id === c.id)
      );

      round++;
    }

    // 兜底：返回推理宇宙的最优
    return this.fallbackCollapse(reasoningUniverse.reason(currentState, candidates));
  }

  /**
   * 坍缩: 两个宇宙的结果融合为最终决策
   *
   * 共振公式:
   *   score = α × reasoningConfidence + β × (1 - riskScore) × completionProb
   *
   * 其中 α = reasoningWeight, β = simulationWeight
   */
  private collapse(
    reasoning: ReasoningPath,
    simulation: SimulationResult,
    allCandidates: CandidateAction[],
  ): EntangledDecision {
    // 对每个候选计算共振分
    const scored = allCandidates.map(c => {
      const r = reasoning.steps.find(s => s.action.id === c.id);
      const s = simulation.scenarios.find(sc => sc.action.id === c.id);

      const reasoningConf = r?.confidence ?? 0;
      const simConf = s ? (1 - this.avgRisk(s.riskPropagation)) * s.completionProb : 0;

      const resonated = this.config.reasoningWeight * reasoningConf
                      + this.config.simulationWeight * simConf;

      return {
        action: c,
        resonatedConfidence: resonated,
        riskScore: s ? this.avgRisk(s.riskPropagation) : 0.5,
        reasoningConfidence: reasoningConf,
        simulationConfidence: simConf,
      };
    });

    scored.sort((a, b) => b.resonatedConfidence - a.resonatedConfidence);

    const best = scored[0];
    const needsConfirm = best.riskScore > this.config.userConfirmRiskThreshold
                      || (scored.length > 1 && scored[1].resonatedConfidence > best.resonatedConfidence * 0.9);

    return {
      selectedAction: best.action,
      resonatedConfidence: best.resonatedConfidence,
      reasoningSummary: this.summarizeReasoning(reasoning, best.action),
      simulationSummary: this.summarizeSimulation(simulation, best.action),
      riskAssessment: best.riskScore,
      needsUserConfirmation: needsConfirm,
      alternatives: scored.slice(1, 3).map(s => ({
        action: s.action,
        confidence: s.resonatedConfidence,
        riskScore: s.riskScore,
      })),
    };
  }

  private avgRisk(risks: RiskNode[]): number {
    if (risks.length === 0) return 0;
    return risks.reduce((s, r) => s + r.risk, 0) / risks.length;
  }
}
```

---

### Phase 3: 并行编排器 (Day 5-6)

**目标:** 编排双宇宙并行运行，接入 RightBrain。

#### 3.5 编排器

```typescript
// src/brain/right/universe/orchestrator.ts

export class ParallelUniverseOrchestrator {
  private reasoningUniverse: ReasoningUniverse;
  private simulationUniverse: SimulationUniverse;
  private entangleLayer: EntangleLayer;
  private config: OrchestratorConfig;

  /**
   * 主入口: 三脑调用此方法做决策
   *
   * 流程:
   * 1. 构建当前状态
   * 2. 生成候选动作
   * 3. 双宇宙并行运行
   * 4. 纠缠层坍缩
   * 5. 返回决策
   */
  async decide(
    input: string,
    context: DecisionContext,
  ): Promise<EntangledDecision> {
    const t0 = performance.now();

    // 1. 构建当前状态（融合推理 latent + 场景图）
    const state = this.buildUniverseState(input, context);

    // 2. 生成候选动作（来自经验/调度器/直觉）
    const candidates = this.generateCandidates(input, context);

    // 3. 并行运行双宇宙 + 纠缠
    const decision = this.entangleLayer.entangle(
      this.reasoningUniverse,
      this.simulationUniverse,
      state,
      candidates,
    );

    decision.latencyMs = performance.now() - t0;
    return decision;
  }

  /**
   * 快速路径: 简单任务跳过模拟，只用推理宇宙
   */
  decideFast(
    input: string,
    context: DecisionContext,
  ): EntangledDecision {
    const state = this.buildUniverseState(input, context);
    const candidates = this.generateCandidates(input, context);

    const reasoning = this.reasoningUniverse.reason(state, candidates);
    const best = reasoning.steps[0];

    return {
      selectedAction: best.action,
      resonatedConfidence: best.confidence,
      reasoningSummary: `快速推理: ${best.action.label} (conf=${best.confidence.toFixed(2)})`,
      simulationSummary: '快速路径，跳过模拟',
      riskAssessment: 1 - best.confidence,
      needsUserConfirmation: false,
      alternatives: [],
    };
  }
}
```

---

### Phase 4: 反事实 + 类比 (Day 7-8)

**目标:** 推理宇宙的独有能力。

#### 3.6 反事实推理

```typescript
// src/brain/right/universe/counterfactual.ts

export class CounterfactualReasoner {
  private worldModel: WorldModel;

  /**
   * "如果当时不这样做呢？"
   *
   * 给定一个已执行的动作和结果状态，
   * 模拟替代动作会产生什么不同结果。
   */
  reason(
    stateBefore: UniverseState,
    actualAction: CandidateAction,
    alternatives: CandidateAction[],
  ): CounterfactualResult {
    const latent = this.encodeState(stateBefore);
    const actualResult = this.worldModel.predict(latent, this.encodeAction(actualAction));

    const alternativeResults = alternatives.map(alt => {
      const altResult = this.worldModel.predict(latent, this.encodeAction(alt));
      return {
        action: alt,
        predictedState: altResult.nextLatent,
        confidence: altResult.confidence,
        // 与实际结果的差异
        divergence: this.computeDivergence(actualResult.nextLatent, altResult.nextLatent),
      };
    });

    return {
      actualAction,
      alternativeResults,
      bestAlternative: alternativeResults.sort((a, b) => b.confidence - a.confidence)[0],
    };
  }
}
```

#### 3.7 类比迁移

```typescript
// src/brain/right/universe/analogy.ts

export class AnalogyEngine {
  private worldModel: WorldModel;

  /**
   * 从相似场景迁移经验
   *
   * 1. 在 latent 空间中找最近邻的历史状态
   * 2. 看当时选了什么动作、结果如何
   * 3. 类比到当前场景
   */
  findAnalogies(
    currentState: UniverseState,
    history: Array<{ state: UniverseState; action: CandidateAction; outcome: number }>,
    topK: number = 3,
  ): AnalogyResult[] {
    const currentLatent = this.encodeState(currentState);

    // 在 latent 空间中找最近邻
    const distances = history.map(h => ({
      ...h,
      distance: this.latentDistance(currentLatent, this.encodeState(h.state)),
    }));
    distances.sort((a, b) => a.distance - b.distance);

    return distances.slice(0, topK).map(d => ({
      sourceState: d.state,
      sourceAction: d.action,
      sourceOutcome: d.outcome,
      similarity: 1 - d.distance,
      recommendation: d.outcome > 0.7 ? '推荐' : '避免',
    }));
  }
}
```

---

### Phase 5: 集成接入 (Day 9-10)

**目标:** 接入 RightBrain 和 ThreeBrain 决策流。

#### 3.8 RightBrain 改造

```typescript
// src/brain/right/index.ts 修改

export class RightBrain {
  // 新增
  readonly parallelOrchestrator: ParallelUniverseOrchestrator;

  constructor(...) {
    // 现有初始化...

    // 新增: 双世界模型编排器
    this.parallelOrchestrator = new ParallelUniverseOrchestrator({
      reasoningUniverse: new ReasoningUniverse(this.worldModel, this.model.reasoningHead, this.byteEncoder),
      simulationUniverse: new SimulationUniverse(this.sceneWorldModel, this.entityRegistry),
      entangleLayer: new EntangleLayer(),
    });
  }

  /**
   * 替代 bestPlan() 的新入口
   */
  bestPlanEntangled(
    candidates: Array<{ label: string; reason: string; score: number }>,
    currentTokens: number[],
    complexity: 'simple' | 'medium' | 'complex' = 'medium',
  ): EntangledDecision | null {
    // 简单任务走快速路径
    if (complexity === 'simple') {
      return this.parallelOrchestrator.decideFast(candidates, currentTokens);
    }

    // 复杂任务走完整纠缠
    return this.parallelOrchestrator.decide(candidates, currentTokens);
  }
}
```

#### 3.9 ThreeBrain 接入

```typescript
// src/brain/brain.ts 修改

// 在 decide() 方法中，替换原有 bestPlan 调用:

// 旧:
const best = this.right.bestPlan(scoredPlans.map(...), currentTokens);

// 新:
const entangled = this.right.bestPlanEntangled(
  scoredPlans.map(sp => ({ label: sp.plan.mode, reason: sp.plan.reason, score: sp.score })),
  currentTokens,
  signal.complexity,
);

if (entangled && entangled.resonatedConfidence > 0.6) {
  // 纠缠决策命中
  plan = scoredPlans.find(sp => sp.plan.mode === entangled.selectedAction.label)?.plan ?? plan;
  mentalSimulation = {
    candidates: scoredPlans.map(sp => ({ label: sp.plan.mode, confidence: sp.score, topologyChange: 0 })),
    selected: entangled.selectedAction.label,
    resonatedConfidence: entangled.resonatedConfidence,
    riskAssessment: entangled.riskAssessment,
  };
}
```

---

### Phase 6: 测试验证 (Day 11-12)

#### 3.10 测试矩阵

| 测试 | 文件 | 验证点 |
|------|------|--------|
| 推理宇宙单元测试 | `universe/reasoning-universe.test.ts` | 20候选<1ms, 输出有效 |
| 模拟宇宙单元测试 | `universe/simulation-universe.test.ts` | 实体变更正确, 风险传播 |
| 纠缠层单元测试 | `universe/entangle-layer.test.ts` | 坍缩正确, 风险打回 |
| 反事实推理测试 | `universe/counterfactual.test.ts` | 替代方案分析 |
| 类比迁移测试 | `universe/analogy.test.ts` | 最近邻检索 |
| A/B 对比测试 | `universe/ab-entangled-vs-single.test.ts` | 纠缠 vs 单宇宙 |
| 集成测试 | `universe/integration.test.ts` | 端到端决策流 |
| 性能基准 | `universe/benchmark.test.ts` | 总延迟 < 5ms |

---

## 4. 文件结构

```
src/brain/right/universe/
├── types.ts                    # 接口定义
├── reasoning-universe.ts       # 宇宙A: 推理
├── simulation-universe.ts      # 宇宙B: 模拟
├── entangle-layer.ts           # 纠缠层
├── orchestrator.ts             # 并行编排器
├── counterfactual.ts           # 反事实推理
├── analogy.ts                  # 类比迁移
├── risk-propagation.ts         # 风险传播分析
├── __tests__/
│   ├── reasoning-universe.test.ts
│   ├── simulation-universe.test.ts
│   ├── entangle-layer.test.ts
│   ├── counterfactual.test.ts
│   ├── analogy.test.ts
│   ├── ab-entangled-vs-single.test.ts
│   ├── integration.test.ts
│   └── benchmark.test.ts
└── index.ts                    # 统一导出
```

---

## 5. 性能预算

| 阶段 | 目标延迟 | 实测参考 |
|------|---------|---------|
| 宇宙A 快速推理 20 候选 | < 1ms | WorldModel: 0.026ms/步 |
| 纠缠层筛选 Top K | < 0.01ms | 纯排序 |
| 宇宙B 精确模拟 K 候选 | < 3ms | SceneWorldModel: 0.293ms/步 |
| 风险反馈 + 重推理 | < 1ms | 通常不需要重推理 |
| 共振决策 | < 0.01ms | 纯计算 |
| **总计** | **< 5ms** | 比单独用 B 模拟 20 候选更快 |

---

## 6. 量子力学对应关系

| 量子概念 | 工程实现 |
|---------|---------|
| **叠加态** | 多个 CandidateAction 同时存在 |
| **波函数** | UniverseState (latent + scene graph) |
| **观测** | EntangleLayer.collapse() |
| **坍缩** | 共振决策 → 唯一 EntangledDecision |
| **纠缠** | A 的输出改变 B 的输入，B 的输出改变 A 的下一步 |
| **干涉** | 高风险方案被排除（相消干涉），好方案被增强（相长干涉） |
| **退相干** | 经验积累 → 候选减少 → 快速直连 |
| **量子隧穿** | 低置信度但有输出 → 组装引擎兜底 |

---

## 7. 代码现状分析与实施前置条件

> 基于完整代码库审查（2026-05-16），覆盖 src/brain/right/ 全部模块。

### 7.1 WorldModel (MLP) — 不需要重写，需要替换编码器

**架构评估**: 2层残差MLP + Xavier初始化 + ReLU激活，64维latent / 128维hidden。理论沿袭 World Models (2018) / DreamerV3 路线，架构本身对潜空间状态转移预测足够。

**已实现且可用的能力**:

| 能力 | 代码位置 | 状态 |
|------|---------|------|
| 前向预测 | `world-model.ts` predict() | ✅ latentDelta + spatialDelta + topologyChange |
| 完整反向传播 | `world-model.ts` trainStep() | ✅ 手写梯度，MSE+BCE loss，SGD 更新 |
| 多步想象 | `world-model.ts` imagine() | ✅ 串行残差传播 |
| 批量训练 | `world-model.ts` trainBatch() | ✅ 随机采样 + 平均 loss |
| 接入 RightBrain | `right/index.ts` imagine/bestAction/bestPlan | ✅ 已集成 |

**需要在封装层解决的问题**:

| 问题 | 影响 | 解决位置 |
|------|------|---------|
| `encodeState()` 用 token hash 均值池化，信息损失严重 | 输入端噪声，下游预测失准 | ReasoningUniverse 封装时用 ByteEncoder 投影替代 |
| 置信度公式 `1/(1+√‖delta‖)` 过于简化 | 无法区分"确定不变"和"不知道往哪走" | EntangleLayer 用扰动一致性重新计算 |
| 训练循环未接入 OnlineLearner | 模型不从运行时经验中学习 | 需要新增 WorldModelTrainer（见 7.4） |

**结论**: WorldModel 本身不需要改动。编码器替换和置信度计算在封装层处理，不侵入现有代码。

### 7.2 SceneWorldModel (GNN) — 架构合理，反向传播需要修复

**架构评估**: 2层GNN消息传递（MessageFunction + GRU-style UpdateFunction + Post-LayerNorm），32维节点特征 / 16维边特征。预测实体变化、边变化、完成概率、风险分数。设计合理。

**已实现且可用的能力**:

| 能力 | 代码位置 | 状态 |
|------|---------|------|
| 单步预测 | `scene-world-model.ts` predict() | ✅ 完整的 GNN 前向 + 输出解码 |
| 多步想象 | `scene-world-model.ts` imagine() | ✅ 串行场景图传播 |
| 多方案对比 | `scene-world-model.ts` bestAction() | ✅ 评分: completion×0.4 + (1-risk)×0.3 + conf×0.3 |
| 旧接口兼容 | `predictLegacy/imagineLegacy` | ✅ 与 WorldModel 接口互通 |
| 实体注册中心 | `entity-registry.ts` | ✅ 完整的实体/边管理、snapshot/diff、TTL淘汰 |
| 4个数据源适配器 | `entity-adapters.ts` | ✅ ProjectIndex、STMP、Experience、Knowledge |
| 运行时数据采集 | `runtime-collector.ts` | ✅ wrapExecution() 自动构建训练样本 |
| 知识转训练样本 | `knowledge-bridge.ts` | ✅ 去重 + 置信度过滤 |
| 合成数据生成 | `scene-training.ts` | ✅ 冷启动用，规则模拟动作效果 |
| 接入 RightBrain | `right/index.ts` imagine/bestAction/bestPlan | ✅ 已集成 |
| 接入组装引擎 | `assembly-world-bridge.ts` | ✅ 片段排序 ← SceneWorldModel.bestAction() |

**需要修复的致命问题**:

| 问题 | 严重度 | 说明 |
|------|--------|------|
| GNN 反向传播是空操作 | **P0** | `trainStep()` 检查 `param.grad` 但 GNNLayer 的 MessageFunction/UpdateFunction 参数的 grad 永远是 null —— 没有梯度链经过 GNN 层。权重不会更新。 |
| 风险传播不走图结构 | P2 | `decodeRiskScore()` 是全局平均池化 → MLP，不是沿边传播的图级风险 |
| 边变化预测过于简化 | P2 | 只做了相似度>0.8的"新增"，无删除/权重更新 |
| `latentToScene` / `sceneToLatent` 互转有损 | P1 | 兼容旧接口的 hack，双世界模型架构下可规避（从 EntityRegistry 直接取场景图） |

**GNN 反向传播修复方案**:

方案A（推荐）: 给 GNNLayer 的前向计算补梯度链。MessageFunction.forward() 和 UpdateFunction.forward() 当前用纯 Float32Array，需要改为使用 autograd Tensor（与 IntuitionNet 的 EncoderBlock 一致），让 `backwardPass()` 的 autograd 能自动回传经过 GNN 层。

方案B（备选）: 手写 GNN 反向传播（类似 `backward.ts` 对 OutputHeads 做的事），精度更高但维护成本大。

**结论**: 架构不需要改，GNN 反向传播需要修复（方案A），其余问题在封装层或后续 Phase 解决。

### 7.3 已就绪的基础设施（双世界模型可直接复用）

| 组件 | 文件 | 作用 | 状态 |
|------|------|------|------|
| EntityRegistry | `entity-registry.ts` | 实体/边管理 + snapshot/diff + 重要性计算 | ✅ 完整 |
| EntityAdapters | `entity-adapters.ts` | 4个数据源自动填充 EntityRegistry | ✅ 完整 |
| RuntimeCollector | `runtime-collector.ts` | wrapExecution() 采集训练数据 | ✅ 完整 |
| KnowledgeBridge | `knowledge-bridge.ts` | 知识→WorldModelTrainingSample | ✅ 完整 |
| SceneTraining | `scene-training.ts` | 合成数据 + 运行时数据 + 知识信号 | ✅ 完整 |
| AssemblyWorldBridge | `assembly-world-bridge.ts` | 组装引擎 ← SceneWorldModel 片段排序 | ✅ 完整 |
| ReasoningHead | `nn/reasoning-head.ts` | 多步推理 + skip gate + early exit + forwardParallel() | ✅ 完整 |
| ByteEncoder | `features/text-encoder.ts` | 字节级文本编码 → 128维语义向量 | ✅ 完整 |
| OnlineLearner | `training/online-learner.ts` | ReplayBuffer + 课程学习 + LPR + 安全阀 | ✅ 完整（但只训练 IntuitionNet） |
| MetaLearner | `training/meta-learner.ts` | 策略选择 → 动态 LR/LPR | ✅ 完整 |
| SGD 优化器 | `training/optimizer.ts` | 动量 + 梯度裁剪 + 学习率调度 | ✅ 完整 |

### 7.4 训练管线缺口 — 数据采集已通但没有消费者

**现状**: RuntimeCollector 在采集 WorldModelTrainingSample，KnowledgeBridge 在转换，SceneTraining 在生成合成数据。但这些样本 **没有喂给世界模型训练**。

```
工具执行 → RuntimeCollector.wrapExecution() → buffer ──→ flush → ???
知识条目 → KnowledgeBridge.convert() → WorldModelTrainingSample ─→ 无消费者
合成数据 → generateSyntheticSamples() ──────────────────────────→ 无消费者
```

**需要新增**: WorldModelTrainer — 世界模型训练调度器

```typescript
class WorldModelTrainer {
  // 定期调用（心跳/梦境时）
  async trainRound(): Promise<void> {
    // 1. 从 RuntimeCollector 取运行时样本
    // 2. 从 KnowledgeBridge 转换知识样本
    // 3. 合成数据（冷启动时）
    // 4. 训练 WorldModel (MLP) — trainBatch() 已可用
    // 5. 训练 SceneWorldModel (GNN) — 需先修复反向传播
  }
}
```

---

## 8. 输出管线接入方案

### 8.1 当前决策管线（brain.ts 实际流程）

```
用户输入
  → Cerebellum.regulate()              // 本体状态更新
  → RightBrain.predictFull()           // ByteEncoder + KnowledgeGate + ReasoningHead
  → DeliberationCouncil.deliberate()   // 议题分析 + 辩论 + 风险校验
  → LeftBrain.decideAll()              // 规则引擎 + 调度器 → 多方案评分
  → [差距 ≤ 0.3?]
      → RightBrain.bestPlan()          // SceneWorldModel.bestAction()
      → 选置信度最高
  → AssemblyEngine.process()           // 组装引擎
  → 输出
```

### 8.2 改造后的决策管线

**唯一接入点**: `brain.ts` 第580行，`this.right.bestPlan()` 替换为 `this.right.bestPlanEntangled()`。

```
brain.ts 第580行:
  旧: this.right.bestPlan(scoredPlans, currentTokens)
  新: this.right.bestPlanEntangled(scoredPlans, currentTokens, signal.complexity)

RightBrain 新增 bestPlanEntangled():
  → ParallelUniverseOrchestrator.decide()
      ├─ complexity === 'simple' → decideFast() (只用宇宙A, <1ms)
      └─ complexity !== 'simple' → entangle()
          ├─ ReasoningUniverse.reason(全部候选)
          │    ├─ WorldModel.predict() × N       // 快速推理 <1ms
          │    └─ ReasoningHead.forward()         // 步骤间推理
          ├─ TopK 筛选 (K=3)
          ├─ SimulationUniverse.simulate(TopK)
          │    └─ SceneWorldModel.predict() × K  // 精确模拟 <3ms
          ├─ EntangleLayer.collapse()
          │    └─ 共振公式: α×reasoningConf + β×(1-risk)×completion
          └─ 返回 EntangledDecision
```

### 8.3 输出格式扩展

```typescript
// 当前 DecisionResult.mentalSimulation
interface MentalSimulation {
  candidates: Array<{ label: string; confidence: number; topologyChange: number }>;
  selected: string;
}

// 改造后（向后兼容，新增字段均为可选）
interface MentalSimulation {
  candidates: Array<{ label: string; confidence: number; topologyChange: number }>;
  selected: string;
  // ── 双世界模型新增 ──
  resonatedConfidence?: number;    // 共振置信度（A×B 加权）
  riskAssessment?: number;         // 风险评估 0-1
  needsUserConfirmation?: boolean; // 高风险或方案接近时标记
  alternatives?: Array<{           // 备选方案
    label: string;
    confidence: number;
    riskScore: number;
  }>;
  reasoningSummary?: string;       // 推理路径摘要
  simulationSummary?: string;      // 模拟结果摘要
}
```

### 8.4 对其他模块的影响

| 模块 | 是否需要改动 | 说明 |
|------|-------------|------|
| **brain.ts** | ✅ 需要 | 替换 bestPlan() → bestPlanEntangled()，扩展 mentalSimulation 类型 |
| **RightBrain** | ✅ 需要 | 新增 bestPlanEntangled() 方法 + 持有 ParallelUniverseOrchestrator |
| **AssemblyEngine** | ❌ 不需要 | 组装引擎在世界模型之后执行，不受影响 |
| **AssemblyWorldBridge** | ❌ 不需要 | SimulationUniverse 内部就是 SceneWorldModel，接口兼容 |
| **LeftBrain** | ❌ 不需要 | decideAll() 输出 scoredPlans 不变 |
| **Cerebellum** | ❌ 不需要 | 本体状态不受决策方式影响 |
| **DeliberationCouncil** | ❌ 不需要 | 审议在世界模型之前完成 |
| **OnlineLearner** | ❌ 不需要 | 只训练 IntuitionNet，世界模型有独立训练循环 |

### 8.5 延迟预算

| 阶段 | 目标延迟 | 说明 |
|------|---------|------|
| ReasoningUniverse.reason() 20候选 | < 1ms | WorldModel: 0.026ms/步 |
| TopK 筛选 | < 0.01ms | 纯排序 |
| SimulationUniverse.simulate() 3候选 | < 3ms | SceneWorldModel: 0.293ms/步 |
| EntangleLayer.collapse() | < 0.01ms | 共振公式计算 |
| **总计** | **< 5ms** | 需加 performance.now() 断言，超时降级 |

### 8.6 降级策略

```
bestPlanEntangled() 返回 null 时（原型<5、场景图为空、异常等）
  → 降级到原有 bestPlan()（SceneWorldModel.bestAction()）
  → bestPlan() 也失败时
  → 使用 scoredPlans[0]（调度器最高分）
```

---

## 9. 里程碑（更新）

| 里程碑 | 交付物 | 验收标准 | 前置条件 |
|--------|--------|---------|---------|
| M0: 前置修复 | GNN 反向传播修复 + WorldModelTrainer | GNN trainStep() 能实际更新权重；训练调度器从 RuntimeCollector 取数据训练 | 无 |
| M1: 宇宙封装 | ReasoningUniverse + SimulationUniverse | 各自独立运行，单元测试通过，用 ByteEncoder 替代 hash 编码 | 无 |
| M2: 纠缠层 | EntangleLayer | 双宇宙交互，坍缩输出正确，brain.ts 接入 bestPlanEntangled() | M1 |
| M3: 编排器 | Orchestrator | 端到端决策流，延迟 < 5ms，降级策略可用 | M2 |
| M4: 高级能力 | 反事实 + 类比 | 推理宇宙独有能力可用 | M3 |
| M5: 集成验证 | A/B 测试 + 性能基准 | 纠缠 vs 单宇宙 A/B 对比，全链路 < 5ms | M4 |

## 10. 实施优先级

| 优先级 | 任务 | 工作量 | 说明 |
|--------|------|--------|------|
| **P0** | 修复 GNN 反向传播 | 中 | 给 GNNLayer 前向改用 autograd Tensor，让梯度能回传 |
| **P0** | 新增 WorldModelTrainer | 小 | 训练调度器，从 RuntimeCollector 取数据训练两个世界模型 |
| **P1** | Phase 1: 宇宙封装层 | 小 | 不改模型，只包装接口，用 ByteEncoder 投影替代 hash |
| **P1** | Phase 2: 纠缠层 + brain.ts 接入 | 小 | 核心价值，改动集中在 RightBrain 和 brain.ts |
| **P2** | Uncertainty estimation | 小 | 用 ReasoningHead.forwardParallel() 扰动一致性 |
| **P2** | 风险传播走图结构 | 中 | GNN 消息传递中加 risk signal |
| **P3** | Phase 3-4: 编排器 + 反事实 + 类比 | 大 | 高级能力，P0-P2 稳定后 |
